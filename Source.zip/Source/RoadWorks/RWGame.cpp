#include "RWGame.h"
#include "RWMapTools.h"
#include "RWScenery.h"
#include "RWTerrain.h"
#include "RWEffects.h"
#include "RWWorld.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWAudio.h"
#include "Engine/World.h"
#include "Engine/Canvas.h"
#include "Engine/Font.h"
#include "Engine/Engine.h"
#include "Engine/Texture2D.h"
#include "Engine/GameViewportClient.h"
#include "UnrealClient.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/GameUserSettings.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PostProcessComponent.h"
#include "RWLoc.h"
#include "RWMods.h"
#include "RWMeshGen.h"
#include "RWPlatform.h"
#include "RWGltf.h"
#include "RWEditor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/CommandLine.h"
#include "Serialization/BufferArchive.h"
#include "Serialization/MemoryReader.h"
#include "HAL/FileManager.h"
#include "Modules/ModuleManager.h"
#include "Kismet/KismetSystemLibrary.h"
#include "RWWater.h"
#include "RWSoilLook.h"
#include "ProceduralMeshComponent.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"

int32 RWCountPropsIn(int32 Type, const FVector2D& C, const FVector2D& H)
{
	int32 N = 0;
	for (const TWeakObjectPtr<ARWProp>& P : ARWProp::All)
	{
		if (!P.IsValid() || P->Type != Type || P->bCarried) continue;
		const FVector L = P->PosM();
		if (FMath::Abs(L.X - C.X) <= H.X && FMath::Abs(L.Y - C.Y) <= H.Y) ++N;
	}
	return N;
}

// ============================================================================================
// Walker (on foot)
// ============================================================================================
ARWWalker::ARWWalker()
{
	PrimaryActorTick.bCanEverTick = true;
	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;
	BodyP = CreateDefaultSubobject<USceneComponent>(TEXT("BodyP"));
	BodyP->SetupAttachment(Root);
	Arm = CreateDefaultSubobject<USpringArmComponent>(TEXT("Arm"));
	Arm->SetupAttachment(Root);
	Arm->bDoCollisionTest = false; Arm->bInheritPitch = false; Arm->bInheritRoll = false;
	Arm->bEnableCameraLag = true; Arm->CameraLagSpeed = 12.f;
	Arm->SetRelativeLocation(FVector(0, 0, 160));
	Cam = CreateDefaultSubobject<UCameraComponent>(TEXT("Cam"));
	Cam->SetupAttachment(Arm);
	EyeCam = CreateDefaultSubobject<UCameraComponent>(TEXT("Eye"));
	EyeCam->SetupAttachment(Root);
	EyeCam->SetRelativeLocation(FVector(10, 0, 168));
	EyeCam->SetAutoActivate(false);
}

void ARWWalker::BuildBody()
{
	auto P = [&](USceneComponent* Parent, UStaticMesh* Mesh, FVector L, FVector Sz, FLinearColor C, float Rough)
	{
		UStaticMeshComponent* M = NewObject<UStaticMeshComponent>(this);
		M->SetStaticMesh(Mesh);
		UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, this);
		MID->SetVectorParameterValue(TEXT("Color"), C); MID->SetScalarParameterValue(TEXT("Roughness"), Rough); MID->SetScalarParameterValue(TEXT("Metallic"), 0.f);
		M->SetMaterial(0, MID);
		M->SetupAttachment(Parent);
		M->SetRelativeLocation(L * M2CM); M->SetRelativeScale3D(Sz);
		M->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		M->RegisterComponent();
		return M;
	};
	for (int32 s = -1; s <= 1; s += 2)
	{
		USceneComponent* Hip = NewObject<USceneComponent>(this);
		Hip->SetupAttachment(BodyP); Hip->SetRelativeLocation(FVector(0, s * 0.11f, 0.9f) * M2CM); Hip->RegisterComponent();
		P(Hip, ARWMachine::GCyl, FVector(0, 0, -0.45f), FVector(0.15f, 0.15f, 0.9f), FLinearColor(0.05f, 0.07f, 0.12f), 0.8f);
		P(Hip, ARWMachine::GCube, FVector(0.05f, 0, -0.88f), FVector(0.28f, 0.12f, 0.1f), FLinearColor(0.08f, 0.05f, 0.03f), 0.6f);
		Legs.Add(Hip);
	}
	P(BodyP, ARWMachine::GCube, FVector(0, 0, 1.22f), FVector(0.26f, 0.44f, 0.62f), FLinearColor(0.9f, 0.45f, 0.02f), 0.6f); // hi-vis vest
	P(BodyP, ARWMachine::GCube, FVector(0, 0, 1.12f), FVector(0.27f, 0.45f, 0.05f), FLinearColor(0.8f, 0.8f, 0.75f), 0.3f);  // reflective band
	// arms on shoulder pivots; the right hand carries a shovel
	for (int32 s = -1; s <= 1; s += 2)
	{
		USceneComponent* Sh = NewObject<USceneComponent>(this);
		Sh->SetupAttachment(BodyP); Sh->SetRelativeLocation(FVector(0, s * 0.28f, 1.48f) * M2CM); Sh->RegisterComponent();
		P(Sh, ARWMachine::GCyl, FVector(0, 0, -0.3f), FVector(0.1f, 0.1f, 0.6f), FLinearColor(0.9f, 0.45f, 0.02f), 0.6f);
		P(Sh, ARWMachine::GSphere, FVector(0, 0, -0.62f), FVector(0.1f), FLinearColor(0.35f, 0.25f, 0.12f), 0.8f); // glove
		(s > 0 ? ArmR : ArmL) = Sh;
	}
	P(ArmR, ARWMachine::GCyl, FVector(0.25f, 0, -0.62f), FVector(0.035f, 0.035f, 1.1f), FLinearColor(0.25f, 0.16f, 0.08f), 0.7f)->SetRelativeRotation(FRotator(-70, 0, 0));
	P(ArmR, ARWMachine::GCube, FVector(0.78f, 0, -0.82f), FVector(0.3f, 0.22f, 0.02f), FLinearColor(0.3f, 0.3f, 0.3f), 0.4f)->SetRelativeRotation(FRotator(-70, 0, 0));
	ShovelLoad = P(ArmR, ARWMachine::GSphere, FVector(0.8f, 0, -0.78f), FVector(0.24f, 0.2f, 0.1f), FLinearColor(0.15f, 0.1f, 0.06f), 0.95f);
	ShovelLoad->SetVisibility(false);
	P(BodyP, ARWMachine::GSphere, FVector(0, 0, 1.68f), FVector(0.22f, 0.2f, 0.25f), FLinearColor(0.45f, 0.3f, 0.2f), 0.6f);
	P(BodyP, ARWMachine::GSphere, FVector(0, 0, 1.76f), FVector(0.27f, 0.26f, 0.18f), FLinearColor(0.85f, 0.75f, 0.02f), 0.35f); // hard hat
}

void ARWWalker::Init(ARWTerrain* T, const FVector& P, float InYaw)
{
	Terrain = T; PosM = P; Yaw = InYaw;
	BuildBody();
}

void ARWWalker::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Terrain) return;
	if (bScripted)
	{
		// animation-driven (climbing): pose the limbs, keep the controller's position
		for (int32 k = 0; k < Legs.Num(); ++k) Legs[k]->SetRelativeRotation(FRotator(bClimbing ? (k == 0 ? 55.f : 15.f) * (0.6f + 0.4f * FMath::Sin(Walk * 3.f)) : -70.f * Crouch, 0, 0));
		if (ArmL) ArmL->SetRelativeRotation(FRotator(bClimbing ? 150.f : 20.f, 0, 0));
		if (ArmR) ArmR->SetRelativeRotation(FRotator(bClimbing ? 120.f : 20.f, 0, 0));
		BodyP->SetRelativeLocation(FVector(0, 0, -Crouch * 35.f));
		Walk += Dt;
		Arm->SetRelativeRotation(FRotator(CamPitch, 0, 0));
		Arm->TargetArmLength = CamDist * M2CM;
		return;
	}
	const float Spd = bRun ? 4.5f : 1.6f;
	const FVector F(FMath::Cos(FMath::DegreesToRadians(Yaw)), FMath::Sin(FMath::DegreesToRadians(Yaw)), 0);
	const FVector R(-F.Y, F.X, 0);
	FVector Move = (F * InFwd + R * InRight);
	if (Move.SizeSquared() > 1.f) Move.Normalize();
	PosM += Move * Spd * Dt;
	PosM.X = FMath::Clamp(PosM.X, -ARWTerrain::Half + 1.f, ARWTerrain::Half - 1.f);
	PosM.Y = FMath::Clamp(PosM.Y, -ARWTerrain::Half + 1.f, ARWTerrain::Half - 1.f);
	PosM.Z = FMath::Max(Terrain->HeightAt(PosM.X, PosM.Y), Terrain->WaterZ - 1.2f);
	const float Moving = Move.Size();
	Walk += Dt * Spd * 3.2f * Moving;
	for (int32 k = 0; k < Legs.Num(); ++k) Legs[k]->SetRelativeRotation(FRotator(FMath::Sin(Walk + k * PI) * 28.f * Moving - 70.f * Crouch, 0, 0));
	// arms swing while walking; the shovel arm digs and throws
	if (ArmL) ArmL->SetRelativeRotation(FRotator(-FMath::Sin(Walk) * 24.f * Moving + 40.f * Crouch, 0, 0));
	if (ArmR) ArmR->SetRelativeRotation(FRotator(FMath::Sin(Walk) * 18.f * Moving + 15.f + ShovelSwing * 60.f + 40.f * Crouch, 0, 0));
	BodyP->SetRelativeLocation(FVector(0, 0, -Crouch * 35.f));
	SetActorLocationAndRotation(PosM * M2CM, FRotator(0, Yaw, 0));
	Arm->SetRelativeRotation(FRotator(CamPitch, 0, 0));
	Arm->TargetArmLength = CamDist * M2CM;
	EyeCam->SetRelativeRotation(FRotator(CamPitch, 0, 0));
	BodyP->SetVisibility(!bFirst, true);
}

// ============================================================================================
// Game mode
// ============================================================================================
ARWGameMode::ARWGameMode()
{
	PrimaryActorTick.bCanEverTick = true;
	PlayerControllerClass = ARWPlayerController::StaticClass();
	HUDClass = ARWHUD::StaticClass();
	DefaultPawnClass = ARWWalker::StaticClass();
}

ARWGameMode* ARWGameMode::Get(const UObject* C)
{
	UWorld* W = C ? C->GetWorld() : nullptr;
	return W ? Cast<ARWGameMode>(W->GetAuthGameMode()) : nullptr;
}

void ARWGameMode::Message(const FString& M)
{
	LastMessage = TR(M); MessageTime = 6.f;
	RWLog(M);
}

ARWMachine* ARWGameMode::SpawnMachine(UClass* C, int32 Size, float X, float Y, float Yaw, bool bOwned)
{
	FActorSpawnParameters P; P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	ARWMachine* M = GetWorld()->SpawnActor<ARWMachine>(C, FTransform(FRotator(0, Yaw, 0), FVector(X, Y, Terrain->HeightAt(X, Y)) * M2CM), P);
	if (!M) return nullptr;
	M->Id = Machines.Num();
	M->bOwned = bOwned;
	M->Setup(Terrain, Fx, Size, FVector(X, Y, Terrain->HeightAt(X, Y)), Yaw);
	Machines.Add(M);
	World->Machines.Add(M);
	if (M->Kind == EMachineKind::DumpTruck || M->Kind == EMachineKind::Paver) Fx->Receivers.Add(M);
	return M;
}

void ARWGameMode::StartPlay()
{
	Super::StartPlay();
	const double T0 = FPlatformTime::Seconds();
	// (-RWExportScenery needs the geometry of the meshes the game builds, so they are kept from the start)
	{ FString Sf; FRWMeshGen::bKeepGeometry = FParse::Value(FCommandLine::Get(), TEXT("RWExportScenery="), Sf); }
	RWLog(TEXT("=== RoadWorks starting ==="));
	ARWMachine::GCube = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
	ARWMachine::GCyl = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	ARWMachine::GSphere = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	ARWMachine::GCone = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cone.Cone"));
	auto LoadMat = [](const TCHAR* Path) -> UMaterialInterface*
	{
		UMaterialInterface* M = LoadObject<UMaterialInterface>(nullptr, Path);
		if (!M) { RWLog(FString::Printf(TEXT("ERROR missing material %s - using fallback"), Path)); M = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")); }
		return M;
	};
	UMaterialInterface* Paint = LoadMat(TEXT("/Game/Materials/M_Paint.M_Paint"));
	UMaterialInterface* TerrainMat = LoadMat(TEXT("/Game/Materials/M_Terrain.M_Terrain"));
	UMaterialInterface* WaterMat = LoadMat(TEXT("/Game/Materials/M_Water.M_Water"));
	UMaterialInterface* DustMat = LoadMat(TEXT("/Game/Materials/M_Dust.M_Dust"));
	UMaterialInterface* RainMat = LoadMat(TEXT("/Game/Materials/M_Rain.M_Rain"));
	ARWMachine::GPaint = Paint;
	FRWMeshGen::DefaultMat = Paint;
	RWLocInit();
	FRWPlatform::Init();
	FRWMods::LoadAll();
	if (UMaterialInterface* RT = FRWMods::ReplacementMaterial(TEXT("terrain_material"))) { TerrainMat = RT; bModTerrainMat = true; } // custom ground textures from a mod
	ClassicTerrainMat = TerrainMat;
	PBRTerrainMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_TerrainPBR.M_TerrainPBR"));
	FRWSoilLook::Init(); // textured loose soil for buckets, beds, heaps and clods
	ARWMachine::GGlass = LoadMat(TEXT("/Game/Materials/M_Glass.M_Glass"));
	FRWGltfModel::PlainMat = Paint;
	FRWGltfModel::GlassMat = ARWMachine::GGlass;
	FRWGltfModel::TexturedMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_Textured.M_Textured"));
	ARWMachine::GEmissive = LoadMat(TEXT("/Game/Materials/M_Emissive.M_Emissive"));
	UMaterialInterface* CloudMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/EngineSky/VolumetricClouds/m_SimpleVolumetricCloud_Inst.m_SimpleVolumetricCloud_Inst"));

	// the map's level, when it has them, says where the lakes, roads and forest are (Tools/make_map.py, edited in the Unreal Editor)
	URWMapTools::ReadLevelLayout(GetWorld(), Layout);
	Layout.Init();
	UWorld* W = GetWorld();
	Terrain = W->SpawnActor<ARWTerrain>();
	Terrain->Generate(&Layout, TerrainMat);
	// surface water simulation on the terrain grid (flowing water, puddles, channels, soaking in)
	Water = W->SpawnActor<ARWWater>();
	{
		UMaterialInterface* FlowMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_WaterFlow.M_WaterFlow"));
		if (UMaterialInterface* RM = FRWMods::ReplacementMaterial(TEXT("water_material"))) FlowMat = RM;
		Water->Init(Terrain, FlowMat ? FlowMat : WaterMat);
	}
	Terrain->OnTouch = [this](int32 i) { if (Water) Water->WakeAt(i); };
	if (FParse::Param(FCommandLine::Get(), TEXT("rwnowater"))) { Water->bEnabled = false; RWLog(TEXT("Water simulation switched off (-rwnowater)")); }
	if (FParse::Param(FCommandLine::Get(), TEXT("rwnohoses"))) { ARWMachine::bNoHoses = true; RWLog(TEXT("Flexible hoses switched off (-rwnohoses)")); }
	Fx = W->SpawnActor<ARWEffects>();
	Fx->Init(Terrain, ARWMachine::GSphere, ARWMachine::GCube, Paint, DustMat, RainMat);
	if (Water) Water->Fx = Fx; // splash at culvert outlets
	World = W->SpawnActor<ARWWorld>();
	World->Build(&Layout, Terrain, Fx, Paint, WaterMat, CloudMat);
	World->SpawnProps();
	// trees and rocks placed by hand in the Unreal Editor: the machines push, flick and scoop them like the game's own
	World->AdoptPlaced();
	// worked ground loses its plants (bushes, ground plants; the grass tufts follow the ground's own grass already)
	Terrain->OnDisturb = [this](int32 i) { if (World) World->DisturbAt(i); };
	// the level's edited scenery (moved, turned, removed, other model or material) over what the game built
	RWTagScenery(W);
	RWApplyLevelScenery(W, Layout);
	FRWMods::SpawnProps(World); // buildings / structures / rocks added by mods
	FRWEditor::LoadAll(World);  // objects and grass placed with the in-game map editor (and mods' map_items)
	Jobs.Init(&Layout, Terrain, World);
	Terrain->OnDeposit = [this](int32 i, ESoil M, float V) { Jobs.OnDeposit(i, M, V); };
	Terrain->OnRemove = [this](int32 i, ESoil M, float V) { Jobs.OnRemove(i, M, V); };
	Eco.Plots.Init(false, 2);
	ARWMachine::CollisionResolver = [this](ARWMachine* M, FVector& P) { return World && World->Resolve(M, P); };
	ARWMachine::TreeHitter = [this](const FVector& P, float R, const FVector& D, float HalfH) { return World ? World->HitTrees(P, R, D, HalfH) : 0; };
	ARWMachine::DesignGrade = [this](const FVector& P, float& Z) { return Jobs.DesignGrade(P, Z); };

	// The built-in machines made of plain shapes only take part in the self tests: the fleet is the machines with real
	// 3D models (Mods). Each mod machine marked "start_machine" goes to the construction site, the others to the yard.
	const bool bTestRun = FParse::Param(FCommandLine::Get(), TEXT("rwtest"));
	ARWMachine* Exc = nullptr;
	if (bTestRun)
	{
		Exc = SpawnMachine(ARWExcavator::StaticClass(), 1, 51.f, -36.5f, 0.f, true);
		SpawnMachine(ARWDumpTruck::StaticClass(), 0, 47.5f, -29.f, 0.f, true);
		SpawnMachine(ARWDozer::StaticClass(), 1, 30.f, -52.f, 20.f, true);
		struct FS { UClass* C; int32 Size; };
		const FS Yard[] = {
			{ARWExcavator::StaticClass(), 0}, {ARWExcavator::StaticClass(), 2}, {ARWDumpTruck::StaticClass(), 1}, {ARWLoader::StaticClass(), 1},
			{ARWGrader::StaticClass(), 1}, {ARWRoller::StaticClass(), 1}, {ARWPaver::StaticClass(), 1}, {ARWWaterTruck::StaticClass(), 1}, {ARWCrane::StaticClass(), 1}};
		for (int32 k = 0; k < UE_ARRAY_COUNT(Yard); ++k)
			SpawnMachine(Yard[k].C, Yard[k].Size, -200.f + k * 7.5f, -158.f, 90.f, false);
	}
	FRWMods::SpawnAll(this); // the model machines (yard row)
	{
		TSet<EMachineKind> Placed;
		for (ARWMachine* M : Machines)
		{
			if (!M || M->ModId.IsEmpty() || Placed.Contains(M->Kind)) continue;
			const FRWModMachine* D = FRWMods::Machines.FindByPredicate([&](const FRWModMachine& X) { return X.Id == M->ModId; });
			bool bStart = false;
			if (!D || !D->Def->TryGetBoolField(TEXT("start_machine"), bStart) || !bStart) continue;
			// its place at the site, by kind
			FVector2D At(51.f, -36.5f); float Yw = 0.f;
			if (M->Kind == EMachineKind::Bulldozer) { At = FVector2D(30.f, -52.f); Yw = 20.f; }
			else if (M->Kind != EMachineKind::Excavator) { At = FVector2D(47.5f, -29.f); }
			if (bTestRun)
			{
				// (in the tests the shape machine of that kind moves aside for it)
				// (each kind to its own place in the yard: an excavator and a dozer moved to the same spot stood inside each other)
				for (ARWMachine* O : Machines)
					if (O && O != M && O->ModId.IsEmpty() && O->Kind == M->Kind && FVector2D::Distance(FVector2D(O->PosM), At) < 3.f)
					{
						const float AsideX = -200.f - 14.f * (float)(uint8)M->Kind;
						O->PosM = FVector(AsideX, -145.f, Terrain->HeightAt(AsideX, -145.f)); O->Yaw = 90.f;
					}
			}
			M->PosM = FVector(At.X, At.Y, Terrain->HeightAt(At.X, At.Y)); M->Yaw = Yw; M->bOwned = true;
			Placed.Add(M->Kind);
			if (M->Kind == EMachineKind::Excavator) Exc = M;
		}
		// (the self tests measure the CX250D at the site: there it takes the site place, the main excavator goes to the yard)
		if (bTestRun)
			for (ARWMachine* M : Machines)
				if (M && M->Kind == EMachineKind::Excavator && M->Model.Contains(TEXT("CX250D")) && M != Exc)
				{
					if (Exc && !Exc->ModId.IsEmpty()) { Exc->PosM = FVector(-180.f, -150.f, Terrain->HeightAt(-180.f, -150.f)); Exc->Yaw = 90.f; }
					M->PosM = FVector(51.f, -36.5f, Terrain->HeightAt(51.f, -36.5f)); M->Yaw = 0.f; M->bOwned = true;
					Exc = M;
					break;
				}
		if (!Exc) for (ARWMachine* M : Machines) if (M && M->bOwned && !Exc) Exc = M;
		// where the level puts each machine (RW_Machine actors moved or turned in the editor; not in the self tests)
		if (!bTestRun && Layout.LevelMachines.Num())
		{
			int32 Moved = 0;
			for (ARWMachine* M : Machines)
			{
				const FTransform* X = M ? Layout.LevelMachines.Find(MachineKey(M)) : nullptr;
				if (!X) continue;
				const FVector P = X->GetLocation() * CM2M;
				if (!Terrain->InBounds(P.X, P.Y)) continue;
				M->PosM = FVector(P.X, P.Y, Terrain->HeightAt(P.X, P.Y));
				M->Yaw = X->Rotator().Yaw;
				++Moved;
			}
			RWLog(FString::Printf(TEXT("Map: %d machines placed where the level has them (of %d there)"), Moved, Layout.LevelMachines.Num()));
		}
	}

	// -RWTime=<hours> -RWLights: a time of day and the machines' lamps on (pictures of the lamps at night)
	{
		float Hours = -1.f;
		if (FParse::Value(FCommandLine::Get(), TEXT("RWTime="), Hours) && World && Hours >= 0.f && Hours < 24.f) World->TimeOfDay = Hours;
		if (FParse::Param(FCommandLine::Get(), TEXT("RWLights"))) for (ARWMachine* M : Machines) if (M) { M->bLights = true; M->bEngineOn = true; } // (lamps run off the engine)
	}
	URWMapTools::HideEditorGround(W);
	if (Layout.HasSculpt() && Terrain)
		RWLog(FString::Printf(TEXT("Map: the game's ground at the sculpted peak (%.0f, %.0f) is %.1f m; the sculpting added %.1f m there"), Layout.SculptPeak.X, Layout.SculptPeak.Y, Terrain->HeightAt(Layout.SculptPeak.X, Layout.SculptPeak.Y), Layout.SculptPeakH));
	// screenshot scene: put the 3D-model excavator (e.g. the CX250D) at the site and let it dig for real
	if (FParse::Value(FCommandLine::Get(), TEXT("RWScene="), Scene) && !Scene.IsEmpty())
	{
		int32 SceneModel = 0; // -RWSceneMachine=1: which of the model excavators the scene uses (they share a name)
		FParse::Value(FCommandLine::Get(), TEXT("RWSceneMachine="), SceneModel);
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && !SceneEx && SceneModel-- == 0) SceneEx = X;
		if (!SceneEx) for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && !SceneEx) SceneEx = X;
		if (SceneEx && Exc && SceneEx != Exc)
		{
			const FVector P = Exc->PosM; const float Y = Exc->Yaw;
			Exc->PosM = SceneEx->PosM; Exc->Yaw = SceneEx->Yaw;
			SceneEx->PosM = P; SceneEx->Yaw = Y; SceneEx->bOwned = true;
			Exc = SceneEx;
		}
		RWLog(FString::Printf(TEXT("Scene '%s' with %s"), *Scene, SceneEx ? *SceneEx->Model : TEXT("(no model excavator)")));
		if (!SceneEx && Scene.ToLower() != TEXT("culvert") && Scene.ToLower() != TEXT("river") && Scene.ToLower() != TEXT("bury")) bSceneReady = true;
	}
	// Player
	APlayerController* PC0 = W->GetFirstPlayerController();
	ARWPlayerController* PC = Cast<ARWPlayerController>(PC0);
	Walker = PC0 ? Cast<ARWWalker>(PC0->GetPawn()) : nullptr;
	if (!Walker) Walker = W->SpawnActor<ARWWalker>();
	Walker->Init(Terrain, FVector(48.f, -40.f, Terrain->HeightAt(48.f, -40.f)), 30.f);
	if (PC0 && PC0->GetPawn() != Walker) PC0->Possess(Walker);
	ApplyGraphics();
	CamM = Exc ? Exc->PosM : FVector::ZeroVector;
	Terrain->UpdateMeshes(CamM, true);
	bReady = true;
	if (FParse::Param(FCommandLine::Get(), TEXT("rwtest"))) RunSelfTests();
	if (PC && Exc)
	{
		PC->EnterMachine(Exc);
		Exc->ToggleEngine();
		Exc->Cranking = 0.01f;
		Exc->CamYaw = 38.f; Exc->CamPitch = -16.f; Exc->CamDist = 19.f;
	}
	Jobs.Accept(0); // the pond contract is already running on site
	Message(TEXT("Welcome! You are in the excavator at the construction site. Press F1 for controls, J for jobs."));
	RWLog(FString::Printf(TEXT("World ready in %.2f s"), FPlatformTime::Seconds() - T0));
	// something went wrong while starting (a mod that did not load, a missing file...): say so, and where to read it
	if (RWProblemCount() > 0)
	{
		Message(TRF(TEXT("{0} problem(s) while starting - see Saved/Logs/RoadWorks_Problems.log"), FString::FromInt(RWProblemCount())));
		RWLog(FString::Printf(TEXT("Problems so far in this run: %d, listed in %s"), RWProblemCount(), *RWProblemFile()));
	}
	// -RWExportPlants / -RWExportScenery: written a moment later (Tick), once the machines stand where they start
	{
		FString F;
		if (FParse::Value(FCommandLine::Get(), TEXT("RWExportPlants="), F) || FParse::Value(FCommandLine::Get(), TEXT("RWExportScenery="), F)) ExportWait = 30;
	}
}

FString ARWGameMode::MachineKey(const ARWMachine* M) const
{
	if (!M) return FString();
	auto Base = [](const ARWMachine* X) { return X->ModId.IsEmpty() ? X->GetClass()->GetName() : X->ModId; };
	const FString B = Base(M);
	int32 N = 0;
	for (const ARWMachine* O : Machines)
	{
		if (O == M) break;
		if (O && Base(O) == B) ++N;
	}
	return FString::Printf(TEXT("%s#%d"), *B, N);
}

void ARWGameMode::TickPipeScene(float Dt)
{
	// -RWScene=pipe: a trench with two pipes laid end to end, and a third on the chain under the bucket
	SceneT += Dt;
	ARWExcavator* E = SceneEx;
	if (!E || SceneT < 2.5f) return;
	E->bEngineOn = true; E->Rpm = FMath::Max(E->Rpm, E->MaxRpm * 0.9f);
	const float Yw = FMath::DegreesToRadians(E->Yaw + E->Swing);
	const FVector2D Fwd(FMath::Cos(Yw), FMath::Sin(Yw)), Side(-Fwd.Y, Fwd.X);
	if (ScenePhase == 0)
	{
		ScenePhase = 1;
		E->BoomA = 5.f; E->ArmA = -60.f; E->BktA = -90.f;
		E->SimStep(1.f / 60.f);
		const FVector Tip = E->TipWorld();
		const float G = Terrain->HeightAt(Tip.X, Tip.Y);
		const FVector2D Start = FVector2D(Tip.X, Tip.Y) + Side * 2.f;
		// a trench running across in front of the machine, with a level floor below the lowest ground on its line
		FPayload Spoil;
		float Lowest = G;
		for (float s = -0.5f; s <= 7.f; s += ARWTerrain::CS)
			for (float w = -1.1f; w <= 1.1f; w += ARWTerrain::CS)
			{
				const FVector2D Q = Start + Side * s + Fwd * w;
				if (Terrain->InBounds(Q.X, Q.Y)) Lowest = FMath::Min(Lowest, Terrain->HeightAt(Q.X, Q.Y));
			}
		const float Floor0 = Lowest - 0.3f;
		for (float s = -0.5f; s <= 7.f; s += ARWTerrain::CS)
			for (float w = -1.1f; w <= 1.1f; w += ARWTerrain::CS)
			{
				const FVector2D Q = Start + Side * s + Fwd * w;
				if (!Terrain->InBounds(Q.X, Q.Y)) continue;
				const int32 i = Terrain->IndexAt(Q.X, Q.Y);
				const float Floor = Floor0 + 0.25f * FMath::Square(w / 1.1f);
				if (Terrain->Height[i] > Floor) Terrain->RemoveAt(i, Terrain->Height[i] - Floor, Spoil, true);
			}
		const float PipeYaw = FMath::RadiansToDegrees(FMath::Atan2(Side.Y, Side.X));
		for (int32 k = 0; k < 2; ++k)
		{
			const FVector2D C = Start + Side * (1.f + k * (ARWProp::PipeLen + 0.3f));
			ARWProp* P = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
			P->Init(3, Terrain, FVector(C.X, C.Y, Terrain->HeightAt(C.X, C.Y)), PipeYaw);
			P->bWasCarried = true; // lands as if a machine had set it down, and joins
			P->Tick(1.f / 60.f);
			FVector EndA, EndB; P->PipeEnds(EndA, EndB);
			RWLog(FString::Printf(TEXT("Scene pipe %d: laid %d, ends %s to %s, ground under middle %.2f"), k, P->bLaid ? 1 : 0, *EndA.ToCompactString(), *EndB.ToCompactString(), Terrain->HeightAt(C.X, C.Y)));
		}
		ARWProp* Sl = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		Sl->Init(3, Terrain, FVector(Tip.X, Tip.Y, Tip.Z - 1.f), PipeYaw);
		E->SlingGrab();
		RWLog(FString::Printf(TEXT("Scene pipe: slung %s, %d pipes in the run"), E->Slung.IsValid() ? TEXT("yes") : TEXT("no"), [] { TArray<ARWProp::FPipeRun> R; ARWProp::PipeRuns(R); int32 N = 0; for (const ARWProp::FPipeRun& X : R) N = FMath::Max(N, X.Count); return N; }()));
		if (!SceneCam)
		{
			SceneCam = GetWorld()->SpawnActor<ACameraActor>();
			if (SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(70.f);
			if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
		}
	}
	E->InA1 = E->InA2 = E->InA3 = E->InA4 = 0.f;
	const FVector Tip = E->TipWorld();
	const FVector Look = Tip + FVector(Side.X, Side.Y, 0.f) * 2.5f + FVector(0.f, 0.f, -1.5f);
	const FVector CamP = Tip + FVector(Fwd.X, Fwd.Y, 0.f) * 7.f + FVector(Side.X, Side.Y, 0.f) * 5.f + FVector(0.f, 0.f, 2.5f);
	if (SceneCam) SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Look - CamP).Rotation());
	bGuide = false;
	if (SceneT > 7.f) bSceneReady = true;
}

void ARWGameMode::TickCulvertScene(float Dt)
{
	SceneT += Dt;
	if (SceneT < 1.5f || !Terrain || !Water || !World) return;
	const float X0 = 58.f, Y0 = -20.f;
	if (ScenePhase == 0)
	{
		ScenePhase = 1;
		const float G = Terrain->HeightAt(X0 + 4.f, Y0);
		FPayload Spoil;
		auto Cut = [&](float XA, float XB, float HalfW, float FloorA, float FloorB)
		{
			for (float x = XA; x <= XB; x += ARWTerrain::CS)
				for (float y = -HalfW; y <= HalfW; y += ARWTerrain::CS)
				{
					const float Fl = FMath::Lerp(FloorA, FloorB, (x - XA) / FMath::Max(XB - XA, 0.1f)) + 0.12f * FMath::Square(y / HalfW);
					const int32 i = Terrain->IndexAt(x, Y0 + y);
					if (Terrain->Height[i] > Fl) Terrain->RemoveAt(i, Terrain->Height[i] - Fl, Spoil, true);
				}
		};
		Cut(X0 - 2.5f, X0 + 2.5f, 2.5f, G - 1.0f, G - 1.0f);    // pond in front of the embankment
		Cut(X0 + 5.6f, X0 + 16.f, 1.6f, G - 1.45f, G - 1.9f);   // ditch below the outlet, falling away
		FRWEditor::Place(World, TEXT("Culvert pipe 0.6 m x 8 m"), FVector(X0 + 4.f, Y0, 0.f), 0.f, 1.f, false);
		UpdateWaterSources();
		CulvertSceneP = FVector(X0 + 8.f, Y0, G);
		RWLog(FString::Printf(TEXT("Scene culvert: ground %.2f m, %d culvert(s)"), G, Water->Culverts.Num()));
		if (!SceneCam)
		{
			SceneCam = GetWorld()->SpawnActor<ACameraActor>();
			if (SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(70.f);
			if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
		}
	}
	// keep the pond topped up (about 0.3 m3/s, a stream running into it)
	Water->AddWater(X0 - 1.5f, Y0, 0.3f * Dt, 0.15f);
	const FVector Look = CulvertSceneP + FVector(-0.3f, 0.f, -1.3f);
	const FVector CamP = CulvertSceneP + FVector(5.5f, 4.2f, 1.2f);
	if (SceneCam) SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Look - CamP).Rotation());
	CamM = CulvertSceneP;
	bGuide = false;
	if (SceneT > 16.f && !bSceneReady)
	{
		bSceneReady = true;
		const ARWWater::FCulvert* C = Water->Culverts.Num() ? &Water->Culverts[0] : nullptr;
		RWLog(FString::Printf(TEXT("Scene culvert ready: Q %.0f L/s, %.1f m/s, flow depth %.2f m, %.1f m3 through the pipe"), C ? C->Q * 1000.f : 0.f, C ? C->Vel : 0.f, C ? C->FlowDepth : 0.f, Water->PipeMoved));
	}
}

void ARWGameMode::TickScene(float Dt)
{
	ARWExcavator* E = SceneEx;
	SceneT += Dt;
	if (SceneT < 2.5f) return; // let the world settle and the engine start
	E->bEngineOn = true; E->Rpm = FMath::Max(E->Rpm, E->MaxRpm * 0.95f); E->ThrottleDial = 1.f;
	if (SceneBook0 == 0.0) SceneBook0 = Terrain->LooseBook();
	// camera beside the bucket, looking at it
	if (!SceneCam)
	{
		SceneCam = GetWorld()->SpawnActor<ACameraActor>();
		if (SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(60.f);
		if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
	}
	const FVector Tip = E->TipWorld();
	const float Yw = FMath::DegreesToRadians(E->Yaw + E->Swing);
	const FVector Fwd(FMath::Cos(Yw), FMath::Sin(Yw), 0.f), Right(-Fwd.Y, Fwd.X, 0.f);
	const FVector Look = Tip + (E->BucketP ? (E->BucketP->GetComponentLocation() * CM2M - Tip) * 0.5f : FVector::ZeroVector);
	// above and to the side of the bucket, looking down into it (clear of the boom and stick); "cab" = the operator's view
	const bool bCabShot = Scene.ToLower().EndsWith(TEXT("cab"));
	FVector CamP = bCabShot && E->CabCam ? E->CabCam->GetComponentLocation() * CM2M : Look + Right * 2.6f - Fwd * 0.6f + FVector(0, 0, 3.6f);
	if (Scene.ToLower() == TEXT("low")) CamP = Look + E->MouthDir() * 2.4f + Right * 1.5f; // straight on to the opening, a little from the side: the rim against the load
	if (Scene.ToLower() == TEXT("lowside")) CamP = Look + Right * 2.6f + E->MouthDir() * 0.15f; // side-on, level with the rim
	if (Scene.ToLower() == TEXT("side")) // the whole undercarriage from the side, in the open
	{
		const FVector Mid = E->PosM + FVector(0, 0, 0.9f);
		FVector MFwd(FMath::Cos(FMath::DegreesToRadians(E->Yaw)), FMath::Sin(FMath::DegreesToRadians(E->Yaw)), 0.f);
		CamP = Mid + FVector(-MFwd.Y, MFwd.X, 0.f) * 6.5f + MFwd * 1.5f + FVector(0, 0, 0.3f);
		SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Mid - CamP).Rotation());
		bGuide = false;
		E->InThrottle = SceneT > 4.f && SceneT < 6.f ? 0.8f : 0.f;
		if (SceneT > 7.f) bSceneReady = true;
		return;
	}
	if (Scene.ToLower() == TEXT("marks")) // the ground a crawler has driven over, from behind and above: straight, then turning
	{
		E->InThrottle = SceneT < 12.f ? 0.9f : 0.f;
		E->InSteer = SceneT > 7.f && SceneT < 12.f ? 0.5f : 0.f;
		if (SceneT > 4.f && !SceneMarkSet) { SceneMarkP = E->PosM; SceneMarkSet = true; }
		const FVector Mk = SceneMarkSet ? SceneMarkP : E->PosM;
		CamP = E->PosM + FVector(0, 0, 8.f) - (E->PosM - Mk).GetSafeNormal2D() * -2.f;
		SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Mk - CamP).Rotation());
		bGuide = false;
		if (SceneT > 13.f) bSceneReady = true;
		return;
	}
	if (bCabShot && SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(100.f);
	bGuide = false; // no grade-guide colours in these pictures
	if (SceneCam) SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Look - CamP).Rotation());
	if (bSceneReady) { E->InA1 = E->InA2 = E->InA3 = E->InA4 = 0.f; return; }
	const FString S = Scene.ToLower();
	bool bDone = false;
	if (S == TEXT("empty")) bDone = SceneT > 4.f;
	else
	{
		const float Target = S == TEXT("half") ? 0.5f : 1.15f; // full / dump / cab: a heaped bucket
		const int32 Before = ScenePhase;
		if (S.StartsWith(TEXT("curl")) && ScenePhase >= 9)
		{
			// after the scoop: curl the bucket and pull the stick all the way in (the case that used to poke through)
			ScenePT += Dt;
			E->InA1 = 0.f; E->InA4 = 0.f;
			E->InA3 = E->BktA > E->BktLo + 0.5f ? -1.f : 0.f;
			E->InA2 = 0.f; // bucket curled fully in (with the stick fully in too this bucket turns over and pours out)
			bDone = E->InA3 == 0.f || ScenePT > 6.f;
		}
		else if (S == TEXT("tilt") && ScenePhase >= 9)
		{
			// after the scoop: tip the opening part way over, the pose where the soil stands above the lip
			ScenePT += Dt;
			E->InA1 = E->InA2 = E->InA4 = 0.f;
			E->InA3 = E->MouthDir().Z > 0.55f ? -0.5f * E->MouthUpInput() : 0.f;
			bDone = (E->InA3 == 0.f && ScenePT > 0.2f) || ScenePT > 5.f;
		}
		else
		bDone = E->AutoDig(Dt, Target, S == TEXT("dump"), 0.6f, ScenePhase, ScenePT);
		if ((S.StartsWith(TEXT("curl")) || S == TEXT("tilt")) && ScenePhase >= 9 && bDone && ScenePT < 0.05f) { bDone = false; } // AutoDig just finished: start curling / tipping
		if (S == TEXT("dump") && ScenePhase == 6)
		{
			if (SceneDumpLoad <= 0.f) SceneDumpLoad = E->Bucket.Load.Total();
			if (E->Bucket.Load.Total() <= 0.6f * SceneDumpLoad && E->Bucket.Load.Total() > 0.05f) bDone = true; // shoot while it pours
		}
		if (ScenePhase != Before)
			RWLog(FString::Printf(TEXT("Scene %s: phase %d -> %d, bucket %.2f m3 (%.0f%%), terrain loose book change %.2f m3, soil mesh %s"), *Scene, Before, ScenePhase,
				E->Bucket.Load.Total(), E->Bucket.Load.Total() / E->Bucket.Capacity * 100.f, Terrain->LooseBook() - SceneBook0, E->FillMesh && E->FillMesh->IsVisible() ? TEXT("visible") : TEXT("hidden")));
	}
	if (bDone || SceneT > 45.f)
	{
		bSceneReady = true;
		RWLog(FString::Printf(TEXT("Scene %s ready: bucket %.2f m3, soil mesh %s, mouth faces (%.2f %.2f %.2f)"), *Scene, E->Bucket.Load.Total(), E->FillMesh && E->FillMesh->IsVisible() ? TEXT("visible") : TEXT("hidden"), E->MouthDir().X, E->MouthDir().Y, E->MouthDir().Z));
	}
}

float ARWGameMode::AirTempC() const
{
	if (!World) return 30.f;
	// tropical day: ~24 C before dawn, ~33 C mid-afternoon; clouds and rain cool it down
	const float Day = FMath::Sin((World->TimeOfDay - 9.f) / 24.f * 2.f * PI);
	return 28.5f + 4.5f * Day - 4.f * World->Rain - 1.5f * World->Overcast;
}

void ARWGameMode::UpdateGradeGuide(bool bForce)
{
	ARWPlayerController* PC = Cast<ARWPlayerController>(GetWorld()->GetFirstPlayerController());
	const bool bShow = bGuide && (bForce || (PC && PC->Driving));
	if (!GuideMesh && World)
	{
		GuideMesh = NewObject<UProceduralMeshComponent>(World);
		GuideMesh->SetupAttachment(World->GetRootComponent());
		GuideMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		GuideMesh->SetCastShadow(false);
		GuideMesh->RegisterComponent();
	}
	if (!GuideMesh) return;
	// which job: the tracked one, else the first running job that has a design surface
	const FRWJob* J = nullptr;
	auto Has = [](const FRWJob& Jb) { return Jb.bAccepted && !Jb.bDone && (Jb.Type == EJob::Road || Jb.Type == EJob::Ditch || Jb.Type == EJob::Pond || Jb.Type == EJob::LevelPad || Jb.Type == EJob::Fill || Jb.Type == EJob::CutHill); };
	GuideJob = -1;
	if (Jobs.Jobs.IsValidIndex(Jobs.Tracked) && Has(Jobs.Jobs[Jobs.Tracked])) GuideJob = Jobs.Tracked;
	for (int32 k = 0; k < Jobs.Jobs.Num() && GuideJob < 0; ++k) if (Has(Jobs.Jobs[k])) GuideJob = k;
	if (GuideJob >= 0) J = &Jobs.Jobs[GuideJob];
	if (!bShow || !J) { GuideMesh->SetVisibility(false); GuideCut = GuideFill = 0.f; return; }
	// sample points: rows x columns along the road / ditch centre line, or a grid over the area job (1 m spacing)
	const float Sp = 1.f;
	TArray<FVector2D> P; int32 Cols = 0, Rows = 0;
	if (J->Type == EJob::Road || J->Type == EJob::Ditch)
	{
		Cols = FMath::Clamp(FMath::RoundToInt(2.f * J->HalfW / Sp) + 1, 3, 17);
		for (int32 s = 0; s + 1 < J->Path.Num(); ++s)
		{
			const FVector2D A = J->Path[s], B = J->Path[s + 1];
			const float Len = FVector2D::Distance(A, B);
			const FVector2D Dir = (B - A) / FMath::Max(Len, 0.01f), Nrm(-Dir.Y, Dir.X);
			for (float d = 0.f; d < Len; d += Sp)
			{
				const FVector2D C = A + Dir * d;
				if (FVector2D::Distance(C, FVector2D(CamM.X, CamM.Y)) > 90.f) continue; // only the stretch around the player
				for (int32 c = 0; c < Cols; ++c) P.Add(C + Nrm * FMath::Lerp(-J->HalfW, J->HalfW, c / float(Cols - 1)));
				++Rows;
			}
		}
	}
	else
	{
		Cols = FMath::Clamp(FMath::RoundToInt(2.f * J->Half.X / Sp) + 1, 2, 90);
		Rows = FMath::Clamp(FMath::RoundToInt(2.f * J->Half.Y / Sp) + 1, 2, 90);
		for (int32 r = 0; r < Rows; ++r)
			for (int32 c = 0; c < Cols; ++c)
				P.Add(J->C + FVector2D(FMath::Lerp(-J->Half.X, J->Half.X, c / float(Cols - 1)), FMath::Lerp(-J->Half.Y, J->Half.Y, r / float(Rows - 1))));
	}
	TArray<FVector> V; TArray<FLinearColor> Col; TArray<uint8> Ok; TArray<FVector> N; TArray<FVector2D> UV;
	V.SetNumUninitialized(P.Num()); Col.SetNumUninitialized(P.Num()); Ok.SetNumZeroed(P.Num()); N.Init(FVector::UpVector, P.Num()); UV.SetNumZeroed(P.Num());
	float Cut = 0.f, Fill = 0.f; int32 On = 0, Valid = 0;
	const FLinearColor Green(0.1f, 0.9f, 0.2f), Orange(1.f, 0.55f, 0.08f), Red(1.f, 0.08f, 0.04f), Cyan(0.2f, 0.75f, 1.f), Blue(0.08f, 0.2f, 1.f);
	for (int32 k = 0; k < P.Num(); ++k)
	{
		const float H = Terrain->InBounds(P[k].X, P[k].Y) ? Terrain->HeightAt(P[k].X, P[k].Y) : 0.f;
		float Z = 0.f;
		V[k] = FVector(P[k].X, P[k].Y, H + 0.06f) * M2CM;
		if (!Terrain->InBounds(P[k].X, P[k].Y) || !Jobs.DesignGrade(FVector(P[k].X, P[k].Y, H), Z)) { Col[k] = FLinearColor(0, 0, 0, 0); continue; }
		Ok[k] = 1; ++Valid;
		const float D = H - Z; // + above design (cut), - below (fill)
		FLinearColor C;
		if (FMath::Abs(D) < 0.05f) { C = Green; ++On; }
		else if (D > 0.f) { C = FMath::Lerp(Orange, Red, FMath::Clamp((D - 0.05f) / 0.45f, 0.f, 1.f)); Cut += D * Sp * Sp; }
		else { C = FMath::Lerp(Cyan, Blue, FMath::Clamp((-D - 0.05f) / 0.45f, 0.f, 1.f)); Fill += -D * Sp * Sp; }
		C.A = 0.5f;
		Col[k] = C;
	}
	GuideCut = Cut; GuideFill = Fill; GuideOnGrade = Valid ? On / float(Valid) : 0.f;
	TArray<int32> Tri;
	for (int32 r = 0; r + 1 < Rows; ++r)
		for (int32 c = 0; c + 1 < Cols; ++c)
		{
			const int32 a = r * Cols + c, b = a + 1, cc = a + Cols, d = cc + 1;
			if (d >= P.Num() || !(Ok[a] && Ok[b] && Ok[cc] && Ok[d])) continue;
			if (FVector::DistSquared(V[a], V[cc]) > FMath::Square(3.f * Sp * M2CM)) continue; // gap between road segments
			Tri.Append({a, cc, b, b, cc, d});
		}
	if (Tri.Num() == 0) { GuideMesh->SetVisibility(false); return; }
	static UMaterialInterface* GuideMat = nullptr;
	if (!GuideMat) { GuideMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_WaterFlow.M_WaterFlow")); if (GuideMat) GuideMat->AddToRoot(); }
	GuideMesh->CreateMeshSection_LinearColor(0, V, Tri, N, UV, Col, TArray<FProcMeshTangent>(), false);
	if (GuideMat) GuideMesh->SetMaterial(0, GuideMat); // translucent, vertex colour = cut / grade / fill
	GuideMesh->SetVisibility(true);
}

void ARWGameMode::UpdateWaterSources()
{
	// water springs / pump outlets placed with the map editor (or shipped by a mod as map_items)
	if (!Water) return;
	Water->Sources.Reset();
	// culverts: same places, rebuilt each second (the flow state is solved again every step anyway)
	Water->Culverts.Reset();
	auto AddCulvert = [&](const FVector& Pos, float Yaw, float Sc)
	{
		ARWWater::FCulvert C; FVector In, Out;
		FRWEditor::CulvertGeometry(Terrain, Pos, Yaw, Sc, In, Out, C.Diameter);
		C.In = FVector2D(In.X, In.Y); C.Out = FVector2D(Out.X, Out.Y); C.InZ = In.Z; C.OutZ = Out.Z;
		C.bKeepMouth = true;
		Water->Culverts.Add(C);
	};
	for (const FRWPlaced& P : FRWEditor::Placed)
	{
		const int32 Idx = FRWEditor::FindItem(P.Item);
		if (Idx != INDEX_NONE && FRWEditor::Catalog[Idx].Builtin == TEXT("culvert")) AddCulvert(P.Pos, P.Yaw, P.Scale);
	}
	// pipes laid by machines: each joined run carries water from one open end to the other
	{
		TArray<ARWProp::FPipeRun> Runs;
		ARWProp::PipeRuns(Runs);
		for (const ARWProp::FPipeRun& R : Runs)
		{
			ARWWater::FCulvert C;
			C.In = FVector2D(R.In.X, R.In.Y); C.Out = FVector2D(R.Out.X, R.Out.Y);
			C.InZ = R.In.Z; C.OutZ = R.Out.Z;
			C.Diameter = ARWProp::PipeDia;
			Water->Culverts.Add(C);
		}
	}
	for (const TSharedPtr<FJsonValue>& V : FRWEditor::PendingModItems)
	{
		const TSharedPtr<FJsonObject> O = V.IsValid() ? V->AsObject() : nullptr;
		FString Item; const TArray<TSharedPtr<FJsonValue>>* Pos;
		if (!O.IsValid() || !O->TryGetStringField(TEXT("item"), Item) || !O->TryGetArrayField(TEXT("pos"), Pos) || Pos->Num() < 2) continue;
		const int32 Idx = FRWEditor::FindItem(Item);
		if (Idx == INDEX_NONE || FRWEditor::Catalog[Idx].Builtin != TEXT("culvert")) continue;
		double Yw = 0, Sc = 1; O->TryGetNumberField(TEXT("yaw"), Yw); O->TryGetNumberField(TEXT("scale"), Sc);
		AddCulvert(FVector((*Pos)[0]->AsNumber(), (*Pos)[1]->AsNumber(), 0.0), (float)Yw, (float)Sc);
	}
	for (const FRWPlaced& P : FRWEditor::Placed)
	{
		const int32 Idx = FRWEditor::FindItem(P.Item);
		if (Idx == INDEX_NONE || FRWEditor::Catalog[Idx].Builtin != TEXT("water_source")) continue;
		ARWWater::FSource S; S.P = FVector2D(P.Pos.X, P.Pos.Y); S.Rate = 0.03f * FMath::Max(P.Scale, 0.1f); // 30 L/s at scale 1
		Water->Sources.Add(S);
	}
	// springs shipped by mods as "map_items" (not part of the player's own edit list)
	for (const TSharedPtr<FJsonValue>& V : FRWEditor::PendingModItems)
	{
		const TSharedPtr<FJsonObject> O = V.IsValid() ? V->AsObject() : nullptr;
		FString Item; const TArray<TSharedPtr<FJsonValue>>* Pos;
		if (!O.IsValid() || !O->TryGetStringField(TEXT("item"), Item) || !O->TryGetArrayField(TEXT("pos"), Pos) || Pos->Num() < 2) continue;
		const int32 Idx = FRWEditor::FindItem(Item);
		if (Idx == INDEX_NONE || FRWEditor::Catalog[Idx].Builtin != TEXT("water_source")) continue;
		double Sc = 1.0; O->TryGetNumberField(TEXT("scale"), Sc);
		ARWWater::FSource S; S.P = FVector2D((*Pos)[0]->AsNumber(), (*Pos)[1]->AsNumber()); S.Rate = 0.03f * FMath::Max((float)Sc, 0.1f);
		Water->Sources.Add(S);
	}
}

void ARWGameMode::KeepPipeMouthsOpen()
{
	if (!Water || !Terrain) return;
	const float Back = 1.1f, Front = 0.8f, Reach = 3.f, Slope = 0.6f, Inside = 0.3f;
	int32 Used = 0;
	// tell the player when a laid pipe has enough soil over it, or has been dug open again
	for (const TWeakObjectPtr<ARWProp>& W : ARWProp::All)
	{
		ARWProp* Pp = W.Get();
		if (!Pp || Pp->Type != 3 || !Pp->bLaid || Pp->bCarried) continue;
		const float Cover = Pp->PipeCover();
		if (!Pp->bPipeBuried && Cover >= 0.3f) { Pp->bPipeBuried = true; Message(TRF(TEXT("Pipe buried: {0} m of soil over it"), RWNum(Cover, 2))); }
		else if (Pp->bPipeBuried && Cover < 0.f) { Pp->bPipeBuried = false; Message(TR(TEXT("Pipe dug open"))); }
	}
	for (const ARWWater::FCulvert& C : Water->Culverts)
	{
		const FVector2D Axis = (C.Out - C.In).GetSafeNormal();
		if (Axis.IsNearlyZero() || !C.bKeepMouth) continue;
		const float R = 0.5f * C.Diameter, HalfW = R + 0.45f;
		for (int32 e = 0; e < 2; ++e)
		{
			const FVector2D End = e == 0 ? C.In : C.Out;
			const float Z0 = e == 0 ? C.InZ : C.OutZ;
			const FVector2D Away = e == 0 ? -Axis : Axis, Lat(-Away.Y, Away.X);
			const float Span = Reach + FMath::Max(HalfW, FMath::Max(Back + 1.f, Front));
			FPayload Spoil;
			for (float y = -Span; y <= Span; y += ARWTerrain::CS)
				for (float x = -Span; x <= Span; x += ARWTerrain::CS)
				{
					if (!Terrain->InBounds(End.X + x, End.Y + y)) continue;
					const int32 i = Terrain->IndexAt(End.X + x, End.Y + y);
					const FVector2D Cell(-ARWTerrain::Half + (i % ARWTerrain::N) * ARWTerrain::CS, -ARWTerrain::Half + (i / ARWTerrain::N) * ARWTerrain::CS);
					const float T = FVector2D::DotProduct(Cell - End, Away), S = FMath::Abs(FVector2D::DotProduct(Cell - End, Lat));
					const float Dt = FMath::Max(0.f, T - Front), Ds = FMath::Max(0.f, S - HalfW), Db = FMath::Max(0.f, -Back - T);
					const float Round = FVector2D(Dt, Ds).Size();
					if (Round > Reach || Db > 1.f) continue; // beyond this the ground is none of the mouth's business
					// clear in front of and over the pipe's end, rising at the soil's own slope around it; further back along
					// the pipe the soil may stand steeply over it
					const float Limit = Z0 + FMath::Max(Db * 3.f, Round * Slope) - (Round <= 0.f && Db <= 0.f ? 0.01f : 0.f);
					const float Over = Terrain->Height[i] - Limit;
					if (Over > 0.02f) Terrain->RemoveAt(i, Over, Spoil, true);
				}
			if (Spoil.Total() > 1e-4f)
			{
				const FVector2D To = End + Away * 0.5f + Lat * (HalfW + Reach + 1.5f) * (Used % 2 == 0 ? 1.f : -1.f);
				Terrain->DepositDisc(To.X, To.Y, 1.5f, Spoil);
			}
			// with soil standing over the pipe its inside is dark; without it you can simply see through the pipe
			const FVector2D Behind = End - Away * (Back + 0.6f);
			const bool bCovered = Terrain->InBounds(Behind.X, Behind.Y) && Terrain->HeightAt(Behind.X, Behind.Y) > Z0 + 0.1f * C.Diameter;
			if (!PipeMouthDark.IsValidIndex(Used))
			{
				UStaticMeshComponent* D = NewObject<UStaticMeshComponent>(Terrain);
				D->SetupAttachment(Terrain->GetRootComponent());
				D->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				D->SetCastShadow(false);
				D->RegisterComponent();
				UMaterialInstanceDynamic* Mid = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, D);
				Mid->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.002f, 0.002f, 0.002f));
				Mid->SetScalarParameterValue(TEXT("Roughness"), 1.f);
				Mid->SetScalarParameterValue(TEXT("Metallic"), 0.f);
				D->SetMaterial(0, Mid);
				PipeMouthDark.Add(D);
			}
			UStaticMeshComponent* Dark = PipeMouthDark[Used++];
			Dark->SetVisibility(bCovered);
			if (bCovered)
			{
				Dark->SetStaticMesh(FRWMeshGen::RoundCyl(C.Diameter * 0.96f, 0.02f));
				const FVector At(End.X - Away.X * Inside, End.Y - Away.Y * Inside, Z0 + R);
				Dark->SetWorldLocationAndRotation(At * M2CM, FRotationMatrix::MakeFromZ(FVector(Away.X, Away.Y, 0.f)).ToQuat());
			}
		}
	}
	for (int32 k = Used; k < PipeMouthDark.Num(); ++k) if (PipeMouthDark[k]) PipeMouthDark[k]->SetVisibility(false);
}

void ARWGameMode::TickVistaScene(float Dt)
{
	SceneT += Dt;
	FString At;
	FParse::Value(FCommandLine::Get(), TEXT("RWCamAt="), At, false);
	TArray<FString> Parts;
	At.ParseIntoArray(Parts, TEXT(","));
	const auto Part = [&](int32 k, float Def) { return Parts.IsValidIndex(k) ? FCString::Atof(*Parts[k]) : Def; };
	const float X = Part(0, 0.f), Y = Part(1, 0.f);
	const float G = Terrain && Terrain->InBounds(X, Y) ? Terrain->HeightAt(X, Y) : 0.f;
	FVector P(X, Y, G + Part(2, 2.f));
	FRotator VistaRot(Part(4, 0.f), Part(3, 0.f), 0.f);
	// -RWCamAt=fall1: from downstream, looking back up at the waterfall where that stream starts
	if (At.StartsWith(TEXT("fall")) && Layout.Streams.IsValidIndex(FCString::Atoi(*At.Mid(4))) && Layout.Streams[FCString::Atoi(*At.Mid(4))].Pts.Num() > 16)
	{
		const FRWStream& St = Layout.Streams[FCString::Atoi(*At.Mid(4))];
		const FVector2D From = St.Pts[12];
		P = FVector(From.X, From.Y, Terrain->HeightAt(From.X, From.Y) + 3.f);
		VistaRot = (FVector(St.Pts[0].X, St.Pts[0].Y, St.Bed[0] + 8.f) - P).Rotation();
	}
	if (!SceneCam)
	{
		SceneCam = GetWorld()->SpawnActor<ACameraActor>();
		if (SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(70.f);
		if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
	}
	if (SceneCam) SceneCam->SetActorLocationAndRotation(P * M2CM, VistaRot);
	CamM = P;
	bGuide = false;
	if (SceneT > 7.f) bSceneReady = true;
}

void ARWGameMode::TickBuryScene(float Dt)
{
	// -RWScene=bury: a pipe on open ground with soil tipped all over it, seen from in front of its open end
	SceneT += Dt;
	if (SceneT < 1.5f || !Terrain || !Water) return;
	const FVector2D C(58.f, -20.f);
	if (ScenePhase == 0)
	{
		ScenePhase = 1;
		ARWProp* P = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		P->Init(3, Terrain, FVector(C.X, C.Y, Terrain->HeightAt(C.X, C.Y)), 0.f);
		P->bWasCarried = true;
		P->Tick(1.f / 60.f);
		for (float x = -3.f; x <= 3.f; x += 0.75f)
			for (float y = -1.5f; y <= 1.5f; y += 0.75f)
			{
				FPayload Fill; Fill.Add(ESoil::DrySoil, 1.3f, 0.2f);
				Terrain->DepositDisc(C.X + x, C.Y + y, 1.1f, Fill);
			}
		UpdateWaterSources();
		if (!SceneCam)
		{
			SceneCam = GetWorld()->SpawnActor<ACameraActor>();
			if (SceneCam && SceneCam->GetCameraComponent()) SceneCam->GetCameraComponent()->SetFieldOfView(60.f);
			if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
		}
	}
	const FVector Mouth(C.X + 0.5f * ARWProp::PipeLen, C.Y, Terrain->HeightAt(C.X + 0.5f * ARWProp::PipeLen + 0.5f, C.Y) + 0.5f);
	const FVector CamP = Mouth + FVector(4.5f, 1.8f, 1.1f);
	if (SceneCam) SceneCam->SetActorLocationAndRotation(CamP * M2CM, (Mouth - CamP).Rotation());
	CamM = Mouth;
	bGuide = false;
	if (SceneT > 6.f && !bSceneReady)
	{
		bSceneReady = true;
		RWLog(FString::Printf(TEXT("Scene bury: ground at the mouth %.2f m, %d pipe end(s) kept open"), Terrain->HeightAt(Mouth.X, Mouth.Y), Water->Culverts.Num() * 2));
	}
}

void ARWGameMode::ApplyGraphics()
{
	UWorld* W = GetWorld();
	if (UGameUserSettings* S = GEngine ? GEngine->GetGameUserSettings() : nullptr)
	{
		S->SetOverallScalabilityLevel(Quality);
		S->ApplyNonResolutionSettings();
	}
	auto Cmd = [&](const FString& C) { if (GEngine) GEngine->Exec(W, *C); };
	Cmd(FString::Printf(TEXT("r.ScreenPercentage %d"), ResScale));
	Cmd(FString::Printf(TEXT("r.Shadow.Virtual.Enable %d"), bVSM ? 1 : 0));
	Cmd(TEXT("r.AntiAliasingMethod 4"));
	if (World && World->Post)
	{
		World->Post->Settings.DynamicGlobalIlluminationMethod = bLumen ? EDynamicGlobalIlluminationMethod::Lumen : EDynamicGlobalIlluminationMethod::None;
		World->Post->Settings.ReflectionMethod = bLumen ? EReflectionMethod::Lumen : EReflectionMethod::ScreenSpace;
	}
	if (Fx) Fx->MaxDust = Quality <= 1 ? 120 : 260;
	// textured soil needs High or Epic (it samples 45 textures); Low / Medium keep the light vertex-colour ground
	if (Terrain)
	{
		const bool bPBR = Quality >= 2 && PBRTerrainMat && !bModTerrainMat;
		Terrain->SetPBR(bPBR, bPBR ? PBRTerrainMat : ClassicTerrainMat);
	}
}

ARWMachine* ARWGameMode::NearestMachine(const FVector& P, float MaxD) const
{
	ARWMachine* B = nullptr; float BD = MaxD;
	for (ARWMachine* M : Machines)
	{
		if (!M) continue;
		const float D = FVector::Dist2D(M->PosM, P) - M->Radius2D * 0.5f;
		if (D < BD) { BD = D; B = M; }
	}
	return B;
}

const FRWZone* ARWGameMode::ZoneAt(const FVector& P, ERWZone T) const
{
	for (const FRWZone& Z : Layout.Zones) if (Z.Type == T && FRWLayout::InZone(Z, P.X, P.Y, 4.f)) return &Z;
	return nullptr;
}

bool ARWGameMode::NearRiver(const FVector& P) const { return Layout.RiverDist(P.X, P.Y) < 14.f; }

void ARWGameMode::Refuel(ARWMachine* M)
{
	if (!M) return;
	const float L = M->FuelCap - M->Fuel;
	const float Cost = L * Eco.FuelPrice;
	if (L < 1.f) { Message(TEXT("Tank already full")); return; }
	if (Eco.Money < Cost) { Message(TEXT("Not enough money for fuel")); return; }
	M->Fuel = M->FuelCap;
	Eco.Add(-Cost, TRF(TEXT("Diesel {0} L for {1}"), RWNum(L), TR(M->Model)));
}

void ARWGameMode::Repair(ARWMachine* M)
{
	if (!M) return;
	const float Cost = (1.f - M->Condition) * M->Price * 0.10f + M->WearCostAccum;
	if (Cost < 1.f) { Message(TEXT("Machine is in perfect condition")); return; }
	if (Eco.Money < Cost) { Message(TEXT("Not enough money for repairs")); return; }
	M->Condition = 1.f; M->WearCostAccum = 0.f; M->Dirt = 0.f;
	M->ApplyDirt();
	Eco.Add(-Cost, TRF(TEXT("Service, parts & wash: {0}"), TR(M->Model)));
}

void ARWGameMode::RentOrReturn(ARWMachine* M)
{
	if (!M || M->bOwned) return;
	if (M->bRented) { M->bRented = false; M->bEngineOn = false; Message(TRF(TEXT("Returned {0}"), TR(M->Model))); return; }
	if (Eco.Money < M->RentPerDay) { Message(TEXT("Not enough money to rent")); return; }
	M->bRented = true;
	Eco.Add(-M->RentPerDay, TRF(TEXT("Rent day 1: {0}"), TR(M->Model)));
}

void ARWGameMode::Buy(ARWMachine* M)
{
	if (!M || M->bOwned) return;
	if (Eco.Money < M->Price) { Message(TRF(TEXT("Need ${0} to buy {1}"), RWNum(M->Price), TR(M->Model))); return; }
	M->bOwned = true; M->bRented = false;
	Eco.Add(-M->Price, TRF(TEXT("Bought {0}"), TR(M->Model)));
}

void ARWGameMode::Upgrade(ARWMachine* M, int32 Which)
{
	if (!M || !M->bOwned) { Message(TEXT("Only owned machines can be upgraded")); return; }
	int32* Lv = Which == 0 ? &M->UpEngine : Which == 1 ? &M->UpHyd : Which == 2 ? &M->UpTraction : &M->UpTool;
	if (*Lv >= 3) { Message(TEXT("Already at maximum level")); return; }
	const float Cost = M->Price * 0.06f * (*Lv + 1);
	if (Eco.Money < Cost) { Message(TEXT("Not enough money")); return; }
	(*Lv)++;
	if (Which == 3)
	{
		if (ARWExcavator* E = Cast<ARWExcavator>(M)) E->Bucket.Capacity *= 1.2f;
		if (ARWLoader* L = Cast<ARWLoader>(M)) L->Bucket.Capacity *= 1.15f;
		if (ARWDumpTruck* T = Cast<ARWDumpTruck>(M)) T->Capacity *= 1.15f;
	}
	static const TCHAR* N[4] = {TEXT("engine"), TEXT("hydraulics"), TEXT("tyres/tracks"), TEXT("bucket/body")};
	Eco.Add(-Cost, TRF(TEXT("Upgrade {0} L{1}: {2}"), TR(N[Which]), FString::FromInt(*Lv), TR(M->Model)));
}

void ARWGameMode::BuyMaterial(ARWMachine* M, ESoil Mat)
{
	float Vol = 0;
	if (ARWDumpTruck* T = Cast<ARWDumpTruck>(M)) Vol = FMath::Min(10.f, T->Capacity - T->Load.Total());
	else if (ARWPaver* P = Cast<ARWPaver>(M)) { if (Mat != ESoil::Asphalt) { Message(TEXT("The paver takes asphalt only")); return; } Vol = P->HopperCap - P->Hopper.Total(); }
	else { Message(TEXT("Drive a dump truck or the paver under the loading bay")); return; }
	if (Vol < 0.5f) { Message(TEXT("Already full")); return; }
	const float Cost = Vol * FRWEconomy::MaterialPrice(Mat);
	if (Eco.Money < Cost) { Message(TEXT("Not enough money")); return; }
	// the plant's loader drops it in as real particles so it lands where it should
	FPayload P; P.Add(Mat, Vol, Mat == ESoil::Asphalt ? 0.05f : 0.2f);
	if (ARWDumpTruck* T = Cast<ARWDumpTruck>(M)) T->Load.AddPayload(P);
	else if (ARWPaver* Pv = Cast<ARWPaver>(M)) Pv->Hopper.AddPayload(P);
	Eco.Add(-Cost, RWNum(Vol, 1) + TR(TEXT(" m3 ")) + TR(SoilProps(Mat).Name));
}

void ARWGameMode::BuyPlot(int32 i)
{
	const float Price[2] = {80000.f, 60000.f};
	if (!Eco.Plots.IsValidIndex(i) || Eco.Plots[i]) return;
	if (Eco.Money < Price[i]) { Message(TEXT("Not enough money for the land")); return; }
	Eco.Plots[i] = true;
	Eco.Add(-Price[i], TR(i == 0 ? TEXT("Bought land plot East") : TEXT("Bought land plot West")));
}

void ARWGameMode::SubmitJob(int32 i)
{
	if (!Jobs.Jobs.IsValidIndex(i)) return;
	FRWJob& J = Jobs.Jobs[i];
	Jobs.Evaluate(J);
	if (!Jobs.CanSubmit(J)) { Message(TRF(TEXT("Not finished yet ({0}%). {1}"), RWNum(J.Progress * 100.f), J.Status)); return; }
	float Pay = J.BasePay * (0.5f + 0.5f * J.Quality);
	if (J.RatePerUnit > 0) Pay += J.RatePerUnit * FMath::Max(J.Delivered, J.Type == EJob::Pond ? J.TargetVol * J.Progress : 0.f);
	int32 Plots = 0; for (bool b : Eco.Plots) Plots += b ? 1 : 0;
	Pay *= 1.f + 0.05f * Plots + 0.002f * Eco.Reputation;
	J.bDone = true; J.Paid = Pay;
	FRWPlatform::Unlock(TEXT("FIRST_CONTRACT"));
	if (J.Type == EJob::Road) FRWPlatform::Unlock(TEXT("ROAD_BUILDER"));
	Eco.Reputation += 5.f + 10.f * J.Quality;
	Eco.Add(Pay, TRF(TEXT("Contract: {0} (quality {1}%)"), TR(J.Title), RWNum(J.Quality * 100.f)));
	Message(TRF(TEXT("Contract complete: {0} - paid ${1}"), TR(J.Title), RWNum(Pay)));
}

void ARWGameMode::UpdateMarkers()
{
	TArray<FTransform> T;
	auto Post = [&](float X, float Y, float TopZ, float H)
	{
		const float G = Terrain->HeightAt(X, Y);
		const float Top = FMath::Max(TopZ, G + 0.3f);
		const float Len = FMath::Max(Top - G + 0.2f, 0.3f);
		T.Add(FTransform(FQuat::Identity, FVector(X, Y, G - 0.2f + Len * 0.5f) * M2CM, FVector(0.06f, 0.06f, Len)));
		T.Add(FTransform(FQuat::Identity, FVector(X, Y, Top) * M2CM, FVector(0.25f, 0.03f, 0.03f))); // grade lath cross bar = design height
		(void)H;
	};
	for (const FRWJob& J : Jobs.Jobs)
	{
		if (!J.bAccepted && !(J.bPlayer && J.Stakes.Num())) continue;
		if (J.bDone) continue;
		if (J.Path.Num() >= 2 && J.PathZ.Num() == J.Path.Num())
		{
			for (int32 i = 0; i < J.Path.Num(); i += 5)
			{
				const FVector2D A = J.Path[i], B = J.Path[FMath::Min(i + 1, J.Path.Num() - 1)];
				const FVector2D D = (B - A).GetSafeNormal(); const FVector2D N(-D.Y, D.X);
				for (int32 s = -1; s <= 1; s += 2)
				{
					const FVector2D P = A + N * (J.HalfW + 0.6f) * s;
					Post(P.X, P.Y, J.PathZ[i] - J.CrossSlope * J.HalfW, 1.f);
				}
			}
		}
		else if (J.Type == EJob::Ditch || J.Type == EJob::Repair)
		{
			for (int32 s = 0; s + 1 < J.Path.Num(); ++s)
				for (float d = 0; d < FVector2D::Distance(J.Path[s], J.Path[s + 1]); d += 4.f)
				{
					const FVector2D P = J.Path[s] + (J.Path[s + 1] - J.Path[s]).GetSafeNormal() * d;
					Post(P.X, P.Y, Terrain->HeightAt(P.X, P.Y) + 0.6f, 1.f);
				}
		}
		else
		{
			const float Z = (J.Type == EJob::LevelPad || J.Type == EJob::Fill || J.Type == EJob::CutHill) ? J.TargetZ : -1e6f;
			for (int32 c = 0; c < 4; ++c)
			{
				const float X = J.C.X + ((c & 1) ? J.Half.X : -J.Half.X), Y = J.C.Y + ((c & 2) ? J.Half.Y : -J.Half.Y);
				Post(X, Y, Z > -1e5f ? Z : Terrain->HeightAt(X, Y) + 1.2f, 1.f);
			}
		}
		if (J.bPlayer) for (const FVector2D& S : J.Stakes) Post(S.X, S.Y, Terrain->HeightAt(S.X, S.Y) + 1.8f, 2.f);
	}
	World->SetMarkers(T);
}

void ARWGameMode::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!bReady) return;
	// -RWExportPlants=<file> / -RWExportScenery=<file>: write the trees and plants / the whole scenery with the machines
	// for the Unreal Editor (Tools/make_level_visuals.py imports them into the level), then quit
	if (ExportWait > 0 && --ExportWait == 0)
	{
		FString PlantsFile, SceneryFile;
		if (FParse::Value(FCommandLine::Get(), TEXT("RWExportPlants="), PlantsFile) && World) World->ExportPlants(PlantsFile);
		if (FParse::Value(FCommandLine::Get(), TEXT("RWExportScenery="), SceneryFile)) RWExportScenery(GetWorld(), SceneryFile);
		FGenericPlatformMisc::RequestExit(false);
	}
	MessageTime -= Dt;
	const double PerfT0 = FPlatformTime::Seconds();
	Terrain->RelaxFor(Dt);
	const double PerfT1 = FPlatformTime::Seconds();
	Terrain->UpdateMeshes(CamM, false);
	const double PerfT2 = FPlatformTime::Seconds();
	static double PerfRelax = 0.0, PerfMeshes = 0.0; static int32 PerfFrames = 0;
	PerfRelax += PerfT1 - PerfT0; PerfMeshes += PerfT2 - PerfT1; ++PerfFrames;
	Fx->CamM = CamM;
	World->CamM = CamM;
	GuideTimer -= Dt;
	if (GuideTimer <= 0.f) { GuideTimer = 0.3f; UpdateGradeGuide(false); }
	if (Scene.ToLower() == TEXT("river"))
	{
		// a look along the river, for checking the water surface and the bank plants in a screenshot
		SceneT += Dt;
		if (!SceneCam)
		{
			SceneCam = GetWorld()->SpawnActor<ACameraActor>();
			if (APlayerController* PC = GetWorld()->GetFirstPlayerController()) PC->SetViewTarget(SceneCam);
		}
		const float RX = 40.f, RY = Layout.RiverY(RX);
		const FVector CamP(RX, RY - 16.f, Layout.WaterZ + 5.f), LookAt(RX + 22.f, Layout.RiverY(RX + 22.f), Layout.WaterZ);
		if (SceneCam) SceneCam->SetActorLocationAndRotation(CamP * M2CM, (LookAt - CamP).Rotation());
		CamM = CamP;
		if (SceneT > 4.f) bSceneReady = true;
	}
	else if (Scene.ToLower() == TEXT("culvert")) TickCulvertScene(Dt);
	else if (Scene.ToLower() == TEXT("pipe")) TickPipeScene(Dt);
	else if (Scene.ToLower() == TEXT("bury")) TickBuryScene(Dt);
	else if (Scene.ToLower() == TEXT("vista")) TickVistaScene(Dt);
	else if (!Scene.IsEmpty() && SceneEx) TickScene(Dt);
	if (Water)
	{
		Water->CamM = CamM;
		// heavy rain ~30 mm/h, sped up with the game clock
		Water->RainRate = World->Rain * 8.3e-6f * FMath::Max(World->TimeMul, 1.f) * 3.f;
		PipeMouthTimer -= Dt;
		if (PipeMouthTimer <= 0.f) { PipeMouthTimer = 0.25f; KeepPipeMouthsOpen(); }
		WaterSourceTimer -= Dt;
		if (WaterSourceTimer <= 0.f)
		{
			WaterSourceTimer = 1.f; UpdateWaterSources();
			static int32 PerfLog = 0;
			if (PerfLog++ % 5 == 1)
			{
				RWLog(FString::Printf(TEXT("Perf: frame %.1f ms, water %.2f ms (%d active tiles, %d meshes), slumping %.2f ms, ground meshes %.2f ms, world %.2f ms"), Dt * 1000.f, Water->TickMs, Water->ActiveTiles(), Water->VisibleTiles(), PerfRelax * 1000.0 / FMath::Max(PerfFrames, 1), PerfMeshes * 1000.0 / FMath::Max(PerfFrames, 1), World->PerfTickSec * 1000.0 / FMath::Max(PerfFrames, 1)));
				PerfRelax = PerfMeshes = 0.0; PerfFrames = 0; World->PerfTickSec = 0.0;
			}
		}
	}
	Jobs.Tick(Dt);
	MarkerTimer -= Dt;
	if (MarkerTimer <= 0)
	{
		MarkerTimer = 1.f;
		UpdateMarkers();
		// achievements are checked against real game state once a second
		int32 Owned = 0;
		ARWPlayerController* PC = Cast<ARWPlayerController>(GetWorld()->GetFirstPlayerController());
		for (ARWMachine* M : Machines)
		{
			if (!M) continue;
			if (M->bOwned) ++Owned;
			if (M->bStuck && PC && PC->Driving == M && FRWPlatform::Unlock(TEXT("STUCK"))) Message(TEXT("Achievement: Stuck in the Mud"));
			if (!M->ModId.IsEmpty() && PC && PC->Driving == M && FRWPlatform::Unlock(TEXT("MODDER"))) Message(TEXT("Achievement: Modder"));
			if (ARWExcavator* E = Cast<ARWExcavator>(M)) if (E->Bucket.Load.Total() > 0.3f && FRWPlatform::Unlock(TEXT("FIRST_DIG"))) Message(TEXT("Achievement: First Bucket"));
		}
		if (Owned >= 5 && FRWPlatform::Unlock(TEXT("FLEET"))) Message(TEXT("Achievement: Fleet Owner"));
		if (Eco.Money >= 500000.0 && FRWPlatform::Unlock(TEXT("TYCOON"))) Message(TEXT("Achievement: Tycoon"));
		World->UpdateGrass(CamM);
	}
	if (World->Day != LastDay)
	{
		LastDay = World->Day;
		for (ARWMachine* M : Machines) if (M && M->bRented && !M->bOwned) Eco.Add(-M->RentPerDay, TRF(TEXT("Rent: {0}"), TR(M->Model)));
		int32 Plots = 0; for (bool b : Eco.Plots) Plots += b ? 1 : 0;
		if (Plots) Eco.Add(Plots * 900.f, TEXT("Yard lease income from owned land"));
	}
}

// ---------------- save / load ----------------
static FString SavePath(const FString& Slot) { return FRWPlatform::SaveDir() / FString::Printf(TEXT("RoadWorks_%s.sav"), *Slot); } // cloud-synced folder when a store backend is active

bool ARWGameMode::SaveGame(const FString& Slot)
{
	Fx->SettleAll();
	FBufferArchive Ar;
	int32 Magic = 0x52575331, Ver = 5; // 5: a 4500 m map, only changed ground is saved; older terrain no longer fits
	Ar << Magic << Ver;
	Ar << Eco.Money << Eco.Reputation << Eco.Plots;
	Ar << World->TimeOfDay << World->Day << World->Weather << World->Rain << World->Overcast;
	TArray<uint8> Alive; for (const FRWTree& T : World->Trees) Alive.Add(T.bAlive ? 1 : 0);
	Ar << Alive;
	int32 NM = Machines.Num(); Ar << NM;
	for (ARWMachine* M : Machines) M->SerializeState(Ar);
	TArray<int32> PT; TArray<FVector> PP; TArray<float> PY;
	for (const TWeakObjectPtr<ARWProp>& P : ARWProp::All) if (P.IsValid()) { PT.Add(P->Type | (P->bLaid ? 256 : 0)); PP.Add(P->PosM()); PY.Add(P->FallYaw); } // bit 8: a laid pipe
	Ar << PT << PP << PY;
	Jobs.Serialize(Ar);
	TArray<uint8> Blob; Terrain->SaveTo(Blob);
	Ar << Blob;
	// (added at the end, so older saves still load) each prop's own model: a felled tree, a rock placed in the level
	TArray<FString> LMesh, LMats; TArray<FTransform> LRel; TArray<float> LSize, LMass;
	for (const TWeakObjectPtr<ARWProp>& P : ARWProp::All) if (P.IsValid())
	{
		FString Mm, Ma; FTransform Rl;
		P->GetLook(Mm, Ma, Rl);
		LMesh.Add(Mm); LMats.Add(Ma); LRel.Add(Rl); LSize.Add(P->RockSize); LMass.Add(P->MassKg);
	}
	Ar << LMesh << LMats << LRel << LSize << LMass;
	const FString Path = SavePath(Slot);
	const bool bOk = FFileHelper::SaveArrayToFile(Ar, *Path);
	Message(bOk ? TRF(TEXT("Game saved ({0} MB)"), RWNum(Ar.Num() / 1048576.f, 1)) : TR(TEXT("SAVE FAILED")));
	return bOk;
}

bool ARWGameMode::LoadGame(const FString& Slot)
{
	TArray<uint8> Data;
	if (!FFileHelper::LoadFileToArray(Data, *SavePath(Slot))) { Message(TEXT("No saved game found")); return false; }
	FMemoryReader Ar(Data);
	int32 Magic = 0, Ver = 0;
	Ar << Magic << Ver;
	if (Magic != 0x52575331 || Ver != 5) { Message(TEXT("Save file is not compatible")); return false; }
	Fx->SettleAll();
	Ar << Eco.Money << Eco.Reputation << Eco.Plots;
	Ar << World->TimeOfDay << World->Day << World->Weather << World->Rain << World->Overcast;
	LastDay = World->Day;
	TArray<uint8> Alive; Ar << Alive;
	for (int32 i = 0; i < World->Trees.Num() && i < Alive.Num(); ++i)
		if ((Alive[i] != 0) != World->Trees[i].bAlive) World->SetTreeAlive(i, Alive[i] != 0);
	int32 NM = 0; Ar << NM;
	for (int32 i = 0; i < FMath::Min(NM, Machines.Num()); ++i) Machines[i]->SerializeState(Ar);
	TArray<int32> PT; TArray<FVector> PP; TArray<float> PY;
	Ar << PT << PP << PY;
	for (const TWeakObjectPtr<ARWProp>& P : ARWProp::All) if (P.IsValid()) P->Destroy();
	ARWProp::All.Reset();
	TArray<ARWProp*> Loaded;
	for (int32 i = 0; i < PT.Num(); ++i)
	{
		ARWProp* P = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		P->Init(PT[i] & 255, Terrain, PP[i], PY[i]);
		P->bLaid = (PT[i] & 256) != 0;
		if (P->bLaid) P->UpdatePipeFloor();
		if (P->Type == 0) P->RemoveAfter = ARWProp::FelledTreeLife; // (a trunk is a felled tree: cleared away 15 s after loading)
		Loaded.Add(P);
	}
	Jobs.Serialize(Ar);
	TArray<uint8> Blob; Ar << Blob;
	if (!Ar.AtEnd())
	{
		TArray<FString> LMesh, LMats; TArray<FTransform> LRel; TArray<float> LSize, LMass;
		Ar << LMesh << LMats << LRel << LSize << LMass;
		for (int32 i = 0; i < Loaded.Num() && i < LMesh.Num() && i < LMats.Num() && i < LRel.Num() && i < LSize.Num() && i < LMass.Num(); ++i)
			Loaded[i]->SetLook(LMesh[i], LMats[i], LRel[i], LSize[i], LMass[i]);
	}
	const bool bOk = Terrain->LoadFrom(Blob);
	if (bOk && World) World->RefreshLowPlants(); // the plants of ground worked in that game are gone again, the rest back
	Message(bOk ? TEXT("Game loaded") : TEXT("Terrain data in save is damaged"));
	return bOk;
}
