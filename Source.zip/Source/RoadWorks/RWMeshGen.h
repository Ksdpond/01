// Procedural model kit: builds real UStaticMesh assets at runtime (rounded boxes, lathed wheels,
// extruded plate profiles, tyres with tread, track shoes, trees). Meshes are cached and shared.
#pragma once

#include "CoreMinimal.h"

class UStaticMesh;
class UTexture;
class UMaterialInterface;

struct ROADWORKS_API FMeshBuild
{
	TArray<FVector3f> P, N;
	TArray<FVector2f> UV;
	TArray<int32> T;

	int32 V(const FVector& Pos, const FVector& Nrm, const FVector2D& Uv);
	// Adds a triangle; winding is fixed automatically so the face points along the vertex normals.
	void Tri(int32 A, int32 B, int32 C);
	void Quad(int32 A, int32 B, int32 C, int32 D) { Tri(A, B, C); Tri(A, C, D); }
	void Append(const FMeshBuild& O, const FTransform& X);

	// Primitives (metres, centred on Centre unless noted)
	void RoundBox(const FVector& Centre, const FVector& Size, float Radius, const FRotator& Rot = FRotator::ZeroRotator);
	// Revolve a (radius, axial) profile around the local Y axis.
	void Lathe(const TArray<FVector2D>& Profile, int32 Segments, const FVector& Centre, bool bSmooth = true);
	// Extrude a closed (X,Z) polygon along Y from -Width/2..Width/2 (relative to Centre).
	void Extrude(const TArray<FVector2D>& Poly, float Width, const FVector& Centre, float SmoothDeg = 25.f);
	void Cyl(const FVector& A, const FVector& B, float Radius, int32 Segments = 16);
	void Blob(const FVector& Centre, const FVector& Radii, float Noise, int32 Seed, int32 Rings = 8, int32 Segs = 12);
	void Cone(const FVector& Base, float Radius, float Height, int32 Segments, float Jag, int32 Seed);
};

class ROADWORKS_API FRWMeshGen
{
public:
	static UStaticMesh* Build(const FString& Key, const FMeshBuild& B);
	static UStaticMesh* Find(const FString& Key);

	// Ready-made parts. All sizes in metres; meshes are built at real size (use component scale 1).
	static UStaticMesh* RoundBox(const FVector& Size, float Radius = -1.f);
	static UStaticMesh* RoundCyl(float Diameter, float Height); // axis Z, rounded rims
	static UStaticMesh* Tyre(float Radius, float Width, int32 Style);   // axis Y; 0 road, 1 off-road chevron, 2 smooth drum
	static UStaticMesh* Rim(float Radius, float Width);
	static UStaticMesh* TrackShoe(float Pitch, float Width);
	static UStaticMesh* TrackPrint(); // 1 m long x 1 m wide strip of grouser imprints (scale Y to the shoe width)
	static UStaticMesh* SoilLump(int32 Seed); // 1 m lumpy heap of loose soil (clods on the surface), centred like a sphere
	static UStaticMesh* CorrugatedPipe(float Length, float Diameter); // open drain / culvert pipe along +X from 0 to Length
	static UStaticMesh* WaterSheet(float SizeM, float MetresPerUV);   // flat grid facing up, centred, with world-scaled UVs
	static UStaticMesh* Sprocket(float Radius, float Width);
	static UStaticMesh* Profile(const FString& Key, const TArray<FVector2D>& Poly, float Width);
	static UStaticMesh* BucketShell(float Length, float Width, float Depth, float Thick);
	static UStaticMesh* BucketSide(float Length, float Depth, float Thick);
	static UStaticMesh* Moldboard(float Width, float Height, float Curve, float Thick);
	static UStaticMesh* LoaderBucket(float Width, float Depth, float Height);
	static UStaticMesh* TreeTrunk(float Height, float Radius, int32 Seed);
	static UStaticMesh* ConiferCrown(float Height, float Radius, int32 Seed);
	static UStaticMesh* BroadleafCrown(float Radius, int32 Seed);
	static UStaticMesh* Rock(float Radius, int32 Seed);
	static UStaticMesh* GrassTuft();
	static UStaticMesh* FarCrown(int32 Seed);            // a very simple 1 m tree crown, for forests seen from far away
	static UStaticMesh* ThaiPlant(int32 Kind, int32 Seed); // 0 coconut palm, 1 banana, 2 bamboo clump; UV.x 0 = leaf, 1 = trunk (M_ThaiPlant)

	static UMaterialInterface* DefaultMat;
	// keep the geometry of every mesh built (for writing the scenery out for the editor: -RWExportScenery)
	static bool bKeepGeometry;
	static TMap<const UStaticMesh*, TPair<FString, FMeshBuild>> KeptGeometry;
	static TMap<const UTexture*, TArray<uint8>> KeptImages; // (the image files of the textures the models brought, for the same)
	// fills a mesh description from built geometry (one material slot "Mat"); also used by the editor to make real mesh assets
	static void FillDescription(const FMeshBuild& B, struct FMeshDescription& MD);
};
