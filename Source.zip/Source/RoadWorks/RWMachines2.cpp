#include "RWMachines.h"
#include "RWSoilMech.h"
#include "RWTerrain.h"
#include "RWLoc.h"
#include "RWEffects.h"
#include "RWAudio.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Camera/CameraComponent.h"
#include "RWMeshGen.h"
#include "RWSoilLook.h"

static UStaticMeshComponent* Seg2(ARWMachine* M, USceneComponent* Parent, const FVector& A, const FVector& B, float W, float H, UMaterialInterface* Mat)
{
	const FVector D = B - A;
	return M->Part(Parent, EShape::Cube, (A + B) * 0.5f, FVector(D.Size(), W, H), D.Rotation(), Mat);
}

static UMaterialInstanceDynamic* HeapMat2(UObject* Outer)
{
	return FRWSoilLook::Make(Outer, ESoil::DrySoil, 0.2f); // textured loose soil (plain paint if the soil textures are missing)
}

// Standard 6x4 truck chassis + cab (water truck)
static void TruckChassis(ARWMachine* M, float FrontX)
{
	const float R = 0.53f, W = 0.32f;
	M->AddWheel(FVector2D(2.9f, -1.0f), R, W, true, false, true); M->AddWheel(FVector2D(2.9f, 1.0f), R, W, true, false, true);
	M->AddWheel(FVector2D(-1.0f, -0.9f), R, W, false, true, true, true); M->AddWheel(FVector2D(-1.0f, 0.9f), R, W, false, true, true, true);
	M->AddWheel(FVector2D(-2.35f, -0.9f), R, W, false, true, true, true); M->AddWheel(FVector2D(-2.35f, 0.9f), R, W, false, true, true, true);
	M->Wheelbase = 4.6f;
	for (int32 s = -1; s <= 1; s += 2) M->Part(M->Body, EShape::Cube, FVector(0.2f, s * 0.45f, 0.95f), FVector(FrontX * 2.f, 0.16f, 0.3f), FRotator::ZeroRotator, M->DarkMID);
	M->Part(M->Body, EShape::Cube, FVector(FrontX + 0.15f, 0, 0.75f), FVector(0.25f, 2.4f, 0.35f), FRotator::ZeroRotator, M->DarkMID);
	M->Part(M->Body, EShape::Cube, FVector(FrontX - 0.85f, 0, 1.35f), FVector(1.7f, 2.45f, 0.8f), FRotator::ZeroRotator, M->PaintMID);
	M->AddCab(M->Body, FVector(FrontX - 0.85f, 0, 2.5f), FVector(1.65f, 2.4f, 1.45f));
	M->Part(M->Body, EShape::Cube, FVector(FrontX + 0.01f, 0, 1.3f), FVector(0.05f, 1.6f, 0.55f), FRotator::ZeroRotator, M->DarkMID);
	M->AddLamp(M->Body, FVector(FrontX + 0.05f, -0.95f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	M->AddLamp(M->Body, FVector(FrontX + 0.05f, 0.95f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	M->Part(M->Body, EShape::Cylinder, FVector(FrontX - 1.85f, 1.05f, 2.4f), FVector(0.14f, 0.14f, 1.6f), FRotator::ZeroRotator, M->ChromeMID);
	if (M->CabCam) M->CabCam->SetRelativeLocation(FVector(-0.1f, -0.5f, 0.25f) * M2CM);
}

// --------------------------------------------------------------------------------------------
// Wheel loader
// --------------------------------------------------------------------------------------------
void ARWLoader::Build()
{
	EmptyMass = 17500; PowerKW = 165; FuelCap = 300; FuelRate = 22; TyreStyle = 1;
	Drive = EDrive::Articulated; MaxSteer = 38.f; Wheelbase = 3.3f;
	Ratios = {4.5f, 4.5f, 2.6f, 1.5f, 0.95f}; NumGears = 4; FinalDrive = 6.5f;
	SpringSag = 0.035f; BrakeDecel = 5.5f; Radius2D = 3.4f; CamDist = 14.f;
	Bucket.Width = 2.9f; Bucket.Capacity = 3.2f * (1.f + 0.15f * UpTool);
	FrontP = Pivot(Body, FVector::ZeroVector);
	RearP = Pivot(Body, FVector::ZeroVector);
	AddWheel(FVector2D(1.65f, -1.05f), 0.8f, 0.6f, false, true, true); AddWheel(FVector2D(1.65f, 1.05f), 0.8f, 0.6f, false, true, true);
	AddWheel(FVector2D(-1.65f, -1.05f), 0.8f, 0.6f, false, true, false); AddWheel(FVector2D(-1.65f, 1.05f), 0.8f, 0.6f, false, true, false);
	Part(RearP, EShape::Cube, FVector(-1.2f, 0, 1.0f), FVector(3.0f, 1.0f, 0.5f), FRotator::ZeroRotator, DarkMID);
	Part(RearP, EShape::Cube, FVector(-2.25f, 0, 1.55f), FVector(1.9f, 1.8f, 1.15f), FRotator::ZeroRotator, PaintMID);
	Part(RearP, EShape::Cube, FVector(-3.2f, 0, 1.15f), FVector(0.4f, 2.2f, 0.9f), FRotator::ZeroRotator, PaintMID);
	for (int32 k = 0; k < 6; ++k) Part(RearP, EShape::Cube, FVector(-3.42f, 0, 0.85f + k * 0.12f), FVector(0.03f, 1.8f, 0.04f), FRotator::ZeroRotator, DarkMID);
	HoodPivot = Pivot(RearP, FVector(-3.1f, 0, 2.15f));
	Part(HoodPivot, EShape::Cube, FVector(0.85f, 0, 0), FVector(1.8f, 1.82f, 0.05f), FRotator::ZeroRotator, PaintMID);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Part(RearP, EShape::Cube, FVector(-1.65f, s * 1.05f, 1.75f), FVector(1.6f, 0.75f, 0.05f), FRotator::ZeroRotator, PaintMID);
		Part(FrontP, EShape::Cube, FVector(1.65f, s * 1.05f, 1.75f), FVector(1.3f, 0.75f, 0.05f), FRotator::ZeroRotator, PaintMID);
	}
	AddCab(RearP, FVector(-0.55f, 0, 2.6f), FVector(1.5f, 1.6f, 1.6f));
	Part(RearP, EShape::Cylinder, FVector(-2.0f, 0.5f, 2.4f), FVector(0.13f, 0.13f, 0.6f), FRotator::ZeroRotator, DarkMID);
	Part(FrontP, EShape::Cube, FVector(1.2f, 0, 1.05f), FVector(2.2f, 0.95f, 0.6f), FRotator::ZeroRotator, DarkMID);
	Part(FrontP, EShape::Cube, FVector(0.75f, 0, 1.75f), FVector(0.4f, 0.9f, 1.0f), FRotator::ZeroRotator, PaintMID);
	LiftP = Pivot(FrontP, FVector(0.9f, 0, 2.1f), FRotator(LiftA, 0, 0));
	for (int32 s = -1; s <= 1; s += 2) Seg2(this, LiftP, FVector(0, s * 0.72f, 0), FVector(ArmLen, s * 0.72f, 0), 0.18f, 0.42f, PaintMID);
	Part(LiftP, EShape::Cube, FVector(ArmLen * 0.55f, 0, 0), FVector(0.3f, 1.4f, 0.3f), FRotator::ZeroRotator, PaintMID);
	BucketP = Pivot(LiftP, FVector(ArmLen, 0, 0));
	const float W = Bucket.Width;
	MeshPart(BucketP, FRWMeshGen::LoaderBucket(W, 1.25f, 1.05f), FVector::ZeroVector, FRotator::ZeroRotator, PaintMID);
	Part(BucketP, EShape::Cube, FVector(1.27f, 0, -0.36f), FVector(0.12f, W, 0.05f), FRotator::ZeroRotator, SteelMID);
	HeapMID = HeapMat2(this);
	Heap = MeshPart(BucketP, FRWMeshGen::SoilLump(3), FVector(0.55f, 0, -0.1f), FRotator::ZeroRotator, HeapMID, FVector(1.1f, W * 0.9f, 0.6f));
	Heap->SetVisibility(false);
	for (int32 s = -1; s <= 1; s += 2) Cyls.Add(MakeCyl(FrontP, FVector(0.35f, s * 0.55f, 1.2f), LiftP, FVector(1.1f, s * 0.55f, -0.25f), 0.12f, 1.1f));
	Cyls.Add(MakeCyl(FrontP, FVector(0.9f, 0, 2.6f), BucketP, FVector(-0.05f, 0, 0.55f), 0.11f, 1.4f));
	AddLamp(FrontP, FVector(0.95f, -0.45f, 2.3f), FRotator(-8, 0, 0), 10000, false);
	AddLamp(FrontP, FVector(0.95f, 0.45f, 2.3f), FRotator(-8, 0, 0), 10000, false);
	LastLip = LipWorld();
}

FVector ARWLoader::LipWorld() const
{
	return BucketP->GetComponentTransform().TransformPosition(FVector(1.27f, 0, -0.36f) * M2CM) * CM2M;
}

FString ARWLoader::HelpText() const
{
	return TR(TEXT("W/S drive  A/D articulated steer  R/F lift arm  Y/H bucket dump/rack back  Space brake  I engine  C camera  Enter exit"));
}

FString ARWLoader::ToolText() const
{
	return TRF(TEXT("Arm {0} deg  bucket {1} deg  load {2} / {3} m3 ({4} t {5})"), RWNum(LiftA), RWNum(TiltA), RWNum(Bucket.Load.Total(), 2), RWNum(Bucket.Capacity, 1), RWNum(Bucket.Load.MassKg() / 1000.f, 1),
		Bucket.Load.Total() > 0.02f ? TR(SoilName(Bucket.Load.Dominant(), Bucket.Load.Moist)) : TR(TEXT("empty")));
}

bool ARWLoader::GradePoint(FVector& Out) const { Out = LipWorld(); return true; }

void ARWLoader::WorkTick(float Dt)
{
	const float H = HydSpeedScale();
	Bucket.ForceLimitN = EmptyMass * GRAV * 0.8f; // a loader's breakout force is about its own weight
	const float Sc = FRWSoilMech::HydSpeedScale(Bucket.Resist * 0.5f);
	const float LoadF = FMath::Clamp(1.f - Bucket.Load.MassKg() / 12000.f, 0.4f, 1.f);
	VLift = FMath::FInterpTo(VLift, InA1 * 20.f * H * (InA1 > 0 ? LoadF * Sc : 1.f), Dt, 6.f);
	VTilt = FMath::FInterpTo(VTilt, -InA3 * 40.f * H * Sc, Dt, 7.f);
	HydLoad = 0;
	LiftA += VLift * Dt; TiltA += VTilt * Dt;
	if (LiftA < -48.f || LiftA > 45.f) { HydLoad = 1.15f; LiftA = FMath::Clamp(LiftA, -48.f, 45.f); }
	if (TiltA < -50.f || TiltA > 48.f) { HydLoad = 1.15f; TiltA = FMath::Clamp(TiltA, -50.f, 48.f); }
	LiftP->SetRelativeRotation(FRotator(LiftA, 0, 0));
	BucketP->SetRelativeRotation(FRotator(TiltA - LiftA, 0, 0));
	FrontP->SetRelativeRotation(FRotator(0, Artic * 0.5f, 0));
	RearP->SetRelativeRotation(FRotator(0, -Artic * 0.5f, 0));
	const FVector Lip = LipWorld();
	const FVector Vel = (Lip - LastLip) / Dt;
	LastLip = Lip;
	const FTransform BT = BucketP->GetComponentTransform();
	const FVector Heel = BT.TransformPosition(FVector(0.1f, 0, -0.36f) * M2CM) * CM2M;
	const FVector Lat = BT.TransformVectorNoScale(FVector(0, 1, 0));
	const FVector Mouth = BT.TransformVectorNoScale(FVector(0.6f, 0, 0.8f).GetSafeNormal());
	const float R = Bucket.Dig(Terrain, Lip, Heel, Lat, Vel, Mouth, H, Dt);
	DrawbarLoad = FMath::Min(Bucket.DigHorizN, 160000.f); // driving the bucket into the pile: the soil pushes back on the machine
	const float Sp = Bucket.Spill(Fx, (Lip + Heel) * 0.5f + FVector(0, 0, 0.2f), Vel, Mouth, Dt);
	Synth->Scrape.store(FMath::Clamp(Bucket.CutRate * 0.6f, 0.f, 1.f));
	Synth->Pour.store(FMath::Clamp(Sp * 0.5f, 0.f, 1.f));
	Synth->Rock.store(Bucket.bBlocked ? 0.6f : 0.f);
	const float Reach = FVector::Dist2D(Lip, LocalToWorldM(FVector(1.65f, 0, 0)));
	if (Bucket.Load.MassKg() * Reach > EmptyMass * 0.55f * 1.65f) Warning = TEXT("REAR WHEELS LIGHT - lower the load");
	const float Flow = FMath::Abs(VLift) / 20.f + FMath::Abs(VTilt) / 40.f;
	HydLoad = FMath::Max(HydLoad, FMath::Clamp(Flow * 0.6f + R * 0.3f, 0.f, 1.3f));
	WorkKW = PowerKW * 0.5f * FMath::Clamp(Flow * 0.6f + R * 0.2f, 0.f, 1.f);
	if (TreeHitter && FMath::Abs(Speed) > 0.5f) TreeHitter(Lip + FVector(0, 0, 0.5f), 1.4f, Fwd2() * Speed, 0.6f); // (the bucket's height around its lip)
}

void ARWLoader::VisualTick(float Dt)
{
	const float F = Bucket.Load.Total() / FMath::Max(Bucket.Capacity, 0.01f);
	Heap->SetVisibility(F > 0.01f);
	if (F > 0.01f)
	{
		const float Ff = FMath::Clamp(F, 0.f, 1.3f);
		Heap->SetRelativeScale3D(FVector(1.15f * FMath::Sqrt(Ff), Bucket.Width * 0.9f, FMath::Max(0.7f * Ff, 0.01f)));
		const FSoilProps& S = SoilProps(Bucket.Load.Dominant());
		FRWSoilLook::Apply(HeapMID, Bucket.Load.Dominant(), Bucket.Load.Moist); (void)S;
	}
}

void ARWLoader::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << LiftA << TiltA;
	for (int32 m = 0; m < SOIL_COUNT; ++m) Ar << Bucket.Load.Vol[m];
}

// --------------------------------------------------------------------------------------------
// Motor grader
// --------------------------------------------------------------------------------------------
void ARWGrader::Build()
{
	EmptyMass = 16500; PowerKW = 150; FuelCap = 400; FuelRate = 18; TyreStyle = 1;
	Ratios = {5.0f, 5.0f, 3.4f, 2.4f, 1.7f, 1.2f, 0.85f}; NumGears = 6; FinalDrive = 5.0f;
	MaxSteer = 40.f; SpringSag = 0.04f; Wheelbase = 5.9f; Radius2D = 4.2f; CamDist = 16.f;
	AddWheel(FVector2D(3.6f, -1.05f), 0.7f, 0.45f, true, false, true); AddWheel(FVector2D(3.6f, 1.05f), 0.7f, 0.45f, true, false, true);
	AddWheel(FVector2D(-1.6f, -1.05f), 0.7f, 0.45f, false, true, true); AddWheel(FVector2D(-1.6f, 1.05f), 0.7f, 0.45f, false, true, true);
	AddWheel(FVector2D(-3.0f, -1.05f), 0.7f, 0.45f, false, true, true); AddWheel(FVector2D(-3.0f, 1.05f), 0.7f, 0.45f, false, true, true);
	Seg2(this, Body, FVector(3.8f, 0, 1.25f), FVector(0.0f, 0, 1.75f), 0.45f, 0.5f, PaintMID);
	Part(Body, EShape::Cube, FVector(3.6f, 0, 0.75f), FVector(0.3f, 2.2f, 0.2f), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cube, FVector(4.0f, 0, 1.0f), FVector(0.3f, 1.6f, 0.4f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(-2.45f, 0, 1.6f), FVector(2.5f, 1.8f, 1.2f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(-2.3f, 0, 0.95f), FVector(2.4f, 1.2f, 0.4f), FRotator::ZeroRotator, DarkMID);
	HoodPivot = Pivot(Body, FVector(-3.65f, 0, 2.23f));
	Part(HoodPivot, EShape::Cube, FVector(1.15f, 0, 0), FVector(2.3f, 1.82f, 0.05f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cylinder, FVector(-2.0f, 0.5f, 2.5f), FVector(0.13f, 0.13f, 0.7f), FRotator::ZeroRotator, DarkMID);
	AddCab(Body, FVector(-0.5f, 0, 2.5f), FVector(1.6f, 1.7f, 1.7f));
	Part(Body, EShape::Cylinder, FVector(BladeX, 0, 1.05f), FVector(1.9f, 1.9f, 0.1f), FRotator::ZeroRotator, DarkMID);
	Seg2(this, Body, FVector(3.4f, 0, 1.0f), FVector(BladeX, 0, 1.05f), 0.25f, 0.2f, DarkMID);
	BladeP = Pivot(Root, FVector(BladeX, 0, BladeH), FRotator(0, BladeYaw, 0));
	Part(BladeP, EShape::Cube, FVector(0, 0, 0.32f), FVector(0.08f, BladeW, 0.62f), FRotator(-12, 0, 0), PaintMID);
	Part(BladeP, EShape::Cube, FVector(0.06f, 0, 0.03f), FVector(0.1f, BladeW, 0.05f), FRotator::ZeroRotator, SteelMID);
	Part(BladeP, EShape::Cube, FVector(-0.25f, 0, 0.55f), FVector(0.3f, 1.6f, 0.15f), FRotator::ZeroRotator, DarkMID);
	for (int32 s = -1; s <= 1; s += 2) Cyls.Add(MakeCyl(Body, FVector(BladeX + 0.6f, s * 0.45f, 1.85f), BladeP, FVector(-0.2f, s * 0.7f, 0.65f), 0.08f, 0.9f));
	AddLamp(Body, FVector(4.1f, -0.6f, 1.3f), FRotator(-5, 0, 0), 11000, false);
	AddLamp(Body, FVector(4.1f, 0.6f, 1.3f), FRotator(-5, 0, 0), 11000, false);
}

FString ARWGrader::HelpText() const
{
	return TR(TEXT("W/S drive  A/D steer  R/F blade height  T/G blade angle  V auto-grade to design  I engine  C camera  Enter exit"));
}

FString ARWGrader::ToolText() const
{
	return TRF(TEXT("Moldboard {0} m  angle {1} deg  carrying {2} m3  auto-grade {3}"), RWNum(BladeH, 2), RWNum(BladeYaw), RWNum(CarriedLoad.Total(), 2), bAutoGrade ? TR(TEXT("ON")) : TR(TEXT("off")));
}

bool ARWGrader::GradePoint(FVector& Out) const { Out = LocalToWorldM(FVector(BladeX, 0, BladeH)); return true; }

void ARWGrader::WorkTick(float Dt)
{
	const float H = HydSpeedScale();
	BladeVel = FMath::FInterpTo(BladeVel, InA1 * 0.3f * H, Dt, 8.f);
	BladeH = FMath::Clamp(BladeH + BladeVel * Dt, -0.35f, 0.8f);
	BladeYaw = FMath::Clamp(BladeYaw + InA2 * 20.f * H * Dt, -45.f, 45.f);
	if (bAutoGrade && DesignGrade)
	{
		// machine control: hold the cutting edge on the design surface
		float Z;
		const FVector C = LocalToWorldM(FVector(BladeX, 0, 0));
		if (DesignGrade(C, Z)) BladeH = FMath::FInterpTo(BladeH, FMath::Clamp(Z - C.Z, -0.35f, 0.8f), Dt, 3.f);
	}
	HydLoad = FMath::Abs(BladeVel) / 0.3f * 0.6f;
	if (Speed < 0.15f) { DrawbarLoad = 0; return; }
	const float Th = FMath::DegreesToRadians(BladeYaw);
	const FVector2D DirY(-FMath::Sin(Th), FMath::Cos(Th));
	const FVector2D C(BladeX, 0);
	FVector2D A = C + DirY * BladeW * 0.5f, B = C - DirY * BladeW * 0.5f;
	if (B.X > A.X) Swap(A, B); // A = leading end
	const int32 NS = FMath::CeilToInt(BladeW / 0.25f);
	float Moved = 0;
	TArray<int32, TInlineAllocator<32>> Seen;
	for (int32 k = 0; k <= NS; ++k)
	{
		const FVector2D P = FMath::Lerp(A, B, k / float(NS));
		const FVector W = LocalToWorldM(FVector(P.X, P.Y, BladeH));
		if (!Terrain->InBounds(W.X, W.Y)) continue;
		const int32 i = Terrain->IndexAt(W.X, W.Y);
		if (Seen.Contains(i)) continue;
		Seen.Add(i);
		const float E = Terrain->Height[i] - W.Z;
		if (E > 0.f)
		{
			const float Before = CarriedLoad.Total();
			Terrain->RemoveAt(i, FMath::Min(E, 0.12f), CarriedLoad);
			Moved += CarriedLoad.Total() - Before;
		}
		else if (E < -0.008f && CarriedLoad.Total() > 0.f)
		{
			FPayload Fill = CarriedLoad.Take(FMath::Min(-E * ARWTerrain::CellArea * 1.15f, CarriedLoad.Total()));
			Terrain->DepositPayloadAt(i, Fill);
		}
	}
	// windrow off the trailing end
	if (CarriedLoad.Total() > 0.f)
	{
		const FVector2D Out = B + (B - C).GetSafeNormal() * 0.6f;
		const FVector W = LocalToWorldM(FVector(Out.X, Out.Y, 0));
		if (Terrain->InBounds(W.X, W.Y))
		{
			Terrain->DepositDisc(W.X, W.Y, 0.5f, CarriedLoad);
			// the windrow settles at once to its angle of repose (as the dozer's pile does), not onto the moldboard's own line
			const FTransform MT = GetActorTransform();
			Terrain->SettleAround(W.X, W.Y, 1.2f, 3, [&](int32 j)
			{
				const FVector Lp = MT.InverseTransformPosition(FVector(Terrain->PX(j % ARWTerrain::N), Terrain->PX(j / ARWTerrain::N), Terrain->Height[j]) * M2CM) * CM2M;
				return FMath::PointDistToSegment(FVector(Lp.X, Lp.Y, 0.f), FVector(A.X, A.Y, 0.f), FVector(B.X, B.Y, 0.f)) < 0.3f;
			});
		}
		CarriedLoad.Clear();
	}
	Carried = Moved / Dt;
	DrawbarLoad = FMath::Min(Moved / Dt * 30000.f, 120000.f);
	Synth->Scrape.store(FMath::Clamp(Moved / Dt, 0.f, 1.f));
}

void ARWGrader::VisualTick(float Dt)
{
	BladeP->SetRelativeLocation(FVector(BladeX, 0, BladeH) * M2CM);
	BladeP->SetRelativeRotation(FRotator(0, BladeYaw, 0));
}

void ARWGrader::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << BladeH << BladeYaw;
}

// --------------------------------------------------------------------------------------------
// Vibratory roller
// --------------------------------------------------------------------------------------------
void ARWRoller::Build()
{
	EmptyMass = 12000; PowerKW = 100; FuelCap = 250; FuelRate = 14; TyreStyle = 1;
	Drive = EDrive::Articulated; MaxSteer = 35.f; Wheelbase = 3.0f;
	Ratios = {28.f, 28.f, 14.f}; NumGears = 2; FinalDrive = 1.f;
	SpringSag = 0.03f; Radius2D = 3.f; CamDist = 13.f;
	{
		FRWWheel D;
		D.Local = FVector2D(DrumX, 0); D.Radius = DrumR; D.Width = DrumW; D.bDriven = true; D.bFront = true;
		D.Pivot = Pivot(Root, FVector(DrumX, 0, DrumR));
		D.Spinner = Pivot(D.Pivot, FVector::ZeroVector);
		Part(D.Spinner, EShape::Cylinder, FVector::ZeroVector, FVector(2 * DrumR, 2 * DrumR, DrumW), FRotator(0, 0, 90), SteelMID);
		for (int32 s = -1; s <= 1; s += 2)
			for (int32 k = 0; k < 6; ++k)
			{
				const float A = k / 6.f * 2 * PI;
				Part(D.Spinner, EShape::Cube, FVector(FMath::Cos(A) * DrumR * 0.6f, s * DrumW * 0.5f, FMath::Sin(A) * DrumR * 0.6f), FVector(0.25f, 0.04f, 0.08f), FRotator(-FMath::RadiansToDegrees(A), 0, 0), DarkMID);
			}
		Wheels.Add(D);
	}
	AddWheel(FVector2D(-1.45f, -0.95f), 0.75f, 0.6f, false, true, false);
	AddWheel(FVector2D(-1.45f, 0.95f), 0.75f, 0.6f, false, true, false);
	Part(Body, EShape::Cube, FVector(DrumX, 0, 1.75f), FVector(1.0f, 2.45f, 0.3f), FRotator::ZeroRotator, PaintMID);
	for (int32 s = -1; s <= 1; s += 2) Part(Body, EShape::Cube, FVector(DrumX, s * 1.2f, 1.05f), FVector(0.9f, 0.08f, 1.3f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(DrumX + 0.85f, 0, 0.6f), FVector(0.06f, 2.2f, 0.1f), FRotator(-35, 0, 0), DarkMID); // scraper bar
	Part(Body, EShape::Cube, FVector(0.4f, 0, 1.3f), FVector(1.1f, 0.8f, 0.6f), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cube, FVector(-1.5f, 0, 1.45f), FVector(2.0f, 1.9f, 1.0f), FRotator::ZeroRotator, PaintMID);
	HoodPivot = Pivot(Body, FVector(-2.5f, 0, 1.97f));
	Part(HoodPivot, EShape::Cube, FVector(1.0f, 0, 0), FVector(2.0f, 1.92f, 0.05f), FRotator::ZeroRotator, PaintMID);
	AddCab(Body, FVector(-0.4f, 0, 2.45f), FVector(1.3f, 1.45f, 1.5f), true);
	AddLamp(Body, FVector(DrumX + 0.5f, -0.9f, 1.95f), FRotator(-10, 0, 0), 9000, false);
	AddLamp(Body, FVector(DrumX + 0.5f, 0.9f, 1.95f), FRotator(-10, 0, 0), 9000, false);
}

FString ARWRoller::HelpText() const
{
	return TR(TEXT("W/S drive  A/D steer  V vibration on/off  Space brake  I engine  C camera  Enter exit"));
}

FString ARWRoller::ToolText() const
{
	float C = 0;
	if (Terrain) C = Terrain->SurfaceComp(Terrain->IndexAt(LocalToWorldM(FVector(DrumX, 0, 0)).X, LocalToWorldM(FVector(DrumX, 0, 0)).Y));
	return TRF(TEXT("Vibration {0}   compaction under drum {1}%   passes {2}"), bVibe ? TR(TEXT("ON")) : TR(TEXT("off")), RWNum(C * 100.f), FString::FromInt(Passes));
}

void ARWRoller::WorkTick(float Dt)
{
	VibrationLevel = (bVibe && bEngineOn) ? 1.f : 0.f;
	Synth->Hammer.store(bVibe && bEngineOn ? 0.25f : 0.f);
	const FVector DC = LocalToWorldM(FVector(DrumX * FMath::Cos(FMath::DegreesToRadians(Artic * 0.5f)), DrumX * FMath::Sin(FMath::DegreesToRadians(Artic * 0.5f)), 0));
	const FVector2D Here(DC.X, DC.Y);
	if (FVector2D::Distance(Here, LastPass) < 0.35f) return;
	LastPass = Here;
	++Passes;
	const float Amt = bVibe && bEngineOn ? 0.34f : 0.14f;
	const FVector Lat = Right2();
	const int32 N = FMath::CeilToInt(DrumW / ARWTerrain::CS);
	for (int32 k = 0; k <= N; ++k)
	{
		const FVector P = DC + Lat * ((k / float(N) - 0.5f) * DrumW);
		if (!Terrain->InBounds(P.X, P.Y)) continue;
		const int32 i = Terrain->IndexAt(P.X, P.Y);
		Terrain->CompactAt(i, Amt);
		Terrain->ClearGrass(i, 0.5f);
	}
	if (bVibe && Fx && GroundMoist < 0.3f && FMath::FRand() < 0.3f) Fx->SpawnDust(DC + FVector(0, 0, 0.2f), 0.6f, FVector::ZeroVector);
}

void ARWRoller::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << bVibe;
}

// --------------------------------------------------------------------------------------------
// Asphalt paver
// --------------------------------------------------------------------------------------------
void ARWPaver::Build()
{
	EmptyMass = 17500; PowerKW = 120; FuelCap = 250; FuelRate = 16;
	MaxSpeedF = 1.3f; MaxSpeedR = 0.8f; SpringSag = 0.02f; Wheelbase = 2.6f; Radius2D = 3.2f; CamDist = 13.f;
	AddTracks(2.7f, 2.0f, 0.32f, 0.6f, 4);
	// hopper with wings
	Part(Body, EShape::Cube, FVector(1.7f, 0, 0.75f), FVector(1.5f, 1.4f, 0.08f), FRotator::ZeroRotator, SteelMID);
	for (int32 s = -1; s <= 1; s += 2) Part(Body, EShape::Cube, FVector(1.7f, s * 1.25f, 1.15f), FVector(1.5f, 0.06f, 0.9f), FRotator(0, 0, s * -30.f), PaintMID);
	Part(Body, EShape::Cube, FVector(2.45f, 0, 0.9f), FVector(0.1f, 2.4f, 0.3f), FRotator::ZeroRotator, DarkMID); // push rollers
	Part(Body, EShape::Cube, FVector(-0.2f, 0, 1.25f), FVector(1.9f, 2.4f, 0.9f), FRotator::ZeroRotator, PaintMID);
	HoodPivot = Pivot(Body, FVector(-1.15f, 0, 1.72f));
	Part(HoodPivot, EShape::Cube, FVector(0.95f, 0, 0), FVector(1.9f, 2.4f, 0.05f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(-1.4f, 0, 1.9f), FVector(1.0f, 2.6f, 0.08f), FRotator::ZeroRotator, DarkMID); // operator platform
	Part(Body, EShape::Cube, FVector(-1.2f, -0.6f, 2.35f), FVector(0.4f, 0.6f, 0.8f), FRotator::ZeroRotator, DarkMID); // console
	Part(Body, EShape::Cube, FVector(-1.5f, 0, 3.35f), FVector(1.8f, 2.6f, 0.06f), FRotator::ZeroRotator, PaintMID); // canopy
	for (int32 s = -1; s <= 1; s += 2) Part(Body, EShape::Cube, FVector(-1.5f, s * 1.25f, 2.65f), FVector(0.06f, 0.06f, 1.4f), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cylinder, FVector(-0.6f, 0.9f, 2.4f), FVector(0.12f, 0.12f, 1.3f), FRotator::ZeroRotator, DarkMID);
	// auger + screed
	Part(Body, EShape::Cylinder, FVector(-2.0f, 0, 0.3f), FVector(0.35f, 0.35f, 2.6f), FRotator(0, 0, 90), SteelMID);
	ScreedL = Pivot(Body, FVector(-2.5f, -0.75f, 0.25f));
	ScreedR = Pivot(Body, FVector(-2.5f, 0.75f, 0.25f));
	Part(ScreedL, EShape::Cube, FVector(0, -0.0f, 0.2f), FVector(0.7f, 1.5f, 0.5f), FRotator::ZeroRotator, PaintMID);
	Part(ScreedR, EShape::Cube, FVector(0, 0.0f, 0.2f), FVector(0.7f, 1.5f, 0.5f), FRotator::ZeroRotator, PaintMID);
	Part(ScreedL, EShape::Cube, FVector(0, 0, -0.06f), FVector(0.6f, 1.5f, 0.04f), FRotator::ZeroRotator, SteelMID);
	Part(ScreedR, EShape::Cube, FVector(0, 0, -0.06f), FVector(0.6f, 1.5f, 0.04f), FRotator::ZeroRotator, SteelMID);
	UMaterialInstanceDynamic* HM = HeapMat2(this);
	HM->SetVectorParameterValue(TEXT("Color"), SoilProps(ESoil::Asphalt).Color);
	HopperHeap = MeshPart(Body, FRWMeshGen::SoilLump(4), FVector(1.7f, 0, 0.9f), FRotator::ZeroRotator, HM, FVector(1.4f, 2.2f, 0.6f));
	HopperHeap->SetVisibility(false);
	CabRoot = Pivot(Body, FVector(-1.5f, 0, 2.2f));
	CabCam->AttachToComponent(CabRoot, FAttachmentTransformRules::KeepRelativeTransform);
	CabCam->SetRelativeLocation(FVector(0.2f, 0, 0.6f) * M2CM);
	AddLamp(Body, FVector(-0.6f, -1.2f, 3.3f), FRotator(-35, 180, 0), 9000, true);
	AddLamp(Body, FVector(-0.6f, 1.2f, 3.3f), FRotator(-35, 180, 0), 9000, true);
}

FString ARWPaver::HelpText() const
{
	return TR(TEXT("W/S crawl  A/D steer  V paving on/off  R/F mat thickness  T/G screed width  I engine  C camera  Enter exit"));
}

FString ARWPaver::ToolText() const
{
	return TRF(TEXT("Paving {0}   mat {1} mm   width {2} m   hopper {3} / {4} m3   laid {5} m2"), bPaving ? TR(TEXT("ON")) : TR(TEXT("off")), RWNum(Thick * 1000.f), RWNum(ScreedW, 1), RWNum(Hopper.Total(), 1), RWNum(HopperCap), RWNum(Laid));
}

bool ARWPaver::TryReceive(const FVector& P, ESoil M, float Vol, float Moist)
{
	const FVector L = WorldToBodyM(P);
	if (L.X < 0.8f || L.X > 2.8f || FMath::Abs(L.Y) > 1.7f || L.Z < 0.2f || L.Z > 4.f) return false;
	if (Hopper.Total() > HopperCap * 1.2f) return false;
	Hopper.Add(M, Vol, Moist);
	return true;
}

void ARWPaver::WorkTick(float Dt)
{
	Thick = FMath::Clamp(Thick + InA1 * 0.02f * Dt, 0.03f, 0.12f);
	ScreedW = FMath::Clamp(ScreedW + InA2 * 0.6f * Dt, 2.5f, 4.75f);
	if (!bPaving || Speed < 0.02f) return;
	if (Hopper.Total() < 0.01f) { Warning = TEXT("Hopper empty - tip asphalt into the hopper"); return; }
	const FVector SC = LocalToWorldM(FVector(-2.75f, 0, 0));
	const FVector2D Here(SC.X, SC.Y);
	if (FVector2D::Distance(Here, LastLay) < 0.3f) return;
	LastLay = Here;
	const FVector Lat = Right2(), F = Fwd2();
	const int32 N = FMath::CeilToInt(ScreedW / ARWTerrain::CS);
	for (int32 k = 0; k <= N; ++k)
	{
		const FVector P = SC + Lat * ((k / float(N) - 0.5f) * ScreedW);
		if (!Terrain->InBounds(P.X, P.Y)) continue;
		const int32 i = Terrain->IndexAt(P.X, P.Y);
		const float Hh = Terrain->Height[i];
		float Target;
		float DZ;
		if (DesignGrade && DesignGrade(P, DZ)) Target = DZ + Thick; // design returns the grade of the layer below the mat
		else
		{
			// floating screed averages the ground under the tractor
			float Avg = 0;
			for (int32 a = 0; a < 4; ++a) { const FVector Q = P + F * (a * 1.3f); Avg += Terrain->HeightAt(Q.X, Q.Y); }
			Target = Avg / 4.f + Thick;
		}
		const float Need = FMath::Clamp(Target - Hh, Thick * 0.4f, Thick * 2.5f);
		FPayload Out = Hopper.Take(Need * ARWTerrain::CellArea * (1.f + 0.2f * 0.75f));
		for (int32 m = 0; m < SOIL_COUNT; ++m) if (Out.Vol[m] > 0) Terrain->DepositAt(i, (ESoil)m, Out.Vol[m], 0.05f, 190);
	}
	Laid += ScreedW * 0.3f;
}

void ARWPaver::VisualTick(float Dt)
{
	ScreedL->SetRelativeLocation(FVector(-2.5f, -(ScreedW * 0.5f - 0.75f), 0.25f) * M2CM);
	ScreedR->SetRelativeLocation(FVector(-2.5f, (ScreedW * 0.5f - 0.75f), 0.25f) * M2CM);
	const float F = Hopper.Total() / HopperCap;
	HopperHeap->SetVisibility(F > 0.01f);
	HopperHeap->SetRelativeScale3D(FVector(1.4f, 2.2f, FMath::Max(1.0f * F, 0.01f)));
}

void ARWPaver::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << Thick << ScreedW << Laid;
	for (int32 m = 0; m < SOIL_COUNT; ++m) Ar << Hopper.Vol[m];
}

// --------------------------------------------------------------------------------------------
// Water truck
// --------------------------------------------------------------------------------------------
void ARWWaterTruck::Build()
{
	EmptyMass = 10500; PowerKW = 250; FuelCap = 300; FuelRate = 25;
	Ratios = {6.5f, 7.0f, 5.0f, 3.6f, 2.6f, 1.9f, 1.4f, 1.0f, 0.8f}; NumGears = 8; FinalDrive = 4.3f;
	SpringSag = 0.07f; MaxSteer = 36.f; Radius2D = 3.6f; CamDist = 15.f;
	TruckChassis(this, 3.6f);
	Part(Body, EShape::Cylinder, FVector(-0.6f, 0, 2.0f), FVector(2.1f, 2.0f, 4.6f), FRotator(90, 0, 0), PaintMID);
	Part(Body, EShape::Cube, FVector(-0.6f, 0, 1.2f), FVector(4.4f, 1.6f, 0.3f), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cylinder, FVector(-3.2f, 0, 0.75f), FVector(0.12f, 0.12f, 2.6f), FRotator(0, 0, 90), SteelMID); // spray bar
	for (int32 k = -2; k <= 2; ++k) Part(Body, EShape::Cone, FVector(-3.25f, k * 0.55f, 0.65f), FVector(0.1f, 0.1f, 0.12f), FRotator(180, 0, 0), SteelMID);
	Part(Body, EShape::Cylinder, FVector(-0.6f, 0, 3.05f), FVector(0.6f, 0.6f, 0.12f), FRotator::ZeroRotator, SteelMID);
}

FString ARWWaterTruck::HelpText() const
{
	return TR(TEXT("W/S drive  A/D steer  V spray on/off  U refill at river or yard  I engine  C camera  Enter exit"));
}

FString ARWWaterTruck::ToolText() const
{
	return TRF(TEXT("Spray {0}   tank {1} / {2} L"), bSpray ? TR(TEXT("ON")) : TR(TEXT("off")), RWNum(Water), RWNum(WaterCap));
}

void ARWWaterTruck::WorkTick(float Dt)
{
	if (!bSpray) return;
	if (Water <= 0.f) { Warning = TEXT("Water tank empty"); bSpray = false; return; }
	Water = FMath::Max(0.f, Water - 28.f * Dt);
	HydLoad = 0.4f;
	const FVector Lat = Right2();
	for (int32 k = 0; k < 3; ++k)
	{
		const FVector P = LocalToWorldM(FVector(-3.3f, FMath::FRandRange(-1.3f, 1.3f), 0.6f));
		if (Fx) Fx->SpawnWater(P, -Fwd2() * 2.f + Fwd2() * Speed + FVector(0, 0, -1.f) + Lat * FMath::FRandRange(-1.5f, 1.5f), 0.004f);
	}
	for (int32 k = -6; k <= 6; ++k)
	{
		const FVector P = LocalToWorldM(FVector(-4.2f, k * 0.5f, 0));
		if (Terrain->InBounds(P.X, P.Y)) Terrain->AddMoisture(Terrain->IndexAt(P.X, P.Y), 0.5f * Dt);
	}
}

void ARWWaterTruck::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << Water;
}

// --------------------------------------------------------------------------------------------
// Mobile crane
// --------------------------------------------------------------------------------------------
void ARWCrane::Build()
{
	EmptyMass = 36000; PowerKW = 300; FuelCap = 400; FuelRate = 30;
	Ratios = {6.5f, 7.5f, 5.2f, 3.7f, 2.6f, 1.9f, 1.35f, 1.0f}; NumGears = 7; FinalDrive = 5.0f;
	SpringSag = 0.06f; MaxSteer = 30.f; Wheelbase = 6.0f; Radius2D = 5.0f; CamDist = 24.f;
	const float R = 0.62f, W = 0.5f;
	AddWheel(FVector2D(3.0f, -1.2f), R, W, true, false, true); AddWheel(FVector2D(3.0f, 1.2f), R, W, true, false, true);
	AddWheel(FVector2D(1.55f, -1.2f), R, W, true, false, true); AddWheel(FVector2D(1.55f, 1.2f), R, W, true, false, true);
	AddWheel(FVector2D(-1.6f, -1.2f), R, W, false, true, true); AddWheel(FVector2D(-1.6f, 1.2f), R, W, false, true, true);
	AddWheel(FVector2D(-3.05f, -1.2f), R, W, false, true, true); AddWheel(FVector2D(-3.05f, 1.2f), R, W, false, true, true);
	Part(Body, EShape::Cube, FVector(0, 0, 1.2f), FVector(8.8f, 2.5f, 0.75f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(3.85f, -0.6f, 2.0f), FVector(1.4f, 1.1f, 1.2f), FRotator::ZeroRotator, PaintMID); // carrier cab
	Part(Body, EShape::Cube, FVector(4.56f, -0.6f, 2.1f), FVector(0.02f, 0.95f, 0.7f), FRotator::ZeroRotator, GlassMID);
	AddLamp(Body, FVector(4.45f, -1.0f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	AddLamp(Body, FVector(4.45f, 1.0f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	for (int32 a = 0; a < 2; ++a)
		for (int32 s = -1; s <= 1; s += 2)
		{
			USceneComponent* B = Pivot(Body, FVector(a == 0 ? 2.3f : -2.4f, s * 1.0f, 1.0f));
			Part(B, EShape::Cube, FVector(0, s * 0.3f, 0), FVector(0.35f, 0.9f, 0.3f), FRotator::ZeroRotator, PaintMID);
			Part(B, EShape::Cylinder, FVector(0, s * 0.75f, -0.4f), FVector(0.2f, 0.2f, 0.9f), FRotator::ZeroRotator, ChromeMID);
			Part(B, EShape::Cylinder, FVector(0, s * 0.75f, -0.9f), FVector(0.6f, 0.6f, 0.08f), FRotator::ZeroRotator, DarkMID);
			OutriggerBeams.Add(B);
		}
	Upper = Pivot(Body, FVector(-1.4f, 0, 1.6f));
	Part(Upper, EShape::Cylinder, FVector(0, 0, 0.05f), FVector(2.0f, 2.0f, 0.15f), FRotator::ZeroRotator, DarkMID);
	Part(Upper, EShape::Cube, FVector(-0.5f, 0, 0.45f), FVector(3.4f, 2.4f, 0.6f), FRotator::ZeroRotator, PaintMID);
	Part(Upper, EShape::Cube, FVector(-2.2f, 0, 1.0f), FVector(0.9f, 2.4f, 1.3f), FRotator::ZeroRotator, PaintMID);
	Part(Upper, EShape::Cylinder, FVector(-1.2f, 0, 1.2f), FVector(0.6f, 0.6f, 1.2f), FRotator(0, 0, 90), SteelMID); // winch
	AddCab(Upper, FVector(0.7f, 1.0f, 1.3f), FVector(1.4f, 0.9f, 1.4f));
	BoomP = Pivot(Upper, FVector(-1.0f, 0, 1.4f), FRotator(Luff, 0, 0));
	const float Wd[3] = {0.95f, 0.8f, 0.65f};
	for (int32 k = 0; k < 3; ++k)
	{
		USceneComponent* Sct = Pivot(BoomP, FVector::ZeroVector);
		Part(Sct, EShape::Cube, FVector(5.25f, 0, 0), FVector(10.5f, Wd[k], Wd[k] * 1.1f), FRotator::ZeroRotator, k == 0 ? PaintMID : SteelMID);
		Sections.Add(Sct);
	}
	Part(Sections[2], EShape::Cylinder, FVector(10.6f, 0, 0), FVector(0.7f, 0.7f, 0.5f), FRotator(0, 0, 90), DarkMID); // head sheave
	Cyls.Add(MakeCyl(Upper, FVector(0.6f, 0, 0.6f), BoomP, FVector(4.0f, 0, -0.5f), 0.2f, 2.6f));
	RopeMesh = Part(Body, EShape::Cylinder, FVector::ZeroVector, FVector(0.03f, 0.03f, 1.f), FRotator::ZeroRotator, DarkMID, true);
	RopeMesh->SetUsingAbsoluteLocation(true); RopeMesh->SetUsingAbsoluteRotation(true); RopeMesh->SetUsingAbsoluteScale(true);
	HookP = Pivot(Body, FVector::ZeroVector);
	HookP->SetUsingAbsoluteLocation(true); HookP->SetUsingAbsoluteRotation(true);
	Part(HookP, EShape::Cube, FVector(0, 0, 0.3f), FVector(0.45f, 0.35f, 0.6f), FRotator::ZeroRotator, PaintMID);
	Part(HookP, EShape::Cylinder, FVector(0, 0, -0.15f), FVector(0.3f, 0.3f, 0.08f), FRotator(0, 0, 90), SteelMID);
}

float ARWCrane::Radius() const
{
	const FVector Tip = Sections.Num() ? Sections[2]->GetComponentTransform().TransformPosition(FVector(1060, 0, 0)) * CM2M : PosM;
	return FMath::Max(3.f, FVector::Dist2D(Tip, Upper->GetComponentLocation() * CM2M));
}

float ARWCrane::AllowedKg() const
{
	return 40000.f * FMath::Min(1.f, 3.f / Radius()) * (bOutriggers && Outrig > 0.95f ? 1.f : 0.2f);
}

FVector ARWCrane::HookWorld() const
{
	const FVector Tip = Sections[2]->GetComponentTransform().TransformPosition(FVector(1060, 0, 0)) * CM2M;
	return Tip - FVector(0, 0, Rope);
}

void ARWCrane::WorkToggle()
{
	if (FMath::Abs(Speed) > 0.2f) { Warning = TEXT("Stop before deploying outriggers"); return; }
	bOutriggers = !bOutriggers;
}

void ARWCrane::ToolCycle()
{
	if (Hooked.IsValid()) { Hooked->bCarried = false; Hooked->VelM = FVector::ZeroVector; Hooked.Reset(); return; }
	const FVector H = HookWorld();
	ARWProp* Best = nullptr; float BD = 2.5f;
	for (const TWeakObjectPtr<ARWProp>& W : ARWProp::All)
	{
		if (!W.IsValid() || W->bCarried) continue;
		const float D = FVector::Dist(W->PosM() + FVector(0, 0, 0.5f), H);
		if (D < BD) { BD = D; Best = W.Get(); }
	}
	if (Best) { Hooked = Best; Best->bCarried = true; }
	else Warning = TEXT("Nothing within reach of the hook");
}

FString ARWCrane::HelpText() const
{
	return TR(TEXT("W/S drive  A/D steer  V outriggers  Q/E slew  R/F luff boom  T/G telescope  Y/H hoist up/down  B hook/release  C camera  Enter exit"));
}

FString ARWCrane::ToolText() const
{
	const float Mass = Hooked.IsValid() ? Hooked->MassKg : 0.f;
	return TRF(TEXT("Outriggers {0}  boom {1} deg / {2} m  radius {3} m  rope {4} m  load {5} t / chart {6} t {7}"),
		bOutriggers ? TR(TEXT("SET")) : TR(TEXT("stowed")), RWNum(Luff), RWNum(Tele, 1), RWNum(Radius(), 1), RWNum(Rope, 1), RWNum(Mass / 1000.f, 1), RWNum(AllowedKg() / 1000.f, 1), Hooked.IsValid() ? Hooked->Label() : FString());
}

void ARWCrane::WorkTick(float Dt)
{
	const float H = HydSpeedScale();
	Outrig = FMath::FInterpConstantTo(Outrig, bOutriggers ? 1.f : 0.f, Dt, 0.4f * FMath::Max(H, 0.2f));
	if (Outrig > 0.05f) { Speed = 0.f; bParkBrake = true; if (FMath::Abs(InThrottle) > 0.1f) Warning = TEXT("Outriggers deployed - retract (V) to drive"); }
	const float Mass = Hooked.IsValid() ? Hooked->MassKg : 0.f;
	const bool bOver = Mass > AllowedKg();
	if (bOver) Warning = TRF(TEXT("OVERLOAD: {0} t exceeds load chart {1} t at {2} m"), RWNum(Mass / 1000.f, 1), RWNum(AllowedKg() / 1000.f, 1), RWNum(Radius(), 1));
	Slew += InA4 * 12.f * H * Dt;
	const float LuffCmd = InA1 * 5.f * H * ((bOver && InA1 < 0) ? 0.f : 1.f);
	Luff = FMath::Clamp(Luff + LuffCmd * Dt, 0.f, 80.f);
	const float TeleCmd = InA2 * 1.2f * H * ((bOver && InA2 > 0) ? 0.f : 1.f);
	Tele = FMath::Clamp(Tele + TeleCmd * Dt, 10.5f, 32.f);
	const float HoistCmd = -InA3 * 2.0f * H * ((bOver && InA3 > 0) ? 0.f : 1.f);
	Rope = FMath::Clamp(Rope + HoistCmd * Dt, 1.0f, 45.f);
	Upper->SetRelativeRotation(FRotator(0, Slew, 0));
	BoomP->SetRelativeRotation(FRotator(Luff, 0, 0));
	const float Ext = Tele - 10.5f;
	Sections[1]->SetRelativeLocation(FVector(Ext * 0.5f, 0, 0) * M2CM);
	Sections[2]->SetRelativeLocation(FVector(Ext, 0, 0) * M2CM);
	// hook can't go into the ground
	FVector Hk = HookWorld();
	const float G = Terrain->HeightAt(Hk.X, Hk.Y) + 0.4f + (Hooked.IsValid() ? 0.8f : 0.f);
	if (Hk.Z < G) { Rope -= (G - Hk.Z); Hk.Z = G; }
	const FVector Tip = Hk + FVector(0, 0, Rope);
	RopeMesh->SetWorldLocation((Tip + Hk) * 0.5f * M2CM);
	RopeMesh->SetWorldRotation(FRotator::ZeroRotator);
	RopeMesh->SetWorldScale3D(FVector(0.03f, 0.03f, FMath::Max(Rope, 0.1f)));
	HookP->SetWorldLocation(Hk * M2CM);
	HookP->SetWorldRotation(FRotator(0, Yaw + Slew, 0));
	if (Hooked.IsValid()) Hooked->SetActorLocation((Hk - FVector(0, 0, 1.0f)) * M2CM);
	const float Flow = FMath::Abs(LuffCmd) / 5.f + FMath::Abs(TeleCmd) + FMath::Abs(HoistCmd) * 0.5f + FMath::Abs(InA4) * 0.5f;
	HydLoad = FMath::Clamp(Flow * 0.5f * (0.5f + Mass / 20000.f), 0.f, 1.3f);
	WorkKW = PowerKW * 0.4f * HydLoad;
}

void ARWCrane::VisualTick(float Dt)
{
	for (int32 k = 0; k < OutriggerBeams.Num(); ++k)
	{
		const float Side = (k % 2 == 0) ? -1.f : 1.f;
		const float BaseX = k < 2 ? 2.3f : -2.4f;
		OutriggerBeams[k]->SetRelativeLocation(FVector(BaseX, Side * (1.0f + Outrig * 2.2f), 1.0f + 0.f) * M2CM);
	}
}

void ARWCrane::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << Slew << Luff << Tele << Rope << bOutriggers;
}
