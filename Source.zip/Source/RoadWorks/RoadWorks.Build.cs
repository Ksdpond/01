﻿using UnrealBuildTool;

public class RoadWorks : ModuleRules
{
	public RoadWorks(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		PublicDependencyModuleNames.AddRange(new string[] {
			"Core", "CoreUObject", "Engine", "InputCore", "ProceduralMeshComponent",
			"AudioMixer", "SignalProcessing", "ImageWrapper", "RenderCore", "RHI", "Slate", "SlateCore", "Json", "JsonUtilities", "MeshDescription", "StaticMeshDescription", "PakFile", "AssetRegistry", "Landscape", "XmlParser"
		});
		// the game's sound files (souds/*.ogg) are decoded with the engine's own Ogg Vorbis decoder
		PrivateDependencyModuleNames.Add("VorbisAudioDecoder");
		AddEngineThirdPartyPrivateStaticDependencies(Target, "UEOgg", "Vorbis", "VorbisFile");
		if (Target.bBuildEditor) PrivateDependencyModuleNames.AddRange(new string[] { "UnrealEd", "Foliage" });
	}
}
