// Fab / Quixel Megascans / Marketplace content added to the project.
// Packs added from Fab land under Content/Fab (or their own folder under Content). At start the game looks
// through the asset registry for static meshes and materials outside its own folders, sorts them by name
// (pine/spruce/fir -> conifer, oak/birch/"tree" -> broadleaf, bush/shrub, grass/fern/weed, rock/boulder/stone,
// water/river/lake materials) and uses them in place of the generated trees, grass, rocks and river water.
// Config/DefaultGame.ini [RoadWorks.Fab] can name exact assets or switch it off:
//   Conifer=/Game/Fab/.../SM_Pine.SM_Pine   (also Broadleaf, Bush, Grass, Rock, Water; several with +Conifer=...)
//   Disable=True
#pragma once

#include "CoreMinimal.h"

class UStaticMesh;
class UMaterialInterface;

struct ROADWORKS_API FRWFab
{
	static TArray<UStaticMesh*> Conifer;
	static TArray<UStaticMesh*> Broadleaf;
	static TArray<UStaticMesh*> Bush;
	static TArray<UStaticMesh*> Grass;
	static TArray<UStaticMesh*> Rock;
	static TArray<UStaticMesh*> Palm;       // coconut, windmill palm
	static TArray<UStaticMesh*> Banana;     // banana plants
	static TArray<UStaticMesh*> Understory; // low tropical plants under the trees and along the banks
	static TArray<UStaticMesh*> GroundProp; // fallen bananas, rotting leaves
	static UMaterialInterface* Water;
	static UMaterialInterface* Lake;        // calm reservoir water
	static bool bScanned;
	static void Scan();
	// name -> category ("conifer", "broadleaf", "bush", "grass", "rock", "" = not environment). Exposed for the tests.
	static FString Classify(const FString& AssetName, const FString& PackagePath);
	// scale factor that makes the mesh TargetM metres tall, and the offset (cm, unscaled) that puts its base at z = 0
	static float HeightScale(const UStaticMesh* M, float TargetM, float* OutBaseZ = nullptr);
	static FString Summary();
	// every model from the packs the map editor can place (the environment lists plus "Placeable" in the config)
	static TArray<FString> PlaceablePaths();
};
