#include "RWSoilMech.h"

// cohesion of each soil at full compaction when dry, kPa (order as ESoil, typical published ranges)
static float BaseCohesionKPa(ESoil M)
{
	switch (M)
	{
	case ESoil::DrySoil: return 30.f;
	case ESoil::WetSoil: return 20.f;
	case ESoil::Mud: return 6.f;
	case ESoil::Sand: return 2.f;
	case ESoil::Gravel: return 5.f;
	case ESoil::SmallRock: return 15.f;
	case ESoil::LargeRock: return 200.f;
	case ESoil::Clay: return 80.f;
	case ESoil::Laterite: return 60.f;
	case ESoil::Compacted: return 90.f;
	case ESoil::Asphalt: return 300.f;
	default: return 20.f;
	}
}

FRWSoilStrength FRWSoilMech::Strength(ESoil M, float Moist, float Comp)
{
	const FSoilProps& P = SoilProps(M);
	Moist = FMath::Clamp(Moist, 0.f, 1.f);
	Comp = FMath::Clamp(Comp, 0.f, 1.f);
	FRWSoilStrength S;
	S.PhiDeg = FMath::Min(FMath::Lerp((float)P.Repose, (float)P.WetRepose, Moist) + 8.f * Comp, 48.f);
	S.DeltaDeg = 0.6f * S.PhiDeg;
	// loose soil barely holds together; the bonds of natural and compacted ground are what the teeth have to break
	float C = BaseCohesionKPa(M) * (0.08f + 1.3f * Comp * Comp);
	if (M == ESoil::Sand) C *= FMath::Clamp(4.f * Moist * (1.f - Moist) + 0.1f, 0.1f, 1.f); // damp sand holds together, dry or soaked does not
	else C *= FMath::Lerp(1.f, 0.25f, Moist); // water softens soil and clay
	S.Cohesion = C * 1000.f;
	S.Adhesion = 0.5f * S.Cohesion * FMath::Lerp(0.6f, 1.f, Moist);
	S.Density = P.Density * 1000.f * FMath::Lerp(0.75f, 1.f, Comp); // loose soil is lighter than the same soil in the ground
	return S;
}

FRWCutForce FRWSoilMech::CutForce(const FRWSoilStrength& S, float Depth, float Width, float RakeDeg, float Speed, float SurchargePa)
{
	FRWCutForce Out;
	if (Depth <= 0.f || Width <= 0.f) return Out;
	const float Beta = FMath::DegreesToRadians(FMath::Clamp(RakeDeg, 15.f, 88.f));
	const float Phi = FMath::DegreesToRadians(S.PhiDeg), Delta = FMath::DegreesToRadians(S.DeltaDeg);
	const float CotB = 1.f / FMath::Tan(Beta);
	const float BD = Beta + Delta;
	float Best = 1e30f, BestRho = 0.f;
	// the soil breaks along whichever plane takes the least force
	for (float RhoDeg = 12.f; RhoDeg <= 78.f; RhoDeg += 3.f)
	{
		const float Rho = FMath::DegreesToRadians(RhoDeg);
		if (Rho + Phi >= PI * 0.97f) continue;
		const float CotR = 1.f / FMath::Tan(Rho), CotRP = 1.f / FMath::Tan(Rho + Phi);
		const float Den = FMath::Cos(BD) + FMath::Sin(BD) * CotRP;
		if (Den < 0.05f) continue;
		const float NG = (CotB + CotR) / (2.f * Den);
		const float NC = (1.f + CotR * CotRP) / Den;
		const float NA = (1.f - CotB * CotRP) / Den;
		const float NQ = (CotB + CotR) / Den;
		// throwing the soil ahead: momentum of the soil set moving at the cutting speed (McKyes' inertial term)
		const float NI = (FMath::Tan(Rho) + 1.f / FMath::Tan(Rho + Phi)) / (Den * (1.f + FMath::Tan(Rho) * CotB));
		const float F = (S.Density * GRAV * Depth * Depth * NG + S.Cohesion * Depth * NC + S.Adhesion * Depth * FMath::Max(NA, 0.f)
			+ SurchargePa * Depth * NQ + S.Density * Speed * Speed * Depth * FMath::Max(NI, 0.f)) * Width;
		if (F < Best) { Best = F; BestRho = Rho; }
	}
	if (Best >= 1e30f) return Out;
	Out.Total = Best;
	Out.Horizontal = Best * FMath::Sin(BD);
	Out.Vertical = Best * FMath::Cos(BD);
	Out.FailureDeg = FMath::RadiansToDegrees(BestRho);
	Out.WedgeVol = 0.5f * Depth * Depth * (CotB + 1.f / FMath::Tan(BestRho)) * Width;
	return Out;
}
