#include "RWMeshGen.h"
#include "RWTypes.h"
#include "Engine/StaticMesh.h"
#include "MeshDescription.h"
#include "StaticMeshAttributes.h"
#include "Materials/MaterialInterface.h"

UMaterialInterface* FRWMeshGen::DefaultMat = nullptr;
static TMap<FString, UStaticMesh*> GMeshCache;
bool FRWMeshGen::bKeepGeometry = false;
TMap<const UStaticMesh*, TPair<FString, FMeshBuild>> FRWMeshGen::KeptGeometry;
TMap<const UTexture*, TArray<uint8>> FRWMeshGen::KeptImages;

// ------------------------------------------------------------------------------------------
// FMeshBuild
// ------------------------------------------------------------------------------------------
int32 FMeshBuild::V(const FVector& Pos, const FVector& Nrm, const FVector2D& Uv)
{
	P.Add(FVector3f(Pos));
	N.Add(FVector3f(Nrm.GetSafeNormal()));
	UV.Add(FVector2f(Uv));
	return P.Num() - 1;
}

void FMeshBuild::Tri(int32 A, int32 B, int32 C)
{
	const FVector3f E1 = P[B] - P[A], E2 = P[C] - P[A];
	const FVector3f Face = FVector3f::CrossProduct(E2, E1); // Unreal front-face convention
	const FVector3f Avg = N[A] + N[B] + N[C];
	if (FVector3f::DotProduct(Face, Avg) < 0.f) Swap(B, C);
	T.Add(A); T.Add(B); T.Add(C);
}

void FMeshBuild::Append(const FMeshBuild& O, const FTransform& X)
{
	const int32 Base = P.Num();
	for (int32 i = 0; i < O.P.Num(); ++i)
	{
		P.Add(FVector3f(X.TransformPosition(FVector(O.P[i]))));
		N.Add(FVector3f(X.TransformVectorNoScale(FVector(O.N[i])).GetSafeNormal()));
		UV.Add(O.UV[i]);
	}
	for (int32 t : O.T) T.Add(Base + t);
}

void FMeshBuild::RoundBox(const FVector& Centre, const FVector& Size, float R, const FRotator& Rot)
{
	const FVector H = Size * 0.5f;
	R = FMath::Clamp(R, 0.001f, H.GetMin() * 0.9f);
	const FVector In = H - FVector(R);
	const FTransform X(Rot, Centre);
	auto Coords = [&](float h) { TArray<float> L; L.Add(-h); L.Add(-h + 0.3f * R); L.Add(-h + R); L.Add(h - R); L.Add(h - 0.3f * R); L.Add(h); return L; };
	for (int32 Axis = 0; Axis < 3; ++Axis)
		for (int32 Sign = -1; Sign <= 1; Sign += 2)
		{
			const int32 U = (Axis + 1) % 3, W = (Axis + 2) % 3;
			const TArray<float> LU = Coords(H[U]), LW = Coords(H[W]);
			const int32 Base = P.Num();
			for (int32 j = 0; j < LW.Num(); ++j)
				for (int32 i = 0; i < LU.Num(); ++i)
				{
					FVector Pt; Pt[Axis] = Sign * H[Axis]; Pt[U] = LU[i]; Pt[W] = LW[j];
					FVector Q(FMath::Clamp(Pt.X, -In.X, In.X), FMath::Clamp(Pt.Y, -In.Y, In.Y), FMath::Clamp(Pt.Z, -In.Z, In.Z));
					FVector D = Pt - Q;
					FVector Nn = D.IsNearlyZero(1e-5f) ? FVector::ZeroVector : D.GetSafeNormal();
					if (Nn.IsNearlyZero()) Nn[Axis] = Sign;
					const FVector Pos = Q + Nn * R;
					V(X.TransformPosition(Pos), X.TransformVectorNoScale(Nn), FVector2D(Pt[U], Pt[W]));
				}
			const int32 NU = LU.Num();
			for (int32 j = 0; j + 1 < LW.Num(); ++j)
				for (int32 i = 0; i + 1 < NU; ++i)
				{
					const int32 A = Base + j * NU + i;
					if (P[A].Equals(P[A + 1], 1e-5f) && P[A + NU].Equals(P[A + NU + 1], 1e-5f)) continue;
					Quad(A, A + 1, A + NU + 1, A + NU);
				}
		}
}

void FMeshBuild::Lathe(const TArray<FVector2D>& Pr, int32 Segs, const FVector& Centre, bool bSmooth)
{
	const int32 NP = Pr.Num();
	if (NP < 2) return;
	TArray<FVector2D> SegN; // normal in (r, y)
	for (int32 k = 0; k + 1 < NP; ++k)
	{
		const FVector2D D = Pr[k + 1] - Pr[k];
		SegN.Add(FVector2D(D.Y, -D.X).GetSafeNormal());
	}
	float Len = 0;
	for (int32 k = 0; k + 1 < NP; ++k)
	{
		const float SL = FVector2D::Distance(Pr[k], Pr[k + 1]);
		FVector2D NA = SegN[k], NB = SegN[k];
		if (bSmooth)
		{
			if (k > 0 && FVector2D::DotProduct(SegN[k - 1], SegN[k]) > 0.82f) NA = (SegN[k - 1] + SegN[k]).GetSafeNormal();
			if (k + 2 < NP && FVector2D::DotProduct(SegN[k + 1], SegN[k]) > 0.82f) NB = (SegN[k + 1] + SegN[k]).GetSafeNormal();
		}
		const int32 Base = P.Num();
		for (int32 j = 0; j <= Segs; ++j)
		{
			const float A = j / float(Segs) * 2.f * PI;
			const float C = FMath::Cos(A), S = FMath::Sin(A);
			for (int32 e = 0; e < 2; ++e)
			{
				const FVector2D Q = e == 0 ? Pr[k] : Pr[k + 1];
				const FVector2D Nn = e == 0 ? NA : NB;
				V(Centre + FVector(Q.X * C, Q.Y, Q.X * S), FVector(Nn.X * C, Nn.Y, Nn.X * S), FVector2D(A * 0.5f, Len + (e ? SL : 0.f)));
			}
		}
		for (int32 j = 0; j < Segs; ++j)
		{
			const int32 A = Base + j * 2;
			if (Pr[k].X < 1e-4f && Pr[k + 1].X < 1e-4f) continue;
			Quad(A, A + 1, A + 3, A + 2);
		}
		Len += SL;
	}
}

static void EarClip(const TArray<FVector2D>& Poly, TArray<int32>& Out)
{
	TArray<int32> Idx; for (int32 i = 0; i < Poly.Num(); ++i) Idx.Add(i);
	double Area = 0; for (int32 i = 0; i < Poly.Num(); ++i) { const FVector2D& A = Poly[i]; const FVector2D& B = Poly[(i + 1) % Poly.Num()]; Area += A.X * B.Y - B.X * A.Y; }
	const bool bCCW = Area > 0;
	int32 Guard = 0;
	while (Idx.Num() > 3 && Guard++ < 10000)
	{
		bool bFound = false;
		for (int32 i = 0; i < Idx.Num(); ++i)
		{
			const int32 a = Idx[(i + Idx.Num() - 1) % Idx.Num()], b = Idx[i], c = Idx[(i + 1) % Idx.Num()];
			const FVector2D A = Poly[a], B = Poly[b], C = Poly[c];
			const double Cr = (B.X - A.X) * (C.Y - A.Y) - (B.Y - A.Y) * (C.X - A.X);
			if ((Cr > 0) != bCCW || FMath::Abs(Cr) < 1e-9) continue;
			bool bInside = false;
			for (int32 k : Idx)
			{
				if (k == a || k == b || k == c) continue;
				const FVector2D Pp = Poly[k];
				const double d1 = (B.X - A.X) * (Pp.Y - A.Y) - (B.Y - A.Y) * (Pp.X - A.X);
				const double d2 = (C.X - B.X) * (Pp.Y - B.Y) - (C.Y - B.Y) * (Pp.X - B.X);
				const double d3 = (A.X - C.X) * (Pp.Y - C.Y) - (A.Y - C.Y) * (Pp.X - C.X);
				if (bCCW ? (d1 > 0 && d2 > 0 && d3 > 0) : (d1 < 0 && d2 < 0 && d3 < 0)) { bInside = true; break; }
			}
			if (bInside) continue;
			Out.Add(a); Out.Add(b); Out.Add(c);
			Idx.RemoveAt(i);
			bFound = true;
			break;
		}
		if (!bFound) break;
	}
	if (Idx.Num() == 3) { Out.Add(Idx[0]); Out.Add(Idx[1]); Out.Add(Idx[2]); }
}

void FMeshBuild::Extrude(const TArray<FVector2D>& Poly, float Width, const FVector& C, float SmoothDeg)
{
	const int32 NP = Poly.Num();
	if (NP < 3) return;
	double Area = 0; for (int32 i = 0; i < NP; ++i) { const FVector2D& A = Poly[i]; const FVector2D& B = Poly[(i + 1) % NP]; Area += A.X * B.Y - B.X * A.Y; }
	const float S = Area > 0 ? 1.f : -1.f;
	TArray<FVector2D> EN;
	for (int32 i = 0; i < NP; ++i) { const FVector2D D = Poly[(i + 1) % NP] - Poly[i]; EN.Add(FVector2D(D.Y, -D.X).GetSafeNormal() * S); }
	const float CosT = FMath::Cos(FMath::DegreesToRadians(SmoothDeg));
	const float HW = Width * 0.5f;
	float U = 0;
	for (int32 i = 0; i < NP; ++i)
	{
		const int32 j = (i + 1) % NP;
		const FVector2D Prev = EN[(i + NP - 1) % NP], Cur = EN[i], Next = EN[j];
		const FVector2D NA = FVector2D::DotProduct(Prev, Cur) > CosT ? (Prev + Cur).GetSafeNormal() : Cur;
		const FVector2D NB = FVector2D::DotProduct(Next, Cur) > CosT ? (Next + Cur).GetSafeNormal() : Cur;
		const float L = FVector2D::Distance(Poly[i], Poly[j]);
		const int32 a = V(C + FVector(Poly[i].X, -HW, Poly[i].Y), FVector(NA.X, 0, NA.Y), FVector2D(U, -HW));
		const int32 b = V(C + FVector(Poly[i].X, HW, Poly[i].Y), FVector(NA.X, 0, NA.Y), FVector2D(U, HW));
		const int32 c = V(C + FVector(Poly[j].X, HW, Poly[j].Y), FVector(NB.X, 0, NB.Y), FVector2D(U + L, HW));
		const int32 d = V(C + FVector(Poly[j].X, -HW, Poly[j].Y), FVector(NB.X, 0, NB.Y), FVector2D(U + L, -HW));
		Quad(a, b, c, d);
		U += L;
	}
	TArray<int32> Tris; EarClip(Poly, Tris);
	for (int32 s = -1; s <= 1; s += 2)
	{
		const int32 Base = P.Num();
		for (int32 i = 0; i < NP; ++i) V(C + FVector(Poly[i].X, s * HW, Poly[i].Y), FVector(0, s, 0), FVector2D(Poly[i].X, Poly[i].Y));
		for (int32 t = 0; t + 2 < Tris.Num(); t += 3) Tri(Base + Tris[t], Base + Tris[t + 1], Base + Tris[t + 2]);
	}
}

void FMeshBuild::Cyl(const FVector& A, const FVector& B, float R, int32 Segs)
{
	const float L = FVector::Dist(A, B);
	FMeshBuild Tmp;
	Tmp.Lathe({FVector2D(0, -L * 0.5f), FVector2D(R, -L * 0.5f), FVector2D(R, L * 0.5f), FVector2D(0, L * 0.5f)}, Segs, FVector::ZeroVector, false);
	const FVector Dir = (B - A).GetSafeNormal();
	const FQuat Q = FQuat::FindBetweenNormals(FVector(0, 1, 0), Dir);
	Append(Tmp, FTransform(Q, (A + B) * 0.5f));
}

static float N3(const FVector& D, int32 Seed)
{
	return RWNoise2(D.X * 1.7f + D.Z * 3.1f + 11.f, D.Y * 1.7f - D.Z * 2.3f + 5.f, Seed) * 0.6f + RWNoise2(D.X * 4.1f - D.Y * 1.3f, D.Z * 4.3f + D.Y * 2.f, Seed + 7) * 0.4f;
}

void FMeshBuild::Blob(const FVector& C, const FVector& Rad, float Noise, int32 Seed, int32 Rings, int32 Segs)
{
	TArray<FVector> G; G.SetNum((Rings + 1) * (Segs + 1));
	for (int32 r = 0; r <= Rings; ++r)
		for (int32 s = 0; s <= Segs; ++s)
		{
			const float Th = r / float(Rings) * PI, Ph = (s % Segs) / float(Segs) * 2.f * PI;
			const FVector D(FMath::Sin(Th) * FMath::Cos(Ph), FMath::Sin(Th) * FMath::Sin(Ph), FMath::Cos(Th));
			const float K = 1.f + Noise * N3(D, Seed);
			G[r * (Segs + 1) + s] = C + D * Rad * K;
		}
	const int32 Base = P.Num();
	for (int32 r = 0; r <= Rings; ++r)
		for (int32 s = 0; s <= Segs; ++s)
		{
			const FVector& X0 = G[FMath::Max(r - 1, 0) * (Segs + 1) + s];
			const FVector& X1 = G[FMath::Min(r + 1, Rings) * (Segs + 1) + s];
			const FVector& Y0 = G[r * (Segs + 1) + (s + Segs - 1) % Segs];
			const FVector& Y1 = G[r * (Segs + 1) + (s + 1) % Segs];
			FVector Nn = FVector::CrossProduct(X1 - X0, Y1 - Y0).GetSafeNormal();
			const FVector Out = (G[r * (Segs + 1) + s] - C).GetSafeNormal();
			if (FVector::DotProduct(Nn, Out) < 0) Nn = -Nn;
			if (r == 0 || r == Rings || Nn.IsNearlyZero()) Nn = Out;
			V(G[r * (Segs + 1) + s], Nn, FVector2D(s / float(Segs) * 4.f, r / float(Rings) * 2.f));
		}
	for (int32 r = 0; r < Rings; ++r)
		for (int32 s = 0; s < Segs; ++s)
		{
			const int32 A = Base + r * (Segs + 1) + s;
			Quad(A, A + 1, A + Segs + 2, A + Segs + 1);
		}
}

void FMeshBuild::Cone(const FVector& B, float R, float H, int32 Segs, float Jag, int32 Seed)
{
	// drooping, jagged skirt of foliage with a hidden underside
	const int32 Apex = V(B + FVector(0, 0, H), FVector(0, 0, 1), FVector2D(0, 0));
	const int32 Under = V(B + FVector(0, 0, H * 0.12f), FVector(0, 0, -1), FVector2D(0, 1));
	TArray<int32> Ring, RingU;
	for (int32 s = 0; s <= Segs; ++s)
	{
		const float A = (s % Segs) / float(Segs) * 2.f * PI;
		const float J = (s % 2 == 0) ? 1.f : 1.f - Jag;
		const float Rr = R * J * (1.f + 0.12f * RWNoise2(s * 0.7f, 3.3f, Seed));
		const FVector Pt = B + FVector(FMath::Cos(A) * Rr, FMath::Sin(A) * Rr, -(J > 0.99f ? 0.08f : 0.f) * H);
		const FVector Side = FVector(FMath::Cos(A) * H, FMath::Sin(A) * H, R).GetSafeNormal();
		Ring.Add(V(Pt, Side, FVector2D(s / float(Segs) * 3.f, 1)));
		RingU.Add(V(Pt, FVector(0, 0, -1), FVector2D(s / float(Segs), 0)));
	}
	for (int32 s = 0; s < Segs; ++s)
	{
		Tri(Apex, Ring[s], Ring[s + 1]);
		Tri(Under, RingU[s + 1], RingU[s]);
	}
}

// ------------------------------------------------------------------------------------------
// Static mesh build + cache
// ------------------------------------------------------------------------------------------
UStaticMesh* FRWMeshGen::Find(const FString& Key)
{
	UStaticMesh** F = GMeshCache.Find(Key);
	return F ? *F : nullptr;
}

UStaticMesh* FRWMeshGen::Build(const FString& Key, const FMeshBuild& B)
{
	if (UStaticMesh* F = Find(Key)) return F;
	if (B.T.Num() < 3) return nullptr;
	FMeshDescription MD;
	FillDescription(B, MD);
	UStaticMesh* SM = NewObject<UStaticMesh>(GetTransientPackage(), *FString::Printf(TEXT("RW_%s"), *Key.Replace(TEXT("."), TEXT("_"))), RF_Transient);
	FStaticMaterial SMat;
	SMat.MaterialInterface = DefaultMat;
	SMat.MaterialSlotName = FName(TEXT("Mat"));
	SMat.UVChannelData = FMeshUVChannelInfo(1.f);
	SM->GetStaticMaterials().Add(SMat);
	UStaticMesh::FBuildMeshDescriptionsParams Params;
	Params.bBuildSimpleCollision = false;
	Params.bFastBuild = true;
	Params.bAllowCpuAccess = false;
	TArray<const FMeshDescription*> List; List.Add(&MD);
	if (!SM->BuildFromMeshDescriptions(List, Params)) { RWLog(FString::Printf(TEXT("Mesh build failed: %s"), *Key)); return nullptr; }
	SM->AddToRoot();
	GMeshCache.Add(Key, SM);
	if (bKeepGeometry) KeptGeometry.Add(SM, TPair<FString, FMeshBuild>(Key, B));
	return SM;
}

void FRWMeshGen::FillDescription(const FMeshBuild& B, FMeshDescription& MD)
{
	FStaticMeshAttributes Attr(MD);
	Attr.Register();
	TVertexAttributesRef<FVector3f> Pos = Attr.GetVertexPositions();
	TVertexInstanceAttributesRef<FVector3f> Nrm = Attr.GetVertexInstanceNormals();
	TVertexInstanceAttributesRef<FVector3f> Tan = Attr.GetVertexInstanceTangents();
	TVertexInstanceAttributesRef<float> Sign = Attr.GetVertexInstanceBinormalSigns();
	TVertexInstanceAttributesRef<FVector2f> UVs = Attr.GetVertexInstanceUVs();
	UVs.SetNumChannels(1);
	MD.ReserveNewVertices(B.P.Num());
	MD.ReserveNewVertexInstances(B.P.Num());
	MD.ReserveNewTriangles(B.T.Num() / 3);
	const FPolygonGroupID G = MD.CreatePolygonGroup();
	Attr.GetPolygonGroupMaterialSlotNames()[G] = FName(TEXT("Mat"));
	TArray<FVertexInstanceID> VI; VI.SetNum(B.P.Num());
	for (int32 i = 0; i < B.P.Num(); ++i)
	{
		const FVertexID Vx = MD.CreateVertex();
		Pos[Vx] = B.P[i] * 100.f;
		const FVertexInstanceID I = MD.CreateVertexInstance(Vx);
		Nrm[I] = B.N[i];
		FVector3f Tg = FVector3f::CrossProduct(B.N[i], FMath::Abs(B.N[i].Z) < 0.9f ? FVector3f(0, 0, 1) : FVector3f(1, 0, 0)).GetSafeNormal();
		Tan[I] = Tg; Sign[I] = 1.f;
		UVs.Set(I, 0, B.UV[i]);
		VI[i] = I;
	}
	for (int32 t = 0; t + 2 < B.T.Num(); t += 3)
	{
		const int32 a = B.T[t], b = B.T[t + 1], c = B.T[t + 2];
		if (B.P[a].Equals(B.P[b], 1e-6f) || B.P[b].Equals(B.P[c], 1e-6f) || B.P[a].Equals(B.P[c], 1e-6f)) continue;
		TArray<FVertexInstanceID, TFixedAllocator<3>> Tri; Tri.Add(VI[a]); Tri.Add(VI[b]); Tri.Add(VI[c]);
		MD.CreateTriangle(G, Tri);
	}
}

static FString Q(float V) { return FString::FromInt(FMath::RoundToInt(V * 100.f)); }

UStaticMesh* FRWMeshGen::RoundBox(const FVector& S, float R)
{
	if (R < 0) R = FMath::Min(0.05f, S.GetMin() * 0.22f);
	const FString K = FString::Printf(TEXT("rb_%s_%s_%s_%s"), *Q(S.X), *Q(S.Y), *Q(S.Z), *Q(R));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B; B.RoundBox(FVector::ZeroVector, S, R);
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::RoundCyl(float D, float H)
{
	const FString K = FString::Printf(TEXT("rc_%s_%s"), *Q(D), *Q(H));
	if (UStaticMesh* F = Find(K)) return F;
	const float R = D * 0.5f, Bv = FMath::Min(0.03f, FMath::Min(R, H * 0.5f) * 0.25f);
	FMeshBuild L;
	L.Lathe({FVector2D(0, -H * 0.5f), FVector2D(R - Bv, -H * 0.5f), FVector2D(R, -H * 0.5f + Bv), FVector2D(R, H * 0.5f - Bv), FVector2D(R - Bv, H * 0.5f), FVector2D(0, H * 0.5f)}, D > 1.f ? 32 : 20, FVector::ZeroVector, true);
	FMeshBuild B; B.Append(L, FTransform(FRotator(0, 0, 90)));
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Tyre(float R, float W, int32 Style)
{
	const FString K = FString::Printf(TEXT("ty_%s_%s_%d"), *Q(R), *Q(W), Style);
	if (UStaticMesh* F = Find(K)) return F;
	const float LugH = Style == 1 ? R * 0.07f : R * 0.035f;
	const float Rc = R - LugH, Ri = R * 0.6f, Hw = W * 0.5f;
	FMeshBuild B;
	// carcass: bead -> bulging sidewall -> rounded shoulder -> tread -> other side
	TArray<FVector2D> Pr;
	Pr.Add(FVector2D(Ri, -Hw * 0.86f));
	Pr.Add(FVector2D(Ri + (Rc - Ri) * 0.35f, -Hw * 1.0f));
	Pr.Add(FVector2D(Ri + (Rc - Ri) * 0.75f, -Hw * 0.98f));
	Pr.Add(FVector2D(Rc - LugH * 0.6f, -Hw * 0.9f));
	Pr.Add(FVector2D(Rc, -Hw * 0.72f));
	Pr.Add(FVector2D(Rc, Hw * 0.72f));
	Pr.Add(FVector2D(Rc - LugH * 0.6f, Hw * 0.9f));
	Pr.Add(FVector2D(Ri + (Rc - Ri) * 0.75f, Hw * 0.98f));
	Pr.Add(FVector2D(Ri + (Rc - Ri) * 0.35f, Hw * 1.0f));
	Pr.Add(FVector2D(Ri, Hw * 0.86f));
	B.Lathe(Pr, 40, FVector::ZeroVector, true);
	// tread blocks
	const float Pitch = Style == 1 ? 0.17f * R / 0.8f : 0.10f;
	const int32 Count = FMath::Max(16, FMath::RoundToInt(2.f * PI * R / Pitch));
	for (int32 k = 0; k < Count; ++k)
	{
		const float A = k / float(Count) * 2.f * PI;
		for (int32 s = -1; s <= 1; s += 2)
		{
			const float Aa = A + (s > 0 ? PI / Count : 0.f);
			const FVector C(FMath::Cos(Aa) * (Rc + LugH * 0.5f), s * Hw * 0.42f, FMath::Sin(Aa) * (Rc + LugH * 0.5f));
			const float Ang = Style == 1 ? 32.f : 12.f;
			const FRotator Rot = FRotator(-FMath::RadiansToDegrees(Aa) + 90.f, 0, 0);
			FMeshBuild Lug;
			Lug.RoundBox(FVector::ZeroVector, FVector(Pitch * (Style == 1 ? 0.45f : 0.6f), W * (Style == 1 ? 0.5f : 0.4f), LugH * 1.2f), LugH * 0.3f, FRotator(0, s * Ang, 0));
			B.Append(Lug, FTransform(Rot, C));
		}
	}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Rim(float R, float W)
{
	const FString K = FString::Printf(TEXT("rim_%s_%s"), *Q(R), *Q(W));
	if (UStaticMesh* F = Find(K)) return F;
	const float Ri = R * 0.6f, Hw = W * 0.5f;
	FMeshBuild B;
	// outer face: rim flange -> dished disc -> hub
	B.Lathe({FVector2D(Ri * 1.02f, -Hw * 0.8f), FVector2D(Ri * 1.02f, Hw * 0.9f), FVector2D(Ri * 0.92f, Hw * 0.92f), FVector2D(Ri * 0.85f, Hw * 0.55f), FVector2D(Ri * 0.45f, Hw * 0.45f), FVector2D(Ri * 0.3f, Hw * 0.75f), FVector2D(Ri * 0.18f, Hw * 0.78f), FVector2D(0, Hw * 0.78f)}, 28, FVector::ZeroVector, true);
	// wheel nuts
	for (int32 k = 0; k < 10; ++k)
	{
		const float A = k / 10.f * 2.f * PI;
		B.Cyl(FVector(FMath::Cos(A) * Ri * 0.37f, Hw * 0.42f, FMath::Sin(A) * Ri * 0.37f), FVector(FMath::Cos(A) * Ri * 0.37f, Hw * 0.62f, FMath::Sin(A) * Ri * 0.37f), Ri * 0.045f, 6);
	}
	// vent holes are suggested by raised ribs on the disc
	for (int32 k = 0; k < 8; ++k)
	{
		const float A = (k + 0.5f) / 8.f * 2.f * PI;
		FMeshBuild Rib; Rib.RoundBox(FVector::ZeroVector, FVector(Ri * 0.32f, Hw * 0.12f, Ri * 0.08f), Ri * 0.02f);
		B.Append(Rib, FTransform(FRotator(-FMath::RadiansToDegrees(A), 0, 0), FVector(FMath::Cos(A) * Ri * 0.65f, Hw * 0.55f, FMath::Sin(A) * Ri * 0.65f)));
	}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::TrackShoe(float Pitch, float Width)
{
	const FString K = FString::Printf(TEXT("shoe_%s_%s"), *Q(Pitch), *Q(Width));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	B.RoundBox(FVector(0, 0, 0), FVector(Pitch * 0.94f, Width, 0.035f), 0.008f);
	B.RoundBox(FVector(Pitch * 0.18f, 0, -0.04f), FVector(0.035f, Width * 0.98f, 0.06f), 0.01f); // grouser bar faces the ground
	B.RoundBox(FVector(0, 0, 0.035f), FVector(Pitch * 0.7f, Width * 0.35f, 0.05f), 0.01f);       // link
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::CorrugatedPipe(float Length, float Dm)
{
	const FString K = FString::Printf(TEXT("cpipe_%s_%s"), *Q(Length), *Q(Dm));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	// corrugated (ribbed) HDPE pipe: outer wall with ribs every 12 cm, a smooth-ish inner wall, rim rings at the ends
	const float R = Dm * 0.5f, Pitch = 0.12f, Rib = R * 0.06f, Wall = R * 0.08f;
	const int32 Seg = 22;
	const int32 Rings = FMath::Max(2, FMath::RoundToInt(Length / (Pitch / 4.f)));
	for (int32 side = 0; side < 2; ++side) // 0 outer, 1 inner
	{
		const int32 Base = B.P.Num();
		for (int32 r = 0; r <= Rings; ++r)
		{
			const float X = Length * r / Rings;
			const float Rr = side == 0 ? R + Rib * FMath::Max(0.f, FMath::Sin(2.f * PI * X / Pitch)) : R - Wall + Rib * 0.3f * FMath::Sin(2.f * PI * X / Pitch);
			for (int32 s = 0; s <= Seg; ++s)
			{
				const float A = s / float(Seg) * 2.f * PI;
				const FVector Dir(0.f, FMath::Cos(A), FMath::Sin(A));
				B.V(FVector(X, 0.f, 0.f) + Dir * Rr, side == 0 ? Dir : -Dir, FVector2D(X / Pitch, s / float(Seg) * 3.f));
			}
		}
		for (int32 r = 0; r < Rings; ++r)
			for (int32 s = 0; s < Seg; ++s)
			{
				const int32 A = Base + r * (Seg + 1) + s;
				B.Quad(A, A + 1, A + Seg + 2, A + Seg + 1);
			}
	}
	// end rims joining the walls
	const int32 Rings1 = Rings + 1;
	for (int32 e = 0; e < 2; ++e)
	{
		const float X = e == 0 ? 0.f : Length;
		const FVector Nn(e == 0 ? -1.f : 1.f, 0.f, 0.f);
		const int32 Base = B.P.Num();
		for (int32 s = 0; s <= Seg; ++s)
		{
			const float A = s / float(Seg) * 2.f * PI;
			const FVector Dir(0.f, FMath::Cos(A), FMath::Sin(A));
			B.V(FVector(X, 0, 0) + Dir * R, Nn, FVector2D(s / float(Seg), 0));
			B.V(FVector(X, 0, 0) + Dir * (R - Wall), Nn, FVector2D(s / float(Seg), 1));
		}
		for (int32 s = 0; s < Seg; ++s) { const int32 A = Base + s * 2; B.Quad(A, A + 2, A + 3, A + 1); }
	}
	(void)Rings1;
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::WaterSheet(float SizeM, float MetresPerUV)
{
	const FString K = FString::Printf(TEXT("watersheet_%s_%s"), *Q(SizeM), *Q(MetresPerUV));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	const int32 N = 64;
	for (int32 y = 0; y <= N; ++y)
		for (int32 x = 0; x <= N; ++x)
		{
			const FVector2D P((x / float(N) - 0.5f) * SizeM, (y / float(N) - 0.5f) * SizeM);
			B.V(FVector(P.X, P.Y, 0.f), FVector::UpVector, P / MetresPerUV);
		}
	for (int32 y = 0; y < N; ++y)
		for (int32 x = 0; x < N; ++x)
		{
			const int32 A = y * (N + 1) + x;
			B.Quad(A, A + N + 1, A + N + 2, A + 1); // clockwise seen from above = faces up in Unreal
		}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::SoilLump(int32 Seed)
{
	const FString K = FString::Printf(TEXT("soillump_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	// main heap: an irregular mound, plus a crust of small clods poking out of its surface
	B.Blob(FVector::ZeroVector, FVector(0.5f, 0.5f, 0.5f), 0.13f, Seed, 16, 24);
	for (int32 k = 0; k < 14; ++k)
	{
		const float A = k * 2.399963f, Rr = 0.12f + 0.3f * FMath::Frac(k * 0.618034f + Seed * 0.13f);
		const float X = FMath::Cos(A) * Rr, Y = FMath::Sin(A) * Rr;
		const float Z = FMath::Sqrt(FMath::Max(0.25f - X * X - Y * Y, 0.f)) * 0.95f;
		const float S = 0.035f + 0.03f * FMath::Frac(k * 0.371f + Seed * 0.29f);
		B.Blob(FVector(X, Y, Z), FVector(S, S * 0.9f, S * 0.75f), 0.3f, Seed * 31 + k, 5, 7);
	}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::TrackPrint()
{
	const FString K = TEXT("trackprint");
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	// five pressed grouser bars across the shoe width (0.19 m pitch), each a little uneven, and two link ruts along it
	for (int32 k = 0; k < 5; ++k)
	{
		const float Tilt = (k % 2 ? 0.003f : -0.002f), Wide = k == 2 ? 0.96f : 0.98f;
		B.RoundBox(FVector(-0.38f + k * 0.19f, Tilt * 4.f, 0.012f + Tilt), FVector(0.11f + 0.01f * (k % 3), Wide, 0.014f), 0.006f);
	}
	for (const float Y : {-0.2f, 0.2f}) B.RoundBox(FVector(0, Y, 0.004f), FVector(0.96f, 0.08f, 0.008f), 0.002f);
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Sprocket(float R, float W)
{
	const FString K = FString::Printf(TEXT("spr_%s_%s"), *Q(R), *Q(W));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	B.Lathe({FVector2D(0, -W * 0.5f), FVector2D(R * 0.85f, -W * 0.5f), FVector2D(R * 0.85f, W * 0.5f), FVector2D(R * 0.3f, W * 0.55f), FVector2D(0, W * 0.6f)}, 24, FVector::ZeroVector, false);
	for (int32 k = 0; k < 11; ++k)
	{
		const float A = k / 11.f * 2.f * PI;
		FMeshBuild T; T.RoundBox(FVector::ZeroVector, FVector(R * 0.18f, W * 0.5f, R * 0.25f), R * 0.04f);
		B.Append(T, FTransform(FRotator(-FMath::RadiansToDegrees(A) + 90.f, 0, 0), FVector(FMath::Cos(A) * R * 0.93f, 0, FMath::Sin(A) * R * 0.93f)));
	}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Profile(const FString& Key, const TArray<FVector2D>& Poly, float Width)
{
	const FString K = TEXT("pr_") + Key;
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B; B.Extrude(Poly, Width, FVector::ZeroVector, 28.f);
	return Build(K, B);
}

static TArray<FVector2D> ThickLine(const TArray<FVector2D>& L, float T)
{
	TArray<FVector2D> Out = L;
	for (int32 i = L.Num() - 1; i >= 0; --i)
	{
		const FVector2D D = (L[FMath::Min(i + 1, L.Num() - 1)] - L[FMath::Max(i - 1, 0)]).GetSafeNormal();
		Out.Add(L[i] + FVector2D(-D.Y, D.X) * T);
	}
	return Out;
}

static TArray<FVector2D> BucketArc(float L, float D, int32 N)
{
	TArray<FVector2D> A;
	for (int32 i = 0; i <= N; ++i)
	{
		const float T = FMath::DegreesToRadians(FMath::Lerp(170.f, 0.f, i / float(N)));
		A.Add(FVector2D(0.5f * L + 0.5f * L * FMath::Cos(T), 0.05f * D + 0.95f * D * FMath::Sin(T)));
	}
	return A;
}

UStaticMesh* FRWMeshGen::BucketShell(float L, float W, float D, float Th)
{
	const FString K = FString::Printf(TEXT("bk_%s_%s_%s"), *Q(L), *Q(W), *Q(D));
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B; B.Extrude(ThickLine(BucketArc(L, D, 14), Th), W, FVector::ZeroVector, 35.f);
	// wear strips on the back of the shell
	for (int32 s = -1; s <= 1; s += 2) B.RoundBox(FVector(0.62f * L, s * W * 0.3f, 0.86f * D + Th), FVector(0.45f * L, 0.06f, 0.03f), 0.01f, FRotator(-28, 0, 0));
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::BucketSide(float L, float D, float Th)
{
	const FString K = FString::Printf(TEXT("bks_%s_%s"), *Q(L), *Q(D));
	if (UStaticMesh* F = Find(K)) return F;
	TArray<FVector2D> P = BucketArc(L, D, 14);
	FMeshBuild B; B.Extrude(P, Th, FVector::ZeroVector, 35.f);
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Moldboard(float W, float H, float Curve, float Th)
{
	const FString K = FString::Printf(TEXT("mb_%s_%s_%s"), *Q(W), *Q(H), *Q(Curve));
	if (UStaticMesh* F = Find(K)) return F;
	TArray<FVector2D> L;
	for (int32 i = 0; i <= 12; ++i)
	{
		const float T = i / 12.f;
		// cutting edge at the front-bottom, top rolls forward like a real dozer blade
		L.Add(FVector2D(-Curve * FMath::Sin(T * PI) * 0.9f + (T > 0.8f ? (T - 0.8f) * Curve * 1.2f : 0.f), H * T));
	}
	FMeshBuild B; B.Extrude(ThickLine(L, -Th), W, FVector::ZeroVector, 35.f);
	// vertical ribs on the back
	for (int32 k = -2; k <= 2; ++k) B.RoundBox(FVector(-Curve * 0.95f - 0.08f, k * W * 0.2f, H * 0.5f), FVector(0.12f, 0.06f, H * 0.85f), 0.02f);
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::LoaderBucket(float W, float D, float H)
{
	const FString K = FString::Printf(TEXT("lb_%s_%s_%s"), *Q(W), *Q(D), *Q(H));
	if (UStaticMesh* F = Find(K)) return F;
	TArray<FVector2D> L;
	L.Add(FVector2D(D, -0.36f));
	L.Add(FVector2D(0.3f * D, -0.36f));
	for (int32 i = 1; i <= 6; ++i)
	{
		const float A = i / 6.f * PI * 0.5f;
		L.Add(FVector2D(0.3f * D - FMath::Sin(A) * 0.3f * D, -0.36f + (1.f - FMath::Cos(A)) * 0.35f * H));
	}
	L.Add(FVector2D(0.02f, H - 0.36f));
	L.Add(FVector2D(0.35f * D, H - 0.3f));
	FMeshBuild B; B.Extrude(ThickLine(L, -0.05f), W, FVector::ZeroVector, 35.f);
	// side plates
	TArray<FVector2D> Side; Side.Add(FVector2D(D, -0.36f)); Side.Append(TArray<FVector2D>(L.GetData() + 1, L.Num() - 1)); Side.Add(FVector2D(D * 0.9f, H * 0.2f - 0.36f));
	for (int32 s = -1; s <= 1; s += 2) { FMeshBuild Sp; Sp.Extrude(Side, 0.05f, FVector(0, s * W * 0.5f, 0), 35.f); B.Append(Sp, FTransform::Identity); }
	B.RoundBox(FVector(D + 0.02f, 0, -0.36f), FVector(0.12f, W, 0.05f), 0.015f);
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::TreeTrunk(float H, float R, int32 Seed)
{
	const FString K = FString::Printf(TEXT("trunk_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	// unit trunk (1 m tall, 1 m wide at the root flare) centred like the engine cylinder
	TArray<FVector2D> Pr;
	for (int32 i = 0; i <= 8; ++i)
	{
		const float T = i / 8.f;
		const float Rr = 0.5f * (0.55f - 0.25f * T) + (T < 0.12f ? (0.12f - T) * 2.2f : 0.f) + 0.02f * RWNoise2(T * 5.f, 1.f, Seed);
		Pr.Add(FVector2D(Rr, T - 0.5f));
	}
	Pr.Add(FVector2D(0, 0.5f));
	FMeshBuild L; L.Lathe(Pr, 10, FVector::ZeroVector, true);
	FMeshBuild B; B.Append(L, FTransform(FRotator(0, 0, 90)));
	(void)H; (void)R;
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::ConiferCrown(float H, float R, int32 Seed)
{
	const FString K = FString::Printf(TEXT("conifer_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	// one drooping, jagged tier of branches in a unit box (centred)
	FMeshBuild B;
	B.Cone(FVector(0, 0, -0.5f), 0.5f, 1.f, 18, 0.35f, Seed);
	B.Cone(FVector(0, 0, -0.15f), 0.36f, 0.7f, 14, 0.3f, Seed + 3);
	(void)H; (void)R;
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::BroadleafCrown(float R, int32 Seed)
{
	const FString K = FString::Printf(TEXT("leaf_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	B.Blob(FVector::ZeroVector, FVector(0.5f), 0.32f, Seed, 10, 16);
	for (int32 k = 0; k < 4; ++k)
	{
		const float A = k * 1.7f + Seed;
		B.Blob(FVector(FMath::Cos(A) * 0.28f, FMath::Sin(A) * 0.28f, -0.1f + 0.08f * k), FVector(0.25f), 0.3f, Seed + k + 1, 6, 10);
	}
	(void)R;
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::Rock(float R, int32 Seed)
{
	const FString K = FString::Printf(TEXT("rock_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B; B.Blob(FVector::ZeroVector, FVector(0.5f, 0.45f, 0.38f), 0.28f, Seed, 9, 14);
	(void)R;
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::FarCrown(int32 Seed)
{
	const FString K = FString::Printf(TEXT("farcrown_%d"), Seed);
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	// seed 100 and up: the cheapest kind, for the mountains beyond the map, too far to see the lumps
	if (Seed >= 100) { B.Blob(FVector::ZeroVector, FVector(0.5f), 0.32f, Seed, 3, 6); return Build(K, B); }
	// a cauliflower of lumps, as a tree canopy looks from a distance, not one smooth ball
	B.Blob(FVector(0, 0, -0.04f), FVector(0.38f, 0.38f, 0.36f), 0.3f, Seed, 4, 7);
	for (int32 k = 0; k < 7; ++k)
	{
		const float A = k * 2.39996f + Seed, Up = (k % 3) * 0.13f;
		B.Blob(FVector(FMath::Cos(A) * 0.27f, FMath::Sin(A) * 0.27f, Up), FVector(0.2f + 0.02f * (k % 2)), 0.32f, Seed + k + 1, 3, 6);
	}
	return Build(K, B);
}

// one drooping leaf or palm frond: a strip with a shallow V across it, narrowing to the tip
static void RWFrond(FMeshBuild& B, const FVector& Root, const FVector& Dir, float Len, float Rise, float Droop, float Width, int32 Segs, bool bSerrated)
{
	const FVector Up(0, 0, 1);
	const FVector Side = FVector::CrossProduct(Dir, Up).GetSafeNormal();
	int32 Prev[3] = {-1, -1, -1};
	for (int32 s = 0; s <= Segs; ++s)
	{
		const float T = s / float(Segs);
		const FVector P = Root + Dir * Len * T + Up * (Rise * Len * T - Droop * Len * T * T);
		const float Wd = Width * FMath::Pow(FMath::Sin(PI * FMath::Min(0.12f + 0.88f * T, 1.f)), 0.6f) * (bSerrated && (s & 1) ? 0.62f : 1.f);
		const FVector Slope = (Dir * Len + Up * (Rise * Len - 2.f * Droop * Len * T)).GetSafeNormal();
		const FVector Nrm = FVector::CrossProduct(Side, Slope).GetSafeNormal() * (FVector::CrossProduct(Side, Slope).Z >= 0.f ? 1.f : -1.f);
		const int32 L = B.V(P - Side * Wd + Up * Wd * 0.22f, Nrm, FVector2D(0, T));
		const int32 C = B.V(P, Nrm, FVector2D(0, T));
		const int32 R = B.V(P + Side * Wd + Up * Wd * 0.22f, Nrm, FVector2D(0, T));
		if (Prev[0] >= 0) { B.Quad(Prev[0], Prev[1], C, L); B.Quad(Prev[1], Prev[2], R, C); }
		Prev[0] = L; Prev[1] = C; Prev[2] = R;
	}
}

UStaticMesh* FRWMeshGen::ThaiPlant(int32 Kind, int32 Seed)
{
	const FString K = FString::Printf(TEXT("thaiplant_%d_%d"), Kind, Seed);
	if (UStaticMesh* F = Find(K)) return F;
	FMeshBuild B;
	FRandomStream Rs(Seed * 31 + Kind * 7 + 5);
	// everything added between two marks gets the same colour channel in the UV
	auto Paint = [&](int32 From, float X) { for (int32 i = From; i < B.UV.Num(); ++i) B.UV[i].X = X; };
	if (Kind == 0)
	{
		// coconut palm: a long leaning trunk with a crown of feathered fronds and a bunch of nuts
		const float H = Rs.FRandRange(10.f, 13.f), Lean = Rs.FRandRange(0.5f, 1.6f), A0 = Rs.FRand() * 2.f * PI;
		const FVector LeanDir(FMath::Cos(A0), FMath::Sin(A0), 0.f);
		auto TrunkAt = [&](float T) { return LeanDir * Lean * T * T + FVector(0, 0, H * T); };
		const int32 Mark = B.UV.Num();
		for (int32 s = 0; s < 7; ++s)
		{
			const float T0 = s / 7.f, T1 = (s + 1) / 7.f;
			B.Cyl(TrunkAt(T0), TrunkAt(T1), FMath::Lerp(0.21f, 0.12f, T0) + (s == 0 ? 0.05f : 0.f), 8);
		}
		for (int32 n = 0; n < 7; ++n)
		{
			const float A = n * 2.39996f;
			B.Blob(TrunkAt(0.985f) + FVector(FMath::Cos(A) * 0.26f, FMath::Sin(A) * 0.26f, -0.3f - 0.06f * (n % 3)), FVector(0.14f), 0.12f, Seed + n, 3, 6);
		}
		Paint(Mark, 1.f);
		const int32 Mark2 = B.UV.Num();
		const FVector Top = TrunkAt(1.f);
		for (int32 f = 0; f < 18; ++f)
		{
			const float A = f * 2.39996f + Rs.FRand() * 0.3f;
			const float Tier = (f % 3) / 2.f;
			RWFrond(B, Top, FVector(FMath::Cos(A), FMath::Sin(A), 0.f), Rs.FRandRange(3.3f, 4.2f), FMath::Lerp(0.75f, 0.1f, Tier), FMath::Lerp(1.0f, 1.25f, Tier), 0.34f, 12, true);
		}
		Paint(Mark2, 0.f);
	}
	else if (Kind == 1)
	{
		// banana: a soft green stem and big paddle leaves arching out of the top
		const float H = Rs.FRandRange(2.2f, 3.1f);
		const int32 Mark = B.UV.Num();
		B.Cyl(FVector::ZeroVector, FVector(0, 0, H), 0.13f, 8);
		for (int32 f = 0; f < 10; ++f)
		{
			const float A = f * 2.39996f;
			RWFrond(B, FVector(0, 0, H - 0.1f), FVector(FMath::Cos(A), FMath::Sin(A), 0.f), Rs.FRandRange(1.7f, 2.3f), Rs.FRandRange(0.7f, 1.1f), Rs.FRandRange(0.65f, 0.95f), 0.3f, 8, false);
		}
		Paint(Mark, 0.f);
	}
	else
	{
		// bamboo: a clump of thin canes bowing outwards, with feathery leaf clouds along their upper half
		const int32 Mark = B.UV.Num();
		for (int32 c = 0; c < 14; ++c)
		{
			const float A = c * 2.39996f, Rr = 0.12f + 0.42f * Rs.FRand();
			const FVector Foot(FMath::Cos(A) * Rr, FMath::Sin(A) * Rr, 0.f), Out(FMath::Cos(A), FMath::Sin(A), 0.f);
			const float H = Rs.FRandRange(8.f, 12.f), Bow = Rs.FRandRange(1.2f, 3.2f);
			auto Cane = [&](float T) { return Foot + Out * Bow * T * T + FVector(0, 0, H * (T - 0.12f * T * T)); };
			for (int32 s = 0; s < 5; ++s) B.Cyl(Cane(s / 5.f), Cane((s + 1) / 5.f), FMath::Lerp(0.055f, 0.022f, s / 5.f), 5);
			// side shoots of narrow leaves all along the upper cane, hanging over at the tip
			for (int32 l = 0; l < 8; ++l)
			{
				const float T = 0.34f + 0.68f * l / 7.f + Rs.FRand() * 0.03f;
				const float Sa = Rs.FRand() * 2.f * PI;
				const FVector ShootDir = (FVector(FMath::Cos(Sa), FMath::Sin(Sa), 0.f) + Out * 0.7f).GetSafeNormal();
				RWFrond(B, Cane(FMath::Min(T, 1.f)), ShootDir, Rs.FRandRange(1.2f, 2.1f) * (1.15f - 0.35f * T), Rs.FRandRange(0.05f, 0.35f), Rs.FRandRange(0.45f, 0.85f), 0.17f, 7, true);
			}
		}
		Paint(Mark, 0.f);
	}
	return Build(K, B);
}

UStaticMesh* FRWMeshGen::GrassTuft()
{
	const FString K = TEXT("grass_tuft");
	if (UStaticMesh* F = Find(K)) return F;
	// a clump of curved, tapering blades (rendered with the two-sided foliage material)
	FMeshBuild B;
	for (int32 b = 0; b < 9; ++b)
	{
		const float A = b * 2.39996f;
		const float R = 0.03f + 0.05f * (b % 3);
		const FVector Base(FMath::Cos(A) * R, FMath::Sin(A) * R, 0.f);
		const FVector Lean = FVector(FMath::Cos(A), FMath::Sin(A), 0.f) * (0.08f + 0.04f * (b % 2));
		const FVector Side = FVector(-FMath::Sin(A), FMath::Cos(A), 0.f);
		const float H = 0.28f + 0.07f * ((b * 7) % 4);
		const int32 Segs = 3;
		int32 Prev[2] = {-1, -1};
		for (int32 s = 0; s <= Segs; ++s)
		{
			const float T = s / float(Segs);
			const FVector C = Base + Lean * T * T + FVector(0, 0, H * T);
			const float W = 0.022f * (1.f - T * 0.9f);
			const FVector Nrm = (FVector(0, 0, 1) * 0.6f + FVector::CrossProduct(Side, FVector(0, 0, 1)) * 0.4f).GetSafeNormal();
			const int32 L = B.V(C - Side * W, Nrm, FVector2D(0, T));
			const int32 Rr = B.V(C + Side * W, Nrm, FVector2D(1, T));
			if (Prev[0] >= 0) B.Quad(Prev[0], Prev[1], Rr, L);
			Prev[0] = L; Prev[1] = Rr;
		}
	}
	return Build(K, B);
}
