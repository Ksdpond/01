#include "Modules/ModuleManager.h"
#include "RWMapTools.h"
#include "RWTypes.h"

class FRoadWorksModule : public FDefaultGameModuleImpl
{
	virtual void StartupModule() override
	{
		RWMapTools_RegisterEditorHooks();
		// the game (not the Unreal Editor) keeps a short list of what went wrong in each run: Saved/Logs/RoadWorks_Problems.log
		if (!GIsEditor) RWProblemsBegin();
	}
};

IMPLEMENT_PRIMARY_GAME_MODULE(FRoadWorksModule, RoadWorks, "RoadWorks");
