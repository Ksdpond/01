// Player character activities: climbing in/out of cabs through each machine's door, on-foot work
// (inspection, field service, jerry-can refuelling, washing, hand shovel), controller support and rumble.
#include "RWGame.h"
#include "RWTerrain.h"
#include "RWWorld.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWLoc.h"
#include "RWPlatform.h"
#include "RWEditor.h"
#include "Engine/Canvas.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "GameFramework/ForceFeedbackEffect.h"

static uint64 GRumbleHandle = 0;

float ARWPlayerController::PadAxis(const FKey& K) const
{
	const float V = GetInputAnalogKeyState(K);
	const bool bTrigger = K == EKeys::Gamepad_LeftTriggerAxis || K == EKeys::Gamepad_RightTriggerAxis;
	const float Dz = bTrigger ? 0.08f : 0.2f;
	if (FMath::Abs(V) < Dz) return 0.f;
	return FMath::Sign(V) * (FMath::Abs(V) - Dz) / (1.f - Dz);
}

bool ARWPlayerController::PadNav(int32& Up, int32& Side, bool& bSel, bool& bBack, float Dt)
{
	Up = 0; Side = 0;
	bSel = WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Bottom);
	bBack = WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Right);
	if (WasInputKeyJustPressed(EKeys::Gamepad_DPad_Up)) Up = 1;
	if (WasInputKeyJustPressed(EKeys::Gamepad_DPad_Down)) Up = -1;
	if (WasInputKeyJustPressed(EKeys::Gamepad_DPad_Left)) Side = -1;
	if (WasInputKeyJustPressed(EKeys::Gamepad_DPad_Right)) Side = 1;
	const float LY = PadAxis(EKeys::Gamepad_LeftY), LX = PadAxis(EKeys::Gamepad_LeftX);
	NavCooldown -= Dt;
	if (FMath::Abs(LY) < 0.3f && FMath::Abs(LX) < 0.3f) NavCooldown = 0.f;
	else if (NavCooldown <= 0.f)
	{
		if (FMath::Abs(LY) >= FMath::Abs(LX)) Up = LY > 0 ? 1 : -1; else Side = LX > 0 ? 1 : -1;
		NavCooldown = 0.22f;
	}
	return Up != 0 || Side != 0 || bSel || bBack;
}

void ARWPlayerController::UpdateRumble(float Dt)
{
	float I = 0.f;
	BumpRumble = FMath::Max(0.f, BumpRumble - Dt * 3.f);
	if (Driving && bVibration)
	{
		ARWMachine* M = Driving;
		if (M->bEngineOn) I += 0.03f + 0.07f * FMath::Clamp(M->EngineLoad, 0.f, 1.f);
		if (M->HydLoad > 1.f) I += 0.3f;                       // relief valve blowing off
		if (ARWExcavator* E = Cast<ARWExcavator>(M))
		{
			I += FMath::Clamp(E->Bucket.Resist * 0.12f, 0.f, 0.45f); // bucket fighting the ground
			if (E->Tool == 1 && E->bToolActive) I += 0.5f;            // breaker hammer
		}
		if (M->bStuck || M->WheelSlip > 0.3f) I += 0.25f;
		I += M->VibrationLevel * 0.4f;                           // vibratory roller
		BumpRumble = FMath::Max(BumpRumble, FMath::Clamp(FMath::Abs(M->BodyVz) * 0.6f, 0.f, 0.8f)); // potholes, kerbs
	}
	I = bVibration ? FMath::Clamp(I + BumpRumble, 0.f, 1.f) : 0.f;
	if (I > 0.01f || GRumbleHandle != 0)
		GRumbleHandle = PlayDynamicForceFeedback(I, 0.3f, true, true, true, true, GRumbleHandle ? EDynamicForceFeedbackAction::Update : EDynamicForceFeedbackAction::Start, GRumbleHandle);
}

// ---------------------------------------------------------------------------------------------
// Climbing in and out
// ---------------------------------------------------------------------------------------------
void ARWPlayerController::BeginEnter(ARWMachine* M)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!M || !GM || !GM->Walker || Trans != ERWTrans::None) return;
	TransM = M; Trans = ERWTrans::Walk; TransT = 0.f;
	GM->Walker->bScripted = true;
	GM->Walker->InFwd = GM->Walker->InRight = 0.f;
}

void ARWPlayerController::BeginExit()
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!Driving || !GM || !GM->Walker || Trans != ERWTrans::None) return;
	ARWMachine* M = Driving;
	M->InThrottle = M->InSteer = M->InBrake = 0.f;
	M->InA1 = M->InA2 = M->InA3 = M->InA4 = 0.f;
	M->bParkBrake = true;
	TransM = M; Trans = ERWTrans::Out; TransT = 0.f;
	TransA = M->SeatWorld() - FVector(0, 0, 0.55f);
	TransB = M->EntryWorld();
	M->bDoorOpen = true;
	ARWWalker* W = GM->Walker;
	W->bScripted = true;
	W->PosM = TransA;
	W->Crouch = 1.f;
	W->Yaw = FMath::RadiansToDegrees(FMath::Atan2(TransB.Y - TransA.Y, TransB.X - TransA.X));
	W->SetActorLocationAndRotation(W->PosM * M2CM, FRotator(0, W->Yaw, 0));
	W->SetActorHiddenInGame(false);
	SetViewTargetWithBlend(W, 0.6f);
	Driving = nullptr;
}

bool ARWPlayerController::StepTransition(float Dt)
{
	if (Trans == ERWTrans::None) return false;
	ARWGameMode* GM = ARWGameMode::Get(this);
	ARWWalker* W = GM ? GM->Walker : nullptr;
	ARWMachine* M = TransM;
	if (!W || !M) { Trans = ERWTrans::None; return false; }
	TransT += Dt;
	auto Face = [&](const FVector& To) { const FVector D = To - W->PosM; if (D.SizeSquared2D() > 1e-4f) W->Yaw = FMath::RadiansToDegrees(FMath::Atan2(D.Y, D.X)); };
	switch (Trans)
	{
	case ERWTrans::Walk:
	{
		// walk round to the machine's own door
		const FVector Target = M->EntryWorld();
		FVector D = Target - W->PosM; D.Z = 0.f;
		const float Dist = D.Size();
		if (Dist > 0.2f && TransT < 6.f)
		{
			W->PosM += D / Dist * FMath::Min(Dist, 2.0f * Dt);
			W->PosM.Z = GM->Terrain->HeightAt(W->PosM.X, W->PosM.Y);
			Face(Target);
			W->Walk += Dt * 6.4f;
		}
		else
		{
			Trans = ERWTrans::In; TransT = 0.f;
			TransA = W->PosM;
			M->bDoorOpen = true;
		}
		break;
	}
	case ERWTrans::In:
	{
		// grab the handrail, climb the steps, swing into the seat
		const float T = FMath::Clamp(TransT / 1.7f, 0.f, 1.f);
		TransB = M->SeatWorld() - FVector(0, 0, 0.55f);
		const FVector Dir = (TransB - TransA).GetSafeNormal2D();
		const FVector Sill(TransA.X + Dir.X * 0.3f, TransA.Y + Dir.Y * 0.3f, TransB.Z - 0.15f);
		if (T < 0.6f) { const float a = T / 0.6f; W->PosM = FMath::Lerp(TransA, Sill, a); W->bClimbing = true; W->Crouch = 0.4f * FMath::Sin(a * PI * 3.f) * 0.5f + 0.2f; }
		else { const float a = (T - 0.6f) / 0.4f; W->PosM = FMath::Lerp(Sill, TransB, a); W->bClimbing = false; W->Crouch = a; }
		Face(TransB);
		if (T >= 1.f)
		{
			W->bScripted = false; W->bClimbing = false; W->Crouch = 0.f;
			M->bDoorOpen = false;
			Trans = ERWTrans::None;
			EnterMachine(M);
		}
		break;
	}
	case ERWTrans::Out:
	{
		const float T = FMath::Clamp(TransT / 1.7f, 0.f, 1.f);
		const FVector Dir = (TransB - TransA).GetSafeNormal2D();
		const FVector Sill(TransB.X - Dir.X * 0.3f, TransB.Y - Dir.Y * 0.3f, TransA.Z + 0.4f);
		if (T < 0.4f) { const float a = T / 0.4f; W->PosM = FMath::Lerp(TransA, Sill, a); W->Crouch = 1.f - a; }
		else { const float a = (T - 0.4f) / 0.6f; W->PosM = FMath::Lerp(Sill, TransB, a); W->bClimbing = true; W->Crouch = 0.2f; }
		if (T >= 1.f)
		{
			W->PosM = TransB;
			W->bScripted = false; W->bClimbing = false; W->Crouch = 0.f;
			M->bDoorOpen = false;
			Trans = ERWTrans::None;
		}
		break;
	}
	default: break;
	}
	W->SetActorLocationAndRotation(W->PosM * M2CM, FRotator(0, W->Yaw, 0));
	return Trans != ERWTrans::None || true;
}

// ---------------------------------------------------------------------------------------------
// On-foot activities
// ---------------------------------------------------------------------------------------------
ARWMachine* ARWPlayerController::InspectTarget() const
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (Driving || !GM || !GM->Walker) return nullptr;
	return GM->NearestMachine(GM->Walker->PosM, 6.f);
}

void ARWPlayerController::StartService(ARWMachine* M, int32 Kind)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!M || !GM) return;
	if (!M->CanOperate()) { GM->Message(TEXT("Only owned or rented machines can be serviced")); return; }
	const float Cost[3] = {60.f, 28.f, 15.f};
	if (Kind == 1 && M->Fuel >= M->FuelCap - 1.f) { GM->Message(TEXT("Tank already full")); return; }
	if (GM->Eco.Money < Cost[Kind]) { GM->Message(TEXT("Not enough money")); return; }
	static const TCHAR* What[3] = {TEXT("Field service"), TEXT("Jerry can diesel"), TEXT("Machine wash")};
	GM->Eco.Add(-Cost[Kind], TR(What[Kind]) + TEXT(": ") + TR(M->Model));
	ServiceM = M; ServiceKind = Kind; ServiceTimer = Kind == 0 ? 4.f : 3.f;
	static const TCHAR* Msg[3] = {TEXT("Greasing pins and checking fluids..."), TEXT("Pouring diesel from the jerry can..."), TEXT("Washing the mud off...")};
	GM->Message(Msg[Kind]);
}

void ARWPlayerController::FootActivities(float Dt)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	ARWWalker* W = GM ? GM->Walker : nullptr;
	if (!W) return;
	ShovelTimer = FMath::Max(0.f, ShovelTimer - Dt);
	W->ShovelSwing = ShovelTimer > 0.f ? FMath::Sin((1.f - ShovelTimer / 0.8f) * PI) : 0.f;
	if (ServiceTimer > 0.f)
	{
		// kneeling at the machine while working
		ServiceTimer -= Dt;
		W->InFwd = W->InRight = 0.f;
		W->Crouch = 1.f;
		if (ServiceM) { const FVector D = ServiceM->PosM - W->PosM; W->Yaw = FMath::RadiansToDegrees(FMath::Atan2(D.Y, D.X)); }
		if (ServiceTimer <= 0.f && ServiceM)
		{
			W->Crouch = 0.f;
			switch (ServiceKind)
			{
			case 0:
				ServiceM->Condition = FMath::Min(0.98f, ServiceM->Condition + 0.05f);
				ServiceM->LastServiceHours = ServiceM->Hours;
				ServiceM->WearCostAccum *= 0.8f;
				FRWPlatform::Unlock(TEXT("MECHANIC"));
				GM->Message(TEXT("Service done: pins greased, fluids topped up"));
				break;
			case 1: ServiceM->Fuel = FMath::Min(ServiceM->FuelCap, ServiceM->Fuel + 20.f); GM->Message(TEXT("20 L of diesel added")); break;
			default: ServiceM->Dirt = 0.f; ServiceM->ApplyDirt(); GM->Message(TEXT("Machine washed")); break;
			}
			ServiceM = nullptr;
		}
		return;
	}
	// hand shovel: Work digs a spadeful in front of you, press again to throw it
	if (Pressed(TEXT("Work")) && ShovelTimer <= 0.f)
	{
		ARWTerrain* T = GM->Terrain;
		const FVector F(FMath::Cos(FMath::DegreesToRadians(W->Yaw)), FMath::Sin(FMath::DegreesToRadians(W->Yaw)), 0);
		if (ShovelLoad.Total() < 0.001f)
		{
			const FVector P = W->PosM + F * 0.9f;
			if (T->InBounds(P.X, P.Y))
			{
				const int32 i = T->IndexAt(P.X, P.Y);
				const ESoil Mt = T->SurfaceMat(i);
				if (!SoilProps(Mt).bDiggable || Mt == ESoil::Asphalt || Mt == ESoil::SmallRock) GM->Message(TEXT("Too hard for a shovel - use a machine or the breaker"));
				else
				{
					T->RemoveAt(i, 0.035f, ShovelLoad); // about 8-9 litres per spadeful
					ShovelTimer = 0.8f;
					FRWPlatform::Unlock(TEXT("HANDS_ON"));
				}
			}
		}
		else
		{
			const FVector Q = W->PosM + F * 1.7f;
			if (T->InBounds(Q.X, Q.Y)) T->DepositPayloadAt(T->IndexAt(Q.X, Q.Y), ShovelLoad);
			ShovelLoad.Clear();
			ShovelTimer = 0.8f;
		}
	}
	if (W->ShovelLoad) W->ShovelLoad->SetVisibility(ShovelLoad.Total() > 0.001f);
}

// ---------------------------------------------------------------------------------------------
// Map editor
// ---------------------------------------------------------------------------------------------
void ARWPlayerController::SetEditMode(bool bOn)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!GM || Driving) return;
	bEditMode = bOn;
	if (EditGhost) { TArray<USceneComponent*> Ch; EditGhost->GetChildrenComponents(true, Ch); for (USceneComponent* C : Ch) C->DestroyComponent(); EditGhost->DestroyComponent(); EditGhost = nullptr; EditGhostItem = -1; }
	if (FRWEditor::Catalog.Num() == 0) FRWEditor::BuildCatalog();
	if (!bOn) FRWEditor::Save();
	GM->Message(bOn ? TEXT("MAP EDITOR: Z/X choose, Q/E rotate, R/F size, left click place, right click delete, F8 done") : TEXT("Map editor closed - edits saved"));
}

void ARWPlayerController::EditorTick(float Dt)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!GM || !GM->World || !PlayerCameraManager || FRWEditor::Catalog.Num() == 0) return;
	ARWTerrain* T = GM->Terrain;
	// cursor: where the view ray meets the ground
	const FVector CamP = PlayerCameraManager->GetCameraLocation() * CM2M;
	const FVector Dir = PlayerCameraManager->GetCameraRotation().Vector();
	bEditCursorValid = false;
	for (float D = 1.f; D < 250.f; D += 0.4f)
	{
		const FVector P = CamP + Dir * D;
		if (!T->InBounds(P.X, P.Y)) break;
		if (P.Z <= T->HeightAt(P.X, P.Y)) { EditCursor = FVector(P.X, P.Y, 0.f); bEditCursorValid = true; break; }
	}
	const int32 NumItems = FRWEditor::Catalog.Num();
	if (Pressed(TEXT("ThrUp")) || WasInputKeyJustPressed(EKeys::Gamepad_RightShoulder)) EditItem = (EditItem + 1) % NumItems;
	if (Pressed(TEXT("ThrDown")) || WasInputKeyJustPressed(EKeys::Gamepad_LeftShoulder)) EditItem = (EditItem - 1 + NumItems) % NumItems;
	const float Rot = (Down(TEXT("SwingR")) ? 1.f : 0.f) - (Down(TEXT("SwingL")) ? 1.f : 0.f) + PadAxis(EKeys::Gamepad_RightTriggerAxis) - PadAxis(EKeys::Gamepad_LeftTriggerAxis);
	EditYaw = FMath::Fmod(EditYaw + Rot * 90.f * Dt + 360.f, 360.f);
	const float Sz = (Down(TEXT("A1Up")) ? 1.f : 0.f) - (Down(TEXT("A1Down")) ? 1.f : 0.f);
	const FRWPlaceable& Item = FRWEditor::Catalog[EditItem];
	const bool bGrass = Item.Builtin.StartsWith(TEXT("grass"));
	if (bGrass) EditBrush = FMath::Clamp(EditBrush * (1.f + Sz * Dt), 0.5f, 15.f);
	else EditScale = FMath::Clamp(EditScale * (1.f + Sz * Dt), 0.2f, 5.f);
	// ghost preview
	if (EditGhostItem != EditItem && EditGhost) { TArray<USceneComponent*> Ch; EditGhost->GetChildrenComponents(true, Ch); for (USceneComponent* C : Ch) C->DestroyComponent(); EditGhost->DestroyComponent(); EditGhost = nullptr; }
	if (!EditGhost && !bGrass && bEditCursorValid) { EditGhost = FRWEditor::Build(GM->World, Item, EditCursor, EditYaw, EditScale); EditGhostItem = EditItem; }
	if (EditGhost && bEditCursorValid)
	{
		EditGhost->SetWorldLocationAndRotation(FVector(EditCursor.X, EditCursor.Y, T->HeightAt(EditCursor.X, EditCursor.Y)) * M2CM, FRotator(0, EditYaw, 0));
		EditGhost->SetWorldScale3D(FVector(EditScale));
	}
	if (!bEditCursorValid) return;
	const bool bPlace = WasInputKeyJustPressed(EKeys::LeftMouseButton) || WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Bottom);
	const bool bDelete = WasInputKeyJustPressed(EKeys::RightMouseButton) || WasInputKeyJustPressed(EKeys::Delete) || WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Right);
	if (bGrass)
	{
		if (IsInputKeyDown(EKeys::LeftMouseButton) || IsInputKeyDown(EKeys::Gamepad_FaceButton_Bottom))
		{
			static float Acc = 0.f; Acc += Dt;
			if (Acc > 0.15f) { Acc = 0.f; FRWEditor::PaintGrass(GM->World, FVector2D(EditCursor.X, EditCursor.Y), EditBrush, Item.Builtin == TEXT("grass_add")); }
		}
	}
	else if (bPlace)
	{
		FRWEditor::Place(GM->World, Item.Name, EditCursor, EditYaw, EditScale);
		GM->Message(TRF(TEXT("Placed {0}"), TR(Item.Name)));
	}
	if (bDelete)
	{
		if (FRWEditor::RemoveNear(GM->World, EditCursor, 5.f)) GM->Message(TEXT("Object removed"));
		else GM->Message(TEXT("Nothing you placed is near the cursor"));
	}
	if (WasInputKeyJustPressed(EKeys::P)) GM->Message(TRF(TEXT("Exported as a mod to {0}"), FRWEditor::ExportAsMod()));
}

void ARWHUD::DrawEditor(ARWGameMode* GM, ARWPlayerController* PC)
{
	if (FRWEditor::Catalog.Num() == 0) return;
	const FRWPlaceable& It = FRWEditor::Catalog[FMath::Clamp(PC->EditItem, 0, FRWEditor::Catalog.Num() - 1)];
	const float X = 16, Y = 140;
	Panel(X, Y, 560, 250);
	Txt(TR(TEXT("MAP EDITOR")), X + 14, Y + 8, FLinearColor(1.f, 0.6f, 0.1f), 1.f, true);
	Txt(TRF(TEXT("Object: {0}   ({1} / {2})"), TR(It.Name), FString::FromInt(PC->EditItem + 1), FString::FromInt(FRWEditor::Catalog.Num())), X + 14, Y + 48, FLinearColor::White, 0.85f);
	const bool bGrass = It.Builtin.StartsWith(TEXT("grass"));
	Txt(bGrass ? TRF(TEXT("Brush radius {0} m"), RWNum(PC->EditBrush, 1)) : TRF(TEXT("Rotation {0} deg   size x{1}"), RWNum(PC->EditYaw), RWNum(PC->EditScale, 2)), X + 14, Y + 76, FLinearColor(0.8f, 0.9f, 1.f), 0.8f);
	Txt(TR(TEXT("Z / X: previous / next object     Q / E: rotate     R / F: size")), X + 14, Y + 108, FLinearColor(0.8f, 0.8f, 0.8f), 0.7f);
	Txt(TR(TEXT("Left click: place (hold = paint grass)     Right click / Delete: remove")), X + 14, Y + 132, FLinearColor(0.8f, 0.8f, 0.8f), 0.7f);
	Txt(TR(TEXT("P: export your edits as a shareable mod     F8: close editor (auto-saved)")), X + 14, Y + 156, FLinearColor(0.8f, 0.8f, 0.8f), 0.7f);
	Txt(TRF(TEXT("Objects placed: {0}   grass strokes: {1}"), FString::FromInt(FRWEditor::Placed.Num()), FString::FromInt(FRWEditor::GrassStrokes.Num())), X + 14, Y + 188, FLinearColor(0.6f, 1.f, 0.6f), 0.75f);
	if (PC->bEditCursorValid)
	{
		// crosshair in the middle of the screen
		const float CX = Canvas->SizeX * 0.5f, CY = Canvas->SizeY * 0.5f;
		DrawLine(CX - 12, CY, CX + 12, CY, FLinearColor(1.f, 0.6f, 0.1f), 2.f);
		DrawLine(CX, CY - 12, CX, CY + 12, FLinearColor(1.f, 0.6f, 0.1f), 2.f);
	}
}

// ---------------------------------------------------------------------------------------------
// HUD: inspection sheet
// ---------------------------------------------------------------------------------------------
void ARWHUD::DrawInspect(ARWGameMode* GM, ARWPlayerController* PC)
{
	ARWMachine* M = PC->InspectTarget();
	if (!M) return;
	const float W = 1100, X0 = (Canvas->SizeX / S - W) * 0.5f, Y0 = 110 + 90 + 4 * 30;
	const FString Own = M->bOwned ? TR(TEXT("OWNED")) : M->bRented ? TR(TEXT("RENTED")) : TR(TEXT("for rent / sale"));
	Txt(FString::Printf(TEXT("%s  [%s]"), *TR(M->Model), *Own), X0 + 30, Y0, FLinearColor(1.f, 0.8f, 0.4f), 0.95f);
	const float SinceService = M->Hours - M->LastServiceHours;
	Txt(TRF(TEXT("Engine hours {0} h   since service {1} h (due every 250 h)   odometer {2} km"), RWNum(M->Hours, 1), RWNum(SinceService, 1), RWNum(M->Odometer / 1000.f, 1)), X0 + 30, Y0 + 32, FLinearColor::White, 0.75f);
	Txt(TRF(TEXT("Fuel {0} / {1} L   condition {2}%   wear parts used ${3}"), RWNum(M->Fuel), RWNum(M->FuelCap), RWNum(M->Condition * 100.f), RWNum(M->WearCostAccum)), X0 + 30, Y0 + 58, FLinearColor::White, 0.75f);
	const FString Hyd = M->Condition > 0.5f ? TR(TEXT("hoses dry, no leaks")) : M->Condition > 0.25f ? TR(TEXT("minor seepage at cylinder seals")) : TR(TEXT("hydraulic leak - repair soon"));
	const FString Running = M->Drive == EDrive::Tracked ? TR(TEXT("tracks")) : TR(TEXT("tyres"));
	Txt(TRF(TEXT("Hydraulics: {0}   {1}: {2}% tread left   dirt {3}%"), Hyd, Running, RWNum(FMath::Clamp(M->Condition * 100.f + 5.f, 0.f, 100.f)), RWNum(M->Dirt * 100.f)), X0 + 30, Y0 + 84, FLinearColor::White, 0.75f);
	Txt(TRF(TEXT("Upgrades: engine L{0}  hydraulics L{1}  traction L{2}  bucket/body L{3}"), FString::FromInt(M->UpEngine), FString::FromInt(M->UpHyd), FString::FromInt(M->UpTraction), FString::FromInt(M->UpTool)), X0 + 30, Y0 + 110, FLinearColor(0.7f, 0.9f, 1.f), 0.75f);
	if (SinceService > 250.f) Txt(TR(TEXT("SERVICE OVERDUE - do a field service or visit the yard")), X0 + 30, Y0 + 140, FLinearColor(1.f, 0.4f, 0.2f), 0.85f);
}
