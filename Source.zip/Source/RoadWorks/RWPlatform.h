// Platform services layer. Today it runs locally (achievements in Saved/, saves in Saved/SaveGames,
// mods from Mods/). A Steam backend (achievements, Steam Cloud, Workshop, Steam Input) plugs in behind
// the same calls - see STEAM.md. Game code only talks to FRWPlatform, never to a store SDK directly.
#pragma once

#include "CoreMinimal.h"

struct FRWAchievement
{
	FName Id;
	FString Name, Desc;
	bool bUnlocked = false;
};

class ROADWORKS_API IRWPlatformBackend
{
public:
	virtual ~IRWPlatformBackend() {}
	virtual FString Name() const = 0;
	virtual void UnlockAchievement(FName Id) {}
	virtual FString CloudSaveDir() const = 0;              // folder that is synced by the store's cloud
	virtual TArray<FString> WorkshopModDirs() const { return {}; } // subscribed Workshop items
	virtual bool IsOverlayActive() const { return false; }
};

class ROADWORKS_API FRWPlatform
{
public:
	static void Init();
	static FString BackendName();
	static TArray<FRWAchievement>& Achievements();
	static bool Unlock(FName Id);             // returns true the first time
	static bool IsUnlocked(FName Id);
	static FString SaveDir();
	static TArray<FString> ExtraModDirs();
	static void SetBackend(TSharedPtr<IRWPlatformBackend> B);
private:
	static void LoadLocal();
	static void SaveLocal();
};
