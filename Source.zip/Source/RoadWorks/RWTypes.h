// Shared types: soil materials, payloads, logging.
#pragma once

#include "CoreMinimal.h"

ROADWORKS_API DECLARE_LOG_CATEGORY_EXTERN(LogRW, Log, All);

// All simulation is in metres / kilograms / seconds. Unreal units are centimetres.
constexpr float M2CM = 100.f;
constexpr float CM2M = 0.01f;
constexpr float GRAV = 9.81f;

enum class ESoil : uint8
{
	DrySoil = 0,
	WetSoil,
	Mud,
	Sand,
	Gravel,
	SmallRock,
	LargeRock,
	Clay,
	Laterite,
	Compacted,
	Asphalt,
	Count
};
constexpr int32 SOIL_COUNT = (int32)ESoil::Count;

struct FSoilProps
{
	const TCHAR* Name;
	float Density;     // bank (in-place) density t/m3
	float Swell;       // loose volume gain when dug (0.25 = +25%)
	float Hardness;    // 0..1 resistance to cutting
	float Friction;    // tyre/track friction coefficient (dry)
	float WetFriction; // multiplier at full saturation
	float Repose;      // angle of repose (deg) loose dry
	float WetRepose;   // angle of repose saturated
	float Bearing;     // bearing capacity kPa (uncompacted, dry)
	float Absorb;      // how fast it soaks up rain
	float Drain;       // how fast it dries
	float RollRes;     // rolling resistance coefficient
	FLinearColor Color;
	FLinearColor WetColor;
	bool bDiggable;    // can a bucket cut it
	bool bCompactable;
};

ROADWORKS_API const FSoilProps& SoilProps(ESoil M);
ROADWORKS_API FString SoilName(ESoil M, float Moisture);

// Effective properties after moisture and compaction.
struct FSoilState
{
	float Friction = 0.7f;
	float Bearing = 200.f;
	float Hardness = 0.3f;
	float Repose = 35.f;
	float RollRes = 0.05f;
};
ROADWORKS_API FSoilState EvalSoil(ESoil M, float Moisture, float Compaction);

// Material carried in a bucket / truck bed / blade. Volumes are LOOSE m3.
struct ROADWORKS_API FPayload
{
	float Vol[SOIL_COUNT];
	float Moist = 0.f;
	FPayload() { Clear(); }
	void Clear() { for (float& V : Vol) V = 0.f; Moist = 0.f; }
	float Total() const { float T = 0; for (float V : Vol) T += V; return T; }
	float MassKg() const;
	ESoil Dominant() const;
	void Add(ESoil M, float V, float Moisture = -1.f);
	void AddPayload(const FPayload& O);
	// Removes up to V loose m3 proportionally; returns what was removed.
	FPayload Take(float V);
};

// Simple file logger in Saved/Logs/RoadWorks.log (in addition to UE log).
ROADWORKS_API void RWLog(const FString& Msg);
// what went wrong in this run, on its own in Saved/Logs/RoadWorks_Problems.log (lines of RWLog that report a problem and the
// engine's errors and warnings go there by themselves); RWProblemsBegin starts the file afresh when the game starts
ROADWORKS_API void RWProblem(const FString& Where, const FString& Msg);
ROADWORKS_API void RWProblemsBegin();
ROADWORKS_API int32 RWProblemCount();
ROADWORKS_API FString RWProblemFile();
ROADWORKS_API void RWTestLog(const FString& Msg);

// Deterministic value noise helpers (independent of engine noise so save files are stable).
ROADWORKS_API float RWNoise2(float X, float Y, int32 Seed);
ROADWORKS_API float RWFbm(float X, float Y, int32 Octaves, int32 Seed);
