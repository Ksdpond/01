﻿// Particle layer of the hybrid soil model: falling clods (carry real volume and deposit it
// into the heightfield or a truck bed / hopper), water spray, dust puffs and rain streaks.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RWTypes.h"
#include "RWEffects.generated.h"

class ARWTerrain;
class ARWMachine;
class UInstancedStaticMeshComponent;

UCLASS()
class ROADWORKS_API ARWEffects : public AActor
{
	GENERATED_BODY()
public:
	ARWEffects();
	void Init(ARWTerrain* InTerrain, UStaticMesh* Sphere, UStaticMesh* Cube, UMaterialInterface* Paint, UMaterialInterface* DustMat, UMaterialInterface* RainMat);
	virtual void Tick(float Dt) override;

	// Positions in metres.
	void SpawnSoil(const FVector& P, const FVector& V, const FPayload& Load, float Spread = 0.3f);
	void SpawnWater(const FVector& P, const FVector& V, float Amount);
	void SpawnDust(const FVector& P, float Size, const FVector& V, FLinearColor Tint = FLinearColor::White);
	// visual-only breakout lumps (the real volume is already in the bucket): fly, land, crumble away
	void SpawnChunks(const FVector& P, const FVector& V, ESoil M, float Moist, int32 Count, float Size);
	// grouser imprint left by a crawler track (P on the ground, metres); removed when the ground there changes
	void AddTrackPrint(const FVector& P, float YawDeg, const FVector& Normal, float Width, ESoil Ground, float Press = 1.f);
	int32 TrackPrintCount() const;
	int32 LiveChunks() const { int32 N = 0; for (const FClod& C : Soil) N += C.bVisual ? 1 : 0; return N; }

	TArray<TWeakObjectPtr<ARWMachine>> Receivers;
	float RainIntensity = 0.f;
	FVector CamM = FVector::ZeroVector;
	int32 LiveSoil() const { return Soil.Num(); }
	double InFlightVolume() const;
	bool bEnabled = true;
	int32 MaxDust = 260;

	// Flush all in-flight material instantly (used by tests and saving).
	void SettleAll();

private:
	struct FClod { FVector P, V; float Vol; float Moist; uint8 Mat; float Life; bool bVisual = false; float Rest = 0.f; };
	struct FPrint { FVector P; FQuat Q; float Width; float Press = 1.f; bool bOn = false; };
	TArray<FPrint> Prints[SOIL_COUNT];
	int32 PrintNext[SOIL_COUNT] = {};
	bool bPrintsDirty[SOIL_COUNT] = {};
	int32 PrintCheck = 0;
	UPROPERTY() TArray<UInstancedStaticMeshComponent*> PrintISM;
	static constexpr int32 PrintPool = 500;
	struct FDrop { FVector P, V; float Amount; float Life; };
	struct FPuff { FVector P, V; float Size, Life, MaxLife; };
	TArray<FClod> Soil;
	TArray<FDrop> Water;
	TArray<FPuff> Dust;
	TArray<FVector> RainPos;

	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() TArray<UInstancedStaticMeshComponent*> SoilISM;
	UPROPERTY() UInstancedStaticMeshComponent* WaterISM = nullptr;
	UPROPERTY() UInstancedStaticMeshComponent* DustISM = nullptr;
	UPROPERTY() UInstancedStaticMeshComponent* RainISM = nullptr;
	static constexpr int32 SoilPool = 500; // instances per soil type (falling clods + trickling grains)
	static constexpr int32 WaterPool = 160;
	static constexpr int32 RainPool = 1400;

	void Land(const FClod& C);
	void UpdatePool(UInstancedStaticMeshComponent* ISM, int32 Pool, TFunctionRef<bool(int32, FTransform&)> Get);
};
