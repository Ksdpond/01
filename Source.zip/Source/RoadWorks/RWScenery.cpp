#include "RWScenery.h"
#include "RWWorld.h"
#include "RWTerrain.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWEffects.h"
#include "RWWater.h"
#include "RWMeshGen.h"
#include "RWLayout.h"
#include "RWGame.h"
#include "RWTypes.h"
#include "EngineUtils.h"
#include "Engine/StaticMesh.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/SplineMeshComponent.h"
#include "ProceduralMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/Texture.h"
#include "LandscapeProxy.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Controller.h"
#include "GameFramework/HUD.h"
#include "Camera/CameraActor.h"
#include "Serialization/MemoryWriter.h"
#include "Misc/FileHelper.h"
#include "HAL/FileManager.h"

FString RWTagValue(const TArray<FName>& Tags, const TCHAR* Prefix)
{
	for (const FName& T : Tags)
	{
		const FString S = T.ToString();
		if (S.StartsWith(Prefix)) return S.Mid(FCString::Strlen(Prefix));
	}
	return FString();
}

FString RWTransformText(const FTransform& X)
{
	const FVector L = X.GetLocation(), S = X.GetScale3D();
	const FQuat Q = X.GetRotation();
	return FString::Printf(TEXT("%.2f %.2f %.2f %.6f %.6f %.6f %.6f %.5f %.5f %.5f"), L.X, L.Y, L.Z, Q.X, Q.Y, Q.Z, Q.W, S.X, S.Y, S.Z);
}

bool RWParseTransform(const FString& S, FTransform& X)
{
	TArray<FString> P;
	S.ParseIntoArrayWS(P);
	if (P.Num() != 10) return false;
	double V[10];
	for (int32 i = 0; i < 10; ++i) V[i] = FCString::Atod(*P[i]);
	X = FTransform(FQuat(V[3], V[4], V[5], V[6]).GetNormalized(), FVector(V[0], V[1], V[2]), FVector(V[7], V[8], V[9]));
	return true;
}

namespace
{
	struct FPart { AActor* A = nullptr; UPrimitiveComponent* P = nullptr; bool bWorld = false; };

	// what the scenery is: everything the game spawned and draws, except the ground, machines, effects, water simulation,
	// the player, trees and grass (which go their own way), lakes (part of RW_Lake) and whatever was loaded with the level itself
	void CollectParts(UWorld* W, TArray<FPart>& Out)
	{
		for (TActorIterator<AActor> It(W); It; ++It)
		{
			AActor* A = *It;
			if (A->HasAnyFlags(RF_WasLoaded) || A->Tags.Contains(TEXT("RW_Generated"))) continue;
			if (A->IsA<ARWTerrain>() || A->IsA<ARWMachine>() || A->IsA<ARWEffects>() || A->IsA<ARWWater>() || A->IsA<APawn>() || A->IsA<AController>() || A->IsA<AHUD>() || A->IsA<ACameraActor>() || A->IsA<ALandscapeProxy>()) continue;
			TSet<const UActorComponent*> Skip;
			ARWWorld* RW = Cast<ARWWorld>(A);
			if (RW)
			{
				for (auto* C : RW->FabTreeH) Skip.Add(C);
				for (auto* C : RW->FabGrassH) Skip.Add(C);
				for (auto* C : RW->FarCrowns) Skip.Add(C);
				Skip.Add(RW->GrassHISM); Skip.Add(RW->Markers); Skip.Add(RW->RiceHISM);
				for (const TPair<const UPrimitiveComponent*, FName>& O : RW->CompObj) if (O.Value.ToString().StartsWith(TEXT("Lake_"))) Skip.Add(O.Key);
			}
			TArray<UPrimitiveComponent*> Prims;
			A->GetComponents(Prims);
			for (UPrimitiveComponent* P : Prims)
			{
				if (!P || Skip.Contains(P) || !P->IsVisible() || P->bHiddenInGame || P->IsA<USplineMeshComponent>()) continue;
				if (!P->IsA<UStaticMeshComponent>() && !P->IsA<UProceduralMeshComponent>()) continue;
				if (const UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(P)) if (I->GetInstanceCount() == 0) continue;
				Out.Add({A, P, RW != nullptr});
			}
		}
	}

	// what a part is and where (sideways only: heights follow the ground, which sculpting changes)
	FString PartText(const UPrimitiveComponent* P)
	{
		const FVector L = P->GetComponentLocation();
		FString S = FString::Printf(TEXT("%s|%d|%d"), *P->GetClass()->GetName(), FMath::RoundToInt(L.X), FMath::RoundToInt(L.Y));
		if (const UStaticMeshComponent* M = Cast<UStaticMeshComponent>(P)) S += TEXT("|") + (M->GetStaticMesh() ? M->GetStaticMesh()->GetName() : FString(TEXT("none")));
		if (const UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(P))
		{
			FTransform X;
			if (I->GetInstanceTransform(0, X, true)) S += FString::Printf(TEXT("|%d|%d|%d"), I->GetInstanceCount(), FMath::RoundToInt(X.GetLocation().X), FMath::RoundToInt(X.GetLocation().Y));
		}
		if (P->IsA<UProceduralMeshComponent>()) S += TEXT("|") + P->GetName();
		return S;
	}

	bool IsAssetPath(const FString& P) { return (P.StartsWith(TEXT("/Game/")) || P.StartsWith(TEXT("/Engine/"))) && !P.StartsWith(TEXT("/Engine/Transient")); }

	struct FMeshOut { bool bAsset = false; FString Ref; FMeshBuild B; };
	struct FMatOut { bool bMid = false; FString Path; FLinearColor Color = FLinearColor::White; float Rough = 0.6f, Metal = 0.f; uint8 Has = 0; FString Tex; };
	struct FObjOut { FString Name; uint8 Kind = 0; FTransform Anchor; };
	struct FItemOut { int32 Obj = -1; FString Id; bool bInst = false; int32 Mesh = -1; TArray<int32> Mats; FTransform X; TArray<FTransform> Inst; bool bShadow = true; };
}

bool RWNearlySame(const FTransform& A, const FTransform& B)
{
	return FVector::Dist(A.GetLocation(), B.GetLocation()) < 1.f && A.GetRotation().AngularDistance(B.GetRotation()) < 1e-3f && (A.GetScale3D() - B.GetScale3D()).GetAbsMax() < 1e-3f;
}

FString RWInstancesText(const TArray<FTransform>& Inst)
{
	// (to the centimetre and a tenth of a degree: what was saved and loaded again counts as the same)
	uint32 Crc = 0;
	for (const FTransform& X : Inst)
	{
		const FVector L = X.GetLocation(), S = X.GetScale3D();
		const FRotator R = X.Rotator();
		const int32 V[9] = {FMath::RoundToInt(L.X), FMath::RoundToInt(L.Y), FMath::RoundToInt(L.Z), FMath::RoundToInt(R.Pitch * 10.f), FMath::RoundToInt(R.Yaw * 10.f), FMath::RoundToInt(R.Roll * 10.f), FMath::RoundToInt(S.X * 100.f), FMath::RoundToInt(S.Y * 100.f), FMath::RoundToInt(S.Z * 100.f)};
		Crc = FCrc::MemCrc32(V, sizeof(V), Crc);
	}
	return FString::Printf(TEXT("%d_%08x"), Inst.Num(), Crc);
}

void RWTagScenery(UWorld* W)
{
	if (!W) return;
	TArray<FPart> Parts;
	CollectParts(W, Parts);
	TMap<FString, int32> Seen;
	TSet<AActor*> Done;
	int32 NParts = 0, NActors = 0;
	for (const FPart& Pt : Parts)
	{
		if (Pt.bWorld)
		{
			const FString Base = PartText(Pt.P);
			int32& K = Seen.FindOrAdd(Base);
			Pt.P->ComponentTags.Add(FName(*FString::Printf(TEXT("RWID:%08x_%d"), FCrc::StrCrc32(*Base), K++)));
			++NParts;
		}
		else if (!Done.Contains(Pt.A))
		{
			Done.Add(Pt.A);
			const FVector L = Pt.A->GetActorLocation();
			const FString Cls = Pt.A->GetClass()->GetName();
			const FString Base = FString::Printf(TEXT("%s|%d|%d"), *Cls, FMath::RoundToInt(L.X), FMath::RoundToInt(L.Y));
			int32& K = Seen.FindOrAdd(Base);
			Pt.A->Tags.Add(FName(*FString::Printf(TEXT("RWObj:%s_%08x_%d"), *Cls, FCrc::StrCrc32(*Base), K++)));
			++NActors;
		}
	}
	RWLog(FString::Printf(TEXT("Scenery: %d parts of the world and %d props named for the level"), NParts, NActors));
}

void RWApplyLevelScenery(UWorld* W, const FRWLayout& L)
{
	if (!W || L.LevelObjs.Num() == 0) return;
	TArray<FPart> Parts;
	CollectParts(W, Parts);
	int32 Moved = 0, Removed = 0, Restyled = 0, Kept = 0;
	TSet<AActor*> Done;
	TArray<AActor*> Gone;
	for (const FPart& Pt : Parts)
	{
		if (Pt.bWorld)
		{
			const FString Id = RWTagValue(Pt.P->ComponentTags, TEXT("RWID:"));
			if (Id.IsEmpty()) continue;
			const FRWLayout::FLevelComp* C = L.LevelComps.Find(Id);
			if (!C)
			{
				// removed in the editor
				Pt.P->SetVisibility(false);
				Pt.P->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				++Removed;
				continue;
			}
			++Kept;
			if (C->bMoved)
			{
				if (UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(Pt.P))
				{
					I->ClearInstances();
					if (C->Inst.Num()) I->AddInstances(C->Inst, false, true);
				}
				else Pt.P->SetWorldTransform(C->X);
				++Moved;
			}
			if (UStaticMeshComponent* S = Cast<UStaticMeshComponent>(Pt.P))
			{
				bool bStyled = false;
				if (!C->Mesh.IsEmpty()) if (UStaticMesh* M = LoadObject<UStaticMesh>(nullptr, *C->Mesh)) { S->SetStaticMesh(M); bStyled = true; }
				for (int32 s = 0; s < C->Mats.Num(); ++s)
					if (!C->Mats[s].IsEmpty()) if (UMaterialInterface* Mi = LoadObject<UMaterialInterface>(nullptr, *C->Mats[s])) { S->SetMaterial(s, Mi); bStyled = true; }
				Restyled += bStyled ? 1 : 0;
			}
		}
		else if (!Done.Contains(Pt.A))
		{
			Done.Add(Pt.A);
			const FString Obj = RWTagValue(Pt.A->Tags, TEXT("RWObj:"));
			if (Obj.IsEmpty()) continue;
			const FRWLayout::FLevelObj* O = L.LevelObjs.Find(Obj);
			if (!O) { Gone.Add(Pt.A); continue; }
			++Kept;
			if (!RWNearlySame(O->Anchor, O->Now))
			{
				Pt.A->SetActorTransform(Pt.A->GetActorTransform() * O->Anchor.Inverse() * O->Now, false, nullptr, ETeleportType::TeleportPhysics);
				++Moved;
			}
		}
	}
	for (AActor* A : Gone) { A->Destroy(); ++Removed; }
	// what the machines run into goes with its building, or with it when it was removed
	int32 ObsMoved = 0, ObsGone = 0;
	for (TActorIterator<ARWWorld> It(W); It; ++It)
		for (FRWObstacle& Ob : It->Obstacles)
		{
			if (Ob.Obj.IsNone()) continue;
			const FRWLayout::FLevelObj* O = L.LevelObjs.Find(Ob.Obj.ToString());
			if (!O) { Ob.Half = FVector2D::ZeroVector; ++ObsGone; continue; }
			if (RWNearlySame(O->Anchor, O->Now)) continue;
			const FVector P = O->Now.TransformPosition(O->Anchor.InverseTransformPosition(FVector(Ob.C.X * M2CM, Ob.C.Y * M2CM, O->Anchor.GetLocation().Z)));
			const FVector Sc = O->Now.GetScale3D() / O->Anchor.GetScale3D().ComponentMax(FVector(1e-3));
			Ob.C = FVector2D(P.X, P.Y) * CM2M;
			Ob.Yaw += O->Now.Rotator().Yaw - O->Anchor.Rotator().Yaw;
			Ob.Half *= FVector2D(FMath::Abs(Sc.X), FMath::Abs(Sc.Y));
			++ObsMoved;
		}
	RWLog(FString::Printf(TEXT("Map: the level's scenery: %d parts and props as in the level, %d moved, %d removed, %d with another model or material; %d obstacles moved, %d removed"),
		Kept, Moved, Removed, Restyled, ObsMoved, ObsGone));
}

int32 RWExportScenery(UWorld* W, const FString& File)
{
	if (!W) return -1;
	TArray<FMeshOut> Meshes; TMap<const UObject*, int32> MeshIdx;
	TArray<const TArray<uint8>*> Images; TMap<const UTexture*, int32> ImageIdx;
	TArray<FMatOut> Mats; TMap<const UMaterialInterface*, int32> MatIdx;
	TArray<FObjOut> Objs; TMap<FString, int32> ObjIdx;
	TArray<FItemOut> Items;
	int32 Skipped = 0, Count = 0;

	auto MeshOf = [&](const UStaticMesh* M) -> int32
	{
		if (!M) return -1;
		if (const int32* F = MeshIdx.Find(M)) return *F;
		FMeshOut O;
		const FString P = M->GetPathName();
		if (IsAssetPath(P)) { O.bAsset = true; O.Ref = P; }
		else if (const TPair<FString, FMeshBuild>* G = FRWMeshGen::KeptGeometry.Find(M)) { O.Ref = G->Key; O.B = G->Value; }
		else return -1;
		const int32 I = Meshes.Add(MoveTemp(O));
		MeshIdx.Add(M, I);
		return I;
	};
	auto MatOf = [&](UMaterialInterface* Mi) -> int32
	{
		if (!Mi) return -1;
		if (const int32* F = MatIdx.Find(Mi)) return *F;
		FMatOut O;
		if (UMaterialInstanceDynamic* D = Cast<UMaterialInstanceDynamic>(Mi))
		{
			UMaterialInterface* Par = D->Parent;
			while (Par && !IsAssetPath(Par->GetPathName()) && Cast<UMaterialInstanceDynamic>(Par)) Par = Cast<UMaterialInstanceDynamic>(Par)->Parent;
			if (!Par || !IsAssetPath(Par->GetPathName())) return -1;
			O.bMid = true; O.Path = Par->GetPathName();
			if (D->GetVectorParameterValue(FHashedMaterialParameterInfo(TEXT("Color")), O.Color)) O.Has |= 1;
			if (D->GetScalarParameterValue(FHashedMaterialParameterInfo(TEXT("Roughness")), O.Rough)) O.Has |= 2;
			if (D->GetScalarParameterValue(FHashedMaterialParameterInfo(TEXT("Metallic")), O.Metal)) O.Has |= 4;
			UTexture* T = nullptr;
			if (D->GetTextureParameterValue(FHashedMaterialParameterInfo(TEXT("BaseTex")), T) && T)
			{
				if (IsAssetPath(T->GetPathName())) O.Tex = T->GetPathName();
				else if (const TArray<uint8>* Img = FRWMeshGen::KeptImages.Find(T))
				{
					// a model's own picture: it goes with the file and becomes a texture asset in the editor
					int32* F = ImageIdx.Find(T);
					const int32 Ix = F ? *F : Images.Add(Img);
					ImageIdx.Add(T, Ix);
					O.Tex = FString::Printf(TEXT("img:%d"), Ix);
				}
			}
		}
		else
		{
			if (!IsAssetPath(Mi->GetPathName())) return -1;
			O.Path = Mi->GetPathName();
		}
		const int32 I = Mats.Add(MoveTemp(O));
		MatIdx.Add(Mi, I);
		return I;
	};
	auto ObjOf = [&](const FString& Name, ERWSceneryKind Kind, const FTransform& Anchor) -> int32
	{
		if (const int32* F = ObjIdx.Find(Name)) return *F;
		FObjOut O; O.Name = Name; O.Kind = (uint8)Kind; O.Anchor = Anchor;
		const int32 I = Objs.Add(MoveTemp(O));
		ObjIdx.Add(Name, I);
		return I;
	};
	// one part (a mesh, a list of instances or the sections of a drawn shape) of the object Obj
	auto AddPart = [&](int32 Obj, const FString& Id, UPrimitiveComponent* P)
	{
		if (UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(P))
		{
			FItemOut O; O.Obj = Obj; O.Id = Id; O.bInst = true; O.Mesh = MeshOf(I->GetStaticMesh()); O.bShadow = I->CastShadow;
			if (O.Mesh < 0) { ++Skipped; return; }
			for (int32 s = 0; s < I->GetNumMaterials(); ++s) O.Mats.Add(MatOf(I->GetMaterial(s)));
			for (int32 i = 0; i < I->GetInstanceCount(); ++i) { FTransform X; if (I->GetInstanceTransform(i, X, true)) O.Inst.Add(X); }
			Count += O.Inst.Num();
			Items.Add(MoveTemp(O));
		}
		else if (UStaticMeshComponent* S = Cast<UStaticMeshComponent>(P))
		{
			FItemOut O; O.Obj = Obj; O.Id = Id; O.Mesh = MeshOf(S->GetStaticMesh()); O.X = S->GetComponentTransform(); O.bShadow = S->CastShadow;
			if (O.Mesh < 0) { ++Skipped; return; }
			for (int32 s = 0; s < S->GetNumMaterials(); ++s) O.Mats.Add(MatOf(S->GetMaterial(s)));
			++Count;
			Items.Add(MoveTemp(O));
		}
		else if (UProceduralMeshComponent* PM = Cast<UProceduralMeshComponent>(P))
		{
			// shapes drawn by the game's code (stream water...): their triangles become a mesh of their own
			for (int32 s = 0; s < PM->GetNumSections(); ++s)
			{
				const FProcMeshSection* Sec = PM->GetProcMeshSection(s);
				if (!Sec || Sec->ProcIndexBuffer.Num() < 3 || !Sec->bSectionVisible) continue;
				FMeshOut Mo; Mo.Ref = FString::Printf(TEXT("proc_%s_%s_%d"), *P->GetOwner()->GetClass()->GetName(), *PM->GetName(), s);
				for (const FProcMeshVertex& V : Sec->ProcVertexBuffer) { Mo.B.P.Add(FVector3f(V.Position * 0.01)); Mo.B.N.Add(FVector3f(V.Normal)); Mo.B.UV.Add(FVector2f(V.UV0)); }
				for (const uint32 Ix : Sec->ProcIndexBuffer) Mo.B.T.Add((int32)Ix);
				FItemOut O; O.Obj = Obj; O.Id = Id; O.Mesh = Meshes.Add(MoveTemp(Mo)); O.X = PM->GetComponentTransform(); O.bShadow = PM->CastShadow;
				O.Mats.Add(MatOf(PM->GetMaterial(s)));
				++Count;
				Items.Add(MoveTemp(O));
			}
		}
	};

	// ---- the world's scenery and the props ----
	ARWWorld* RW = nullptr;
	for (TActorIterator<ARWWorld> It(W); It; ++It) { RW = *It; break; }
	TArray<FPart> Parts;
	CollectParts(W, Parts);
	for (const FPart& Pt : Parts)
	{
		if (Pt.bWorld)
		{
			const FString Id = RWTagValue(Pt.P->ComponentTags, TEXT("RWID:"));
			if (Id.IsEmpty()) continue; // (added later by mods or the in-game map editor: those keep their own way)
			FVector At = Pt.P->GetComponentLocation();
			if (const UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(Pt.P)) { FTransform X; if (I->GetInstanceTransform(0, X, true)) At = X.GetLocation(); }
			const FName* Named = RW ? RW->CompObj.Find(Pt.P) : nullptr;
			int32 Obj;
			if (Named) Obj = ObjOf(Named->ToString(), ERWSceneryKind::WorldParts, FTransform(At));
			else if (Pt.P->IsA<UInstancedStaticMeshComponent>()) Obj = ObjOf(TEXT("Inst_") + Id, ERWSceneryKind::WorldParts, FTransform(At));
			else
			{
				// loose parts (road lines, bridges, waterfalls...) by 500 m squares of the map
				const int32 Cx = FMath::FloorToInt(At.X / 50000.f), Cy = FMath::FloorToInt(At.Y / 50000.f);
				Obj = ObjOf(FString::Printf(TEXT("Cell_%d_%d"), Cx, Cy), ERWSceneryKind::WorldParts, FTransform(FVector((Cx + 0.5f) * 50000.f, (Cy + 0.5f) * 50000.f, At.Z)));
			}
			AddPart(Obj, Id, Pt.P);
		}
		else
		{
			const FString Name = RWTagValue(Pt.A->Tags, TEXT("RWObj:"));
			if (Name.IsEmpty()) continue;
			AddPart(ObjOf(Name, ERWSceneryKind::WholeActor, Pt.A->GetActorTransform()), FString(), Pt.P);
		}
	}
	// ---- the machines, as they stand at the start ----
	int32 NMachines = 0;
	if (ARWGameMode* GM = Cast<ARWGameMode>(W->GetAuthGameMode()))
		for (ARWMachine* M : GM->Machines)
		{
			if (!M) continue;
			const int32 Obj = ObjOf(GM->MachineKey(M), ERWSceneryKind::Machine, FTransform(FRotator(0.f, M->Yaw, 0.f), M->PosM * M2CM));
			TArray<UPrimitiveComponent*> Prims;
			M->GetComponents(Prims);
			const int32 Before = Items.Num();
			for (UPrimitiveComponent* P : Prims)
			{
				if (!P || !P->IsVisible() || P->bHiddenInGame || P->IsA<USplineMeshComponent>() || !P->IsA<UStaticMeshComponent>()) continue;
				if (const UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(P)) if (I->GetInstanceCount() == 0) continue;
				AddPart(Obj, FString(), P);
			}
			NMachines += Items.Num() > Before ? 1 : 0;
		}

	TArray<uint8> Out;
	FMemoryWriter Wr(Out);
	int32 Magic = RWSceneryMagic, Ver = RWSceneryVersion, NM = Meshes.Num(), NImg = Images.Num(), NT = Mats.Num(), NO = Objs.Num(), NI = Items.Num();
	Wr << Magic << Ver << NM;
	for (FMeshOut& M : Meshes) { uint8 bA = M.bAsset ? 1 : 0; Wr << bA << M.Ref; if (!M.bAsset) Wr << M.B.P << M.B.N << M.B.UV << M.B.T; }
	Wr << NImg;
	for (const TArray<uint8>* Img : Images) { TArray<uint8> Copy = *Img; Wr << Copy; }
	Wr << NT;
	for (FMatOut& M : Mats) { uint8 bM = M.bMid ? 1 : 0; Wr << bM << M.Path << M.Color << M.Rough << M.Metal << M.Has << M.Tex; }
	Wr << NO;
	for (FObjOut& O : Objs) Wr << O.Name << O.Kind << O.Anchor;
	Wr << NI;
	for (FItemOut& I : Items) { uint8 bI = I.bInst ? 1 : 0, bS = I.bShadow ? 1 : 0; Wr << I.Obj << I.Id << bI << I.Mesh << I.Mats << I.X << I.Inst << bS; }
	// ---- the soil heaps and the excavation the world started with ----
	int32 NP = RW ? RW->PileDefs.Num() : 0, ND = RW ? RW->DigDefs.Num() : 0;
	Wr << NP;
	for (int32 i = 0; i < NP; ++i) { ARWWorld::FPileDef& P = RW->PileDefs[i]; uint8 Soil = (uint8)P.M; Wr << P.P << P.R << P.H << Soil; }
	Wr << ND;
	for (int32 i = 0; i < ND; ++i)
	{
		FVector D = RW->DigDefs[i];
		// (the ground as it was before the pit: its middle is dug 1.4 m deep)
		const float Z = RW->Terrain ? RW->Terrain->HeightAt(D.X, D.Y) + 1.4f : 0.f;
		FVector At(D.X, D.Y, Z);
		float Yaw = D.Z;
		Wr << At << Yaw;
	}
	IFileManager::Get().MakeDirectory(*FPaths::GetPath(File), true);
	const bool bOk = FFileHelper::SaveArrayToFile(Out, *File);
	RWLog(FString::Printf(TEXT("Scenery exported: %d objects in %d items of %d level objects (%d machines), %d meshes (%d built by the game), %d pictures, %d materials, %d heaps, %d digs, %d skipped -> %s (%s)"),
		Count, Items.Num(), Objs.Num(), NMachines, Meshes.Num(), Meshes.FilterByPredicate([](const FMeshOut& M) { return !M.bAsset; }).Num(), Images.Num(), Mats.Num(), NP, ND, Skipped, *File, bOk ? TEXT("ok") : TEXT("FAILED")));
	return bOk ? Count : -1;
}
