// Runtime glTF 2.0 loader (.glb or .gltf + .bin): node hierarchy with pivots (object origins),
// meshes, PBR material factors and embedded / external base-colour textures.
// Used by machine mods, prop mods and the map editor, so models can be dropped into Mods/ without
// the Unreal editor - export from Blender with File > Export > glTF 2.0.
#pragma once

#include "CoreMinimal.h"
#include "RWMeshGen.h"

class UStaticMesh;
class UMaterialInterface;
class UStaticMeshComponent;
class USceneComponent;
class UTexture2D;

struct FRWGltfNode
{
	FString Name;
	int32 Parent = -1;
	TArray<int32> Children;
	FTransform Local;   // Unreal space (cm), relative to parent
	FTransform World;   // Unreal space (cm), relative to the model root
	int32 Mesh = -1;
	int32 Light = -1;   // a light placed in Blender (KHR_lights_punctual), index into FRWGltfModel::Lights
	TMap<FString, FString> Extras; // Blender's custom properties of the object (e.g. rw_part = "boom", set by the RoadWorks add-on)
};

// a light placed in the model (Blender: a Spot or Point light, exported with "Punctual Lights")
struct FRWGltfLight
{
	FString Type = TEXT("spot");
	FLinearColor Color = FLinearColor::White;
	float Intensity = 0.f;   // as written by the exporter (candela for spot/point)
	float Range = 0.f;       // m, 0 = not given
	float OuterCone = 0.6f;  // radians (half angle)
	float InnerCone = 0.3f;
};

class ROADWORKS_API FRWGltfModel
{
public:
	bool Load(const FString& Path, float Scale, float YawOffsetDeg);
	FString Path, Error;
	TArray<FRWGltfNode> Nodes;
	TArray<FRWGltfLight> Lights;
	// the lamps the modder placed: lights in the file, or empties named "lamp..." / "RW_Lamp..."; a lamp shines along its
	// local -Z in Blender's light convention (what a Spot light does), given back as a direction in model space
	struct FLampPoint { int32 Node = -1; FVector Pos = FVector::ZeroVector; FVector Dir = FVector::ForwardVector; float Lumens = 10000.f; float OuterDeg = 35.f; float RangeM = 60.f; FLinearColor Color = FLinearColor(1.f, 0.94f, 0.82f); bool bWork = false; FString Part; };
	TArray<FLampPoint> LampPoints() const;
	TArray<TArray<UStaticMesh*>> MeshPrims;
	TArray<TArray<UMaterialInterface*>> MeshMats;
	TArray<FBox> MeshBounds; // per mesh, local cm
	TArray<TArray<FVector3f>> MeshPoints; // per mesh vertex positions, local cm (e.g. to measure a bucket's real shell)
	TArray<TArray<int32>> MeshTris;       // per mesh triangles, three indices into MeshPoints each
	TArray<TArray<FMeshBuild>> MeshBuilds; // per mesh, per primitive: the geometry (metres), to merge parts that move together

	TMap<FString, class UMaterialInstanceDynamic*> MatByName; // the file's materials, by their names

	// A mod's "materials" section: {"Name": {"color": [r,g,b], "metallic": m, "roughness": r}} replaces what the file says (linear colour).
	void ApplyMaterialOverrides(const class FJsonObject& Section);
	int32 Find(const FString& Name) const;
	// Bounds of a node and its descendants (stopping at Exclude), in the node's own space (cm).
	FBox SubtreeBounds(int32 Node, const TSet<int32>& Exclude) const;
	// Creates mesh components for Node and its descendants (not entering Exclude), attached to Parent.
	// ParentWorldRest = where Parent sits in model space at the rest pose.
	void Spawn(AActor* Owner, USceneComponent* Parent, int32 Node, const FTransform& ParentWorldRest, const TSet<int32>& Exclude, TArray<UStaticMeshComponent*>* Out = nullptr) const;
	void SpawnAll(AActor* Owner, USceneComponent* Parent, TArray<UStaticMeshComponent*>* Out = nullptr) const;
	TArray<int32> Roots() const;

	static TSharedPtr<FRWGltfModel> Get(const FString& Path, float Scale = 1.f, float YawOffsetDeg = 0.f);
	static UMaterialInterface* TexturedMat;
	static UMaterialInterface* PlainMat;
	static UMaterialInterface* GlassMat;
};
