#include "RWMapTools.h"
#include "Serialization/MemoryReader.h"
#include "RWLayout.h"
#include "RWTypes.h"
#include "Landscape.h"
#include "LandscapeProxy.h"
#include "EngineUtils.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Misc/Compression.h"
#include "Misc/ConfigCacheIni.h"
#include "Async/ParallelFor.h"
#include "Components/SplineComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "RWScenery.h"

void URWMapTools::HideEditorGround(UWorld* World)
{
	if (!World) return;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (!It->IsA<ALandscapeProxy>() && !It->Tags.Contains(TEXT("RW_Generated"))) continue;
		It->SetActorHiddenInGame(true);
		It->SetActorEnableCollision(false);
	}
}

void URWMapTools::ReadLevelLayout(UWorld* World, FRWLayout& L)
{
	if (!World) return;
	int32 Roads = 0;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* A = *It;
		if (A->Tags.Contains(TEXT("RW_Lake")))
		{
			// a plane of 1 m, scaled to the lake's width and 40 m of shore
			const FVector S = A->GetActorScale3D(), P = A->GetActorLocation() * 0.01f;
			FRWLayout::FRWLake Lk; Lk.C = FVector2D(P.X, P.Y); Lk.R = FMath::Max(10.f, (0.5f * (S.X + S.Y) - 40.f) * 0.5f); Lk.Z = P.Z + 0.1f;
			L.LevelLakes.Add(Lk);
			RWLog(FString::Printf(TEXT("Map: lake %s from the level at %.0f, %.0f, %.0f m across, water at %.1f m"), *A->GetName(), Lk.C.X, Lk.C.Y, 2.f * Lk.R, Lk.Z));
		}
		for (const FName& Tg : A->Tags)
		{
			const FString T = Tg.ToString();
			if (!T.StartsWith(TEXT("RWRoad:"))) continue;
			if (USplineComponent* Sp = A->FindComponentByClass<USplineComponent>())
			{
				TArray<FVector2D> Pts;
				const float Len = Sp->GetSplineLength();
				for (float D = 0.f; D < Len; D += 400.f) { const FVector Q = Sp->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World) * 0.01f; Pts.Add(FVector2D(Q.X, Q.Y)); }
				const FVector Q = Sp->GetLocationAtDistanceAlongSpline(Len, ESplineCoordinateSpace::World) * 0.01f; Pts.Add(FVector2D(Q.X, Q.Y));
				L.LevelRoads.Add(T.Mid(7), Pts);
				++Roads;
			}
		}
		if (A->Tags.Contains(TEXT("RW_Plants")))
		{
			FRWLayout::FLevelPlants Lp;
			Lp.bTree = A->Tags.Contains(TEXT("RWTree"));
			for (const FName& Tg : A->Tags) if (Tg.ToString().StartsWith(TEXT("RWMesh:"))) Lp.Mesh = Tg.ToString().Mid(7);
			TArray<UInstancedStaticMeshComponent*> Ism;
			A->GetComponents(Ism);
			for (UInstancedStaticMeshComponent* C : Ism)
			{
				if (Lp.Mesh.IsEmpty() && C->GetStaticMesh()) Lp.Mesh = C->GetStaticMesh()->GetPathName();
				for (int32 i = 0; i < C->GetInstanceCount(); ++i) { FTransform X; if (C->GetInstanceTransform(i, X, true)) Lp.Instances.Add(X); }
			}
			if (Lp.Instances.Num()) L.LevelPlants.Add(MoveTemp(Lp));
		}
		if (A->Tags.Contains(TEXT("RW_Forest")))
		{
			TArray<UInstancedStaticMeshComponent*> Ism;
			A->GetComponents(Ism);
			for (UInstancedStaticMeshComponent* C : Ism)
				for (int32 i = 0; i < C->GetInstanceCount(); ++i)
				{
					FTransform X;
					if (C->GetInstanceTransform(i, X, true)) L.LevelTrees.Add(FVector(X.GetLocation().X * 0.01f, X.GetLocation().Y * 0.01f, X.GetScale3D().Z));
				}
		}
		// the scenery as left in the editor (RWScenery.h): each object where it is now and where it was, each part's place,
		// model and materials when they were changed
		if (A->Tags.Contains(TEXT("RW_Scenery")))
		{
			const FString Obj = RWTagValue(A->Tags, TEXT("RWObj:"));
			FRWLayout::FLevelObj O;
			if (!Obj.IsEmpty() && RWParseTransform(RWTagValue(A->Tags, TEXT("RWAnchor:")), O.Anchor))
			{
				O.Kind = (uint8)FCString::Atoi(*RWTagValue(A->Tags, TEXT("RWKind:")));
				O.Now = A->GetActorTransform();
				L.LevelObjs.Add(Obj, O);
			}
			TArray<UPrimitiveComponent*> Prims;
			A->GetComponents(Prims);
			for (UPrimitiveComponent* P : Prims)
			{
				const FString Id = P ? RWTagValue(P->ComponentTags, TEXT("RWID:")) : FString();
				if (Id.IsEmpty() || L.LevelComps.Contains(Id)) continue;
				FRWLayout::FLevelComp C;
				if (UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(P))
				{
					C.bInst = true;
					for (int32 i = 0; i < I->GetInstanceCount(); ++i) { FTransform X; if (I->GetInstanceTransform(i, X, true)) C.Inst.Add(X); }
					C.bMoved = RWInstancesText(C.Inst) != RWTagValue(P->ComponentTags, TEXT("RWI0:"));
				}
				else
				{
					C.X = P->GetComponentTransform();
					FTransform X0;
					C.bMoved = !RWParseTransform(RWTagValue(P->ComponentTags, TEXT("RWX0:")), X0) || !RWNearlySame(X0, C.X);
				}
				if (UStaticMeshComponent* S = Cast<UStaticMeshComponent>(P))
				{
					const FString MeshNow = S->GetStaticMesh() ? S->GetStaticMesh()->GetPathName() : FString();
					if (MeshNow != RWTagValue(P->ComponentTags, TEXT("RWM:"))) C.Mesh = MeshNow;
					for (int32 s = 0; s < S->GetNumMaterials(); ++s)
					{
						UMaterialInterface* Mi = S->GetMaterial(s);
						const FString MatNow = Mi ? Mi->GetPathName() : FString();
						C.Mats.Add(MatNow != RWTagValue(P->ComponentTags, *FString::Printf(TEXT("RWT%d:"), s)) ? MatNow : FString());
					}
				}
				L.LevelComps.Add(Id, MoveTemp(C));
			}
		}
		// machines, soil heaps and the excavation already under way
		if (A->Tags.Contains(TEXT("RW_Machine")))
		{
			const FString Key = RWTagValue(A->Tags, TEXT("RWMachine:"));
			if (!Key.IsEmpty()) L.LevelMachines.Add(Key, A->GetActorTransform());
		}
		if (A->Tags.Contains(TEXT("RW_Pile")))
		{
			// a cone 1 m wide (radius) and 1 m high, scaled to the heap
			const FVector S = A->GetActorScale3D();
			FRWLayout::FLevelPile Pl;
			Pl.P = A->GetActorLocation() * 0.01f;
			Pl.R = 0.5f * (FMath::Abs(S.X) + FMath::Abs(S.Y));
			Pl.H = FMath::Abs(S.Z);
			Pl.Soil = (uint8)FCString::Atoi(*RWTagValue(A->Tags, TEXT("RWSoil:")));
			L.LevelPiles.Add(Pl);
			L.bLevelPiles = true;
		}
		if (A->Tags.Contains(TEXT("RW_Dig")))
		{
			const FVector P = A->GetActorLocation() * 0.01f;
			L.LevelDigs.Add(FVector(P.X, P.Y, A->GetActorRotation().Yaw));
			L.bLevelPiles = true;
		}
	}
	if (L.LevelObjs.Num()) L.bLevelPiles = true; // (the level has the whole scenery: heaps and digs it does not have were removed)
	if (L.LevelObjs.Num() || L.LevelMachines.Num() || L.bLevelPiles)
		RWLog(FString::Printf(TEXT("Map: from the level: %d scenery objects with %d parts, %d machines, %d soil heaps, %d excavations"), L.LevelObjs.Num(), L.LevelComps.Num(), L.LevelMachines.Num(), L.LevelPiles.Num(), L.LevelDigs.Num()));
	// read: the game draws its own water, roads, trees and scenery, so the level's copies go (a hidden forest of 170 000 instances still costs)
	TArray<AActor*> Done;
	static const FName ReadTags[] = {TEXT("RW_Lake"), TEXT("RW_Road"), TEXT("RW_Forest"), TEXT("RW_Plants"), TEXT("RW_Scenery"), TEXT("RW_Machine"), TEXT("RW_Pile"), TEXT("RW_Dig")};
	for (TActorIterator<AActor> It(World); It; ++It)
		for (const FName& T : ReadTags) if (It->Tags.Contains(T)) { Done.Add(*It); break; }
	for (AActor* A : Done) A->Destroy();
	int32 Plants = 0; for (const FRWLayout::FLevelPlants& Lp : L.LevelPlants) Plants += Lp.Instances.Num();
	if (Plants) L.LevelTrees.Reset(); // (the full set of plants replaces the simple forest)
	if (L.LevelLakes.Num() || Roads || L.LevelTrees.Num() || Plants)
		RWLog(FString::Printf(TEXT("Map: from the level: %d lakes, %d road lines, %d trees, %d placed trees and plants in %d model lists"), L.LevelLakes.Num(), Roads, L.LevelTrees.Num(), Plants, L.LevelPlants.Num()));
}

#if WITH_EDITOR

#include "Editor.h"
#include "LandscapeInfo.h"
#include "LandscapeEdit.h"
#include "LandscapeEditLayer.h"
#include "LandscapeComponent.h"
#include "LandscapeSubsystem.h"
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/WorldPartitionHelpers.h"
#include "WorldPartition/WorldPartitionActorDescInstance.h"
#include "WorldPartition/WorldPartitionEditorLoaderAdapter.h"
#include "WorldPartition/LoaderAdapter/LoaderAdapterShape.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/StaticMesh.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "Components/SkyAtmosphereComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/SplineComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Misc/PackageName.h"
#include "UObject/Package.h"
#include "Materials/MaterialInstanceConstant.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "MeshDescription.h"
#include "Engine/Texture2D.h"
#include "RWScenery.h"
#include "RWMeshGen.h"
#include "RWFab.h"
#include "RWSoilLook.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Modules/ModuleManager.h"

namespace
{
	// 4032 quads over 4500 m (1.116 m between points), in components of 2 x 63 quads
	const int32 LandSize = 4033, LandSections = 2, LandSectionQuads = 63;
	const float LandScaleZ = 400.f; // a height value step of 3.125 cm, heights to +-1024 m
	const FName GeneratedTag(TEXT("RW_Generated"));
	TArray<FString> ReplacedFiles; // one file per actor in a World Partition level

	uint16 ToLand(float Zm) { return (uint16)FMath::Clamp(FMath::RoundToInt(Zm * 100.f * 128.f / LandScaleZ + 32768.f), 0, 65535); }
	float FromLand(uint16 H) { return (H - 32768.f) * LandScaleZ / 128.f * 0.01f; }

	UWorld* EditorWorld() { return GEditor ? GEditor->GetEditorWorldContext().World() : nullptr; }

	void EditorOnly(AActor* A)
	{
		// (a cooked game has its own terrain and lights: none of this goes into it)
		if (FBoolProperty* P = FindFProperty<FBoolProperty>(AActor::StaticClass(), TEXT("bIsEditorOnlyActor"))) P->SetPropertyValue_InContainer(A, true);
	}

	// The ground as the game makes it, on the Landscape's grid: the generator's surface plus the roads with their cuttings and banks.
	void ComputeGround(const FRWLayout& L, TArray<float>& Out)
	{
		const int32 Num = LandSize * LandSize;
		const float Step = 2.f * FRWLayout::MapHalf / (LandSize - 1), Org = -FRWLayout::MapHalf;
		Out.SetNumUninitialized(Num);
		ParallelFor(LandSize, [&](int32 y)
		{
			for (int32 x = 0; x < LandSize; ++x) Out[y * LandSize + x] = L.NaturalHeight(Org + x * Step, Org + y * Step);
		});
		TArray<float> BestD, RoadZ, RoadW;
		BestD.Init(1e9f, Num); RoadZ.Init(0.f, Num); RoadW.Init(0.f, Num);
		auto ToG = [&](float W) { return FMath::Clamp(FMath::RoundToInt((W - Org) / Step), 0, LandSize - 1); };
		for (const FRWRoad& R : L.Roads)
			for (int32 s = 0; s + 2 < R.Pts.Num(); s += 2)
			{
				const FVector2D A = R.Pts[s], B = R.Pts[s + 2];
				const FVector2D Dir = (B - A).GetSafeNormal(), Lat(-Dir.Y, Dir.X);
				float Off = 0.f;
				for (const float Sd : {-1.f, 0.f, 1.f})
				{
					const FVector2D Q = A + Lat * (Sd * (R.HalfW + 12.f));
					Off = FMath::Max(Off, FMath::Abs(Out[ToG(Q.Y) * LandSize + ToG(Q.X)] - R.Z[s]));
				}
				const float Ext = R.HalfW + 9.f + FMath::Min(1.5f * Off, 70.f);
				const int32 X0 = ToG(FMath::Min(A.X, B.X) - Ext), X1 = ToG(FMath::Max(A.X, B.X) + Ext), Y0 = ToG(FMath::Min(A.Y, B.Y) - Ext), Y1 = ToG(FMath::Max(A.Y, B.Y) + Ext);
				const FVector2D AB = B - A; const float L2 = FMath::Max(AB.SizeSquared(), 1e-4f);
				for (int32 y = Y0; y <= Y1; ++y)
					for (int32 x = X0; x <= X1; ++x)
					{
						const FVector2D P(Org + x * Step, Org + y * Step);
						const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / L2, 0.f, 1.f);
						const float D = FVector2D::Distance(P, A + AB * T);
						const int32 i = y * LandSize + x;
						if (D < BestD[i] && D < Ext) { BestD[i] = D; RoadZ[i] = FMath::Lerp(R.Z[s], R.Z[s + 2], T); RoadW[i] = R.HalfW; }
					}
			}
		for (int32 i = 0; i < Num; ++i)
		{
			if (RoadW[i] <= 0.f) continue;
			const float D = BestD[i], HW = RoadW[i];
			if (D <= HW + 0.6f) { Out[i] = RoadZ[i]; continue; }
			const float Foot = RoadZ[i] - 0.25f, Run = (D - HW - 0.6f) / 1.5f;
			Out[i] = Out[i] > Foot ? FMath::Min(Out[i], Foot + Run) : FMath::Max(Out[i], Foot - Run);
		}
	}

	void ForEachMapActor(UWorld* World, TFunctionRef<void(AActor*)> Fn)
	{
		// (with World Partition this also reaches what is not loaded at the moment, or a rebuild would leave it behind as a duplicate)
		TArray<AActor*> Found;
		auto Mine = [](AActor* A) { return A && (A->IsA<ALandscapeProxy>() || A->Tags.Contains(GeneratedTag)); };
		if (UWorldPartition* WP = World->GetWorldPartition())
		{
			FWorldPartitionHelpers::FForEachActorWithLoadingParams Params;
			Params.ActorClasses = {AActor::StaticClass()};
			Params.OnPreGarbageCollect = [&]() { for (AActor* A : Found) Fn(A); Found.Reset(); };
			FWorldPartitionHelpers::ForEachActorWithLoading(WP, [&](const FWorldPartitionActorDescInstance* D)
			{
				AActor* A = D->GetActor();
				if (Mine(A)) Found.Add(A);
				return true;
			}, Params);
		}
		for (TActorIterator<AActor> It(World); It; ++It) if (Mine(*It)) Found.Add(*It);
		for (AActor* A : Found) Fn(A);
	}

	// bForGame: the game reads it (lakes, roads, forest), so it goes into the packaged level too - hidden there, the game draws its own
	template <class T> T* SpawnGenerated(UWorld* World, const TCHAR* Label, const FTransform& X = FTransform::Identity, FName Kind = NAME_None)
	{
		T* A = World->SpawnActor<T>(T::StaticClass(), X);
		if (!A) return nullptr;
		A->SetActorLabel(Label);
		A->Tags.AddUnique(GeneratedTag);
		A->SetIsSpatiallyLoaded(false); // always there
		if (Kind.IsNone()) EditorOnly(A);
		else { A->Tags.AddUnique(Kind); A->SetActorHiddenInGame(true); A->SetActorEnableCollision(false); }
		return A;
	}

	void SetSeedInConfig(int32 Seed)
	{
		// the seed lives in the project's own settings file, so that the packaged game gets it too
		const FString Path = FPaths::SourceConfigDir() / TEXT("DefaultGame.ini");
		FString Text;
		FFileHelper::LoadFileToString(Text, *Path);
		TArray<FString> Lines;
		Text.ParseIntoArrayLines(Lines, false);
		bool bDone = false, bInSec = false;
		for (FString& Ln : Lines)
		{
			if (Ln.StartsWith(TEXT("["))) bInSec = Ln.TrimStartAndEnd() == TEXT("[RoadWorks.Map]");
			else if (bInSec && Ln.StartsWith(TEXT("Seed="))) { Ln = FString::Printf(TEXT("Seed=%d"), Seed); bDone = true; }
		}
		if (!bDone) { Lines.Add(TEXT("")); Lines.Add(TEXT("[RoadWorks.Map]")); Lines.Add(FString::Printf(TEXT("Seed=%d"), Seed)); }
		FFileHelper::SaveStringToFile(FString::Join(Lines, TEXT("\r\n")) + TEXT("\r\n"), *Path);
		if (GConfig) GConfig->SetInt(TEXT("RoadWorks.Map"), TEXT("Seed"), Seed, GGameIni);
	}

	AActor* SpawnLine(UWorld* World, const FString& Label, const TArray<FVector>& Pts, const FColor& Color, FName Kind = NAME_None)
	{
		if (Pts.Num() < 2) return nullptr;
		AActor* A = SpawnGenerated<AActor>(World, *Label, FTransform::Identity, Kind);
		if (!A) return nullptr;
		USplineComponent* Sp = NewObject<USplineComponent>(A, TEXT("Line"));
		A->SetRootComponent(Sp);
		A->AddInstanceComponent(Sp);
		Sp->RegisterComponent();
		Sp->SetSplinePoints(Pts, ESplineCoordinateSpace::World, true);
		Sp->SetDrawDebug(true);
		Sp->EditorUnselectedSplineSegmentColor = FLinearColor(Color);
		return A;
	}
}

bool URWMapTools::BuildMap(int32 Seed, UMaterialInterface* LandscapeMaterial, UMaterialInterface* LakeMaterial, UStaticMesh* TreeMesh, int32 TreeCount)
{
	UWorld* World = EditorWorld();
	if (!World) return false;
	if (Seed >= 0)
	{
		int32 Old = 0;
		if (GConfig) GConfig->GetInt(TEXT("RoadWorks.Map"), TEXT("Seed"), Old, GGameIni);
		SetSeedInConfig(Seed);
		if (Old != Seed) ClearSculpt();
	}
	const double T0 = FPlatformTime::Seconds();
	FRWLayout L;
	L.bIgnoreSculpt = true;
	L.Init();
	TArray<float> Ground;
	ComputeGround(L, Ground);

	// anything an earlier run made goes first
	int32 Removed = 0;
	ForEachMapActor(World, [&](AActor* A)
	{
		if (!A || A->IsActorBeingDestroyed()) return;
		if (UPackage* Pk = A->GetExternalPackage()) ReplacedFiles.AddUnique(FPackageName::LongPackageNameToFilename(Pk->GetName(), FPackageName::GetAssetPackageExtension()));
		World->DestroyActor(A);
		++Removed;
	});

	// ---- the Landscape ----
	TArray<uint16> Heights; Heights.SetNumUninitialized(Ground.Num());
	ParallelFor(Ground.Num(), [&](int32 i) { Heights[i] = ToLand(Ground[i]); });
	const float ScaleXY = 2.f * FRWLayout::MapHalf * 100.f / (LandSize - 1);
	ALandscape* Land = World->SpawnActor<ALandscape>(FVector(-FRWLayout::MapHalf * 100.f, -FRWLayout::MapHalf * 100.f, 0.f), FRotator::ZeroRotator);
	if (!Land) return false;
	Land->LandscapeMaterial = LandscapeMaterial;
	Land->SetActorRelativeScale3D(FVector(ScaleXY, ScaleXY, LandScaleZ));
	Land->StaticLightingLOD = 2;
	TMap<FGuid, TArray<uint16>> HeightData; HeightData.Add(FGuid(), MoveTemp(Heights));
	TMap<FGuid, TArray<FLandscapeImportLayerInfo>> Layers; Layers.Add(FGuid(), TArray<FLandscapeImportLayerInfo>());
	Land->Import(FGuid::NewGuid(), 0, 0, LandSize - 1, LandSize - 1, LandSections, LandSectionQuads, HeightData, nullptr, Layers, ELandscapeImportAlphamapType::Additive, TArrayView<const FLandscapeLayer>());
	Land->SetActorLabel(TEXT("RW_Landscape"));
	if (ULandscapeInfo* Info = Land->GetLandscapeInfo())
	{
		Info->UpdateLayerInfoMap(Land);
		if (World->GetWorldPartition())
			if (ULandscapeSubsystem* Sub = World->GetSubsystem<ULandscapeSubsystem>()) Sub->ChangeGridSize(Info, 4);
	}
	for (TActorIterator<ALandscapeProxy> It(World); It; ++It) EditorOnly(*It);

	// ---- light to work by (the game makes its own sky and sun) ----
	if (ADirectionalLight* Sun = SpawnGenerated<ADirectionalLight>(World, TEXT("RW_EditorSun"), FTransform(FRotator(-48.f, 40.f, 0.f), FVector(0, 0, 200000.f))))
		Sun->SetMobility(EComponentMobility::Movable);
	if (ASkyLight* Sky = SpawnGenerated<ASkyLight>(World, TEXT("RW_EditorSky"), FTransform(FVector(0, 0, 200000.f))))
	{
		Sky->GetLightComponent()->SetMobility(EComponentMobility::Movable);
		Sky->GetLightComponent()->SetRealTimeCaptureEnabled(true);
	}
	SpawnGenerated<ASkyAtmosphere>(World, TEXT("RW_EditorAtmosphere"));

	// ---- lakes ----
	UStaticMesh* Plane = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));
	int32 Li = 0;
	for (const FRWLayout::FRWLake& Lk : L.Lakes)
	{
		const FTransform X(FRotator::ZeroRotator, FVector(Lk.C.X, Lk.C.Y, Lk.Z - 0.1f) * 100.f, FVector(2.f * Lk.R + 40.f, 2.f * Lk.R + 40.f, 1.f));
		if (AStaticMeshActor* W = SpawnGenerated<AStaticMeshActor>(World, *FString::Printf(TEXT("RW_Lake_%d"), ++Li), X, TEXT("RW_Lake")))
		{
			W->SetMobility(EComponentMobility::Movable);
			W->GetStaticMeshComponent()->SetStaticMesh(Plane);
			if (LakeMaterial) W->GetStaticMeshComponent()->SetMaterial(0, LakeMaterial);
		}
	}
	// ---- the lines of the roads, the streams and the river ----
	for (const FRWRoad& R : L.Roads)
	{
		TArray<FVector> P;
		// (a point every 10 m: the tight curves of a mountain road stay as they are)
		for (int32 i = 0; i < R.Pts.Num(); i += 5) P.Add(FVector(R.Pts[i].X, R.Pts[i].Y, R.Z[i] + 1.f) * 100.f);
		if (P.Num() && (P.Last() - FVector(R.Pts.Last().X, R.Pts.Last().Y, R.Z.Last() + 1.f) * 100.f).Size() > 1.f) P.Add(FVector(R.Pts.Last().X, R.Pts.Last().Y, R.Z.Last() + 1.f) * 100.f);
		if (AActor* Ra = SpawnLine(World, FString::Printf(TEXT("RW_Road_%s"), *R.Name.Replace(TEXT(" "), TEXT("_"))), P, FColor(255, 160, 40), TEXT("RW_Road")))
			Ra->Tags.Add(FName(*(TEXT("RWRoad:") + R.Name)));
	}
	int32 Si = 0;
	for (const FRWStream& St : L.Streams)
	{
		TArray<FVector> P;
		for (int32 i = 0; i < St.Pts.Num(); i += 12) P.Add(FVector(St.Pts[i].X, St.Pts[i].Y, St.Bed[i] + 1.f) * 100.f);
		SpawnLine(World, FString::Printf(TEXT("RW_Stream_%d"), ++Si), P, FColor(60, 160, 255));
	}
	{
		TArray<FVector> P;
		for (float X = -FRWLayout::MapHalf; X <= FRWLayout::MapHalf; X += 30.f) P.Add(FVector(X, L.RiverY(X), L.WaterZ) * 100.f);
		SpawnLine(World, TEXT("RW_River"), P, FColor(60, 160, 255));
	}
	// ---- the forest: the game plants its trees where these stand (move, add or remove instances in the editor) ----
	int32 Planted = 0;
	if (TreeMesh && TreeCount > 0)
	{
		if (AActor* F = SpawnGenerated<AActor>(World, TEXT("RW_Forest"), FTransform::Identity, TEXT("RW_Forest")))
		{
			UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(F, TEXT("Trees"));
			F->SetRootComponent(H);
			F->AddInstanceComponent(H);
			H->SetStaticMesh(TreeMesh);
			H->RegisterComponent();
			FRandomStream Rs(L.Params.Seed + 4242);
			const float Step = 2.f * FRWLayout::MapHalf / (LandSize - 1), Org = -FRWLayout::MapHalf;
			TArray<FTransform> Tr;
			Tr.Reserve(TreeCount);
			for (int32 k = 0; k < TreeCount * 3 && Tr.Num() < TreeCount; ++k)
			{
				const int32 x = Rs.RandRange(3, LandSize - 4), y = Rs.RandRange(3, LandSize - 4);
				const float X = Org + x * Step, Y = Org + y * Step, Z = Ground[y * LandSize + x];
				const float Sl = FVector2D(Ground[y * LandSize + x + 2] - Ground[y * LandSize + x - 2], Ground[(y + 2) * LandSize + x] - Ground[(y - 2) * LandSize + x]).Size() / (4.f * Step);
				if (Sl > 0.95f || Z < L.WaterZ + 1.f || Z > L.Params.TreeLine + Rs.FRandRange(-90.f, 90.f)) continue;
				if (L.RiverDist(X, Y) < 11.f || L.StreamDist(X, Y) < 6.f || L.LakeShoreDist(X, Y) < 8.f) continue;
				float RZ; if (L.RoadInfluence(X, Y, RZ) > 0.05f) continue;
				bool bZone = false;
				for (const FRWZone& Zn : L.Zones) if (Zn.Type != ERWZone::Forest && FRWLayout::InZone(Zn, X, Y, 6.f)) { bZone = true; break; }
				if (bZone || RWNoise2(X / 95.f, Y / 95.f, 19) < -0.3f) continue;
				// (the plain in the middle stays open; the forest thickens towards the hills)
				const float Edge = FMath::Max(FMath::Abs(X), FMath::Abs(Y));
				if ((Edge < 255.f && Y < 120.f) || Rs.FRand() > FMath::Clamp((Edge - 200.f) / 180.f + 0.25f, 0.f, 1.f)) continue;
				Tr.Add(FTransform(FRotator(0.f, Rs.FRand() * 360.f, 0.f), FVector(X, Y, Z) * 100.f, FVector(Rs.FRandRange(0.8f, 1.3f))));
			}
			H->AddInstances(Tr, false);
			Planted = Tr.Num();
		}
	}
	RWLog(FString::Printf(TEXT("Map built in %.1f s: removed %d earlier actors, Landscape %d x %d points, seed %d, %d lakes, %d roads, %d streams, %d preview trees"), FPlatformTime::Seconds() - T0, Removed, LandSize, LandSize, L.Params.Seed, L.Lakes.Num(), L.Roads.Num(), L.Streams.Num(), Planted));
	return true;
}

int32 URWMapTools::ImportPlants(const FString& File)
{
	UWorld* World = EditorWorld();
	TArray<uint8> In;
	if (!World || !FFileHelper::LoadFileToArray(In, *File)) return -1;
	FMemoryReader R(In);
	int32 Magic = 0, Lists = 0, Total = 0;
	R << Magic << Lists;
	if (Magic != 0x52575031) return -1;
	// the earlier plants and the simple forest go first (their files are removed by FinishRebuild after saving)
	ForEachMapActor(World, [&](AActor* A)
	{
		if (!A || A->IsActorBeingDestroyed() || !(A->Tags.Contains(TEXT("RW_Plants")) || A->Tags.Contains(TEXT("RW_Forest")))) return;
		if (UPackage* Pk = A->GetExternalPackage()) ReplacedFiles.AddUnique(FPackageName::LongPackageNameToFilename(Pk->GetName(), FPackageName::GetAssetPackageExtension()));
		World->DestroyActor(A);
	});
	for (int32 l = 0; l < Lists && !R.IsError(); ++l)
	{
		FString Path; uint8 bTree = 0; int32 N = 0;
		R << Path << bTree << N;
		TArray<FTransform> Xs; Xs.Reserve(N);
		for (int32 i = 0; i < N; ++i) { FVector L, S; FQuat Q; R << L << Q << S; Xs.Add(FTransform(Q, L, S)); }
		UStaticMesh* Mesh = LoadObject<UStaticMesh>(nullptr, *Path);
		if (!Mesh) { RWLog(FString::Printf(TEXT("Plants import: %s not found"), *Path)); continue; }
		AActor* A = SpawnGenerated<AActor>(World, *FString::Printf(TEXT("RW_Plants_%s"), *Mesh->GetName()), FTransform::Identity, TEXT("RW_Plants"));
		if (!A) continue;
		A->Tags.Add(bTree ? FName(TEXT("RWTree")) : FName(TEXT("RWPlant")));
		A->Tags.Add(FName(*(TEXT("RWMesh:") + Path)));
		UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(A, TEXT("Plants"));
		A->SetRootComponent(H);
		A->AddInstanceComponent(H);
		H->SetStaticMesh(Mesh);
		H->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		H->RegisterComponent();
		H->AddInstances(Xs, false, true);
		Total += N;
	}
	RWLog(FString::Printf(TEXT("Plants import: %d instances in %d lists from %s"), Total, Lists, *File));
	return Total;
}

namespace
{
	// a new or replaced asset in a package of its own
	template <class T> T* MakeAsset(const FString& Folder, const FString& Name, bool& bExisted)
	{
		const FString PkgName = Folder / Name;
		bExisted = false;
		if (T* Old = LoadObject<T>(nullptr, *(PkgName + TEXT(".") + Name), nullptr, LOAD_NoWarn | LOAD_Quiet)) { bExisted = true; return Old; }
		UPackage* Pkg = CreatePackage(*PkgName);
		Pkg->FullyLoad();
		T* A = NewObject<T>(Pkg, *Name, RF_Public | RF_Standalone);
		FAssetRegistryModule::AssetCreated(A);
		Pkg->MarkPackageDirty();
		return A;
	}

	FString CleanName(const FString& In)
	{
		FString O;
		for (const TCHAR C : In) O.AppendChar(FChar::IsAlnum(C) ? C : TEXT('_'));
		return O.Left(48) + FString::Printf(TEXT("_%08x"), FCrc::StrCrc32(*In));
	}
}

int32 URWMapTools::ImportScenery(const FString& File)
{
	UWorld* World = EditorWorld();
	TArray<uint8> In;
	if (!World || !FFileHelper::LoadFileToArray(In, *File)) return -1;
	FMemoryReader R(In);
	int32 Magic = 0, Ver = 0, NM = 0;
	R << Magic << Ver;
	if (Magic != RWSceneryMagic || Ver != RWSceneryVersion) { RWLog(FString::Printf(TEXT("Scenery import: %s is not a version %d scenery file (export it again from the game)"), *File, RWSceneryVersion)); return -1; }
	R << NM;
	// what an earlier import made goes first, before anything new is made (its files are removed by FinishRebuild after saving)
	static const FName Mine[] = {TEXT("RW_Scenery"), TEXT("RW_Machine"), TEXT("RW_Pile"), TEXT("RW_Dig")};
	ForEachMapActor(World, [&](AActor* A)
	{
		if (!A || A->IsActorBeingDestroyed()) return;
		bool bMine = false;
		for (const FName& T : Mine) bMine |= A->Tags.Contains(T);
		if (!bMine) return;
		if (UPackage* Pk = A->GetExternalPackage()) ReplacedFiles.AddUnique(FPackageName::LongPackageNameToFilename(Pk->GetName(), FPackageName::GetAssetPackageExtension()));
		World->DestroyActor(A);
	});
	int32 Made = 0;
	auto MeshAsset = [&](const FString& Name, const FMeshBuild& B, bool bAlways) -> UStaticMesh*
	{
		bool bExisted = false;
		UStaticMesh* SM = MakeAsset<UStaticMesh>(TEXT("/Game/Maps/Scenery/Meshes"), Name, bExisted);
		if (!bExisted || bAlways)
		{
			SM->GetStaticMaterials().Reset();
			SM->GetStaticMaterials().Add(FStaticMaterial(FRWMeshGen::DefaultMat, FName(TEXT("Mat")), FName(TEXT("Mat"))));
			if (SM->GetNumSourceModels() == 0) SM->AddSourceModel();
			FStaticMeshSourceModel& Src = SM->GetSourceModel(0);
			Src.BuildSettings.bRecomputeNormals = false;
			Src.BuildSettings.bRecomputeTangents = true;
			Src.BuildSettings.bGenerateLightmapUVs = false;
			FMeshDescription* MD = SM->CreateMeshDescription(0);
			MD->Empty();
			FRWMeshGen::FillDescription(B, *MD);
			SM->CommitMeshDescription(0);
			SM->Build(true);
			SM->PostEditChange();
			SM->MarkPackageDirty();
			++Made;
		}
		SM->AddToRoot(); // (kept through the garbage collections that loading parts of the world brings)
		return SM;
	};
	// ---- meshes: the game's own as real mesh assets ----
	TArray<UStaticMesh*> Meshes; Meshes.SetNum(NM);
	for (int32 i = 0; i < NM && !R.IsError(); ++i)
	{
		uint8 bAsset = 0; FString Ref;
		R << bAsset << Ref;
		if (bAsset) { Meshes[i] = LoadObject<UStaticMesh>(nullptr, *Ref); continue; }
		FMeshBuild B;
		R << B.P << B.N << B.UV << B.T;
		if (B.T.Num() >= 3) Meshes[i] = MeshAsset(TEXT("SM_") + CleanName(Ref), B, Ref.StartsWith(TEXT("proc_")));
	}
	// ---- the models' own pictures as texture assets ----
	int32 NImg = 0;
	R << NImg;
	TArray<UTexture2D*> Images; Images.SetNum(NImg);
	IImageWrapperModule& IW = FModuleManager::LoadModuleChecked<IImageWrapperModule>(TEXT("ImageWrapper"));
	for (int32 i = 0; i < NImg && !R.IsError(); ++i)
	{
		TArray<uint8> Bytes;
		R << Bytes;
		const EImageFormat Fmt = IW.DetectImageFormat(Bytes.GetData(), Bytes.Num());
		TSharedPtr<IImageWrapper> Wr = Fmt != EImageFormat::Invalid ? IW.CreateImageWrapper(Fmt) : nullptr;
		TArray<uint8> Raw;
		if (!Wr.IsValid() || !Wr->SetCompressed(Bytes.GetData(), Bytes.Num()) || !Wr->GetRaw(ERGBFormat::BGRA, 8, Raw)) continue;
		bool bExisted = false;
		UTexture2D* T = MakeAsset<UTexture2D>(TEXT("/Game/Maps/Scenery/Textures"), FString::Printf(TEXT("T_Model_%08x_%d"), FCrc::MemCrc32(Bytes.GetData(), Bytes.Num()), Bytes.Num()), bExisted);
		if (!bExisted)
		{
			T->Source.Init(Wr->GetWidth(), Wr->GetHeight(), 1, 1, TSF_BGRA8, Raw.GetData());
			T->SRGB = true;
			T->PostEditChange();
			T->MarkPackageDirty();
		}
		Images[i] = T;
	}
	// ---- materials: one constant instance for each colour (and picture) of each base material ----
	int32 NT = 0;
	R << NT;
	TArray<UMaterialInterface*> Mats; Mats.SetNum(NT);
	for (int32 i = 0; i < NT && !R.IsError(); ++i)
	{
		uint8 bMid = 0, Has = 0; FString Path, Tex; FLinearColor Color; float Rough = 0.f, Metal = 0.f;
		R << bMid << Path << Color << Rough << Metal << Has << Tex;
		UMaterialInterface* Parent = LoadObject<UMaterialInterface>(nullptr, *Path);
		if (!Parent) continue;
		if (!bMid) { Mats[i] = Parent; continue; }
		UTexture* TexObj = nullptr;
		if (Tex.StartsWith(TEXT("img:"))) { const int32 Ix = FCString::Atoi(*Tex.Mid(4)); TexObj = Images.IsValidIndex(Ix) ? Images[Ix] : nullptr; }
		else if (!Tex.IsEmpty()) TexObj = LoadObject<UTexture>(nullptr, *Tex);
		const FString Key = FString::Printf(TEXT("%s|%.3f,%.3f,%.3f,%.3f|%.2f|%.2f|%d|%s"), *Path, Color.R, Color.G, Color.B, Color.A, Rough, Metal, Has, TexObj ? *TexObj->GetPathName() : TEXT(""));
		bool bExisted = false;
		UMaterialInstanceConstant* Mi = MakeAsset<UMaterialInstanceConstant>(TEXT("/Game/Maps/Scenery/Materials"), FString::Printf(TEXT("MI_%s_%08x"), *Parent->GetName().Left(24), FCrc::StrCrc32(*Key)), bExisted);
		if (!bExisted)
		{
			Mi->SetParentEditorOnly(Parent);
			if (Has & 1) Mi->SetVectorParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Color")), Color);
			if (Has & 2) Mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Roughness")), Rough);
			if (Has & 4) Mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Metallic")), Metal);
			if (TexObj) Mi->SetTextureParameterValueEditorOnly(FMaterialParameterInfo(TEXT("BaseTex")), TexObj);
			Mi->PostEditChange();
		}
		Mats[i] = Mi;
	}
	// ---- objects: one actor each (a house, the yard, a prop, a machine, a 500 m square of road lines...) ----
	struct FObjIn { FString Name; uint8 Kind = 0; FTransform Anchor; AActor* A = nullptr; };
	int32 NO = 0;
	R << NO;
	TArray<FObjIn> Objs; Objs.SetNum(NO);
	for (int32 i = 0; i < NO && !R.IsError(); ++i) R << Objs[i].Name << Objs[i].Kind << Objs[i].Anchor;
	auto ActorOf = [&](FObjIn& O) -> AActor*
	{
		if (O.A) return O.A;
		const bool bMachine = O.Kind == (uint8)ERWSceneryKind::Machine;
		const FString Label = (bMachine ? TEXT("RW_Machine_") : TEXT("RW_Scenery_")) + O.Name.Replace(TEXT("#"), TEXT("_"));
		AActor* A = SpawnGenerated<AActor>(World, *Label, O.Anchor, bMachine ? FName(TEXT("RW_Machine")) : FName(TEXT("RW_Scenery")));
		if (!A) return nullptr;
		USceneComponent* Rt = NewObject<USceneComponent>(A, TEXT("Root"));
		Rt->SetMobility(EComponentMobility::Movable);
		A->SetRootComponent(Rt); A->AddInstanceComponent(Rt); Rt->RegisterComponent();
		A->SetActorTransform(O.Anchor);
		if (bMachine) A->Tags.Add(FName(*(TEXT("RWMachine:") + O.Name)));
		else
		{
			A->Tags.Add(FName(*(TEXT("RWObj:") + O.Name)));
			A->Tags.Add(FName(*FString::Printf(TEXT("RWKind:%d"), O.Kind)));
			A->Tags.Add(FName(*(TEXT("RWAnchor:") + RWTransformText(O.Anchor))));
		}
		O.A = A;
		return A;
	};
	int32 NI = 0, Placed = 0;
	R << NI;
	for (int32 i = 0; i < NI && !R.IsError(); ++i)
	{
		int32 Obj = -1, Mesh = -1; FString Id; uint8 bInst = 0, bShadow = 1; TArray<int32> MatIx; FTransform X; TArray<FTransform> Inst;
		R << Obj << Id << bInst << Mesh << MatIx << X << Inst << bShadow;
		UStaticMesh* SM = Meshes.IsValidIndex(Mesh) ? Meshes[Mesh] : nullptr;
		AActor* A = SM && Objs.IsValidIndex(Obj) ? ActorOf(Objs[Obj]) : nullptr;
		if (!A) continue;
		UStaticMeshComponent* C = nullptr;
		if (bInst)
		{
			UInstancedStaticMeshComponent* I = NewObject<UInstancedStaticMeshComponent>(A, NAME_None);
			I->SetStaticMesh(SM);
			C = I;
		}
		else
		{
			C = NewObject<UStaticMeshComponent>(A, NAME_None);
			C->SetStaticMesh(SM);
		}
		C->SetMobility(EComponentMobility::Movable);
		C->SetupAttachment(A->GetRootComponent());
		A->AddInstanceComponent(C);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->SetCastShadow(bShadow != 0);
		C->RegisterComponent();
		if (bInst) { Cast<UInstancedStaticMeshComponent>(C)->AddInstances(Inst, false, true); Placed += Inst.Num(); }
		else { C->SetWorldTransform(X); ++Placed; }
		for (int32 s = 0; s < MatIx.Num(); ++s) if (Mats.IsValidIndex(MatIx[s]) && Mats[MatIx[s]]) C->SetMaterial(s, Mats[MatIx[s]]);
		if (!Id.IsEmpty())
		{
			// what it was when it came in: the game sees what was changed by comparing with these
			C->ComponentTags.Add(FName(*(TEXT("RWID:") + Id)));
			C->ComponentTags.Add(FName(*(TEXT("RWM:") + SM->GetPathName())));
			for (int32 s = 0; s < C->GetNumMaterials(); ++s)
				if (UMaterialInterface* Mi = C->GetMaterial(s)) C->ComponentTags.Add(FName(*FString::Printf(TEXT("RWT%d:%s"), s, *Mi->GetPathName())));
			if (bInst) C->ComponentTags.Add(FName(*(TEXT("RWI0:") + RWInstancesText(Inst))));
			else C->ComponentTags.Add(FName(*(TEXT("RWX0:") + RWTransformText(C->GetComponentTransform()))));
		}
	}
	// ---- soil heaps: a cone of the heap's soil, 1 m (radius) by 1 m, scaled to the heap ----
	FMeshBuild ConeB;
	ConeB.Cone(FVector::ZeroVector, 1.f, 1.f, 40, 0.f, 1);
	UStaticMesh* ConeM = MeshAsset(TEXT("SM_RW_SoilHeap"), ConeB, false);
	UMaterialInterface* Loose = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_SoilLoose.M_SoilLoose"));
	auto SoilMat = [&](ESoil M) -> UMaterialInterface*
	{
		if (!Loose) return nullptr;
		const FString Set = FRWSoilLook::SetFor(M, 0.3f);
		bool bExisted = false;
		UMaterialInstanceConstant* Mi = MakeAsset<UMaterialInstanceConstant>(TEXT("/Game/Maps/Scenery/Materials"), TEXT("MI_Heap_") + Set, bExisted);
		if (!bExisted)
		{
			Mi->SetParentEditorOnly(Loose);
			for (const TCHAR* K : {TEXT("BaseColor"), TEXT("Normal"), TEXT("ORM")})
				if (UTexture2D* T = FRWSoilLook::Tex(Set, K))
					Mi->SetTextureParameterValueEditorOnly(FMaterialParameterInfo(FName(*FString::Printf(TEXT("%sTex"), FCString::Strcmp(K, TEXT("BaseColor")) == 0 ? TEXT("Base") : K))), T);
			Mi->SetVectorParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Color")), FLinearColor(1.05f, 1.03f, 1.f));
			Mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Tiling")), M == ESoil::Gravel || M == ESoil::SmallRock || M == ESoil::LargeRock ? 0.45f : 0.6f);
			Mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Wet")), 0.2f);
			Mi->PostEditChange();
		}
		return Mi;
	};
	auto HeapPart = [&](AActor* A, const FVector& At, const FVector& Scale, ESoil M, bool bRoot)
	{
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(A, bRoot ? FName(TEXT("Heap")) : NAME_None);
		C->SetMobility(EComponentMobility::Movable);
		C->SetStaticMesh(ConeM);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		if (UMaterialInterface* Mi = SoilMat(M)) C->SetMaterial(0, Mi);
		if (bRoot) A->SetRootComponent(C); else C->SetupAttachment(A->GetRootComponent());
		A->AddInstanceComponent(C);
		C->RegisterComponent();
		if (!bRoot) { C->SetWorldLocation(At); C->SetWorldScale3D(Scale); }
		return C;
	};
	int32 NP = 0, ND = 0;
	R << NP;
	for (int32 i = 0; i < NP && !R.IsError(); ++i)
	{
		FVector P; float Rr = 0.f, H = 0.f; uint8 Soil = 0;
		R << P << Rr << H << Soil;
		AActor* A = SpawnGenerated<AActor>(World, *FString::Printf(TEXT("RW_Pile_%d_%s"), i + 1, *FRWSoilLook::SetFor((ESoil)Soil, 0.3f)), FTransform::Identity, TEXT("RW_Pile"));
		if (!A) continue;
		HeapPart(A, FVector::ZeroVector, FVector::OneVector, (ESoil)Soil, true);
		A->SetActorTransform(FTransform(FRotator::ZeroRotator, P * 100.f, FVector(Rr, Rr, H)));
		A->Tags.Add(FName(*FString::Printf(TEXT("RWSoil:%d"), Soil)));
	}
	// ---- the excavation already under way: the pit's outline on the ground and its two heaps of spoil ----
	R << ND;
	for (int32 i = 0; i < ND && !R.IsError(); ++i)
	{
		FVector At; float Yaw = 0.f;
		R << At << Yaw;
		AActor* A = SpawnGenerated<AActor>(World, *FString::Printf(TEXT("RW_Dig_%d"), i + 1), FTransform::Identity, TEXT("RW_Dig"));
		if (!A) continue;
		UStaticMeshComponent* Pit = NewObject<UStaticMeshComponent>(A, TEXT("Pit"));
		Pit->SetMobility(EComponentMobility::Movable);
		Pit->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")));
		Pit->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		if (UMaterialInterface* Mi = SoilMat(ESoil::WetSoil)) Pit->SetMaterial(0, Mi);
		A->SetRootComponent(Pit); A->AddInstanceComponent(Pit); Pit->RegisterComponent();
		A->SetActorTransform(FTransform(FRotator(0.f, Yaw, 0.f), At * 100.f));
		Pit->SetRelativeScale3D(FVector(12.5f, 10.5f, 0.3f)); // (the pit is 12.5 x 10.5 m and 1.4 m deep in the game's ground)
		const FTransform AX = A->GetActorTransform();
		HeapPart(A, AX.TransformPosition(FVector(0.f, -950.f, 0.f)), FVector(3.2f, 3.2f, 1.9f), ESoil::DrySoil, false);
		HeapPart(A, AX.TransformPosition(FVector(800.f, -850.f, 0.f)), FVector(2.5f, 2.5f, 1.6f), ESoil::DrySoil, false);
	}
	// ---- the lakes: the game's water material, and the island in the middle (both move with the lake's actor) ----
	FRWFab::Scan();
	int32 Lakes = 0;
	UStaticMesh* IslandM = LoadObject<UStaticMesh>(nullptr, TEXT("/Game/WaterMaterials/Meshes/SM_Island.SM_Island"));
	ForEachMapActor(World, [&](AActor* A)
	{
		AStaticMeshActor* L = Cast<AStaticMeshActor>(A);
		if (!L || !L->Tags.Contains(TEXT("RW_Lake"))) return;
		if (FRWFab::Lake) L->GetStaticMeshComponent()->SetMaterial(0, FRWFab::Lake);
		bool bHas = false;
		TArray<UStaticMeshComponent*> Cs; L->GetComponents(Cs);
		for (UStaticMeshComponent* C : Cs) bHas |= C->GetFName() == TEXT("Island");
		if (!bHas && IslandM)
		{
			UStaticMeshComponent* Is = NewObject<UStaticMeshComponent>(L, TEXT("Island"));
			Is->SetMobility(EComponentMobility::Movable);
			Is->SetStaticMesh(IslandM);
			Is->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			Is->SetupAttachment(L->GetRootComponent());
			Is->SetUsingAbsoluteScale(true);
			L->AddInstanceComponent(Is);
			Is->RegisterComponent();
			Is->SetWorldLocationAndRotation(L->GetActorLocation() - FVector(0.f, 0.f, 40.f), FRotator(0.f, 30.f, 0.f));
			Is->SetWorldScale3D(FVector(0.7f));
		}
		L->MarkPackageDirty();
		++Lakes;
	});
	for (UStaticMesh* M : Meshes) if (M && M->IsRooted()) M->RemoveFromRoot();
	if (ConeM && ConeM->IsRooted()) ConeM->RemoveFromRoot();
	int32 Actors = 0; for (const FObjIn& O : Objs) Actors += O.A ? 1 : 0;
	RWLog(FString::Printf(TEXT("Scenery import: %d objects in %d actors (machines among them), %d heaps, %d digs, %d lakes given the game's water, %d mesh assets made, %d pictures, %d materials"),
		Placed, Actors, NP, ND, Lakes, Made, NImg, NT));
	return Placed;
}

bool URWMapTools::SetLandscapeMaterial(UMaterialInterface* Material)
{
	UWorld* World = EditorWorld();
	if (!World || !Material) return false;
	bool bAny = false;
	for (TActorIterator<ALandscape> It(World); It; ++It)
	{
		It->Modify();
		It->LandscapeMaterial = Material;
		FProperty* P = FindFProperty<FProperty>(ALandscapeProxy::StaticClass(), TEXT("LandscapeMaterial"));
		FPropertyChangedEvent E(P);
		It->PostEditChangeProperty(E);
		bAny = true;
	}
	return bAny;
}

bool URWMapTools::BakeSurface(int32 Size)
{
	Size = FMath::Clamp(Size, 256, 8192);
	// the ground as the game has it, with the sculpted changes (heights decide where it is wet)
	FRWLayout L;
	L.Init();
	const float Half = FRWLayout::MapHalf, Step = 2.f * Half / Size;
	const int32 Num = Size * Size;
	// texel centres over the map: the material samples at (world + Half) / (2 Half)
	auto WX = [&](int32 i) { return -Half + (i + 0.5f) * Step; };
	TArray<float> Ground; Ground.SetNumUninitialized(Num);
	TArray<uint8> Soil; Soil.SetNumUninitialized(Num);
	TArray<float> GrassW; GrassW.SetNumUninitialized(Num);
	TArray<float> Wet; Wet.SetNumUninitialized(Num);
	ParallelFor(Size, [&](int32 y)
	{
		for (int32 x = 0; x < Size; ++x)
		{
			const int32 i = y * Size + x;
			const float X = WX(x), Y = WX(y);
			const float H = L.NaturalHeight(X, Y);
			Ground[i] = H;
			ESoil S = L.Strata(X, Y, 0.01f);
			for (const FRWZone& Z : L.Zones)
				if ((Z.Type == ERWZone::Depot || Z.Type == ERWZone::Plant || Z.Type == ERWZone::Village) && FRWLayout::InZone(Z, X, Y))
					S = Z.Type == ERWZone::Village ? ESoil::Compacted : ESoil::Gravel;
			Soil[i] = (uint8)S;
			GrassW[i] = (S == ESoil::Gravel || S == ESoil::Compacted) ? 0.f : L.InitGrass(X, Y);
			Wet[i] = L.InitMoisture(X, Y, H);
		}
	});
	// roads: the surface, the shoulders, and cuttings and banks as the game makes them
	TArray<float> BestD; BestD.Init(1e9f, Num);
	TArray<uint8> RType; RType.Init(0, Num);
	TArray<float> RZ, RW; RZ.Init(0.f, Num); RW.Init(0.f, Num);
	auto ToG = [&](float W) { return FMath::Clamp(FMath::FloorToInt((W + Half) / Step), 0, Size - 1); };
	for (const FRWRoad& Rd : L.Roads)
		for (int32 s = 0; s + 1 < Rd.Pts.Num(); ++s)
		{
			const FVector2D A = Rd.Pts[s], B = Rd.Pts[s + 1];
			const float Ext = Rd.HalfW + 9.f + 30.f;
			const int32 X0 = ToG(FMath::Min(A.X, B.X) - Ext), X1 = ToG(FMath::Max(A.X, B.X) + Ext), Y0 = ToG(FMath::Min(A.Y, B.Y) - Ext), Y1 = ToG(FMath::Max(A.Y, B.Y) + Ext);
			const FVector2D AB = B - A; const float L2 = FMath::Max(AB.SizeSquared(), 1e-4f);
			for (int32 y = Y0; y <= Y1; ++y)
				for (int32 x = X0; x <= X1; ++x)
				{
					const FVector2D P(WX(x), WX(y));
					const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / L2, 0.f, 1.f);
					const float D = FVector2D::Distance(P, A + AB * T);
					const int32 i = y * Size + x;
					if (D < BestD[i] && D < Ext) { BestD[i] = D; RZ[i] = FMath::Lerp(Rd.Z[s], Rd.Z[s + 1], T); RW[i] = Rd.HalfW; RType[i] = Rd.bAsphalt ? 1 : (Rd.MaxGrade > 0.f ? 3 : 2); }
				}
		}
	for (int32 i = 0; i < Num; ++i)
	{
		if (!RType[i]) continue;
		const float D = BestD[i], HW = RW[i];
		if (D <= HW + 0.6f)
		{
			Soil[i] = (uint8)(RType[i] == 1 ? (D > HW ? ESoil::Gravel : ESoil::Asphalt) : RType[i] == 3 ? ESoil::Gravel : ESoil::Laterite);
			GrassW[i] = 0.f; Wet[i] = FMath::Min(Wet[i], 0.24f);
			continue;
		}
		const float Foot = RZ[i] - 0.25f, Run = (D - HW - 0.6f) / 1.5f;
		const float Was = Ground[i], Now = Was > Foot ? FMath::Min(Was, Foot + Run) : FMath::Max(Was, Foot - Run), Moved = Now - Was;
		if (FMath::Abs(Moved) > 0.1f) { Soil[i] = (uint8)(Moved < -3.f ? ESoil::SmallRock : ESoil::DrySoil); GrassW[i] *= Moved < -3.f ? 0.15f : 0.55f; }
		else GrassW[i] *= 1.f - 0.6f * (1.f - FMath::SmoothStep(HW + 0.6f, HW + 9.f, D));
	}
	// weights as the game's vertices carry them (ARWTerrain::PBRWeights)
	TArray<FColor> A, B, C;
	A.SetNumUninitialized(Num); B.SetNumUninitialized(Num); C.SetNumUninitialized(Num);
	auto U8 = [](float V) { return (uint8)FMath::Clamp(FMath::RoundToInt(V * 255.f), 0, 255); };
	ParallelFor(Num, [&](int32 i)
	{
		const ESoil M = (ESoil)Soil[i];
		const float W = Wet[i];
		float Dry = 0, Sand = 0, Lat = 0, Mud = 0, Grav = 0, Rock = 0, Clay = 0, Comp = 0;
		switch (M)
		{
		case ESoil::DrySoil: case ESoil::WetSoil: { const float ToMud = FMath::Clamp((W - 0.72f) * 3.f, 0.f, 1.f); Dry = 1.f - ToMud; Mud = ToMud; break; }
		case ESoil::Mud: Mud = 1.f; break;
		case ESoil::Sand: Sand = 1.f; break;
		case ESoil::Gravel: Grav = 1.f; break;
		case ESoil::SmallRock: Rock = 1.f; break;
		case ESoil::Clay: Clay = 1.f; break;
		case ESoil::Laterite: Lat = 1.f; break;
		case ESoil::Compacted: Comp = 1.f; break;
		default: break; // large rock, asphalt
		}
		float Wa = FMath::Clamp(W * 0.85f - 0.15f, 0.f, 1.f);
		if (Ground[i] < L.WaterZ + 0.08f) Wa = 0.95f;
		// (FColor is stored B, G, R, A)
		A[i] = FColor(U8(Dry), U8(Sand), U8(Lat), U8(Wa));
		B[i] = FColor(U8(Mud), U8(GrassW[i]), U8(Grav), U8(Rock));
		C[i] = FColor(U8(Clay), U8(Comp), 0, 255);
	});
	auto Write = [&](const TCHAR* Name, const TArray<FColor>& Px)
	{
		bool bExisted = false;
		UTexture2D* T = MakeAsset<UTexture2D>(TEXT("/Game/Maps"), Name, bExisted);
		T->Modify();
		T->Source.Init(Size, Size, 1, 1, TSF_BGRA8, (const uint8*)Px.GetData());
		T->SRGB = false;
		T->CompressionSettings = TC_Masks;
		T->AddressX = TA_Clamp; T->AddressY = TA_Clamp;
		T->LODGroup = TEXTUREGROUP_World;
		T->PostEditChange();
		T->MarkPackageDirty();
	};
	Write(TEXT("T_RWSurfA"), A);
	Write(TEXT("T_RWSurfB"), B);
	Write(TEXT("T_RWSurfC"), C);
	RWLog(FString::Printf(TEXT("Surface baked: %d x %d texels (%.2f m each) for the Landscape's soils"), Size, Size, Step));
	return true;
}

int32 URWMapTools::FinishRebuild()
{
	int32 Gone = 0;
	for (const FString& F : ReplacedFiles) if (IFileManager::Get().FileExists(*F) && IFileManager::Get().Delete(*F, false, true, true)) ++Gone;
	RWLog(FString::Printf(TEXT("Map rebuild: %d files of replaced actors removed of %d"), Gone, ReplacedFiles.Num()));
	ReplacedFiles.Reset();
	return Gone;
}

int32 URWMapTools::BakeSculpt()
{
	UWorld* World = EditorWorld();
	if (!World) return -1;
	ALandscape* Land = nullptr;
	for (TActorIterator<ALandscape> It(World); It; ++It) { Land = *It; break; }
	ULandscapeInfo* Info = Land ? Land->GetLandscapeInfo() : nullptr;
	if (!Info) return -1;
	// the sculpt brush paints into the Landscape's edit layers, which the graphics card merges into the final heights a few
	// frames later: merge them now, or the strokes just made are not in what is read below (Play showed the old ground)
	Land->ForceUpdateLayersContent();
	FRWLayout L;
	L.bIgnoreSculpt = true;
	L.Init();
	TArray<float> Ground;
	ComputeGround(L, Ground);
	// start from what was baked before: a part of the Landscape that is not loaded now keeps its earlier changes
	TArray<float> Delta;
	if (!FRWLayout::ReadSculptFile(L.Params.Seed, Delta, LandSize)) Delta.Init(0.f, LandSize * LandSize);
	const int32 Quads = LandSections * LandSectionQuads;
	FLandscapeEditDataInterface Edit(Info);
	TArray<uint16> Comp; Comp.SetNumUninitialized((Quads + 1) * (Quads + 1));
	int32 Changed = 0;
	for (const TPair<FIntPoint, ULandscapeComponent*>& E : Info->XYtoComponentMap)
	{
		const int32 X0 = E.Key.X * Quads, Y0 = E.Key.Y * Quads;
		Edit.GetHeightDataFast(X0, Y0, X0 + Quads, Y0 + Quads, Comp.GetData(), 0);
		for (int32 y = 0; y <= Quads; ++y)
			for (int32 x = 0; x <= Quads; ++x)
			{
				const int32 Gx = X0 + x, Gy = Y0 + y;
				if (Gx >= LandSize || Gy >= LandSize) continue;
				const int32 i = Gy * LandSize + Gx;
				// (differences of a height step or two are only rounding)
				const float D = FromLand(Comp[y * (Quads + 1) + x]) - Ground[i];
				Delta[i] = FMath::Abs(D) < 0.08f ? 0.f : D;
			}
	}
	for (const float D : Delta) Changed += D != 0.f ? 1 : 0;
	if (Changed == 0) { ClearSculpt(); RWLog(TEXT("Map bake: nothing sculpted")); return 0; }
	const bool bOk = FRWLayout::WriteSculptFile(L.Params.Seed, Delta, LandSize);
	RWLog(FString::Printf(TEXT("Map bake: %d of %d points differ from the generated ground, written: %s"), Changed, Delta.Num(), bOk ? TEXT("yes") : TEXT("no")));
	return bOk ? Changed : -1;
}

bool URWMapTools::ClearSculpt()
{
	return IFileManager::Get().Delete(*FRWLayout::SculptFile(), false, false, true) || !IFileManager::Get().FileExists(*FRWLayout::SculptFile());
}

bool URWMapTools::LoadWholeMap()
{
	UWorld* World = EditorWorld();
	UWorldPartition* WP = World ? World->GetWorldPartition() : nullptr;
	if (!WP) return false;
	const float H = FRWLayout::MapHalf * 100.f + 1000.f;
	UWorldPartitionEditorLoaderAdapter* Ad = WP->CreateEditorLoaderAdapter<FLoaderAdapterShape>(World, FBox(FVector(-H, -H, -HALF_WORLD_MAX * 0.5), FVector(H, H, HALF_WORLD_MAX * 0.5)), TEXT("RoadWorks whole map"));
	Ad->GetLoaderAdapter()->SetUserCreated(true);
	Ad->GetLoaderAdapter()->Load();
	// (the heights a commandlet wrote only reach the drawn surface once the graphics card has merged the edit layers: that happens here)
	for (TActorIterator<ALandscape> It(World); It; ++It) It->ForceLayersFullUpdate();
	return true;
}

bool URWMapTools::SculptHill(float X, float Y, float Radius, float Height)
{
	UWorld* World = EditorWorld();
	if (!World) return false;
	ALandscape* Land = nullptr;
	for (TActorIterator<ALandscape> It(World); It; ++It) { Land = *It; break; }
	ULandscapeInfo* Info = Land ? Land->GetLandscapeInfo() : nullptr;
	const ULandscapeEditLayerBase* Layer = Land ? Land->GetEditLayerConst(0) : nullptr;
	if (!Info || !Layer) return false;
	const float Step = 2.f * FRWLayout::MapHalf / (LandSize - 1);
	const int32 Cx = FMath::RoundToInt((X + FRWLayout::MapHalf) / Step), Cy = FMath::RoundToInt((Y + FRWLayout::MapHalf) / Step), Rg = FMath::CeilToInt(Radius / Step);
	const int32 X1 = FMath::Max(Cx - Rg, 0), Y1 = FMath::Max(Cy - Rg, 0), X2 = FMath::Min(Cx + Rg, LandSize - 1), Y2 = FMath::Min(Cy + Rg, LandSize - 1);
	const int32 W = X2 - X1 + 1, H = Y2 - Y1 + 1;
	TArray<uint16> Data; Data.SetNumUninitialized(W * H);
	{
		FLandscapeEditDataInterface Edit(Info, Layer->GetGuid());
		Edit.GetHeightDataFast(X1, Y1, X2, Y2, Data.GetData(), 0);
		for (int32 y = 0; y < H; ++y)
			for (int32 x = 0; x < W; ++x)
			{
				const float D = FVector2D(x + X1 - Cx, y + Y1 - Cy).Size() * Step / Radius;
				if (D >= 1.f) continue;
				const float Bump = Height * FMath::Square(FMath::Cos(D * HALF_PI));
				uint16& V = Data[y * W + x];
				V = (uint16)FMath::Clamp(V + FMath::RoundToInt(Bump * 100.f * 128.f / LandScaleZ), 0, 65535);
			}
		Edit.SetHeightData(X1, Y1, X2, Y2, Data.GetData(), 0, true);
		Edit.Flush();
	}
	Land->RequestLayersContentUpdateForceAll();
	return true;
}

FString URWMapTools::GroundReport(bool bRefresh)
{
	UWorld* World = EditorWorld();
	if (!World) return TEXT("no world");
	int32 Actors = 0, Comps = 0, Registered = 0, Proxies = 0, Visible = 0, WithMat = 0, WithHeight = 0;
	FString First;
	for (TActorIterator<ALandscapeProxy> It(World); It; ++It)
	{
		++Actors;
		TArray<ULandscapeComponent*> Cs;
		It->GetComponents(Cs);
		for (ULandscapeComponent* C : Cs)
		{
			++Comps;
			Registered += C->IsRegistered();
			Proxies += C->SceneProxy != nullptr;
			Visible += C->IsVisible();
			WithMat += C->GetMaterial(0) != nullptr;
			UTexture2D* Hm = C->GetHeightmap();
			WithHeight += Hm && Hm->GetResource() != nullptr;
			if (First.IsEmpty())
				First = FString::Printf(TEXT("first: bounds %s, material %s, heightmap %s"), *C->Bounds.GetBox().ToString(), C->GetMaterial(0) ? *C->GetMaterial(0)->GetName() : TEXT("none"), Hm ? *Hm->GetName() : TEXT("none"));
		}
	}
	if (bRefresh)
		for (TActorIterator<ALandscape> It(World); It; ++It) { It->ForceLayersFullUpdate(); It->ReregisterAllComponents(); }
	return FString::Printf(TEXT("%d actors, %d components: %d registered, %d with a scene proxy, %d visible, %d with a material, %d with a heightmap resource; %s"), Actors, Comps, Registered, Proxies, Visible, WithMat, WithHeight, *First);
}

FString URWMapTools::MapReport()
{
	UWorld* World = EditorWorld();
	if (!World) return TEXT("no editor world");
	int32 Proxies = 0, Generated = 0; FBox Box(ForceInit);
	for (TActorIterator<ALandscapeProxy> It(World); It; ++It)
	{
		++Proxies;
		FVector O, Ext; It->GetActorBounds(false, O, Ext, false);
		Box += O - Ext; Box += O + Ext;
	}
	for (TActorIterator<AActor> It(World); It; ++It) if (It->Tags.Contains(GeneratedTag)) ++Generated;
	int32 Seed = 0;
	if (GConfig) GConfig->GetInt(TEXT("RoadWorks.Map"), TEXT("Seed"), Seed, GGameIni);
	const FVector Sz = Box.IsValid ? Box.GetSize() * 0.01f : FVector::ZeroVector;
	return FString::Printf(TEXT("level %s, world partition: %s, Landscape actors loaded %d, size %.0f x %.0f m, height %.0f m, generated actors %d, seed %d, sculpt file: %s"),
		*World->GetOutermost()->GetName(), World->GetWorldPartition() ? TEXT("yes") : TEXT("no"), Proxies, Sz.X, Sz.Y, Sz.Z, Generated, Seed, IFileManager::Get().FileExists(*FRWLayout::SculptFile()) ? TEXT("yes") : TEXT("no"));
}

void RWMapTools_RegisterEditorHooks()
{
	// what was sculpted is in the game as soon as you press Play
	FEditorDelegates::PreBeginPIE.AddLambda([](const bool) { URWMapTools::BakeSculpt(); });
	// and the whole Landscape is there to work on as soon as the map is open
	FEditorDelegates::OnMapOpened.AddLambda([](const FString& File, bool)
	{
		if (File.Contains(TEXT("L_RoadWorks_Main"))) URWMapTools::LoadWholeMap();
	});
}

#else

bool URWMapTools::BuildMap(int32, UMaterialInterface*, UMaterialInterface*, UStaticMesh*, int32) { return false; }
int32 URWMapTools::BakeSculpt() { return -1; }
bool URWMapTools::ClearSculpt() { return false; }
int32 URWMapTools::ImportPlants(const FString&) { return -1; }
int32 URWMapTools::ImportScenery(const FString&) { return -1; }
bool URWMapTools::BakeSurface(int32) { return false; }
bool URWMapTools::SetLandscapeMaterial(UMaterialInterface*) { return false; }
int32 URWMapTools::FinishRebuild() { return 0; }
FString URWMapTools::GroundReport(bool) { return TEXT("only in the editor"); }
bool URWMapTools::LoadWholeMap() { return false; }
bool URWMapTools::SculptHill(float, float, float, float) { return false; }
FString URWMapTools::MapReport() { return TEXT("only in the editor"); }
void RWMapTools_RegisterEditorHooks() {}

#endif
