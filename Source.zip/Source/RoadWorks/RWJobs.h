// Contracts, measured progress & quality from the real terrain, road design (survey), and company money.
#pragma once

#include "CoreMinimal.h"
#include "RWTypes.h"

class ARWTerrain;
class ARWWorld;
class FRWLayout;

enum class EJob : uint8 { Pond, LevelPad, Ditch, HaulOut, Fill, Road, Repair, Quarry, Deliver, CutHill, Clear, Lift };

struct FRWJob
{
	int32 Id = 0;
	EJob Type = EJob::Pond;
	FString Title, Client, Desc;
	FVector2D C = FVector2D::ZeroVector, Half = FVector2D(5, 5);
	float TargetZ = 0, Depth = 0, TargetVol = 0;
	float BasePay = 0, RatePerUnit = 0;
	ESoil Mat = ESoil::Gravel;
	int32 Count = 0;
	// road design
	TArray<FVector2D> Path;
	TArray<float> PathZ;
	float PlanCut = 0.f, PlanFill = 0.f; // earth to move for the road itself (bank m3), from its design line against the ground
	float HalfW = 3.f, SubbaseT = 0.2f, BaseT = 0.15f, AsphaltT = 0.05f, CrossSlope = 0.025f;
	TArray<float> Offsets; // per survey stake elevation offset (player road)
	TArray<FVector2D> Stakes;
	// state
	bool bAccepted = false, bDone = false, bPlayer = false;
	float Progress = 0, Quality = 0, Delivered = 0, Paid = 0;
	float StageFrac[7] = {0, 0, 0, 0, 0, 0, 0};
	int32 InitialTrees = 0;
	FString Status;
	TArray<float> Snap; int32 SX0 = 0, SY0 = 0, SW = 0, SH = 0;
	float EstimatedPay() const;
};

struct FRWEconomy
{
	double Money = 180000.0;
	float Reputation = 0.f;
	TArray<FString> Ledger;
	TArray<bool> Plots;
	float FuelPrice = 1.3f;
	void Add(double Amount, const FString& What);
	static float MaterialPrice(ESoil M);
};

class ROADWORKS_API FRWJobs
{
public:
	TArray<FRWJob> Jobs;
	int32 Tracked = -1;
	ARWTerrain* Terrain = nullptr;
	ARWWorld* World = nullptr;
	const FRWLayout* Layout = nullptr;
	float EvalTimer = 0.f;

	void Init(const FRWLayout* L, ARWTerrain* T, ARWWorld* W);
	void Accept(int32 i);
	void Abandon(int32 i);
	void Evaluate(FRWJob& J);
	void Tick(float Dt);
	bool CanSubmit(const FRWJob& J) const { return J.bAccepted && !J.bDone && J.Progress >= 0.97f; }
	void OnDeposit(int32 Idx, ESoil M, float Vol);
	void OnRemove(int32 Idx, ESoil M, float Vol);
	// Machine-control target for the active road / pad job at a point.
	bool DesignGrade(const FVector& P, float& Z) const;
	bool DesignSurface(const FRWJob& J, const FVector2D& P, float& Z, float& Lat) const;

	// Survey: player road design built from stakes
	FRWJob* PlayerRoad();
	void AddStake(const FVector2D& P);
	void RemoveStake();
	void RebuildPlayerRoad();
	void PublishPlayerRoad();

	void Serialize(FArchive& Ar);
	static FString TypeName(EJob T);

private:
	void Snapshot(FRWJob& J);
	void BuildRoadProfile(FRWJob& J, bool bFromSnapshot);
	void EvalRoad(FRWJob& J);
	int32 NextId = 1;
};
