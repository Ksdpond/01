#include "RWPlatform.h"
#include "RWTypes.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

class FRWLocalBackend : public IRWPlatformBackend
{
public:
	virtual FString Name() const override { return TEXT("Local (offline)"); }
	virtual FString CloudSaveDir() const override { return FPaths::ProjectSavedDir() / TEXT("SaveGames"); }
};

static TSharedPtr<IRWPlatformBackend> GBackend;
static TArray<FRWAchievement> GAch;

void FRWPlatform::SetBackend(TSharedPtr<IRWPlatformBackend> B) { GBackend = B; }

void FRWPlatform::Init()
{
	if (!GBackend.IsValid()) GBackend = MakeShared<FRWLocalBackend>();
	if (GAch.Num() == 0)
	{
		auto A = [](const TCHAR* Id, const TCHAR* Name, const TCHAR* Desc) { FRWAchievement X; X.Id = FName(Id); X.Name = Name; X.Desc = Desc; GAch.Add(X); };
		A(TEXT("FIRST_DIG"), TEXT("First Bucket"), TEXT("Fill an excavator bucket with soil"));
		A(TEXT("HANDS_ON"), TEXT("Hands On"), TEXT("Dig with a hand shovel"));
		A(TEXT("FIRST_CONTRACT"), TEXT("Contractor"), TEXT("Complete and get paid for a contract"));
		A(TEXT("ROAD_BUILDER"), TEXT("Road Builder"), TEXT("Finish a road contract"));
		A(TEXT("STUCK"), TEXT("Stuck in the Mud"), TEXT("Get a machine stuck"));
		A(TEXT("MECHANIC"), TEXT("Mechanic"), TEXT("Service a machine in the field"));
		A(TEXT("FLEET"), TEXT("Fleet Owner"), TEXT("Own 5 machines"));
		A(TEXT("TYCOON"), TEXT("Tycoon"), TEXT("Have $500,000 in the bank"));
		A(TEXT("MODDER"), TEXT("Modder"), TEXT("Play with a mod machine"));
		LoadLocal();
	}
	RWLog(FString::Printf(TEXT("Platform backend: %s"), *GBackend->Name()));
}

FString FRWPlatform::BackendName() { return GBackend.IsValid() ? GBackend->Name() : TEXT("none"); }
TArray<FRWAchievement>& FRWPlatform::Achievements() { return GAch; }

static FString AchFile() { return FPaths::ProjectSavedDir() / TEXT("SaveGames") / TEXT("Achievements.txt"); }

void FRWPlatform::LoadLocal()
{
	TArray<FString> L;
	if (!FFileHelper::LoadFileToStringArray(L, *AchFile())) return;
	for (FRWAchievement& A : GAch) A.bUnlocked = L.Contains(A.Id.ToString());
}

void FRWPlatform::SaveLocal()
{
	FString Out;
	for (const FRWAchievement& A : GAch) if (A.bUnlocked) Out += A.Id.ToString() + LINE_TERMINATOR;
	FFileHelper::SaveStringToFile(Out, *AchFile());
}

bool FRWPlatform::IsUnlocked(FName Id)
{
	for (const FRWAchievement& A : GAch) if (A.Id == Id) return A.bUnlocked;
	return false;
}

bool FRWPlatform::Unlock(FName Id)
{
	for (FRWAchievement& A : GAch)
	{
		if (A.Id != Id || A.bUnlocked) continue;
		A.bUnlocked = true;
		SaveLocal();
		if (GBackend.IsValid()) GBackend->UnlockAchievement(Id);
		RWLog(FString::Printf(TEXT("Achievement unlocked: %s"), *A.Name));
		return true;
	}
	return false;
}

FString FRWPlatform::SaveDir() { return GBackend.IsValid() ? GBackend->CloudSaveDir() : FPaths::ProjectSavedDir() / TEXT("SaveGames"); }
TArray<FString> FRWPlatform::ExtraModDirs() { return GBackend.IsValid() ? GBackend->WorkshopModDirs() : TArray<FString>(); }
