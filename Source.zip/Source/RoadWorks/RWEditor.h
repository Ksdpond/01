// In-game map editor: place buildings, structures, trees, rocks and any mod model (glTF) on the map,
// rotate / scale / delete them and paint grass. Edits are saved to Saved/MapEdits/map.json, load on
// every start and can be exported as a mod (Mods/MyMapEdits) to share. Mods can also ship
// "map_items" (same format) and "placeables" (new objects for the editor's catalogue).
#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class ARWWorld;
class UStaticMesh;
class USceneComponent;

struct FRWPlaceable
{
	FString Name;       // shown in the editor (also the key saved in map.json)
	FString Builtin;    // container, house, shed, silo, conifer, broadleaf, bush, rock, barrier, fence, lamp, grass_add, grass_remove
	FString ModelPath;  // glTF file from a mod
	FString AssetPath;  // static mesh from the Content packs (real size, own materials)
	float Scale = 1.f;
	FVector2D Footprint = FVector2D(2, 2); // metres, for machine collisions
	bool bObstacle = true;
};

struct FRWPlaced
{
	FString Item;
	FVector Pos = FVector::ZeroVector; // metres, z = height above the ground
	float Yaw = 0.f, Scale = 1.f;
	USceneComponent* Root = nullptr;
	int32 Obstacle = -1;
};

class ROADWORKS_API FRWEditor
{
public:
	static TArray<FRWPlaceable> Catalog;
	static TArray<FRWPlaced> Placed;
	static TArray<FVector4> GrassStrokes; // x, y, radius, +1 add / -1 remove
	static void BuildCatalog();
	static int32 FindItem(const FString& Name);
	static USceneComponent* Build(ARWWorld* W, const FRWPlaceable& P, const FVector& PosM, float Yaw, float Scale);
	static int32 Place(ARWWorld* W, const FString& Item, const FVector& PosM, float Yaw, float Scale, bool bRecord = true);
	static bool RemoveNear(ARWWorld* W, const FVector& PosM, float Radius);
	static void PaintGrass(ARWWorld* W, const FVector2D& P, float R, bool bAdd, bool bRecord = true);
	static void LoadAll(ARWWorld* W);
	static bool Save();
	static FString ExportAsMod();
	static FString SaveFile();
	static void ApplyItems(ARWWorld* W, const TArray<TSharedPtr<FJsonValue>>& Items, bool bRecord);
	static TArray<TSharedPtr<FJsonValue>> PendingModItems; // "map_items" collected from mods
	// a culvert placed at PosM (its middle) along Yaw: 8 m x 0.6 m at scale 1. In / Out = pipe-floor points (m) at
	// each end - laid at the ground there and falling at least 1 % towards Out - and the pipe diameter.
	static void CulvertGeometry(const class ARWTerrain* T, const FVector& PosM, float Yaw, float Scale, FVector& In, FVector& Out, float& Diameter);
};
