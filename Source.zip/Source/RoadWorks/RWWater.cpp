#include "RWWater.h"
#include "RWTerrain.h"
#include "ProceduralMeshComponent.h"
#include "Async/ParallelFor.h"
#include "Misc/ScopeExit.h"
#include "RWEffects.h"

namespace
{
	constexpr int32 GN = ARWTerrain::N;
	constexpr float GL = ARWTerrain::CS;             // cell size (m)
	constexpr float GA = ARWTerrain::CS * ARWTerrain::CS; // cell area (m2)
	constexpr float WetMin = 0.004f;                 // thinner films are drawn as dry ground
	const int32 DX[4] = { 1, -1, 0, 0 };
	const int32 DY[4] = { 0, 0, 1, -1 };
}

ARWWater::ARWWater()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

float ARWWater::Permeability(ESoil M)
{
	switch (M)
	{
	case ESoil::Sand: return 5.0e-5f;       // ปรับลดจาก 2.0e-4f เพื่อให้ซึมช้าลง
	case ESoil::Gravel: return 1.0e-4f;     // ปรับลดจาก 4.0e-4f
	case ESoil::SmallRock: return 8.0e-5f;  // ปรับลดจาก 3.0e-4f
	case ESoil::DrySoil: return 1.0e-5f;    // ปรับลดจาก 5.0e-5f
	case ESoil::WetSoil: return 8.0e-6f;    // ปรับลดจาก 3.0e-5f
	case ESoil::Laterite: return 1.0e-5f;   // ปรับลดจาก 4.0e-5f
	case ESoil::Clay: return 1.0e-6f;       // ปรับลดจาก 8.0e-6f
	case ESoil::Mud: return 1.0e-6f;        // ปรับลดจาก 8.0e-6f
	case ESoil::Compacted: return 2.0e-6f;  // ปรับลดจาก 1.0e-5f
	default: return 0.f; // asphalt, solid rock
	}
}

static float Erodibility(ESoil M)
{
	switch (M)
	{
	case ESoil::DrySoil: case ESoil::WetSoil: case ESoil::Mud: return 1.f;
	case ESoil::Sand: return 0.6f;
	case ESoil::Laterite: return 0.7f;
	case ESoil::Clay: return 0.5f;
	case ESoil::Compacted: return 0.25f;
	case ESoil::Gravel: return 0.2f;
	default: return 0.f;
	}
}

void ARWWater::Init(ARWTerrain* InTerrain, UMaterialInterface* InMat)
{
	Terrain = InTerrain; Mat = InMat;
	const int32 Num = GN * GN;
	W.Init(0.f, Num); Mud.Init(0.f, Num); WNew.Init(0.f, Num); MudNew.Init(0.f, Num); Soak.Init(0.f, Num);
	F.Init(0.f, Num * 4);
	NT = (GN + TS - 1) / TS;
	TileOn.Init(0, NT * NT); TileDirty.Init(0, NT * NT); TileWet.Init(0, NT * NT);
	TileIdle.Init(0.f, NT * NT); TileChange.Init(0.f, NT * NT);
	// ground below the water table is part of the river / groundwater body
	for (int32 i = 0; i < Num; ++i) if (IsReservoir(i)) W[i] = Terrain->WaterZ - Terrain->Height[i];
	RWLog(FString::Printf(TEXT("Water simulation ready: %d x %d points, %d tiles of %d m"), GN, GN, NT * NT, (int32)(TS * GL)));
}

int32 ARWWater::TileOf(int32 i) const { return ((i / GN) / TS) * NT + (i % GN) / TS; }

bool ARWWater::IsReservoir(int32 i) const { return Terrain->Height[i] < Terrain->WaterZ - 0.02f; }

void ARWWater::Activate(int32 T)
{
	if (T < 0 || T >= NT * NT || TileOn[T]) return;
	TileOn[T] = 1; TileIdle[T] = 0.f;
	Active.Add(T);
}

void ARWWater::WakeAt(int32 i)
{
	if (W.Num() == 0 || i < 0 || i >= W.Num()) return;
	const int32 T = TileOf(i);
	if (TileOn[T]) return;
	// only worth simulating if water is near: this tile or a neighbouring one holds some
	const int32 TX = T % NT, TY = T / NT;
	for (int32 dy = -1; dy <= 1; ++dy)
		for (int32 dx = -1; dx <= 1; ++dx)
		{
			const int32 X = TX + dx, Y = TY + dy;
			if (X < 0 || Y < 0 || X >= NT || Y >= NT) continue;
			if (TileWet[Y * NT + X] || TileOn[Y * NT + X]) { Activate(T); return; }
		}
	// next to the river: a cut may now connect to it
	if (Terrain->Height[i] < Terrain->WaterZ + 0.3f) Activate(T);
}

void ARWWater::AddWater(float X, float Y, float Vol, float MudLevel)
{
	if (!Terrain || Vol <= 0.f || !Terrain->InBounds(X, Y)) return;
	const int32 i = Terrain->IndexAt(X, Y);
	Added += Vol;
	if (IsReservoir(i)) { Drained += Vol; return; }
	const float V0 = W[i] * GA;
	W[i] += Vol / GA;
	Mud[i] = (Mud[i] * V0 + MudLevel * Vol) / FMath::Max(V0 + Vol, 1e-6f);
	TileWet[TileOf(i)] = 1;
	Activate(TileOf(i));
}

float ARWWater::DepthAt(float X, float Y) const
{
	if (!Terrain || !Terrain->InBounds(X, Y)) return 0.f;
	return W[Terrain->IndexAt(X, Y)];
}

float ARWWater::MudAt(float X, float Y) const
{
	if (!Terrain || !Terrain->InBounds(X, Y)) return 0.f;
	return Mud[Terrain->IndexAt(X, Y)];
}

double ARWWater::StandingVolume() const
{
	double V = 0;
	for (int32 T = 0; T < NT * NT; ++T)
	{
		if (!TileWet[T] && !TileOn[T]) continue;
		const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
		for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
			for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x)
			{
				const int32 i = y * GN + x;
				if (!IsReservoir(i)) V += W[i] * GA;
			}
	}
	return V;
}

void ARWWater::SoakCell(int32 i, float Dt)
{
	// infiltration: dry permeable soil drinks fast, saturated or sealed ground hardly at all
	if (W[i] <= 0.f || IsReservoir(i)) return;
	const float Moist = Terrain->MoistureAt(i) + Soak[i];
	const float Rate = Permeability(Terrain->SurfaceMat(i)) * FMath::Clamp(1.1f - Moist, 0.01f, 0.3f);
	const float D = FMath::Min(W[i], Rate * Dt);
	W[i] -= D;
	Soaked += D * GA;
	// ~1 cm of water soaked into the top soil makes it about 15% wetter; standing water keeps it soaked
	Soak[i] += D * 30.f + (W[i] > 0.01f ? 0.05f * Dt : 0.f);
	if (W[i] < 2e-5f) { Soaked += W[i] * GA; W[i] = 0.f; }
	if (Soak[i] >= 1.f / 255.f)
	{
		if (Terrain->MoistureAt(i) < 0.999f) Terrain->AddMoisture(i, Soak[i]);
		Soak[i] = 0.f;
	}
}

float ARWWater::PipeFlow(float Dm, float N, float Length, float InvUp, float InvDown, float HeadUp, float HeadDown, float* OutVel, float* OutDepth)
{
	if (OutVel) *OutVel = 0.f;
	if (OutDepth) *OutDepth = 0.f;
	const float Depth = HeadUp - InvUp; // water above the pipe floor at the inlet
	if (Depth <= 0.005f || Dm <= 0.05f) return 0.f;
	// part-full circular section at the inlet: theta = 2 acos(1 - 2y/D), A = D^2/8 (theta - sin theta), P = D theta / 2
	const float Y = FMath::Min(Depth, Dm * 0.98f);
	const float Th = 2.f * FMath::Acos(FMath::Clamp(1.f - 2.f * Y / Dm, -1.f, 1.f));
	const float A = Dm * Dm / 8.f * (Th - FMath::Sin(Th));
	const float P = 0.5f * Dm * Th;
	const float R = A / FMath::Max(P, 1e-4f);
	const float AFull = PI * Dm * Dm / 4.f;
	// 1) inlet control: a free-surface inlet acts like a weir (critical flow, ~half the depth as head),
	//    a drowned inlet like an orifice driven by the water above the pipe centre (Cd ~ 0.6)
	const float QIn = Depth < Dm ? 0.6f * A * FMath::Sqrt(2.f * GRAV * 0.5f * Y) : 0.6f * AFull * FMath::Sqrt(2.f * GRAV * (Depth - 0.5f * Dm));
	// 2) barrel control (Manning): energy slope from the drop over the pipe length; a free outlet falls to its invert
	const float Tail = FMath::Max(HeadDown, InvDown);
	const float S = FMath::Max((HeadUp - Tail) / FMath::Max(Length, 0.5f), 0.0005f);
	const float QBar = (1.f / FMath::Max(N, 0.009f)) * A * FMath::Pow(R, 2.f / 3.f) * FMath::Sqrt(S);
	const float Q = FMath::Max(0.f, FMath::Min(QIn, QBar));
	if (OutVel) *OutVel = Q / FMath::Max(A, 1e-4f);
	if (OutDepth) *OutDepth = Y;
	return Q;
}

void ARWWater::StepCulverts(float Dt)
{
	if (!Terrain) return;
	const TArray<float>& H = Terrain->Height;
	for (FCulvert& C : Culverts)
	{
		C.Q = 0.f; C.Vel = 0.f; C.FlowDepth = 0.f;
		if (!Terrain->InBounds(C.In.X, C.In.Y) || !Terrain->InBounds(C.Out.X, C.Out.Y)) continue;
		const int32 iA = Terrain->IndexAt(C.In.X, C.In.Y), iB = Terrain->IndexAt(C.Out.X, C.Out.Y);
		const float HA = H[iA] + W[iA], HB = H[iB] + W[iB];
		// water runs from the end with the higher water surface (normally the inlet)
		const bool bFwd = HA >= HB;
		const int32 iU = bFwd ? iA : iB, iD = bFwd ? iB : iA;
		const float InvU = bFwd ? C.InZ : C.OutZ, InvD = bFwd ? C.OutZ : C.InZ;
		const float Len = FVector2D::Distance(C.In, C.Out);
		float Vel = 0.f, Yd = 0.f;
		const float Q = PipeFlow(C.Diameter, C.Manning, Len, InvU, InvD, bFwd ? HA : HB, bFwd ? HB : HA, &Vel, &Yd);
		if (Q <= 0.f) continue;
		// draw the volume from the pool around the upstream end (3 x 3 points), never more than it holds above the invert
		const int32 UX = iU % ARWTerrain::N, UY = iU / ARWTerrain::N;
		const bool bResU = IsReservoir(iU);
		float Avail = 0.f; TArray<int32, TInlineAllocator<9>> Cells;
		for (int32 dy = -1; dy <= 1; ++dy)
			for (int32 dx = -1; dx <= 1; ++dx)
			{
				const int32 X = UX + dx, Y = UY + dy;
				if (X < 0 || Y < 0 || X >= ARWTerrain::N || Y >= ARWTerrain::N) continue;
				const int32 j = Y * ARWTerrain::N + X;
				const float Above = FMath::Max(0.f, FMath::Min(W[j], H[j] + W[j] - InvU));
				if (Above > 0.f) { Avail += Above * ARWTerrain::CellArea; Cells.Add(j); }
			}
		float Vol = Q * Dt;
		if (!bResU) Vol = FMath::Min(Vol, Avail);
		if (Vol <= 1e-6f) continue;
		float MudOut = 0.f;
		if (bResU) Drained -= Vol; // the river / water table feeds the pipe
		else
			for (int32 j : Cells)
			{
				const float Above = FMath::Max(0.f, FMath::Min(W[j], H[j] + W[j] - InvU));
				const float Take = Vol * (Above * ARWTerrain::CellArea) / FMath::Max(Avail, 1e-6f);
				MudOut += Mud[j] * Take;
				W[j] -= Take / ARWTerrain::CellArea;
			}
		MudOut /= FMath::Max(Vol, 1e-6f);
		// deliver at the downstream end (a drowned outlet still just adds to the pool there)
		if (IsReservoir(iD)) Drained += Vol;
		else
		{
			const float V0 = W[iD] * ARWTerrain::CellArea;
			W[iD] += Vol / ARWTerrain::CellArea;
			Mud[iD] = (Mud[iD] * V0 + MudOut * Vol) / FMath::Max(V0 + Vol, 1e-6f);
			TileWet[TileOf(iD)] = 1;
		}
		Activate(TileOf(iU)); Activate(TileOf(iD));
		PipeMoved += Vol;
		C.Q = (bFwd ? 1.f : -1.f) * Vol / Dt; C.Vel = Vel; C.FlowDepth = Yd;
	}
}

void ARWWater::Step(float Dt)
{
	if (!Terrain) return;
	StepCulverts(Dt);
	if (Active.Num() == 0) return;
	const TArray<float>& H = Terrain->Height;
	const float WZ = Terrain->WaterZ;
	// sources and rain
	for (const FSource& S : Sources) AddWater(S.P.X, S.P.Y, S.Rate * Dt, 0.f);
	if (RainRate > 0.f)
	{
		for (int32 T : Active)
		{
			const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
			const float CX = Terrain->PX(X0 + TS / 2), CY = Terrain->PX(Y0 + TS / 2);
			if (FVector2D::Distance(FVector2D(CX, CY), FVector2D(CamM.X, CamM.Y)) > 100.f) continue; // ขยายระยะรับฝนเป็น 100 m
			for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
				for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x)
				{
					const int32 i = y * GN + x;
					if (!IsReservoir(i)) W[i] += RainRate * Dt * 1.8f; // เพิ่มอัตราน้ำสะสม 1.8x
				}
			Added += RainRate * Dt * 1.8f * TS * TS * GA;
		}
	}
	// 1) outflow through the four "pipes" of every wet cell (parallel: each cell writes only its own pipes)
	const int32 NA = Active.Num();
	ParallelFor(NA, [&](int32 a)
		{
			const int32 T = Active[a];
			const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
			for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
				for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x)
				{
					const int32 i = y * GN + x;
					float* Fi = &F[i * 4];
					const float Wi = W[i];
					if (Wi <= 1e-5f) { Fi[0] = Fi[1] = Fi[2] = Fi[3] = 0.f; continue; }
					const float Si = H[i] + Wi;
					// bed friction: เพิ่มแรงเสียดทานผิวดินเพื่อให้น้ำไหลลงช้าลงและเกิดน้ำขังเป็นแอ่ง
					const float Fr = 1.f / (1.f + Dt * (1.2f + 0.04f / FMath::Max(Wi, 0.002f)));
					float Sum = 0.f;
					for (int32 k = 0; k < 4; ++k)
					{
						const int32 X = x + DX[k], Y = y + DY[k];
						if (X < 0 || Y < 0 || X >= GN || Y >= GN) { Fi[k] = 0.f; continue; }
						const int32 j = Y * GN + X;
						const float f = FMath::Max(0.f, Fi[k] * Fr + Dt * GRAV * GL * (Si - (H[j] + W[j])));
						Fi[k] = f; Sum += f;
					}
					// never send out more water than the cell holds
					if (Sum > 0.f) { const float K = FMath::Min(1.f, Wi * GA / (Sum * Dt)); if (K < 1.f) for (int32 k = 0; k < 4; ++k) Fi[k] *= K; }
				}
		});
	// 2) water leaving into a sleeping tile wakes it (its own pipes are still zero, so nothing is lost)
	for (int32 a = 0; a < NA; ++a)
	{
		const int32 T = Active[a];
		const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS, X1 = FMath::Min(X0 + TS, GN) - 1, Y1 = FMath::Min(Y0 + TS, GN) - 1;
		auto Edge = [&](int32 x, int32 y, int32 k) { if (F[(y * GN + x) * 4 + k] > 0.f) { const int32 X = x + DX[k], Y = y + DY[k]; if (X >= 0 && Y >= 0 && X < GN && Y < GN) Activate(TileOf(Y * GN + X)); } };
		for (int32 y = Y0; y <= Y1; ++y) { Edge(X1, y, 0); Edge(X0, y, 1); }
		for (int32 x = X0; x <= X1; ++x) { Edge(x, Y1, 2); Edge(x, Y0, 3); }
	}
	// 3) new depth = old + inflow - outflow; muddiness is carried with the water and picked up from bare soil
	const int32 NB = Active.Num();
	ParallelFor(NB, [&](int32 a)
		{
			const int32 T = Active[a];
			const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
			float MaxCh = 0.f;
			for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
				for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x)
				{
					const int32 i = y * GN + x;
					const float* Fi = &F[i * 4];
					const float Out = Fi[0] + Fi[1] + Fi[2] + Fi[3];
					float In = 0.f, MudIn = 0.f;
					for (int32 k = 0; k < 4; ++k)
					{
						const int32 X = x + DX[k], Y = y + DY[k];
						if (X < 0 || Y < 0 || X >= GN || Y >= GN) continue;
						const int32 j = Y * GN + X;
						const float f = F[j * 4 + (k ^ 1)]; // the neighbour's pipe pointing back at this cell
						In += f; MudIn += f * Mud[j];
					}
					const float V0 = W[i] * GA;
					const float Vn = FMath::Max(0.f, V0 + (In - Out) * Dt);
					float M = Vn > 1e-7f ? (Mud[i] * FMath::Max(V0 - Out * Dt, 0.f) + MudIn * Dt) / Vn : 0.f;
					// fast water over bare soil turns muddy; still water slowly clears
					const float Spd = Out / (FMath::Max(W[i], 0.005f) * GL);
					const float Er = Erodibility(Terrain->SurfaceMat(i)) * (1.f - 0.6f * Terrain->SurfaceComp(i));
					M = FMath::Clamp(M + Dt * 0.8f * FMath::Clamp(Spd - 0.08f, 0.f, 1.f) * Er, 0.f, 1.f);
					M *= 1.f - Dt * (Spd < 0.03f ? 0.05f : 0.01f);
					WNew[i] = Vn / GA; MudNew[i] = M;
					MaxCh = FMath::Max(MaxCh, FMath::Abs(WNew[i] - W[i]));
				}
			TileChange[T] = MaxCh;
		});
	// 4) commit, soak into the soil, hold the water table, put settled tiles to sleep
	for (int32 a = Active.Num() - 1; a >= 0; --a)
	{
		const int32 T = Active[a];
		const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
		bool bWet = false;
		for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
			for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x)
			{
				const int32 i = y * GN + x;
				W[i] = WNew[i]; Mud[i] = MudNew[i];
				if (IsReservoir(i))
				{
					// the river / groundwater keeps its level: extra water drains away, a new cut fills from it
					const float Fix = WZ - H[i];
					Drained += (W[i] - Fix) * GA;
					W[i] = Fix; Mud[i] *= 0.9f;
					continue;
				}
				SoakCell(i, Dt);
				bWet |= W[i] > WetMin;
			}
		TileWet[T] = bWet ? 1 : 0;
		if (TileChange[T] > 2e-4f) TileDirty[T] = 1;
		TileIdle[T] = TileChange[T] < 2e-5f ? TileIdle[T] + Dt : 0.f;
		if (TileIdle[T] > 2.f)
		{
			// settled: stop simulating (standing water still soaks in slowly, see Tick)
			const int32 X1 = FMath::Min(X0 + TS, GN), Y1 = FMath::Min(Y0 + TS, GN);
			for (int32 y = Y0; y < Y1; ++y) for (int32 x = X0; x < X1; ++x) { float* Fi = &F[(y * GN + x) * 4]; Fi[0] = Fi[1] = Fi[2] = Fi[3] = 0.f; }
			TileOn[T] = 0; TileDirty[T] = 1;
			Active.RemoveAtSwap(a, 1, EAllowShrinking::No);
		}
	}
}

void ARWWater::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Terrain || !bEnabled) return;
	const double T0 = FPlatformTime::Seconds();
	ON_SCOPE_EXIT{ TickMs = (FPlatformTime::Seconds() - T0) * 1000.0; };
	Dt = FMath::Min(Dt, 0.1f);
	// rain wakes the ground around the camera
	RainT -= Dt;
	if (RainRate > 0.f && RainT <= 0.f)
	{
		RainT = 1.f;
		const int32 C = Terrain->IndexAt(CamM.X, CamM.Y), CT = TileOf(C), TX = CT % NT, TY = CT / NT;
		for (int32 dy = -3; dy <= 3; ++dy) for (int32 dx = -3; dx <= 3; ++dx)
		{
			const int32 X = TX + dx, Y = TY + dy;
			if (X >= 0 && Y >= 0 && X < NT && Y < NT) Activate(Y * NT + X);
		}
	}
	if (Sources.Num()) for (const FSource& S : Sources) if (Terrain->InBounds(S.P.X, S.P.Y)) Activate(TileOf(Terrain->IndexAt(S.P.X, S.P.Y)));
	Acc += Dt;
	int32 Steps = 0;
	while (Acc >= 1.f / 40.f && Steps < 3) { Step(1.f / 40.f); Acc -= 1.f / 40.f; ++Steps; }
	if (Steps == 3) Acc = 0.f; // falling behind: slow the water down rather than the game
	// pipe outlets: a jet of water shoots out and splashes into the pool / stream below
	SplashT += Dt;
	if (Fx && SplashT > 0.05f)
	{
		SplashT = 0.f;
		for (const FCulvert& C : Culverts)
		{
			if (FMath::Abs(C.Q) < 0.002f) continue;
			const bool bFwd = C.Q > 0.f;
			const FVector2D A = bFwd ? C.In : C.Out, B = bFwd ? C.Out : C.In;
			const FVector2D Dir = (B - A).GetSafeNormal(), Side(-Dir.Y, Dir.X);
			const float Inv = bFwd ? C.OutZ : C.InZ;
			const int32 Count = FMath::Clamp(FMath::RoundToInt(FMath::Abs(C.Q) * 60.f), 1, 6);
			for (int32 k = 0; k < Count; ++k)
			{
				const FVector2D Q = B + Dir * 0.1f + Side * (FMath::FRandRange(-0.3f, 0.3f) * C.Diameter);
				Fx->SpawnWater(FVector(Q.X, Q.Y, Inv + C.FlowDepth * FMath::FRandRange(0.2f, 0.8f)), FVector(Dir.X, Dir.Y, 0.15f) * C.Vel, 0.0005f);
			}
		}
	}
	// sleeping puddles still soak away
	SleepT -= Dt;
	if (SleepT <= 0.f)
	{
		SleepT = 3.f;
		for (int32 T = 0; T < NT * NT; ++T)
		{
			if (TileOn[T] || !TileWet[T]) continue;
			const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
			bool bWet = false;
			for (int32 y = Y0; y < FMath::Min(Y0 + TS, GN); ++y)
				for (int32 x = X0; x < FMath::Min(X0 + TS, GN); ++x) { const int32 i = y * GN + x; SoakCell(i, 3.f); bWet |= W[i] > WetMin && !IsReservoir(i); }
			TileWet[T] = bWet; TileDirty[T] = 1;
		}
	}
	RenderT -= Dt;
	if (RenderT <= 0.f) { RenderT = 0.15f; UpdateRender(false); }
}

int32 ARWWater::VisibleTiles() const
{
	int32 N = 0;
	for (const auto& KV : Meshes) if (KV.Value && KV.Value->IsVisible() && KV.Value->GetNumSections() > 0) ++N;
	return N;
}

void ARWWater::UpdateRender(bool bAll)
{
	for (int32 T = 0; T < NT * NT; ++T)
	{
		if (!TileDirty[T] && !bAll) continue;
		if (!TileWet[T] && !Meshes.Contains(T)) { TileDirty[T] = 0; continue; }
		const float CX = Terrain->PX((T % NT) * TS + TS / 2), CY = Terrain->PX((T / NT) * TS + TS / 2);
		if (!bAll && FVector2D::Distance(FVector2D(CX, CY), FVector2D(CamM.X, CamM.Y)) > 320.f) continue; // far away: draw when we get closer
		TileDirty[T] = 0;
		BuildTile(T);
	}
}

void ARWWater::BuildTile(int32 T)
{
	const int32 X0 = (T % NT) * TS, Y0 = (T / NT) * TS;
	const int32 V = TS + 1;
	const TArray<float>& H = Terrain->Height;
	TArray<FVector> Pos; Pos.SetNumUninitialized(V * V);
	TArray<FLinearColor> Col; Col.SetNumUninitialized(V * V);
	TArray<uint8> Wet; Wet.SetNumZeroed(V * V);
	TArray<float> Z; Z.SetNumUninitialized(V * V);
	auto GIdx = [&](int32 x, int32 y) { return FMath::Min(Y0 + y, GN - 1) * GN + FMath::Min(X0 + x, GN - 1); };
	for (int32 y = 0; y < V; ++y)
		for (int32 x = 0; x < V; ++x)
		{
			const int32 i = GIdx(x, y), v = y * V + x;
			// the river / water table is drawn by the world's water plane; this mesh shows water above it
			Wet[v] = W[i] > WetMin && !IsReservoir(i);
		}
	for (int32 y = 0; y < V; ++y)
		for (int32 x = 0; x < V; ++x)
		{
			const int32 GX = FMath::Min(X0 + x, GN - 1), GY = FMath::Min(Y0 + y, GN - 1);
			const int32 i = GY * GN + GX, v = y * V + x;
			const bool bW = Wet[v] != 0;
			float Level = 0.f; int32 NW = 0;
			if (!bW)
			{
				// dry corner next to water: carry the water level to it, so the bank (where it rises above the level)
				// cuts the surface along the real contour instead of in 0.5 m steps; lower dry ground stays hidden
				for (int32 dy = -1; dy <= 1; ++dy)
					for (int32 dx = -1; dx <= 1; ++dx)
					{
						const int32 j = GIdx(FMath::Clamp(x + dx, -X0, GN - 1 - X0), FMath::Clamp(y + dy, -Y0, GN - 1 - Y0));
						if (W[j] > WetMin && !IsReservoir(j)) { Level += H[j] + W[j]; ++NW; }
					}
			}
			Z[v] = bW ? H[i] + W[i] : NW > 0 ? FMath::Min(Level / NW, H[i] - 0.02f) : H[i] - 0.06f;
			Pos[v] = FVector(Terrain->PX(GX), Terrain->PX(GY), Z[v]) * M2CM;
			const FLinearColor Clean(0.015f, 0.08f, 0.078f), Muddy(0.19f, 0.13f, 0.075f); // clear water is turquoise
			FLinearColor C = FMath::Lerp(Clean, Muddy, FMath::Clamp(Mud[i] * 1.6f, 0.f, 1.f));
			// thin films are nearly clear, deep or muddy water opaque; the shoreline fades out
			C.A = bW ? FMath::Clamp(0.22f + W[i] * 3.f + Mud[i] * 0.5f, 0.22f, 0.92f) : 0.04f;
			// whitewater: fast AND deep enough to churn (not every thin film on a slope), plus the plunge pool under a running pipe
			const float* Fi = &F[i * 4];
			const float Spd = (Fi[0] + Fi[1] + Fi[2] + Fi[3]) / (FMath::Max(W[i], 0.005f) * GL);
			float Foam = bW ? FMath::Clamp((Spd - 1.0f) / 1.5f, 0.f, 1.f) * FMath::Clamp(W[i] / 0.08f, 0.f, 1.f) : 0.f;
			if (bW)
				for (const FCulvert& Cv : Culverts)
				{
					if (FMath::Abs(Cv.Q) < 0.005f) continue;
					const FVector2D End = Cv.Q > 0.f ? Cv.Out : Cv.In, Dir = (Cv.Q > 0.f ? Cv.Out - Cv.In : Cv.In - Cv.Out).GetSafeNormal();
					const FVector2D P(Terrain->PX(GX), Terrain->PX(GY)), Plunge = End + Dir * (0.3f + 0.15f * Cv.Vel);
					const float R = 0.6f + 1.5f * FMath::Clamp(FMath::Abs(Cv.Q) / 0.3f, 0.f, 1.f);
					Foam = FMath::Max(Foam, (1.f - FVector2D::Distance(P, Plunge) / R) * FMath::Clamp(FMath::Abs(Cv.Q) / 0.05f, 0.f, 1.f));
				}
			if (Foam > 0.f) { C = FMath::Lerp(C, FLinearColor(0.75f, 0.8f, 0.8f, 0.9f), FMath::Min(Foam, 1.f) * 0.75f); }
			Col[v] = C;
		}
	TArray<int32> Tri;
	for (int32 y = 0; y < V - 1; ++y)
		for (int32 x = 0; x < V - 1; ++x)
		{
			const int32 A = y * V + x, B = A + 1, C = A + V, D = C + 1;
			if (Wet[A] + Wet[B] + Wet[C] + Wet[D] == 0) continue;
			Tri.Append({ A, C, D, A, D, B });
		}
	UProceduralMeshComponent** Found = Meshes.Find(T);
	UProceduralMeshComponent* PM = Found ? *Found : nullptr;
	if (Tri.Num() == 0) { if (PM) { PM->ClearAllMeshSections(); PM->SetVisibility(false); } return; }
	if (!PM)
	{
		PM = NewObject<UProceduralMeshComponent>(this);
		PM->SetupAttachment(RootComponent);
		PM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		PM->SetCastShadow(false);
		PM->RegisterComponent();
		Meshes.Add(T, PM);
	}
	TArray<FVector> Nrm; Nrm.SetNumUninitialized(V * V);
	for (int32 y = 0; y < V; ++y)
		for (int32 x = 0; x < V; ++x)
		{
			const float ZX = Z[y * V + FMath::Min(x + 1, V - 1)] - Z[y * V + FMath::Max(x - 1, 0)];
			const float ZY = Z[FMath::Min(y + 1, V - 1) * V + x] - Z[FMath::Max(y - 1, 0) * V + x];
			Nrm[y * V + x] = FVector(-ZX, -ZY, 2.f * GL).GetSafeNormal();
		}
	TArray<FVector2D> UV; UV.SetNumUninitialized(V * V);
	for (int32 v = 0; v < V * V; ++v) UV[v] = FVector2D(Pos[v].X, Pos[v].Y) / 400.f;
	PM->CreateMeshSection_LinearColor(0, Pos, Tri, Nrm, UV, Col, TArray<FProcMeshTangent>(), false);
	PM->SetMaterial(0, Mat);
	PM->SetVisibility(true);
	(void)H;
}