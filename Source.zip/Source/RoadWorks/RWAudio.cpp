#include "RWAudio.h"
#include "RWTypes.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "HAL/FileManager.h"
#include "Audio.h"
#include "Decoders/VorbisAudioInfo.h"
THIRD_PARTY_INCLUDES_START
#include "vorbis/vorbisfile.h"
THIRD_PARTY_INCLUDES_END

FRWClip FRWSoundFiles::Track, FRWSoundFiles::Start, FRWSoundFiles::Stop;
FString FRWSoundFiles::Folder;
bool FRWSoundFiles::bLoaded = false;

namespace
{
	// an Ogg file read from memory
	struct FOggMem { const uint8* D = nullptr; int64 N = 0, P = 0; };
	size_t OggRead(void* Ptr, size_t Size, size_t Count, void* Src)
	{
		FOggMem* M = (FOggMem*)Src;
		const int64 Want = (int64)(Size * Count), Got = FMath::Clamp<int64>(M->N - M->P, 0, Want);
		if (Got > 0) { FMemory::Memcpy(Ptr, M->D + M->P, Got); M->P += Got; }
		return Size ? (size_t)(Got / Size) : 0;
	}
	int OggSeek(void* Src, ogg_int64_t Off, int Whence)
	{
		FOggMem* M = (FOggMem*)Src;
		const int64 Base = Whence == SEEK_SET ? 0 : Whence == SEEK_CUR ? M->P : M->N;
		M->P = FMath::Clamp<int64>(Base + Off, 0, M->N);
		return 0;
	}
	long OggTell(void* Src) { return (long)((FOggMem*)Src)->P; }
	int OggClose(void*) { return 0; }
}

bool FRWSoundFiles::Decode(const FString& Path, FRWClip& Out)
{
	Out = FRWClip();
	TArray<uint8> Bytes;
	if (!FFileHelper::LoadFileToArray(Bytes, *Path) || Bytes.Num() < 64) return false;
	Out.File = FPaths::GetCleanFilename(Path);
	if (Path.EndsWith(TEXT(".wav"), ESearchCase::IgnoreCase))
	{
		// 16-bit PCM WAV
		FWaveModInfo W;
		if (!W.ReadWaveInfo(Bytes.GetData(), Bytes.Num()) || *W.pBitsPerSample != 16 || *W.pChannels == 0) return false;
		const int32 Ch = *W.pChannels, Frames = W.SampleDataSize / 2 / Ch;
		const int16* P = (const int16*)W.SampleDataStart;
		Out.Rate = (float)*W.pSamplesPerSec;
		Out.S.SetNumUninitialized(Frames);
		for (int32 i = 0; i < Frames; ++i) { float A = 0.f; for (int32 c = 0; c < Ch; ++c) A += P[i * Ch + c]; Out.S[i] = A / (32768.f * Ch); }
		return Out.IsValid();
	}
	// Ogg Vorbis, with the engine's own libvorbis (its libraries are loaded first)
	LoadVorbisLibraries();
	FOggMem M; M.D = Bytes.GetData(); M.N = Bytes.Num();
	OggVorbis_File VF;
	ov_callbacks Cb; Cb.read_func = OggRead; Cb.seek_func = OggSeek; Cb.close_func = OggClose; Cb.tell_func = OggTell;
	if (ov_open_callbacks(&M, &VF, nullptr, 0, Cb) < 0) return false;
	if (const vorbis_info* VI = ov_info(&VF, -1)) Out.Rate = (float)VI->rate;
	float** Pcm = nullptr;
	int Section = 0;
	long Got;
	while ((Got = ov_read_float(&VF, &Pcm, 4096, &Section)) > 0)
	{
		const vorbis_info* VI = ov_info(&VF, -1);
		const int32 Ch = VI ? FMath::Max(VI->channels, 1) : 1;
		for (long i = 0; i < Got; ++i) { float A = 0.f; for (int32 c = 0; c < Ch; ++c) A += Pcm[c][i]; Out.S.Add(A / Ch); }
	}
	ov_clear(&VF);
	return Out.IsValid();
}

void FRWSoundFiles::Load()
{
	if (bLoaded) return;
	bLoaded = true;
	// next to the game (the packaged game: <game>/RoadWorks/souds), or next to the project's Mods folder (-RWMods=..., as
	// the launcher starts it), or the project's own folder (the editor)
	TArray<FString> Dirs = {FPaths::ProjectDir() / TEXT("souds"), FPaths::ProjectDir() / TEXT("Sounds")};
	FString ModsDir;
	if (FParse::Value(FCommandLine::Get(), TEXT("RWMods="), ModsDir)) Dirs.Add(FPaths::GetPath(ModsDir.TrimQuotes()) / TEXT("souds"));
	TArray<FString> Files;
	for (const FString& D : Dirs)
	{
		Files.Reset();
		IFileManager::Get().FindFiles(Files, *(D / TEXT("*.ogg")), true, false);
		TArray<FString> Wavs; IFileManager::Get().FindFiles(Wavs, *(D / TEXT("*.wav")), true, false);
		Files.Append(Wavs);
		if (Files.Num()) { Folder = FPaths::ConvertRelativePathToFull(D); break; }
	}
	if (Folder.IsEmpty()) { RWLog(TEXT("Sounds: no souds folder with .ogg / .wav files - the engine and tracks are made by the game")); return; }
	Files.Sort();
	for (const FString& F : Files)
	{
		const FString L = F.ToLower();
		FRWClip* To = (L.Contains(TEXT("chenille")) || L.Contains(TEXT("track"))) ? &Track
			: (L.Contains(TEXT("start")) && !L.Contains(TEXT("loop"))) ? &Start
			: (L.Contains(TEXT("stop")) && !L.Contains(TEXT("loop"))) ? &Stop : nullptr;
		if (!To || To->IsValid()) continue;
		if (!Decode(Folder / F, *To)) RWLog(FString::Printf(TEXT("Sounds: %s could not be read"), *F));
	}
	auto Say = [](const FRWClip& C) { return C.IsValid() ? FString::Printf(TEXT("%s (%.1f s, %.0f Hz)"), *C.File, C.Seconds(), C.Rate) : FString(TEXT("-")); };
	RWLog(FString::Printf(TEXT("Sounds from %s: tracks %s, engine start %s, engine stop %s"), *Folder, *Say(Track), *Say(Start), *Say(Stop)));
}

URWEngineSynth::URWEngineSynth(const FObjectInitializer& OI) : Super(OI)
{
	NumChannels = 1;
	bAutoActivate = false;
	bOverrideAttenuation = true;
	AttenuationOverrides.bAttenuate = true;
	AttenuationOverrides.bSpatialize = true;
	AttenuationOverrides.AttenuationShapeExtents = FVector(800.f, 0, 0);
	AttenuationOverrides.FalloffDistance = 9000.f;
}

bool URWEngineSynth::Init(int32& SampleRate)
{
	SR = (float)SampleRate;
	NumChannels = 1;
	return true;
}

int32 URWEngineSynth::OnGenerateAudio(float* Out, int32 NumSamples)
{
	const float TRpm = Rpm.load(), TLoad = Load.load(), H = Hyd.load(), TS = TrackSpeed.load();
	const float Gr = Gravel.load(), Sc = Scrape.load(), Rk = Rock.load(), Po = Pour.load(), Hm = Hammer.load(), Ms = Master.load();
	const float Dt = 1.f / SR;
	// the recorded sounds (souds folder): the engine starting / stopping once, the tracks running in a loop
	const FRWClip& StartC = FRWSoundFiles::Start;
	const FRWClip& StopC = FRWSoundFiles::Stop;
	const FRWClip& TrackC = FRWSoundFiles::Track;
	const int32 SC = StartCount.load(), PC = StopCount.load();
	if (SC != SeenStart) { SeenStart = SC; if (StartC.IsValid()) { StartPos = 0.0; StopPos = -1.0; } }
	if (PC != SeenStop) { SeenStop = PC; if (StopC.IsValid()) { StopPos = 0.0; StartPos = -1.0; } }
	const bool bTrackFile = TrackC.IsValid();
	const float ATS = FMath::Abs(TS);
	// the tracks: heard from a walking pace, louder and a little faster the faster they run
	const float TrackTarget = bTrackFile ? FMath::Clamp(ATS / 0.35f, 0.f, 1.f) * (0.55f + 0.45f * FMath::Clamp(ATS / 2.5f, 0.f, 1.f)) : 0.f;
	const double TrackStep = bTrackFile ? TrackC.Rate / SR * (0.85 + 0.35 * FMath::Clamp(ATS / 2.5f, 0.f, 1.f)) : 0.0;
	for (int32 n = 0; n < NumSamples; ++n)
	{
		SmRpm += (TRpm - SmRpm) * 0.0006f;
		SmLoad += (TLoad - SmLoad) * 0.0008f;
		float S = 0.f;
		// the recorded start / stop: the engine made by the game steps back while one plays (back over its last 0.6 s)
		float DuckT = 0.f;
		if (StartPos >= 0.0)
		{
			if (StartPos < StartC.S.Num() - 1) { S += StartC.At(StartPos) * 0.9f; DuckT = FMath::Clamp((float)((StartC.S.Num() - 1 - StartPos) / StartC.Rate) / 0.6f, 0.f, 1.f); StartPos += StartC.Rate / SR; }
			else StartPos = -1.0;
		}
		if (StopPos >= 0.0)
		{
			if (StopPos < StopC.S.Num() - 1) { S += StopC.At(StopPos) * 0.9f; DuckT = FMath::Max(DuckT, FMath::Clamp((float)((StopC.S.Num() - 1 - StopPos) / StopC.Rate) / 0.6f, 0.f, 1.f)); StopPos += StopC.Rate / SR; }
			else StopPos = -1.0;
		}
		Duck += (DuckT - Duck) * 0.002f;
		if (bTrackFile)
		{
			TrackGain += (TrackTarget - TrackGain) * 0.0004f;
			if (TrackGain > 1e-4f)
			{
				S += TrackC.At(TrackPos) * TrackGain * 0.9f;
				TrackPos += TrackStep;
				if (TrackPos >= TrackC.S.Num() - 1) TrackPos -= TrackC.S.Num() - 1;
			}
		}
		const float EngineMix = 1.f - 0.85f * Duck;
		if (SmRpm > 40.f)
		{
			const float S0 = S;
			const float F0 = SmRpm / 60.f * Cylinders * 0.5f * Pitch;
			Phase += F0 * Dt;
			if (Phase > 1.0) Phase -= 1.0;
			const float Ph = (float)Phase * 2.f * PI;
			// Diesel firing pulses: sharp envelope per firing event + half-order roughness.
			const float Pulse = FMath::Pow(FMath::Max(0.f, FMath::Sin(Ph)), 6.f);
			const float Half = 0.25f * FMath::Sin(Ph * 0.5f + 0.7f);
			const float Body = 0.45f * FMath::Sin(Ph) + 0.25f * FMath::Sin(2 * Ph + 0.3f) + 0.12f * FMath::Sin(3 * Ph + 1.1f) + Half;
			const float Nz = Rand();
			LP1 += (Nz - LP1) * 0.08f;               // rumble noise
			const float Knock = Pulse * (0.4f + SmLoad) * LP1 * 3.f;
			const float Lvl = 0.25f + 0.55f * SmLoad + 0.2f * FMath::Clamp(SmRpm / 2200.f, 0.f, 1.f);
			S += (Body * 0.55f + Knock * 0.6f + Pulse * 0.35f) * Lvl;
			// Exhaust low end
			LP2 += (Nz - LP2) * 0.01f;
			S += LP2 * (0.8f + SmLoad * 1.5f);
			// Turbo whistle spools with load and rpm
			const float TBoost = FMath::Clamp((SmRpm - 900.f) / 1300.f, 0.f, 1.f) * (0.3f + 0.7f * SmLoad);
			Boost += (TBoost - Boost) * 0.00008f;
			TurboPhase += (1800.f + 5200.f * Boost) * Dt;
			if (TurboPhase > 1.0) TurboPhase -= 1.0;
			S += FMath::Sin((float)TurboPhase * 2.f * PI) * Boost * 0.035f;
			// Hydraulic pump: 9-piston ripple + relief valve hiss above max pressure
			if (H > 0.01f)
			{
				PumpPhase += SmRpm / 60.f * 9.f * Dt;
				if (PumpPhase > 1.0) PumpPhase -= 1.0;
				const float PP = (float)PumpPhase * 2.f * PI;
				S += (FMath::Sin(PP) * 0.6f + 0.3f * FMath::Sin(2 * PP)) * FMath::Min(H, 1.f) * 0.09f;
				const float HPf = Nz - HPPrev; HPPrev = Nz;
				if (H > 1.f) S += HPf * (H - 1.f) * 0.2f;
				S += HPf * FMath::Min(H, 1.f) * 0.02f;
			}
			S = S0 + (S - S0) * EngineMix;
		}
		// Track links hitting sprockets & rollers (made here only when there is no recorded track sound).
		if (!bTrackFile && FMath::Abs(TS) > 0.05f)
		{
			TrackPhase += FMath::Abs(TS) / 0.19f * Dt;
			if (TrackPhase > 1.0) { TrackPhase -= 1.0; Ping = 1.f; }
		}
		if (!bTrackFile && Ping > 0.001f)
		{
			PingPhase += 720.f * Dt;
			S += (FMath::Sin(PingPhase * 2.f * PI) * 0.5f + Rand() * 0.5f) * Ping * 0.22f;
			Ping *= 0.9965f;
		}
		// Ground contact: gravel crunch / scraping / rock clatter / pouring.
		const float Nz2 = Rand();
		LP3 += (Nz2 - LP3) * 0.25f;
		const float Band = LP3 - LP4; LP4 += (LP3 - LP4) * 0.05f;
		S += Band * (Gr * 0.25f + Sc * 0.45f);
		if (Rk > 0.01f && (Rng & 0xFFF) < (uint32)(Rk * 6.f)) RockEnv = 1.f;
		if (RockEnv > 0.001f) { S += Nz2 * RockEnv * 0.35f; RockEnv *= 0.993f; }
		LP4 += 0.f;
		S += LP3 * Po * 0.35f;
		if (Hm > 0.01f)
		{
			HammerPhase += 11.f * Dt; // ~11 blows / s
			if (HammerPhase > 1.0) { HammerPhase -= 1.0; RockEnv = 1.f * Hm; }
		}
		Out[n] = FMath::Clamp(S * Ms * 0.6f, -1.f, 1.f);
	}
	return NumSamples;
}

URWAmbientSynth::URWAmbientSynth(const FObjectInitializer& OI) : Super(OI)
{
	NumChannels = 2;
	bAutoActivate = false;
	bIsUISound = true;
}

bool URWAmbientSynth::Init(int32& SampleRate)
{
	SR = (float)SampleRate;
	NumChannels = 2;
	return true;
}

int32 URWAmbientSynth::OnGenerateAudio(float* Out, int32 NumSamples)
{
	const float R = Rain.load(), W = Wind.load(), B = Birds.load();
	const int32 TC = ThunderCount.load();
	if (TC != SeenThunder) { SeenThunder = TC; Thunder = 1.f; }
	const float Dt = 1.f / SR;
	const int32 Frames = NumSamples / 2;
	for (int32 n = 0; n < Frames; ++n)
	{
		const float Nz = Rand();
		const float HPf = Nz - HPPrev; HPPrev = Nz;
		HP += (HPf - HP) * 0.5f;
		LP1 += (Nz - LP1) * 0.02f;
		WindMod += (Rand() * 0.5f + 0.5f - WindMod) * 0.00002f;
		float L = 0, Rr = 0;
		// Rain: dense high-frequency hiss plus random drops
		const float Drop = ((Rng & 0x3FF) < (uint32)(R * 30.f)) ? Rand() : 0.f;
		const float RainS = (HP * 0.5f + Drop * 0.3f) * R * 0.35f;
		// Wind: slow band noise
		LP2 += (LP1 - LP2) * 0.05f;
		const float WindS = (LP1 - LP2) * W * (0.6f + WindMod) * 1.6f;
		// Thunder: long rumbling decay
		if (Thunder > 0.0005f)
		{
			ThunderLP += (Nz - ThunderLP) * 0.004f;
			ThunderLP2 += (ThunderLP - ThunderLP2) * 0.02f;
			const float Th = ThunderLP2 * Thunder * 14.f * (0.6f + 0.4f * FMath::Sin(Thunder * 40.f));
			L += Th; Rr += Th;
			Thunder *= 0.99996f;
		}
		// Birds in fair weather
		BirdT += Dt;
		if (BirdT > BirdNext && B > 0.05f) { BirdT = 0; BirdNext = 0.4f + FMath::Abs(Rand()) * 4.f / FMath::Max(B, 0.1f); BirdEnv = 1.f; BirdF = 2600.f + FMath::Abs(Rand()) * 2400.f; }
		float Bird = 0;
		if (BirdEnv > 0.001f)
		{
			BirdPh += (BirdF + 900.f * FMath::Sin(BirdEnv * 30.f)) * Dt;
			Bird = FMath::Sin(BirdPh * 2.f * PI) * BirdEnv * 0.025f * B;
			BirdEnv *= 0.9993f;
		}
		L += RainS + WindS + Bird * 0.7f;
		Rr += RainS * 0.9f + WindS * 0.8f + Bird * 0.3f + HP * R * 0.05f;
		Out[2 * n] = FMath::Clamp(L, -1.f, 1.f);
		Out[2 * n + 1] = FMath::Clamp(Rr, -1.f, 1.f);
	}
	return NumSamples;
}
