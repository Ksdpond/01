#include "RWEditor.h"
#include "RWWorld.h"
#include "RWTerrain.h"
#include "RWMachine.h"
#include "RWMeshGen.h"
#include "RWMods.h"
#include "RWGltf.h"
#include "RWTypes.h"
#include "RWFab.h"
#include "Engine/StaticMesh.h"
#include "Misc/PackageName.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

TArray<FRWPlaceable> FRWEditor::Catalog;
TArray<FRWPlaced> FRWEditor::Placed;
TArray<FVector4> FRWEditor::GrassStrokes;
TArray<TSharedPtr<FJsonValue>> FRWEditor::PendingModItems;

FString FRWEditor::SaveFile() { return FPaths::ProjectSavedDir() / TEXT("MapEdits") / TEXT("map.json"); }

void FRWEditor::BuildCatalog()
{
	Catalog.Reset();
	auto B = [](const TCHAR* Name, const TCHAR* Kind, FVector2D Fp, bool bObs) { FRWPlaceable P; P.Name = Name; P.Builtin = Kind; P.Footprint = Fp; P.bObstacle = bObs; Catalog.Add(P); };
	B(TEXT("Site container"), TEXT("container"), FVector2D(6.1f, 2.45f), true);
	B(TEXT("House"), TEXT("house"), FVector2D(8.f, 6.f), true);
	B(TEXT("Warehouse shed"), TEXT("shed"), FVector2D(20.f, 14.f), true);
	B(TEXT("Silo"), TEXT("silo"), FVector2D(4.f, 4.f), true);
	B(TEXT("Conifer tree"), TEXT("conifer"), FVector2D(0.6f, 0.6f), false);
	B(TEXT("Broadleaf tree"), TEXT("broadleaf"), FVector2D(0.6f, 0.6f), false);
	B(TEXT("Bush"), TEXT("bush"), FVector2D(1.f, 1.f), false);
	B(TEXT("Rock"), TEXT("rock"), FVector2D(1.6f, 1.4f), true);
	B(TEXT("Concrete barrier"), TEXT("barrier"), FVector2D(2.f, 0.6f), true);
	B(TEXT("Fence section"), TEXT("fence"), FVector2D(4.f, 0.2f), true);
	B(TEXT("Light pole"), TEXT("lamp"), FVector2D(0.4f, 0.4f), true);
	B(TEXT("Water spring (pump outlet)"), TEXT("water_source"), FVector2D(0.6f, 0.6f), false); // 30 L/s x scale, flows over the terrain
	B(TEXT("Culvert pipe 0.6 m x 8 m"), TEXT("culvert"), FVector2D(8.f, 0.7f), false); // drains water through an embankment
	B(TEXT("Grass brush (paint)"), TEXT("grass_add"), FVector2D(0, 0), false);
	B(TEXT("Grass eraser"), TEXT("grass_remove"), FVector2D(0, 0), false);
	// everything usable from the Content packs: named after the asset so a saved map finds it again
	for (const FString& Path : FRWFab::PlaceablePaths())
	{
		FRWPlaceable P;
		P.Name = FString::Printf(TEXT("Pack: %s"), *FPackageName::ObjectPathToObjectName(Path));
		P.AssetPath = Path;
		P.Footprint = FVector2D(1.f, 1.f);
		P.bObstacle = false;
		Catalog.Add(P);
	}
	// mod placeables: any glTF model a mod lists under "placeables"
	for (const FRWModInfo& Md : FRWMods::Mods)
	{
		if (!Md.bEnabled) continue;
		FString Text; TSharedPtr<FJsonObject> Root;
		if (!FFileHelper::LoadFileToString(Text, *(Md.Folder / TEXT("mod.json"))) || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Root) || !Root.IsValid()) continue;
		const TArray<TSharedPtr<FJsonValue>>* A;
		if (Root->TryGetArrayField(TEXT("placeables"), A))
			for (const TSharedPtr<FJsonValue>& V : *A)
			{
				const TSharedPtr<FJsonObject> O = V->AsObject();
				if (!O.IsValid()) continue;
				FRWPlaceable P;
				O->TryGetStringField(TEXT("name"), P.Name);
				FString Model; O->TryGetStringField(TEXT("model"), Model);
				if (P.Name.IsEmpty() || Model.IsEmpty()) continue;
				P.ModelPath = Md.Folder / Model;
				double S = 1.0; O->TryGetNumberField(TEXT("scale"), S); P.Scale = S;
				O->TryGetBoolField(TEXT("obstacle"), P.bObstacle);
				const TArray<TSharedPtr<FJsonValue>>* F;
				if (O->TryGetArrayField(TEXT("footprint"), F) && F->Num() == 2) P.Footprint = FVector2D((*F)[0]->AsNumber(), (*F)[1]->AsNumber());
				Catalog.Add(P);
			}
	}
}

void FRWEditor::CulvertGeometry(const ARWTerrain* T, const FVector& PosM, float Yaw, float Scale, FVector& In, FVector& Out, float& Diameter)
{
	const float S = FMath::Clamp(Scale, 0.4f, 3.f);
	const float L = 8.f * S;
	Diameter = FMath::Clamp(0.6f * S, 0.3f, 1.5f);
	const FVector2D Dir(FMath::Cos(FMath::DegreesToRadians(Yaw)), FMath::Sin(FMath::DegreesToRadians(Yaw)));
	const FVector2D A = FVector2D(PosM.X, PosM.Y) - Dir * L * 0.5f, B = FVector2D(PosM.X, PosM.Y) + Dir * L * 0.5f;
	// the pipe stays where it was first laid: soil tipped over it later must not lift its inverts
	static TMap<uint32, FVector2D> Laid;
	const uint32 Key = HashCombine(HashCombine(GetTypeHash(FMath::RoundToInt(PosM.X * 10.f)), GetTypeHash(FMath::RoundToInt(PosM.Y * 10.f))), HashCombine(GetTypeHash(FMath::RoundToInt(Yaw * 10.f)), GetTypeHash(FMath::RoundToInt(S * 100.f))));
	if (T && !Laid.Contains(Key))
	{
		const float InZ0 = T->HeightAt(A.X, A.Y) - 0.05f;                                // pipe floor just below the ground at the inlet
		Laid.Add(Key, FVector2D(InZ0, FMath::Min(T->HeightAt(B.X, B.Y) - 0.05f, InZ0 - 0.01f * L))); // and at least a 1 % fall to the outlet
	}
	const FVector2D Z = T ? Laid[Key] : FVector2D(-0.05f, -0.05f - 0.01f * L);
	In = FVector(A.X, A.Y, Z.X); Out = FVector(B.X, B.Y, Z.Y);
}

int32 FRWEditor::FindItem(const FString& Name)
{
	for (int32 i = 0; i < Catalog.Num(); ++i) if (Catalog[i].Name == Name) return i;
	return INDEX_NONE;
}

static UStaticMeshComponent* Piece(ARWWorld* W, USceneComponent* Root, UStaticMesh* Mesh, const FVector& LocM, const FVector& Scale, const FLinearColor& Col, float Rough, const FRotator& Rot = FRotator::ZeroRotator, float Metal = 0.f)
{
	UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(W);
	C->SetStaticMesh(Mesh);
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, W);
	M->SetVectorParameterValue(TEXT("Color"), Col);
	M->SetScalarParameterValue(TEXT("Roughness"), Rough);
	M->SetScalarParameterValue(TEXT("Metallic"), Metal);
	C->SetMaterial(0, M);
	C->SetupAttachment(Root);
	C->SetRelativeLocationAndRotation(LocM * M2CM, Rot);
	C->SetRelativeScale3D(Scale);
	C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	C->RegisterComponent();
	return C;
}

USceneComponent* FRWEditor::Build(ARWWorld* W, const FRWPlaceable& P, const FVector& PosM, float Yaw, float Scale)
{
	if (!W || !W->Terrain) return nullptr;
	USceneComponent* R = NewObject<USceneComponent>(W);
	R->SetupAttachment(W->GetRootComponent());
	R->SetMobility(EComponentMobility::Movable);
	R->RegisterComponent();
	const float G = W->Terrain->HeightAt(PosM.X, PosM.Y);
	R->SetWorldLocationAndRotation(FVector(PosM.X, PosM.Y, G + PosM.Z) * M2CM, FRotator(0, Yaw, 0));
	R->SetWorldScale3D(FVector(Scale));
	auto RB = [](float X, float Y, float Z, float Rad = -1.f) { return FRWMeshGen::RoundBox(FVector(X, Y, Z), Rad); };
	const FString& K = P.Builtin;
	// a model from the Content packs at real size with its own materials, standing on the ground
	auto PackPiece = [&](UStaticMesh* Mesh, float Sc)
	{
		float Base = 0.f;
		FRWFab::HeightScale(Mesh, 1.f, &Base);
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(W);
		C->SetStaticMesh(Mesh);
		C->SetupAttachment(R);
		C->SetRelativeLocation(FVector(0, 0, -Base * Sc));
		C->SetRelativeScale3D(FVector(Sc));
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->RegisterComponent();
	};
	// the plain tree, bush and rock items use the pack models when there are any
	const TArray<UStaticMesh*>* PackList = K == TEXT("conifer") ? (FRWFab::Conifer.Num() ? &FRWFab::Conifer : &FRWFab::Broadleaf)
		: K == TEXT("broadleaf") ? (FRWFab::Broadleaf.Num() ? &FRWFab::Broadleaf : &FRWFab::Conifer)
		: K == TEXT("bush") ? &FRWFab::Bush : K == TEXT("rock") ? &FRWFab::Rock : nullptr;
	if (!P.AssetPath.IsEmpty())
	{
		if (UStaticMesh* Mesh = LoadObject<UStaticMesh>(nullptr, *P.AssetPath)) PackPiece(Mesh, 1.f);
		else RWLog(FString::Printf(TEXT("Map editor: pack model %s could not be loaded"), *P.AssetPath));
	}
	else if (PackList && PackList->Num() > 0)
	{
		UStaticMesh* Mesh = (*PackList)[FMath::Abs(FMath::RoundToInt(PosM.X * 7.f + PosM.Y * 13.f)) % PackList->Num()];
		const bool bTree = K == TEXT("conifer") || K == TEXT("broadleaf");
		PackPiece(Mesh, FRWFab::HeightScale(Mesh, bTree ? 13.f : K == TEXT("bush") ? 1.6f : 1.2f));
	}
	else if (!P.ModelPath.IsEmpty())
	{
		if (TSharedPtr<FRWGltfModel> Md = FRWGltfModel::Get(P.ModelPath, P.Scale, 0.f)) Md->SpawnAll(W, R);
	}
	else if (K == TEXT("container"))
	{
		Piece(W, R, RB(6.06f, 2.44f, 2.59f, 0.04f), FVector(0, 0, 1.3f), FVector::OneVector, FLinearColor(0.12f, 0.3f, 0.55f), 0.5f, FRotator::ZeroRotator, 0.3f);
		for (int32 k = -6; k <= 6; ++k) Piece(W, R, RB(0.06f, 2.46f, 2.4f, 0.01f), FVector(k * 0.45f, 0, 1.3f), FVector::OneVector, FLinearColor(0.1f, 0.26f, 0.5f), 0.5f, FRotator::ZeroRotator, 0.3f);
		Piece(W, R, RB(0.05f, 2.3f, 2.4f, 0.01f), FVector(3.05f, 0, 1.3f), FVector::OneVector, FLinearColor(0.11f, 0.28f, 0.52f), 0.45f, FRotator::ZeroRotator, 0.3f);
	}
	else if (K == TEXT("house"))
	{
		Piece(W, R, RB(8.6f, 6.6f, 0.5f), FVector(0, 0, 0.25f), FVector::OneVector, FLinearColor(0.35f, 0.34f, 0.32f), 0.9f);
		Piece(W, R, RB(8.f, 6.f, 2.7f), FVector(0, 0, 1.85f), FVector::OneVector, FLinearColor(0.62f, 0.58f, 0.5f), 0.8f);
		for (int32 s = -1; s <= 1; s += 2) Piece(W, R, RB(8.6f, 3.6f, 0.15f), FVector(0, s * 1.55f, 3.95f), FVector::OneVector, FLinearColor(0.25f, 0.07f, 0.04f), 0.7f, FRotator(0, 0, s * -25.f));
		for (int32 s = -1; s <= 1; s += 2) Piece(W, R, RB(1.2f, 0.05f, 1.0f), FVector(s * 2.4f, 3.01f, 1.85f), FVector::OneVector, FLinearColor(0.02f, 0.03f, 0.04f), 0.05f, FRotator::ZeroRotator, 0.5f);
		Piece(W, R, RB(1.0f, 0.05f, 2.1f), FVector(0, 3.01f, 1.2f), FVector::OneVector, FLinearColor(0.12f, 0.07f, 0.04f), 0.6f);
	}
	else if (K == TEXT("shed"))
	{
		Piece(W, R, RB(20.f, 14.f, 8.f, 0.08f), FVector(0, 0, 4.f), FVector::OneVector, FLinearColor(0.32f, 0.34f, 0.36f), 0.45f, FRotator::ZeroRotator, 0.6f);
		Piece(W, R, RB(21.f, 15.f, 0.5f, 0.08f), FVector(0, 0, 8.25f), FVector::OneVector, FLinearColor(0.15f, 0.17f, 0.2f), 0.4f, FRotator::ZeroRotator, 0.7f);
		Piece(W, R, RB(10.f, 0.1f, 6.f, 0.02f), FVector(0, 7.05f, 3.f), FVector::OneVector, FLinearColor(0.5f, 0.38f, 0.05f), 0.5f);
	}
	else if (K == TEXT("silo"))
	{
		Piece(W, R, FRWMeshGen::RoundCyl(4.f, 10.f), FVector(0, 0, 8.f), FVector::OneVector, FLinearColor(0.62f, 0.62f, 0.6f), 0.35f, FRotator::ZeroRotator, 0.7f);
		Piece(W, R, ARWMachine::GCone, FVector(0, 0, 13.7f), FVector(4.f, 4.f, 1.4f), FLinearColor(0.55f, 0.55f, 0.52f), 0.4f, FRotator::ZeroRotator, 0.7f);
		for (int32 l = 0; l < 4; ++l) Piece(W, R, RB(0.25f, 0.25f, 3.f), FVector(l & 1 ? 1.5f : -1.5f, l & 2 ? 1.5f : -1.5f, 1.5f), FVector::OneVector, FLinearColor(0.3f, 0.3f, 0.3f), 0.5f, FRotator::ZeroRotator, 0.7f);
	}
	else if (K == TEXT("conifer") || K == TEXT("broadleaf"))
	{
		const float H = 13.f;
		Piece(W, R, FRWMeshGen::TreeTrunk(1, 1, 1), FVector(0, 0, H * 0.3f), FVector(0.48f, 0.48f, H * 0.62f), FLinearColor(0.06f, 0.04f, 0.025f), 0.9f);
		UMaterialInterface* Fol = W->FoliageMat;
		for (int32 k = 0; k < 3; ++k)
		{
			UStaticMeshComponent* C = K == TEXT("conifer")
				? Piece(W, R, FRWMeshGen::ConiferCrown(1, 1, 1), FVector(0, 0, H * (0.42f + k * 0.2f)), FVector(H * 0.34f * (1.f - k * 0.27f), H * 0.34f * (1.f - k * 0.27f), H * (0.46f - k * 0.08f)), FLinearColor(0.035f, 0.065f, 0.028f), 0.8f, FRotator(0, k * 40.f, 0))
				: Piece(W, R, FRWMeshGen::BroadleafCrown(1, 2), FVector(k == 0 ? 0.f : (k == 1 ? 1.5f : -1.4f), k == 2 ? 1.f : 0.f, H * (k == 0 ? 0.74f : 0.64f)), FVector(H * (k == 0 ? 0.45f : 0.3f)), FLinearColor(0.06f, 0.1f, 0.03f), 0.75f);
			if (Fol) { UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(Fol, W); M->SetVectorParameterValue(TEXT("Color"), K == TEXT("conifer") ? FLinearColor(0.035f, 0.065f, 0.028f) : FLinearColor(0.06f, 0.1f, 0.03f)); C->SetMaterial(0, M); }
		}
	}
	else if (K == TEXT("culvert"))
	{
		// black corrugated pipe from the inlet floor to the outlet floor (water flow: ARWWater culverts)
		FVector In, Out; float Dm;
		CulvertGeometry(W->Terrain, PosM, Yaw, Scale, In, Out, Dm);
		const FVector Axis = Out - In;
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(W);
		C->SetStaticMesh(FRWMeshGen::CorrugatedPipe(Axis.Size(), Dm));
		UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, W);
		M->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.02f, 0.02f, 0.022f));
		M->SetScalarParameterValue(TEXT("Roughness"), 0.55f);
		M->SetScalarParameterValue(TEXT("Metallic"), 0.f);
		C->SetMaterial(0, M);
		C->SetupAttachment(R);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->RegisterComponent();
		C->SetWorldScale3D(FVector::OneVector);
		C->SetWorldLocationAndRotation((In + FVector(0, 0, Dm * 0.5f)) * M2CM, Axis.Rotation());
	}
	else if (K == TEXT("water_source"))
	{
		// pump outlet: a short steel pipe with a flange, water pours out at its foot
		Piece(W, R, FRWMeshGen::RoundCyl(0.25f, 0.9f), FVector(0, 0, 0.45f), FVector::OneVector, FLinearColor(0.2f, 0.32f, 0.42f), 0.4f, FRotator::ZeroRotator, 0.6f);
		Piece(W, R, FRWMeshGen::RoundCyl(0.42f, 0.06f), FVector(0, 0, 0.9f), FVector::OneVector, FLinearColor(0.25f, 0.25f, 0.25f), 0.4f, FRotator::ZeroRotator, 0.8f);
		Piece(W, R, FRWMeshGen::RoundCyl(0.2f, 0.5f), FVector(0.25f, 0, 0.75f), FVector::OneVector, FLinearColor(0.2f, 0.32f, 0.42f), 0.4f, FRotator(90, 0, 0), 0.6f);
	}
	else if (K == TEXT("bush")) Piece(W, R, FRWMeshGen::BroadleafCrown(1, 5), FVector(0, 0, 0.5f), FVector(1.6f, 1.6f, 1.1f), FLinearColor(0.04f, 0.06f, 0.02f), 0.85f);
	else if (K == TEXT("rock")) Piece(W, R, FRWMeshGen::Rock(1, 3), FVector(0, 0, 0.3f), FVector(1.8f, 1.5f, 1.2f), FLinearColor(0.17f, 0.16f, 0.15f), 0.85f);
	else if (K == TEXT("barrier")) Piece(W, R, RB(2.f, 0.6f, 0.8f, 0.05f), FVector(0, 0, 0.4f), FVector::OneVector, FLinearColor(0.42f, 0.41f, 0.38f), 0.85f);
	else if (K == TEXT("fence"))
	{
		for (int32 k = -1; k <= 1; ++k) Piece(W, R, RB(0.08f, 0.08f, 2.f), FVector(k * 2.f, 0, 1.f), FVector::OneVector, FLinearColor(0.4f, 0.4f, 0.4f), 0.4f, FRotator::ZeroRotator, 0.8f);
		Piece(W, R, RB(4.f, 0.02f, 1.9f, 0.005f), FVector(0, 0, 1.f), FVector::OneVector, FLinearColor(0.35f, 0.36f, 0.35f), 0.5f, FRotator::ZeroRotator, 0.8f);
	}
	else if (K == TEXT("lamp"))
	{
		Piece(W, R, FRWMeshGen::RoundCyl(0.2f, 9.f), FVector(0, 0, 4.5f), FVector::OneVector, FLinearColor(0.45f, 0.45f, 0.45f), 0.4f, FRotator::ZeroRotator, 0.8f);
		Piece(W, R, RB(1.6f, 0.12f, 0.12f), FVector(0.7f, 0, 8.9f), FVector::OneVector, FLinearColor(0.45f, 0.45f, 0.45f), 0.4f, FRotator::ZeroRotator, 0.8f);
		Piece(W, R, RB(0.6f, 0.3f, 0.15f), FVector(1.4f, 0, 8.8f), FVector::OneVector, FLinearColor(0.9f, 0.85f, 0.7f), 0.3f);
	}
	return R;
}

int32 FRWEditor::Place(ARWWorld* W, const FString& Item, const FVector& PosM, float Yaw, float Scale, bool bRecord)
{
	const int32 Idx = FindItem(Item);
	if (Idx < 0 || !W) return INDEX_NONE;
	const FRWPlaceable& P = Catalog[Idx];
	if (P.Builtin.StartsWith(TEXT("grass"))) return INDEX_NONE;
	FRWPlaced D; D.Item = Item; D.Pos = PosM; D.Yaw = Yaw; D.Scale = Scale;
	D.Root = Build(W, P, PosM, Yaw, Scale);
	if (P.bObstacle && P.Footprint.X > 0)
	{
		W->Obstacles.Add({FVector2D(PosM.X, PosM.Y), P.Footprint * 0.5f * Scale, Yaw});
		D.Obstacle = W->Obstacles.Num() - 1;
	}
	Placed.Add(D);
	if (bRecord) Save();
	return Placed.Num() - 1;
}

bool FRWEditor::RemoveNear(ARWWorld* W, const FVector& PosM, float Radius)
{
	int32 Best = INDEX_NONE; float BD = Radius;
	for (int32 i = 0; i < Placed.Num(); ++i)
	{
		const float D = FVector2D::Distance(FVector2D(Placed[i].Pos.X, Placed[i].Pos.Y), FVector2D(PosM.X, PosM.Y));
		if (D < BD) { BD = D; Best = i; }
	}
	if (Best == INDEX_NONE) return false;
	FRWPlaced& D = Placed[Best];
	if (D.Root)
	{
		TArray<USceneComponent*> Ch; D.Root->GetChildrenComponents(true, Ch);
		for (USceneComponent* C : Ch) C->DestroyComponent();
		D.Root->DestroyComponent();
	}
	if (W && W->Obstacles.IsValidIndex(D.Obstacle)) W->Obstacles[D.Obstacle].Half = FVector2D::ZeroVector; // keep indices stable
	Placed.RemoveAt(Best);
	Save();
	return true;
}

void FRWEditor::PaintGrass(ARWWorld* W, const FVector2D& P, float R, bool bAdd, bool bRecord)
{
	if (!W || !W->Terrain) return;
	ARWTerrain* T = W->Terrain;
	const int32 CX = T->ToGrid(P.X), CY = T->ToGrid(P.Y), RR = FMath::CeilToInt(R / ARWTerrain::CS);
	for (int32 dy = -RR; dy <= RR; ++dy)
		for (int32 dx = -RR; dx <= RR; ++dx)
		{
			if (!T->Valid(CX + dx, CY + dy)) continue;
			const float D = FVector2D(dx, dy).Size() * ARWTerrain::CS;
			if (D > R) continue;
			const int32 i = T->Idx(CX + dx, CY + dy);
			if (bAdd) T->AddGrass(i, 0.5f * (1.f - D / R) + 0.2f); else T->ClearGrass(i, 1.f);
		}
	W->LastGrassCam = FVector(1e9);
	if (bRecord) GrassStrokes.Add(FVector4(P.X, P.Y, R, bAdd ? 1.f : -1.f));
}

static TSharedPtr<FJsonObject> ItemsToJson()
{
	TSharedPtr<FJsonObject> Root = MakeShared<FJsonObject>();
	TArray<TSharedPtr<FJsonValue>> Items, Grass;
	for (const FRWPlaced& P : FRWEditor::Placed)
	{
		TSharedPtr<FJsonObject> O = MakeShared<FJsonObject>();
		O->SetStringField(TEXT("item"), P.Item);
		O->SetArrayField(TEXT("pos"), {MakeShared<FJsonValueNumber>(P.Pos.X), MakeShared<FJsonValueNumber>(P.Pos.Y), MakeShared<FJsonValueNumber>(P.Pos.Z)});
		O->SetNumberField(TEXT("yaw"), P.Yaw);
		O->SetNumberField(TEXT("scale"), P.Scale);
		Items.Add(MakeShared<FJsonValueObject>(O));
	}
	for (const FVector4& S : FRWEditor::GrassStrokes)
		Grass.Add(MakeShared<FJsonValueArray>(TArray<TSharedPtr<FJsonValue>>{MakeShared<FJsonValueNumber>(S.X), MakeShared<FJsonValueNumber>(S.Y), MakeShared<FJsonValueNumber>(S.Z), MakeShared<FJsonValueNumber>(S.W)}));
	Root->SetArrayField(TEXT("map_items"), Items);
	Root->SetArrayField(TEXT("grass_strokes"), Grass);
	return Root;
}

bool FRWEditor::Save()
{
	FString Out;
	const TSharedRef<TJsonWriter<>> Wr = TJsonWriterFactory<>::Create(&Out);
	FJsonSerializer::Serialize(ItemsToJson().ToSharedRef(), Wr);
	IFileManager::Get().MakeDirectory(*FPaths::GetPath(SaveFile()), true);
	return FFileHelper::SaveStringToFile(Out, *SaveFile(), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

FString FRWEditor::ExportAsMod()
{
	// a shareable mod: copy this folder into someone else's Mods directory
	const FString Dir = FRWMods::SearchDirs().Num() ? FRWMods::SearchDirs()[0] / TEXT("MyMapEdits") : FPaths::ProjectDir() / TEXT("Mods") / TEXT("MyMapEdits");
	TSharedPtr<FJsonObject> Root = ItemsToJson();
	Root->SetStringField(TEXT("name"), TEXT("My map edits"));
	Root->SetStringField(TEXT("id"), TEXT("player.mapedits"));
	Root->SetStringField(TEXT("version"), TEXT("1.0"));
	Root->SetStringField(TEXT("sdk_version"), TEXT("2"));
	FString Out;
	const TSharedRef<TJsonWriter<>> Wr = TJsonWriterFactory<>::Create(&Out);
	FJsonSerializer::Serialize(Root.ToSharedRef(), Wr);
	IFileManager::Get().MakeDirectory(*Dir, true);
	FFileHelper::SaveStringToFile(Out, *(Dir / TEXT("mod.json")), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
	return Dir;
}

void FRWEditor::ApplyItems(ARWWorld* W, const TArray<TSharedPtr<FJsonValue>>& Items, bool bRecord)
{
	for (const TSharedPtr<FJsonValue>& V : Items)
	{
		const TSharedPtr<FJsonObject> O = V->AsObject();
		if (!O.IsValid()) continue;
		const TArray<TSharedPtr<FJsonValue>>* P;
		if (!O->TryGetArrayField(TEXT("pos"), P) || P->Num() < 2) continue;
		const FVector Pos((*P)[0]->AsNumber(), (*P)[1]->AsNumber(), P->Num() > 2 ? (*P)[2]->AsNumber() : 0.0);
		double Yaw = 0, Scale = 1; O->TryGetNumberField(TEXT("yaw"), Yaw); O->TryGetNumberField(TEXT("scale"), Scale);
		const int32 Idx = Place(W, O->GetStringField(TEXT("item")), Pos, Yaw, Scale, false);
		if (!bRecord && Idx != INDEX_NONE) Placed.RemoveAt(Idx, 1, EAllowShrinking::No); // mod items are not part of your own edit list
	}
}

void FRWEditor::LoadAll(ARWWorld* W)
{
	BuildCatalog();
	ApplyItems(W, PendingModItems, false);
	Placed.Reset(); GrassStrokes.Reset();
	FString Text; TSharedPtr<FJsonObject> Root;
	if (FFileHelper::LoadFileToString(Text, *SaveFile()) && FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Root) && Root.IsValid())
	{
		const TArray<TSharedPtr<FJsonValue>>* Items;
		if (Root->TryGetArrayField(TEXT("map_items"), Items)) ApplyItems(W, *Items, true);
		const TArray<TSharedPtr<FJsonValue>>* G;
		if (Root->TryGetArrayField(TEXT("grass_strokes"), G))
			for (const TSharedPtr<FJsonValue>& S : *G)
			{
				const TArray<TSharedPtr<FJsonValue>>& A = S->AsArray();
				if (A.Num() == 4) PaintGrass(W, FVector2D(A[0]->AsNumber(), A[1]->AsNumber()), A[2]->AsNumber(), A[3]->AsNumber() > 0, true);
			}
	}
	RWLog(FString::Printf(TEXT("Map editor: %d catalogue items, %d placed objects, %d grass strokes"), Catalog.Num(), Placed.Num(), GrassStrokes.Num()));
}
