﻿#include "RWTerrain.h"
#include "RWLayout.h"
#include "ProceduralMeshComponent.h"
#include "Misc/Compression.h"
#include "Async/ParallelFor.h"
#include "Materials/MaterialInterface.h"
#include "Serialization/BufferArchive.h"
#include "Serialization/MemoryReader.h"

ARWTerrain::ARWTerrain()
{
	PrimaryActorTick.bCanEverTick = false;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

static float SStepT(float A, float B, float X)
{
	const float T = FMath::Clamp((X - A) / (B - A), 0.f, 1.f);
	return T * T * (3 - 2 * T);
}

void ARWTerrain::Generate(const FRWLayout* InLayout, UMaterialInterface* Mat)
{
	if (!InLayout)
	{
		UE_LOG(LogTemp, Error, TEXT("RoadWorks Terrain: Generate called with null layout"));
		return;
	}
	// Generate can be invoked again when rebuilding a world. Never retain old mesh
	// components, active solver entries, or generated-ground bookkeeping.
	for (UProceduralMeshComponent* PM : ChunkComps)
	{
		if (IsValid(PM)) PM->DestroyComponent();
	}
	ChunkComps.Reset();
	if (IsValid(Backdrop)) Backdrop->DestroyComponent();
	Backdrop = nullptr;
	Chunks.Reset();
	ActiveList.Reset();
	DigFloor.Reset();
	GenPoints.Reset();
	MoistRow = 0;
	DepositSeq = 0;
	Layout = InLayout;
	TerrainMat = Mat;
	WaterZ = Layout->WaterZ;
	const int32 Num = N * N;
	Natural.SetNumUninitialized(Num);
	Base.SetNumUninitialized(Num);
	Height.SetNumUninitialized(Num);
	Layers.SetNum(Num);
	BaseComp.SetNumUninitialized(Num);
	Moist.SetNumUninitialized(Num);
	Grass.SetNumUninitialized(Num);
	ActiveFlag.Init(false, Num);

	ParallelFor(N, [&](int32 Y)
	{
		for (int32 X = 0; X < N; ++X)
		{
			const int32 i = Idx(X, Y);
			const float WX = PX(X), WY = PX(Y);
			const float H = Layout->NaturalHeight(WX, WY);
			Natural[i] = H; Base[i] = H;
			BaseComp[i] = 175;
			Moist[i] = (uint8)(Layout->InitMoisture(WX, WY, H) * 255.f);
			Grass[i] = (uint8)(Layout->InitGrass(WX, WY) * 255.f);
			Layers[i] = FLayers();
		}
	});

	// Built surfaces in yards and plant: compacted gravel hardstanding.
	for (const FRWZone& Z : Layout->Zones)
	{
		if (Z.Type != ERWZone::Depot && Z.Type != ERWZone::Plant && Z.Type != ERWZone::Village) continue;
		const int32 X0 = ToGrid(Z.C.X - Z.HalfExt.X), X1 = ToGrid(Z.C.X + Z.HalfExt.X);
		const int32 Y0 = ToGrid(Z.C.Y - Z.HalfExt.Y), Y1 = ToGrid(Z.C.Y + Z.HalfExt.Y);
		for (int32 Y = FMath::Max(Y0, 0); Y <= FMath::Min(Y1, N - 1); ++Y)
			for (int32 X = FMath::Max(X0, 0); X <= FMath::Min(X1, N - 1); ++X)
			{
				const int32 i = Idx(X, Y);
				FLayers& L = Layers[i];
				const float T = Z.Type == ERWZone::Village ? 0.15f : 0.25f;
				L.Count = 1; L.Mat[0] = (uint8)(Z.Type == ERWZone::Village ? ESoil::Compacted : ESoil::Gravel); L.Comp[0] = 235; L.T[0] = T;
				Base[i] -= T; Natural[i] = Base[i];
				Grass[i] = 0; BaseComp[i] = 230;
			}
	}

	// Roads: rasterise each segment, cut/fill to the profile and build the pavement layers.
	TArray<float> BestD; BestD.Init(1e9f, Num);
	TArray<float> RoadZ; RoadZ.Init(0.f, Num);
	TArray<uint8> RoadType; RoadType.Init(0, Num);
	TArray<float> RoadHW; RoadHW.Init(0.f, Num);
	for (const FRWRoad& R : Layout->Roads)
	{
		for (int32 s = 0; s + 1 < R.Pts.Num(); ++s)
		{
			const FVector2D A = R.Pts[s], B = R.Pts[s + 1];
			// how far the cutting or embankment reaches depends on how far the road lies from the ground beside it (side slopes 1 : 1.5)
			float Off = 0.f;
			{
				const FVector2D Dir = (B - A).GetSafeNormal(), Lat(-Dir.Y, Dir.X);
				for (const float Sd : {-1.f, 0.f, 1.f})
				{
					const FVector2D Q = A + Lat * (Sd * (R.HalfW + 12.f));
					if (InBounds(Q.X, Q.Y)) Off = FMath::Max(Off, FMath::Abs(Base[IndexAt(Q.X, Q.Y)] - R.Z[s]));
				}
			}
			// Extend the cut/fill footprint far enough to reconnect steep mountain slopes.
			// Keep a bounded search region to avoid scanning the entire heightfield.
			const float Ext = R.HalfW + 9.f + FMath::Min(1.5f * Off, 120.f);
			const int32 X0 = FMath::Max(0, ToGrid(FMath::Min(A.X, B.X) - Ext)), X1 = FMath::Min(N - 1, ToGrid(FMath::Max(A.X, B.X) + Ext));
			const int32 Y0 = FMath::Max(0, ToGrid(FMath::Min(A.Y, B.Y) - Ext)), Y1 = FMath::Min(N - 1, ToGrid(FMath::Max(A.Y, B.Y) + Ext));
			const FVector2D AB = B - A; const float L2 = FMath::Max(AB.SizeSquared(), 1e-4f);
			for (int32 Y = Y0; Y <= Y1; ++Y)
				for (int32 X = X0; X <= X1; ++X)
				{
					const FVector2D P(PX(X), PX(Y));
					const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / L2, 0.f, 1.f);
					const float D = FVector2D::Distance(P, A + AB * T);
					const int32 i = Idx(X, Y);
					if (D < BestD[i])
					{
						BestD[i] = D;
						// 2.5% crown on asphalt, 4% on gravel tracks.
						const float Crown = (R.bAsphalt ? 0.025f : 0.04f) * FMath::Min(D, R.HalfW);
						RoadZ[i] = FMath::Lerp(R.Z[s], R.Z[s + 1], T) - Crown;
						RoadType[i] = R.bAsphalt ? 1 : (R.MaxGrade > 0.f ? 3 : 2);
						RoadHW[i] = R.HalfW;
					}
				}
		}
	}
	double RoadCut = 0.0, RoadFill = 0.0;
	TMap<int32, float> WorkedDepth;
	for (int32 i = 0; i < Num; ++i)
	{
		if (RoadType[i] == 0) continue;
		const float HW = RoadHW[i];
		const float D = BestD[i];
		const int32 X = i % N, Y = i / N;
		if (D <= HW + 0.6f)
		{
			FLayers& L = Layers[i];
			L = FLayers();
			if (RoadType[i] == 1)
			{
				L.Count = 3;
				L.Mat[0] = (uint8)ESoil::Laterite; L.T[0] = 0.20f; L.Comp[0] = 245;
				L.Mat[1] = (uint8)ESoil::Gravel;   L.T[1] = 0.20f; L.Comp[1] = 245;
				L.Mat[2] = (uint8)ESoil::Asphalt;  L.T[2] = 0.06f; L.Comp[2] = 250;
				if (D > HW) { L.Mat[2] = (uint8)ESoil::Gravel; } // gravel shoulder
			}
			else
			{
				// (the long roads out in the mountains are surfaced with crushed stone from the hills they run through)
				L.Count = 1; L.Mat[0] = (uint8)(RoadType[i] == 3 ? ESoil::Gravel : ESoil::Laterite); L.T[0] = 0.30f; L.Comp[0] = 215;
			}
			const float Moved = RoadZ[i] - L.Total() - Base[i];
			if (Moved < 0.f) RoadCut += -Moved * CellArea; else RoadFill += Moved * CellArea;
			Base[i] = RoadZ[i] - L.Total();
			Natural[i] = Base[i];
			BaseComp[i] = 235; Grass[i] = 0;
			Moist[i] = FMath::Min<uint8>(Moist[i], 60);
		}
		else
		{
			// The side slopes of a cutting or an embankment, 1 : 1.5 from the edge of the road back to the ground.
			// Cut and fill use different repose profiles: a steeper excavated bank
			// and a flatter loose embankment. Both blend into undisturbed terrain.
			const float Foot = RoadZ[i] - 0.25f;
			const float DistanceFromShoulder = FMath::Max(0.f, D - HW - 0.6f);
			const float CutRise = DistanceFromShoulder / 1.0f;
			const float FillDrop = DistanceFromShoulder / 1.8f;
			const float Was = Base[i];
			Base[i] = Was > Foot ? FMath::Min(Was, Foot + CutRise) : FMath::Max(Was, Foot - FillDrop);
			Natural[i] = Base[i];
			const float Moved = Base[i] - Was;
			if (Moved < 0.f) RoadCut += -Moved * CellArea; else RoadFill += Moved * CellArea;
			// freshly worked: no grass on a cutting, little on a new bank; the ground of a cutting is what was below the surface
			if (FMath::Abs(Moved) > 0.1f) { Grass[i] = (uint8)(Grass[i] * (Moved < -3.f ? 0.15f : 0.55f)); WorkedDepth.Add(i, FMath::Max(-Moved, 0.f)); }
			else Grass[i] = (uint8)(Grass[i] * (1.f - 0.6f * (1.f - SStepT(HW + 0.6f, HW + 9.f, D))));
		}
		(void)X; (void)Y;
	}

	// Road profile scratch buffers are no longer needed. Release ~1 GB of
	// temporary arrays before building the rest of the world.
	BestD.Empty();
	RoadZ.Empty();
	RoadType.Empty();
	RoadHW.Empty();

	// Potholes on a stretch of Highway 7 (repair job).
	{
		const FVector2D A = Layout->PotholeA, B = Layout->PotholeB;
		for (int32 k = 0; k < 14; ++k)
		{
			const FVector2D C = FMath::Lerp(A, B, (k + 0.5f) / 14.f) + FVector2D(0, RWNoise2(k * 3.1f, 1.7f, 5) * 2.5f);
			const float R = 0.6f + 0.5f * FMath::Abs(RWNoise2(k * 1.3f, 9.1f, 7));
			const int32 CX = ToGrid(C.X), CY = ToGrid(C.Y);
			for (int32 dy = -3; dy <= 3; ++dy)
				for (int32 dx = -3; dx <= 3; ++dx)
				{
					if (!Valid(CX + dx, CY + dy)) continue;
					const float D = FVector2D(dx * CS, dy * CS).Size();
					if (D > R) continue;
					const int32 i = Idx(CX + dx, CY + dy);
					FLayers& L = Layers[i];
					if (L.Count == 3)
					{
						const float Depth = 0.12f * (1.f - D / R);
						L.Count = 2; // asphalt gone
						L.T[1] = FMath::Max(0.05f, L.T[1] - Depth);
						L.Mat[1] = (uint8)ESoil::DrySoil; L.Comp[1] = 90;
						Moist[i] = 160;
					}
				}
		}
	}

	for (int32 i = 0; i < Num; ++i) Recalc(i);

	// the surface soil of the untouched ground, once (road and yard surfaces have their own layers)
	NatSurf.Reset();
	{
		TArray<uint8> Surf; Surf.SetNumUninitialized(Num);
		ParallelFor(N, [&](int32 Y)
		{
			for (int32 X = 0; X < N; ++X)
			{
				const int32 i = Idx(X, Y);
				Surf[i] = (uint8)Layout->Strata(PX(X), PX(Y), 0.01f);
			}
		});
		NatSurf = MoveTemp(Surf);
	}
	for (const TPair<int32, float>& E : WorkedDepth)
		NatSurf[E.Key] = (uint8)(E.Value > 3.f ? ESoil::SmallRock : ESoil::DrySoil); // rock shows in a deep cutting, soil on a bank or a shallow one
	RWLog(FString::Printf(TEXT("Roads: %.0f m3 cut, %.0f m3 filled"), RoadCut, RoadFill));
	// remember what the roads and yards put down, for loading a game later
	GenPoints.Reset();
	for (int32 i = 0; i < Num; ++i)
		if (Layers[i].Count > 0) { FGenPoint& Gp = GenPoints.Add(i); Gp.L = Layers[i]; Gp.BaseC = BaseComp[i]; Gp.G = Grass[i]; }
	// and the grass as the map was made (roads' cuttings and banks have less): ground with less than that was worked since
	GrassGen = Grass;
	ChunkEdited.Init(false, NumChunks * NumChunks);

	// Rendering components.
	Chunks.SetNum(NumChunks * NumChunks);
	for (int32 C = 0; C < NumChunks * NumChunks; ++C)
	{
		UProceduralMeshComponent* PM = NewObject<UProceduralMeshComponent>(this, *FString::Printf(TEXT("Chunk_%d"), C));
		PM->SetupAttachment(RootComponent);
		PM->bUseAsyncCooking = true;
		PM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		PM->SetCastShadow(true);
		PM->RegisterComponent();
		ChunkComps.Add(PM);
	}
	BuildBackdrop();
	RWLog(FString::Printf(TEXT("Terrain generated: %d x %d points (%.0f m), %d chunks"), N, N, Half * 2, Chunks.Num()));
}

int32 ARWTerrain::IndexAt(float X, float Y) const
{
	const int32 GX = FMath::Clamp(ToGrid(X), 0, N - 1), GY = FMath::Clamp(ToGrid(Y), 0, N - 1);
	return Idx(GX, GY);
}

float ARWTerrain::HeightAt(float X, float Y) const
{
	if (Height.Num() == 0) return 0.f;
	const float FX = FMath::Clamp((X + Half) / CS, 0.f, (float)(N - 1) - 0.001f);
	const float FY = FMath::Clamp((Y + Half) / CS, 0.f, (float)(N - 1) - 0.001f);
	const int32 X0 = (int32)FX, Y0 = (int32)FY;
	const float TX = FX - X0, TY = FY - Y0;
	const int32 i = Idx(X0, Y0);
	const float A = FMath::Lerp(Height[i], Height[i + 1], TX);
	const float B = FMath::Lerp(Height[i + N], Height[i + N + 1], TX);
	return FMath::Lerp(A, B, TY);
}

FVector ARWTerrain::NormalAt(float X, float Y) const
{
	const float D = CS;
	const float HX = HeightAt(X + D, Y) - HeightAt(X - D, Y);
	const float HY = HeightAt(X, Y + D) - HeightAt(X, Y - D);
	return FVector(-HX, -HY, 2 * D).GetSafeNormal();
}

ESoil ARWTerrain::MatAtDepth(int32 i, float Depth) const
{
	const FLayers& L = Layers[i];
	float Acc = 0;
	for (int32 k = L.Count - 1; k >= 0; --k)
	{
		Acc += L.T[k];
		if (Depth < Acc) return (ESoil)L.Mat[k];
	}
	const int32 X = i % N, Y = i / N;
	return Layout ? Layout->Strata(PX(X), PX(Y), (Natural[i] - Base[i]) + (Depth - Acc)) : ESoil::DrySoil;
}

ESoil ARWTerrain::SurfaceMat(int32 i) const
{
	const FLayers& L = Layers[i];
	if (L.Count > 0) return (ESoil)L.Mat[L.Count - 1];
	// untouched ground: looked up once at the start (working it out each time cost 15 ms a frame on this size of map)
	if (Base[i] == Natural[i] && NatSurf.IsValidIndex(i)) return (ESoil)NatSurf[i];
	return MatAtDepth(i, 0.01f);
}

float ARWTerrain::SurfaceComp(int32 i) const
{
	const FLayers& L = Layers[i];
	if (L.Count > 0) return L.Comp[L.Count - 1] / 255.f;
	return BaseComp[i] / 255.f;
}

FSoilState ARWTerrain::SurfaceState(int32 i) const
{
	return EvalSoil(SurfaceMat(i), MoistureAt(i), SurfaceComp(i));
}

void ARWTerrain::MarkEdited(int32 i)
{
	if (ChunkEdited.Num() == 0) return;
	const int32 X = i % N, Y = i / N;
	ChunkEdited[FMath::Min(Y / ChunkCells, NumChunks - 1) * NumChunks + FMath::Min(X / ChunkCells, NumChunks - 1)] = true;
}

void ARWTerrain::MarkChunk(int32 X, int32 Y)
{
	if (!Valid(X, Y) || Chunks.Num() != NumChunks * NumChunks) return;
	const int32 CX = FMath::Min(X / ChunkCells, NumChunks - 1), CY = FMath::Min(Y / ChunkCells, NumChunks - 1);
	Chunks[CY * NumChunks + CX].bDirty = true;
	// points on chunk borders belong to two chunks
	if (X % ChunkCells == 0 && CX > 0) Chunks[CY * NumChunks + CX - 1].bDirty = true;
	if (Y % ChunkCells == 0 && CY > 0) Chunks[(CY - 1) * NumChunks + CX].bDirty = true;
	if (X % ChunkCells == 0 && Y % ChunkCells == 0 && CX > 0 && CY > 0) Chunks[(CY - 1) * NumChunks + CX - 1].bDirty = true;
}

void ARWTerrain::Touch(int32 i, bool bRelax)
{
	if (!Height.IsValidIndex(i) || !Layers.IsValidIndex(i) || ActiveFlag.Num() != N * N) return;
	Recalc(i);
	MarkEdited(i);
	if (OnTouch) OnTouch(i);
	if (OnDisturb) OnDisturb(i);
	const int32 X = i % N, Y = i / N;
	MarkChunk(X, Y);
	// neighbours' normals change too
	if (X + 1 < N) MarkChunk(X + 1, Y);
	if (Y + 1 < N) MarkChunk(X, Y + 1);
	if (bRelax)
	{
		for (int32 dy = -1; dy <= 1; ++dy)
			for (int32 dx = -1; dx <= 1; ++dx)
			{
				if (!Valid(X + dx, Y + dy)) continue;
				const int32 j = Idx(X + dx, Y + dy);
				if (!ActiveFlag[j]) { ActiveFlag[j] = true; ActiveList.Add(j); }
			}
	}
}

float ARWTerrain::RemoveAt(int32 i, float Dh, FPayload& Out, bool bAllowRock)
{
	if (!FMath::IsFinite(Dh) || Dh <= 0.f || !Height.IsValidIndex(i) || !Layers.IsValidIndex(i)) return 0.f;
	if (DigFloor.Num() > 0)
		if (const float* Fl = DigFloor.Find(i))
		{
			Dh = FMath::Min(Dh, Height[i] - *Fl);
			if (Dh <= 0.f) return 0.f;
		}
	float Left = Dh;
	FLayers& L = Layers[i];
	const float M = MoistureAt(i);
	while (Left > 1e-6f && L.Count > 0)
	{
		const int32 k = L.Count - 1;
		const ESoil Mat = (ESoil)L.Mat[k];
		if (!bAllowRock && !SoilProps(Mat).bDiggable) break;
		const float T = FMath::Min(Left, L.T[k]);
		const float Loose = T * CellArea * (1.f + SoilProps(Mat).Swell * (L.Comp[k] / 255.f));
		Out.Add(Mat, Loose, M);
		if (OnRemove) OnRemove(i, Mat, Loose);
		L.T[k] -= T; Left -= T;
		if (L.T[k] <= 1e-5f) L.Count--;
	}
	// Natural ground: cut in slices so stratum boundaries are honoured.
	// Process the full requested depth in 10 cm strata, with a conservative
	// per-call ceiling to avoid unbounded work from malformed input.
	int32 Guard = 0;
	while (Left > 1e-6f && L.Count == 0 && Guard++ < 4096)
	{
		const ESoil Mat = MatAtDepth(i, 0.005f);
		if (!bAllowRock && !SoilProps(Mat).bDiggable) break;
		const float T = FMath::Min(Left, 0.1f);
		const float Loose = T * CellArea * (1.f + SoilProps(Mat).Swell * (BaseComp[i] / 255.f));
		Out.Add(Mat, Loose, M);
		if (OnRemove) OnRemove(i, Mat, Loose);
		Base[i] -= T; Left -= T;
	}
	const float Removed = Dh - Left;
	if (Removed > 0)
	{
		Grass[i] = 0;
		Touch(i);
	}
	return Removed;
}

void ARWTerrain::DepositAt(int32 i, ESoil M, float LooseVol, float Moisture, uint8 Comp)
{
	if (!Layers.IsValidIndex(i) || !FMath::IsFinite(LooseVol) || LooseVol <= 0.f ||
		!FMath::IsFinite(Moisture) || !FMath::IsFinite(SoilProps(M).Swell)) return;
	FLayers& L = Layers[i];
	const float T = LooseVol / CellArea / (1.f + SoilProps(M).Swell * (Comp / 255.f));
	if (L.Count > 0 && L.Mat[L.Count - 1] == (uint8)M && FMath::Abs((int32)L.Comp[L.Count - 1] - (int32)Comp) < 40)
	{
		const int32 k = L.Count - 1;
		L.Comp[k] = (uint8)((L.Comp[k] * L.T[k] + Comp * T) / (L.T[k] + T));
		L.T[k] += T;
	}
	else
	{
		if (L.Count == 4)
		{
			// merge the two lowest layers (keeps the stack bounded, material of the thicker one wins)
			const float T01 = L.T[0] + L.T[1];
			L.Mat[0] = L.T[0] >= L.T[1] ? L.Mat[0] : L.Mat[1];
			L.Comp[0] = (uint8)((L.Comp[0] * L.T[0] + L.Comp[1] * L.T[1]) / FMath::Max(T01, 1e-6f));
			L.T[0] = T01;
			for (int32 k = 1; k < 3; ++k) { L.Mat[k] = L.Mat[k + 1]; L.Comp[k] = L.Comp[k + 1]; L.T[k] = L.T[k + 1]; }
			L.Count = 3;
		}
		L.Mat[L.Count] = (uint8)M; L.Comp[L.Count] = Comp; L.T[L.Count] = T; L.Count++;
	}
	if (Moisture >= 0) Moist[i] = (uint8)FMath::Clamp(FMath::Lerp(Moist[i] / 255.f, Moisture, 0.7f) * 255.f, 0.f, 255.f);
	Grass[i] = 0;
	if (OnDeposit) OnDeposit(i, M, LooseVol);
	Touch(i);
}

void ARWTerrain::DepositPayloadAt(int32 i, const FPayload& P)
{
	// A mixed load lands as one layer of its dominant material (keeps the layer stack meaningful).
	const float Tot = P.Total();
	if (Tot > 1e-7f) DepositAt(i, P.Dominant(), Tot, P.Moist);
}

// cheap integer hash -> 0..1 (deterministic, so tests and saves stay repeatable)
static float RWHash01(uint32 X)
{
	X ^= X >> 16; X *= 0x7feb352dU; X ^= X >> 15; X *= 0x846ca68bU; X ^= X >> 16;
	return (X & 0xFFFFFF) / 16777215.f;
}

void ARWTerrain::DepositDisc(float X, float Y, float R, const FPayload& P)
{
	++DepositSeq;
	const float Tot = P.Total();
	if (Tot <= 0) return;
	const int32 CX = ToGrid(X), CY = ToGrid(Y);
	const int32 RR = FMath::Max(0, FMath::CeilToInt(R / CS));
	TArray<int32, TInlineAllocator<64>> Pts; TArray<float, TInlineAllocator<64>> W; float WS = 0;
	for (int32 dy = -RR; dy <= RR; ++dy)
		for (int32 dx = -RR; dx <= RR; ++dx)
		{
			if (!Valid(CX + dx, CY + dy)) continue;
			const float D = FVector2D(dx, dy).Size() * CS;
			if (D > R + 0.01f) continue;
			// uneven spread: each landing clod piles a bit more on some cells than others (volume is unchanged)
			const int32 j = Idx(CX + dx, CY + dy);
			const float Wk = (1.f - D / (R + CS)) * (0.6f + 0.8f * RWHash01((uint32)j * 2654435761U ^ DepositSeq * 40503U));
			Pts.Add(j); W.Add(Wk); WS += Wk;
		}
	if (Pts.Num() == 0) return;
	for (int32 k = 0; k < Pts.Num(); ++k)
	{
		FPayload Part = P; // copy proportions
		const float F = W[k] / WS;
		for (float& V : Part.Vol) V *= F;
		DepositPayloadAt(Pts[k], Part);
	}
}

void ARWTerrain::CompactAt(int32 i, float Amount)
{
	FLayers& L = Layers[i];
	const float M = MoistureAt(i);
	// Proctor-style moisture effect: best compaction near optimum moisture (~0.45 here).
	const float MoistEff = FMath::Clamp(1.f - FMath::Abs(M - 0.45f) * 1.4f, 0.25f, 1.f);
	if (L.Count > 0)
	{
		const int32 k = L.Count - 1;
		const ESoil Mat = (ESoil)L.Mat[k];
		if (!SoilProps(Mat).bCompactable) return;
		const float C0 = L.Comp[k] / 255.f;
		const float Eff = Mat == ESoil::Asphalt ? 1.f : MoistEff;
		const float C1 = FMath::Min(1.f, C0 + (1.f - C0) * Amount * Eff);
		const float Sw = SoilProps(Mat).Swell;
		L.T[k] *= (1.f + Sw * C0) / (1.f + Sw * C1);
		L.Comp[k] = (uint8)(C1 * 255.f);
		if (Mat == ESoil::DrySoil && C1 > 0.86f) L.Mat[k] = (uint8)ESoil::Compacted;
	}
	else
	{
		const float C0 = BaseComp[i] / 255.f;
		const float C1 = FMath::Min(1.f, C0 + (1.f - C0) * Amount * MoistEff * 0.6f);
		Base[i] -= 0.04f * (C1 - C0); // settlement of natural ground
		BaseComp[i] = (uint8)(C1 * 255.f);
	}
	Touch(i, false);
}

// One ground deformation entry point for all wheels and crawler rollers.
// Contact is a finite rectangle in world metres, not a line and not a decal.
// Only the world heightfield can alter the actual riding surface.
float ARWTerrain::ApplyContactRut(const FVector2D& Center, const FVector2D& Forward,
    float ContactLength, float ContactWidth, float NormalLoadN, float Slip,
    float PassFactor, bool bCrawler, float MaxRutDepth)
{
    if (!FMath::IsFinite(Center.X) || !FMath::IsFinite(Center.Y) ||
        !FMath::IsFinite(ContactLength) || !FMath::IsFinite(ContactWidth) ||
        !FMath::IsFinite(NormalLoadN) || !FMath::IsFinite(Slip) ||
        !FMath::IsFinite(PassFactor) || NormalLoadN <= 1.f ||
        ContactLength <= 0.f || ContactWidth <= 0.f || PassFactor <= 0.f ||
        !InBounds(Center.X, Center.Y) || Height.Num() != N * N)
        return 0.f;

    const FVector2D Axis = Forward.GetSafeNormal();
    if (Axis.IsNearlyZero()) return 0.f;
    const FVector2D Lateral(-Axis.Y, Axis.X);
    const float L = FMath::Clamp(ContactLength, 0.1f, 3.f);
    const float W = FMath::Clamp(ContactWidth, 0.1f, 3.f);
    const float HalfL = L * 0.5f, HalfW = W * 0.5f;
    // Same kPa scale as GroundEffects used before the refactor.
    const float PressureKPa = (NormalLoadN / 1000.f) / FMath::Max(L * W, 0.05f);
    const float Reach = HalfL + HalfW + CS;
    const int32 X0 = FMath::Max(1, ToGrid(Center.X - Reach));
    const int32 X1 = FMath::Min(N - 2, ToGrid(Center.X + Reach));
    const int32 Y0 = FMath::Max(1, ToGrid(Center.Y - Reach));
    const int32 Y1 = FMath::Min(N - 2, ToGrid(Center.Y + Reach));
    float Displaced = 0.f;
    int32 Worked = 0;
    for (int32 Gy = Y0; Gy <= Y1; ++Gy)
    for (int32 Gx = X0; Gx <= X1; ++Gx)
    {
        const FVector2D Cell(PX(Gx), PX(Gy));
        const FVector2D D = Cell - Center;
        const float Along = FVector2D::DotProduct(D, Axis);
        const float Across = FVector2D::DotProduct(D, Lateral);
        // Anti-alias the contact edges at the existing 0.5m heightfield pitch.
        // A narrow tyre still affects neighbouring cells, with reduced coverage.
        const float A = FMath::Clamp((HalfL + CS * 0.5f - FMath::Abs(Along)) / CS, 0.f, 1.f);
        const float B = FMath::Clamp((HalfW + CS * 0.5f - FMath::Abs(Across)) / CS, 0.f, 1.f);
        const float Coverage = A * B;
        if (Coverage < 0.02f) continue;
        const int32 I = Idx(Gx, Gy);
        const ESoil Material = SurfaceMat(I);
        const FSoilProps& Props = SoilProps(Material);
        // The old solver could still compact hard paving. Do not carve hard
        // asphalt, non-diggable rock or material that cannot compact.
        if (!Props.bDiggable && !Props.bCompactable) continue;
        if (Material == ESoil::Asphalt || Material == ESoil::LargeRock) continue;
        const FSoilState Soil = SurfaceState(I);
        const float Moisture = MoistureAt(I);
        const float Comp = SurfaceComp(I);
        const float Ratio = PressureKPa / FMath::Max(Soil.Bearing, 10.f);
        const float Shear = FMath::Clamp(FMath::Abs(Slip), 0.f, 1.f);
        const float Pass = FMath::Clamp(PassFactor, 0.f, 1.f);
        // The soil's response is the one every regression test was calibrated and passed against before this solver
        // (GroundEffects up to 11 Nov: trucks rutting mud, crawlers rutting fresh fill, rollers compacting): what changed
        // is only that it is now applied over the whole contact area. (This solver's first coefficients - noted as
        // placeholders - ruts a third as deep, and always pushed some soil aside, even dry packed laterite under a roller's
        // tyres: the loose spoil it dropped beside each tyre covered the packed surface the drum had just made.)
        // freshly dumped loose soil settles even under the low ground pressure of a crawler
        const float Loose = 1.f - FMath::Clamp(Comp / 0.45f, 0.f, 1.f);
        // never a clean ruler line: the ground gives way a little more here and less there
        const float Uneven = 0.75f + 0.5f * FMath::Clamp(RWNoise2(Cell.X * 0.9f, Cell.Y * 0.9f, 211) * 0.5f + 0.5f, 0.f, 1.f);
        // and even firm ground takes a shallow print under a track where it is not packed hard yet
        const float SoftFloor = bCrawler && Comp < 0.7f ? 0.004f : 0.f;
        float Depth = FMath::Max(FMath::Clamp((Ratio - 0.55f + 0.35f * Loose) * 0.03f * (1.f + 2.5f * Moisture), 0.f, 0.07f), SoftFloor) * Uneven;
        Depth *= Coverage * Pass * (1.f + (bCrawler ? 0.24f : 0.12f) * Shear);
        if (!bCrawler) // tyres have a rounded transverse pressure profile
        {
            const float U = FMath::Clamp(FMath::Abs(Across) / FMath::Max(HalfW, 0.01f), 0.f, 1.f);
            Depth *= 1.f - 0.30f * U * U;
        }
        ClearGrass(I, FMath::Clamp(0.25f * Coverage, 0.f, 1.f));
        // a wheel that has sunk to its limit rides on its rim and frame: no deeper
        const float RutNow = Natural[I] - Height[I];
        const bool bRoom = MaxRutDepth <= 0.f || RutNow < MaxRutDepth;
        if (Depth <= 0.002f * Coverage || !bRoom)
        {
            // no rut here: the pressure still packs ground that is not packed yet
            if (Props.bCompactable && Ratio > 0.25f && Comp < 0.6f) CompactAt(I, 0.02f * Ratio * Coverage * Pass);
            continue;
        }
        ++Worked;
        // wet soil flows, and freshly dumped loose soil is shoved aside, under a heavy wheel or track; dry, packed soil only
        // gets denser
        const bool bFlows = Props.bDiggable && (Moisture > 0.45f || (Comp < 0.45f && Ratio > 0.4f));
        if (!bFlows)
        {
            if (Props.bCompactable) CompactAt(I, FMath::Clamp(0.06f * Ratio, 0.f, 0.25f) * Coverage);
            continue;
        }
        {
            FPayload SoilOut;
            RemoveAt(I, Depth, SoilOut);
            // dry loose fill gets denser under the wheel too, so the rut stops deepening after a few passes
            if (Moisture <= 0.45f && Props.bCompactable) CompactAt(I, FMath::Clamp(0.08f * Ratio + 0.05f, 0.f, 0.25f) * Coverage);
            const float Vol = SoilOut.Total();
            if (Vol > 0.f)
            {
                // Reuse existing mass/loose-volume accounting. Four nearby
                // shoulder cells receive the excavated material, never one spike.
                TArray<int32, TInlineAllocator<4>> Receivers;
                for (int32 Side = -1; Side <= 1; Side += 2)
                for (int32 End = -1; End <= 1; End += 2)
                {
                    const FVector2D Q = Cell + Lateral * (Side * (HalfW + CS * 0.8f)) +
                        Axis * (End * CS * 0.4f);
                    if (!InBounds(Q.X, Q.Y)) continue;
                    const int32 J = IndexAt(Q.X, Q.Y);
                    if (J != I) Receivers.AddUnique(J);
                }
                if (Receivers.Num() == 0) Receivers.Add(I); // edge conservation
                for (const int32 J : Receivers)
                {
                    FPayload Part = SoilOut;
                    for (float& V : Part.Vol) V /= Receivers.Num();
                    DepositPayloadAt(J, Part);
                }
                Displaced += Vol;
            }
        }
    }
    // The terrain already has a mass-conserving granular relaxation solver.
    // Apply it locally to prevent displaced soil forming isolated needle peaks.
    if (Worked > 0 && Displaced > 0.f)
        SettleAround(Center.X, Center.Y, FMath::Max(L, W) + CS, 1,
            [](int32) { return false; });
    return Displaced;
}

void ARWTerrain::AddMoisture(int32 i, float D)
{
	const uint8 Old = Moist[i];
	Moist[i] = (uint8)FMath::Clamp(Moist[i] + D * 255.f, 0.f, 255.f);
	if (FMath::Abs((int32)Old - (int32)Moist[i]) > 0) { MarkChunk(i % N, i / N); MarkEdited(i); }
}

void ARWTerrain::ClearGrass(int32 i, float Amt)
{
	const uint8 Old = Grass[i];
	Grass[i] = (uint8)FMath::Max(0.f, Grass[i] - Amt * 255.f);
	if (Old != Grass[i]) { MarkChunk(i % N, i / N); MarkEdited(i); if (OnDisturb && IsWorked(i)) OnDisturb(i); }
}

uint8 ARWTerrain::GenGrass(int32 i) const
{
	if (GrassGen.IsValidIndex(i)) return GrassGen[i];
	if (const FGenPoint* G = GenPoints.Find(i)) return G->G;
	return Layout ? (uint8)(Layout->InitGrass(PX(i % N), PX(i / N)) * 255.f) : 0;
}

void ARWTerrain::AddGrass(int32 i, float Amt)
{
	const uint8 Old = Grass[i];
	Grass[i] = (uint8)FMath::Min(255.f, Grass[i] + Amt * 255.f);
	if (Old != Grass[i]) { MarkChunk(i % N, i / N); MarkEdited(i); }
}

void ARWTerrain::BreakRock(int32 i, float Depth)
{
	// Breaker hammer: fractures in-situ rock into a loose small-rock layer of the same height.
	FLayers& L = Layers[i];
	if (L.Count > 0 && L.Mat[L.Count - 1] == (uint8)ESoil::LargeRock)
	{
		L.Mat[L.Count - 1] = (uint8)ESoil::SmallRock; L.Comp[L.Count - 1] = 60;
	}
	else if (L.Count == 0 && MatAtDepth(i, 0.01f) == ESoil::LargeRock)
	{
		const float T = FMath::Min(Depth, 0.25f);
		Base[i] -= T;
		const float Sw = SoilProps(ESoil::SmallRock).Swell;
		L.Count = 1; L.Mat[0] = (uint8)ESoil::SmallRock; L.Comp[0] = 60;
		L.T[0] = T * (1.f + SoilProps(ESoil::LargeRock).Swell) / (1.f + Sw * (60.f / 255.f)) * 0.8f;
	}
	Grass[i] = 0;
	Touch(i);
}

void ARWTerrain::Relax(int32 Budget)
{
	static const int32 DX[8] = {1, -1, 0, 0, 1, 1, -1, -1};
	static const int32 DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
	if (Budget <= 0 || ActiveFlag.Num() != N * N) return;
	int32 Done = 0;
	while (ActiveList.Num() > 0 && Done < Budget)
	{
		const int32 i = ActiveList.Pop(EAllowShrinking::No);
		ActiveFlag[i] = false;
		++Done;
		const int32 X = i % N, Y = i / N;
		const FSoilState S = SurfaceState(i);
		// natural soil is never uniform: the stable slope varies a few degrees from spot to spot,
		// which gives heaps and spoil banks irregular flanks instead of a perfect cone
		const float Jit = (RWHash01((uint32)i * 747796405U + 2891336453U) - 0.5f) * 7.f;
		const float TanR = FMath::Tan(FMath::DegreesToRadians(FMath::Clamp(S.Repose + Jit, 5.f, 80.f)));
		int32 Best = -1; float BestEx = 0; float BestDist = CS;
		for (int32 k = 0; k < 8; ++k)
		{
			const int32 NX = X + DX[k], NY = Y + DY[k];
			if (!Valid(NX, NY)) continue;
			const int32 j = Idx(NX, NY);
			const float Dist = k < 4 ? CS : CS * 1.41421f;
			const float Diff = Height[i] - Height[j];
			const float Ex = Diff - TanR * Dist;
			if (Ex > BestEx) { BestEx = Ex; Best = j; BestDist = Dist; }
		}
		if (Best >= 0 && BestEx > 0.004f)
		{
			// Underwater material slides more easily.
			const float Move = BestEx * 0.42f;
			FPayload P;
			const float Got = RemoveAt(i, Move, P, false);
			if (Got > 0)
			{
				DepositPayloadAt(Best, P);
			}
		}
	}
}

void ARWTerrain::RelaxFor(float Dt)
{
	// (it was 9000 points every frame whatever the frame rate: twice the settling per second at 120 fps as at 60)
	const float Sd = FMath::IsFinite(Dt) ? FMath::Clamp(Dt, 0.f, 0.1f) : 1.f / 60.f;
	Relax(FMath::Clamp(FMath::RoundToInt(540000.f * Sd), 1500, 54000));
}

float ARWTerrain::SettleAround(float X, float Y, float R, int32 Iterations, TFunctionRef<bool(int32)> Wall)
{
	static const int32 DX[8] = {1, -1, 0, 0, 1, 1, -1, -1};
	static const int32 DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
	if (!InBounds(X, Y) || Layers.Num() != N * N) return 0.f;
	const int32 CX = ToGrid(X), CY = ToGrid(Y), RR = FMath::Max(1, FMath::CeilToInt(R / CS));
	float Moved = 0.f;
	for (int32 It = 0; It < Iterations; ++It)
	{
		float MovedNow = 0.f;
		for (int32 Gy = CY - RR; Gy <= CY + RR; ++Gy)
			for (int32 Gx = CX - RR; Gx <= CX + RR; ++Gx)
			{
				if (Gx < 1 || Gy < 1 || Gx >= N - 1 || Gy >= N - 1) continue;
				const int32 i = Idx(Gx, Gy);
				if (Wall(i)) continue;
				// (the same stable slope as Relax, with its few degrees of natural variation from spot to spot)
				const FSoilState S = SurfaceState(i);
				const float Jit = (RWHash01((uint32)i * 747796405U + 2891336453U) - 0.5f) * 7.f;
				const float TanR = FMath::Tan(FMath::DegreesToRadians(FMath::Clamp(S.Repose + Jit, 5.f, 80.f)));
				int32 To[8]; float Ex[8]; int32 NTo = 0; float ExSum = 0.f, ExMax = 0.f;
				for (int32 k = 0; k < 8; ++k)
				{
					const int32 j = Idx(Gx + DX[k], Gy + DY[k]);
					const float E = Height[i] - Height[j] - TanR * (k < 4 ? CS : CS * 1.41421f);
					if (E <= 0.004f || Wall(j)) continue;
					To[NTo] = j; Ex[NTo] = E; ++NTo; ExSum += E; ExMax = FMath::Max(ExMax, E);
				}
				if (NTo == 0) continue;
				// only loose soil runs: the loose layers on top, never packed fill or the natural ground under them (taken up
				// as loose, that swelled - soil out of nothing - and ate into banks and the ends of culverts)
				float LooseT = 0.f;
				{
					const FLayers& L = Layers[i];
					for (int32 k = L.Count - 1; k >= 0 && L.Comp[k] < 150; --k) LooseT += L.T[k];
				}
				if (LooseT < 0.004f) continue;
				// as much as Relax moves to the steepest neighbour, shared out by how far over each neighbour is
				FPayload P;
				const float Got = RemoveAt(i, FMath::Min(ExMax * 0.42f, LooseT), P, false);
				if (Got <= 0.f) continue;
				for (int32 n = 0; n < NTo; ++n)
				{
					FPayload Part = P;
					for (float& V : Part.Vol) V *= Ex[n] / ExSum;
					DepositPayloadAt(To[n], Part);
				}
				MovedNow += P.Total();
			}
		Moved += MovedNow;
		if (MovedNow < 1e-4f) break;
	}
	return Moved;
}

void ARWTerrain::SpikeCount(const FVector2D& C, float HalfX, float HalfY, int32& Peaks, int32& Steep, float& WorstPeak, float* WorstOver, double* Vol, int32* WorstAt) const
{
	if (WorstAt) *WorstAt = INDEX_NONE;
	Peaks = Steep = 0; WorstPeak = 0.f;
	if (WorstOver) *WorstOver = 0.f;
	if (Vol) *Vol = 0.0;
	static const int32 DX[8] = {1, -1, 0, 0, 1, 1, -1, -1};
	static const int32 DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
	const int32 X0 = ToGrid(C.X - HalfX), X1 = ToGrid(C.X + HalfX), Y0 = ToGrid(C.Y - HalfY), Y1 = ToGrid(C.Y + HalfY);
	for (int32 Y = FMath::Max(Y0, 1); Y <= FMath::Min(Y1, N - 2); ++Y)
		for (int32 X = FMath::Max(X0, 1); X <= FMath::Min(X1, N - 2); ++X)
		{
			const int32 i = Idx(X, Y);
			float MaxN = -1e9f;
			bool bSteep = false;
			const bool bLoose = Layers[i].Count > 0 && Layers[i].Comp[Layers[i].Count - 1] < 120;
			const float Rep = bLoose ? SurfaceState(i).Repose : 0.f;
			const float TanR = bLoose ? FMath::Tan(FMath::DegreesToRadians(FMath::Min(Rep + 10.f, 85.f))) : 0.f;
			// (the settling lets each spot stand up to 3.5 degrees steeper or shallower: natural soil is not uniform)
			const float TanR0 = bLoose ? FMath::Tan(FMath::DegreesToRadians(FMath::Min(Rep + 3.5f, 85.f))) : 0.f;
			if (Vol) *Vol += Height[i] * CellArea;
			for (int32 k = 0; k < 8; ++k)
			{
				const int32 j = Idx(X + DX[k], Y + DY[k]);
				MaxN = FMath::Max(MaxN, Height[j]);
				const float Dist = k < 4 ? CS : CS * 1.41421f;
				if (bLoose && Height[i] - Height[j] > TanR * Dist + 0.05f) bSteep = true;
				if (bLoose && WorstOver && Height[i] - Height[j] - TanR0 * Dist > *WorstOver) { *WorstOver = Height[i] - Height[j] - TanR0 * Dist; if (WorstAt) *WorstAt = i; }
			}
			if (Height[i] - MaxN > 0.08f) { ++Peaks; WorstPeak = FMath::Max(WorstPeak, Height[i] - MaxN); }
			Steep += bSteep ? 1 : 0;
		}
}

void ARWTerrain::UpdateMoisture(float Dt, float RainRate, float DryRate)
{
	if (!FMath::IsFinite(Dt) || Dt <= 0.f || !FMath::IsFinite(RainRate) || !FMath::IsFinite(DryRate) || Moist.Num() != N * N) return;
	// Sweep 1/1024 of the rows each call; time step scaled accordingly (the map has 9001 x 9001 points).
	const int32 Rows = N / 1024 + 1;
	const float Step = Dt * (float)N / (float)Rows;
	for (int32 r = 0; r < Rows; ++r)
	{
		const int32 Y = MoistRow;
		MoistRow = (MoistRow + 1) % N;
		for (int32 X = 0; X < N; ++X)
		{
			const int32 i = Idx(X, Y);
			const ESoil M = SurfaceMat(i);
			const FSoilProps& P = SoilProps(M);
			float W = Moist[i] / 255.f;
			const float Old = W;
			if (Height[i] < WaterZ + 0.05f) W = 1.f;
			else
			{
				W += Step * (RainRate * P.Absorb - DryRate * P.Drain * (0.3f + W));
				// Ground water keeps low ground damp
				const float Floor = Height[i] < WaterZ + 0.6f ? 0.7f : 0.04f;
				W = FMath::Clamp(W, Floor, 1.f);
			}
			const uint8 NewM = (uint8)(W * 255.f);
			if (NewM != Moist[i])
			{
				const bool bVisible = FMath::Abs(W - Old) > 0.f && (FMath::Abs((int32)NewM - (int32)Moist[i]) >= 1);
				Moist[i] = NewM;
				if (bVisible && (X % 4 == 0)) MarkChunk(X, Y);
				// Saturated slopes may fail: wake the relaxation solver.
				if (RainRate > 0.f && W > 0.6f && (X & 7) == (Y & 7) && !ActiveFlag[i]) { ActiveFlag[i] = true; ActiveList.Add(i); }
			}
		}
	}
}

FLinearColor ARWTerrain::PointColor(int32 i) const
{
	const ESoil M = SurfaceMat(i);
	const FSoilProps& P = SoilProps(M);
	const float W = MoistureAt(i);
	FLinearColor C = FMath::Lerp(P.Color, P.WetColor, FMath::Clamp(W * 1.15f - 0.1f, 0.f, 1.f));
	if (M == ESoil::DrySoil && W > 0.72f) C = FMath::Lerp(C, SoilProps(ESoil::Mud).WetColor, (W - 0.72f) * 3.f);
	const float G = Grass[i] / 255.f;
	if (G > 0)
	{
		const int32 X = i % N, Y = i / N;
		const float V = RWNoise2(X * 0.13f, Y * 0.13f, 3) * 0.5f + 0.5f;
		const FLinearColor Dry(0.16f, 0.15f, 0.055f), Lush(0.045f, 0.085f, 0.02f);
		FLinearColor GC = FMath::Lerp(Lush, Dry, V * 0.6f);
		GC = FMath::Lerp(GC, GC * 0.6f, W * 0.5f);
		C = FMath::Lerp(C, GC, FMath::Clamp(G * 1.2f, 0.f, 1.f));
	}
	// Loose (uncompacted) material looks slightly lighter and rougher; compacted asphalt darker.
	const float Comp = SurfaceComp(i);
	if (M == ESoil::Asphalt) C *= FMath::Lerp(1.25f, 0.85f, Comp);
	else C *= FMath::Lerp(1.08f, 0.96f, Comp);
	// Alpha encodes wetness / smoothness for roughness in the material.
	float A = FMath::Clamp(W * 0.85f - 0.15f, 0.f, 1.f);
	if (Height[i] < WaterZ + 0.08f) A = 0.95f;
	if (M == ESoil::Asphalt) A = FMath::Max(A, 0.15f * Comp);
	C.A = A;
	return C;
}

void ARWTerrain::PBRWeights(int32 i, FLinearColor& Col, FVector2D& UV1, FVector2D& UV2, FVector2D& UV3) const
{
	// one soil per point; the GPU blends neighbouring points, so soil borders fade over half a metre
	// colour R dry soil, G sand, B laterite, A wetness | UV1.x mud, UV1.y grass (+) / loose soil (-)
	// UV2.x gravel, UV2.y small rock | UV3.x clay, UV3.y compacted | nothing = asphalt / bedrock
	const ESoil M = SurfaceMat(i);
	const float W = MoistureAt(i);
	float Dry = 0, Sand = 0, Lat = 0, Mud = 0, Grav = 0, Rock = 0, Clay = 0, Comp = 0;
	switch (M)
	{
	case ESoil::DrySoil: case ESoil::WetSoil:
	{
		const float ToMud = FMath::Clamp((W - 0.72f) * 3.f, 0.f, 1.f); // soaked soil turns to mud
		Dry = 1.f - ToMud; Mud = ToMud; break;
	}
	case ESoil::Mud: Mud = 1.f; break;
	case ESoil::Sand: Sand = 1.f; break;
	case ESoil::Gravel: Grav = 1.f; break;
	case ESoil::SmallRock: Rock = 1.f; break;
	case ESoil::Clay: Clay = 1.f; break;
	case ESoil::Laterite: Lat = 1.f; break;
	case ESoil::Compacted: Comp = 1.f; break;
	default: break; // large rock, asphalt
	}
	float A = FMath::Clamp(W * 0.85f - 0.15f, 0.f, 1.f);
	if (Height[i] < WaterZ + 0.08f) A = 0.95f;
	if (M == ESoil::Asphalt) A = FMath::Max(A, 0.15f * SurfaceComp(i));
	Col = FLinearColor(Dry, Sand, Lat, A);
	const float G = Grass[i] / 255.f;
	const bool bLooseKind = M == ESoil::DrySoil || M == ESoil::WetSoil || M == ESoil::Clay || M == ESoil::Laterite || M == ESoil::Sand;
	const float Loose = bLooseKind ? 1.f - FMath::Clamp(SurfaceComp(i) / 0.45f, 0.f, 1.f) : 0.f;
	UV1 = FVector2D(Mud, G > 0.01f ? G : -Loose);
	UV2 = FVector2D(Grav, Rock);
	UV3 = FVector2D(Clay, Comp);
}

void ARWTerrain::SetPBR(bool bOn, UMaterialInterface* Mat)
{
	if (bPBR == bOn && TerrainMat == Mat) return;
	bPBR = bOn;
	if (Mat) TerrainMat = Mat;
	for (FChunk& Ch : Chunks) { Ch.bDirty = true; Ch.Lod = -1; } // rebuild with the other vertex layout
	if (Backdrop) BuildBackdrop();
	RWLog(FString::Printf(TEXT("Terrain material: %s"), bPBR ? TEXT("textured soil (PBR)") : TEXT("classic")));
}

void ARWTerrain::BuildTriangles(int32 Lod)
{
	TArray<int32>& T = TriCache[Lod];
	if (T.Num() > 0) return;
	const int32 S = LodStep(Lod);
	const int32 V = ChunkCells / S + 1;
	for (int32 y = 0; y < V - 1; ++y)
		for (int32 x = 0; x < V - 1; ++x)
		{
			const int32 A = y * V + x, B = A + 1, C = A + V, D = C + 1;
			// alternate diagonal for less directional artefacts
			if ((x + y) & 1) { T.Add(A); T.Add(C); T.Add(B); T.Add(B); T.Add(C); T.Add(D); }
			else { T.Add(A); T.Add(C); T.Add(D); T.Add(A); T.Add(D); T.Add(B); }
		}
	// Skirts: 4 edges, each edge vertex duplicated below.
	const int32 SkirtBase = V * V;
	auto EdgeVert = [&](int32 Edge, int32 k) -> int32
	{
		switch (Edge)
		{
		case 0: return k;                    // y = 0
		case 1: return (V - 1) * V + k;      // y = max
		case 2: return k * V;                // x = 0
		default: return k * V + (V - 1);     // x = max
		}
	};
	for (int32 e = 0; e < 4; ++e)
		for (int32 k = 0; k < V - 1; ++k)
		{
			const int32 A = EdgeVert(e, k), B = EdgeVert(e, k + 1);
			const int32 SA = SkirtBase + e * V + k, SB = SA + 1;
			// both windings so the skirt is visible from either side
			T.Add(A); T.Add(SA); T.Add(B); T.Add(B); T.Add(SA); T.Add(SB);
			T.Add(A); T.Add(B); T.Add(SA); T.Add(B); T.Add(SB); T.Add(SA);
		}
}

void ARWTerrain::BuildChunk(int32 C, int32 Lod)
{
	BuildTriangles(Lod);
	const int32 S = LodStep(Lod);
	const int32 V = ChunkCells / S + 1;
	const int32 CX = C % NumChunks, CY = C / NumChunks;
	const int32 X0 = CX * ChunkCells, Y0 = CY * ChunkCells;
	const int32 NumV = V * V + 4 * V;
	TArray<FVector> Pos; Pos.SetNumUninitialized(NumV);
	TArray<FVector> Nrm; Nrm.SetNumUninitialized(NumV);
	TArray<FVector2D> UV; UV.SetNumUninitialized(NumV);
	TArray<FVector2D> UV1; UV1.SetNumUninitialized(NumV); // x = surface grain (fine soil .. rock), y = grass cover
	TArray<FVector2D> Empty;
	TArray<FLinearColor> Col; Col.SetNumUninitialized(NumV);
	TArray<FProcMeshTangent> Tan;
	// textured (PBR) mode: soil weights in colour + UV1..UV3, and tangents for the normal maps
	TArray<FVector2D> UV2, UV3;
	if (bPBR) { UV2.SetNumUninitialized(NumV); UV3.SetNumUninitialized(NumV); Tan.SetNumUninitialized(NumV); }
	for (int32 y = 0; y < V; ++y)
		for (int32 x = 0; x < V; ++x)
		{
			const int32 GX = FMath::Min(X0 + x * S, N - 1), GY = FMath::Min(Y0 + y * S, N - 1);
			const int32 i = Idx(GX, GY);
			const int32 v = y * V + x;
			Pos[v] = FVector(PX(GX) * M2CM, PX(GY) * M2CM, Height[i] * M2CM);
			const int32 XL = FMath::Max(GX - 1, 0), XR = FMath::Min(GX + 1, N - 1);
			const int32 YD = FMath::Max(GY - 1, 0), YU = FMath::Min(GY + 1, N - 1);
			const float HX = (Height[Idx(XR, GY)] - Height[Idx(XL, GY)]) / ((XR - XL) * CS);
			const float HY = (Height[Idx(GX, YU)] - Height[Idx(GX, YD)]) / ((YU - YD) * CS);
			Nrm[v] = FVector(-HX, -HY, 1.f).GetSafeNormal();
			UV[v] = FVector2D(PX(GX) / 4.f, PX(GY) / 4.f);
			Col[v] = PointColor(i);
			static const float Grain[SOIL_COUNT] = {0.12f, 0.08f, 0.f, 0.3f, 0.65f, 0.85f, 1.f, 0.05f, 0.4f, 0.18f, 0.35f};
			UV1[v] = FVector2D(Grain[(int32)SurfaceMat(i)], Grass[i] / 255.f);
			if (bPBR)
			{
				PBRWeights(i, Col[v], UV1[v], UV2[v], UV3[v]);
				const FVector Tx = (FVector(1, 0, 0) - Nrm[v] * Nrm[v].X).GetSafeNormal();
				Tan[v] = FProcMeshTangent(Tx, false);
			}
		}
	auto EdgeVert = [&](int32 Edge, int32 k) -> int32
	{
		switch (Edge)
		{
		case 0: return k;
		case 1: return (V - 1) * V + k;
		case 2: return k * V;
		default: return k * V + (V - 1);
		}
	};
	const float Drop = Lod >= 4 ? 2500.f : (60.f + Lod * 60.f); // (the coarsest meshes can differ by metres on a mountain side)
	for (int32 e = 0; e < 4; ++e)
		for (int32 k = 0; k < V; ++k)
		{
			const int32 Src = EdgeVert(e, k);
			const int32 Dst = V * V + e * V + k;
			Pos[Dst] = Pos[Src] - FVector(0, 0, Drop);
			Nrm[Dst] = Nrm[Src]; UV[Dst] = UV[Src]; Col[Dst] = Col[Src]; UV1[Dst] = UV1[Src];
			if (bPBR) { UV2[Dst] = UV2[Src]; UV3[Dst] = UV3[Src]; Tan[Dst] = Tan[Src]; }
		}
	UProceduralMeshComponent* PM = ChunkComps[C];
	FChunk& Ch = Chunks[C];
	if (Ch.Lod == Lod && Ch.Verts == NumV)
	{
		// same colour conversion for updates as for creation, so edited ground keeps its colour
		PM->UpdateMeshSection_LinearColor(0, Pos, Nrm, UV, UV1, bPBR ? UV2 : Empty, bPBR ? UV3 : Empty, Col, Tan, false);
	}
	else
	{
		PM->CreateMeshSection_LinearColor(0, Pos, TriCache[Lod], Nrm, UV, UV1, bPBR ? UV2 : Empty, bPBR ? UV3 : Empty, Col, Tan, false, false);
		PM->SetMaterial(0, TerrainMat);
	}
	Ch.Lod = Lod; Ch.Verts = NumV; Ch.bDirty = false;
}

int32 ARWTerrain::PendingChunks() const
{
	int32 P = 0;
	for (const FChunk& C : Chunks) if (C.bDirty || C.Lod < 0) ++P;
	return P;
}

void ARWTerrain::UpdateMeshes(const FVector& CamM, bool bForceAll)
{
	struct FCand { int32 C; int32 Lod; float D; };
	TArray<FCand> Cands;
	int32 FarDirtyPick = -1; float FarDirtyD = 0.f;
	for (int32 C = 0; C < Chunks.Num(); ++C)
	{
		const int32 CX = C % NumChunks, CY = C / NumChunks;
		const float MX = -Half + (CX + 0.5f) * ChunkCells * CS, MY = -Half + (CY + 0.5f) * ChunkCells * CS;
		const float D = FMath::Max(0.f, FVector2D::Distance(FVector2D(CamM.X, CamM.Y), FVector2D(MX, MY)) - 30.f);
		int32 Want = D < 70.f ? 0 : D < 150.f ? 1 : D < 260.f ? 2 : D < 700.f ? 3 : 4;
		FChunk& Ch = Chunks[C];
		// hysteresis: only coarsen when clearly beyond the threshold
		if (Ch.Lod >= 0 && Want > Ch.Lod)
		{
			const float Th[5] = {70.f, 150.f, 260.f, 700.f, 1e9f};
			if (D < Th[Ch.Lod] + 12.f) Want = Ch.Lod;
		}
		// the ground drying or wetting far away barely shows: a far chunk with nothing but that waits its turn, one every half second
		if (!bForceAll && Ch.bDirty && Ch.Lod == Want && D > 150.f)
		{
			if (FarDirtyPick < 0 || D < FarDirtyD) { FarDirtyPick = C; FarDirtyD = D; }
			continue;
		}
		if (Ch.bDirty || Ch.Lod != Want) Cands.Add({C, Want, D});
	}
	if (FarDirtyPick >= 0 && FPlatformTime::Seconds() - FarDirtyAt > 0.5)
	{
		FarDirtyAt = FPlatformTime::Seconds();
		Cands.Add({FarDirtyPick, Chunks[FarDirtyPick].Lod, FarDirtyD});
	}
	if (Cands.Num() == 0) return;
	Cands.Sort([](const FCand& A, const FCand& B) { return A.D < B.D; });
	const double Start = FPlatformTime::Seconds();
	int32 Built = 0;
	for (const FCand& K : Cands)
	{
		// Cap both the number of chunk rebuilds and the frame-time budget.
		// Previously a slow first build forced a second build even past budget.
		if (!bForceAll && (Built >= 2 || (Built > 0 && FPlatformTime::Seconds() - Start > 0.004))) break;
		BuildChunk(K.C, K.Lod);
		++Built;
	}
}

void ARWTerrain::BuildBackdrop()
{
	// Far landscape ring (non-deformable, 30 m grid) out to 9 km: the mountain ranges on the horizon.
	if (!Backdrop)
	{
		Backdrop = NewObject<UProceduralMeshComponent>(this, TEXT("Backdrop"));
		Backdrop->SetupAttachment(RootComponent);
		Backdrop->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		Backdrop->RegisterComponent();
	}
	Backdrop->ClearAllMeshSections();
	const float Ext = 9000.f, Step = 30.f, Hole = Half - 6.f;
	const int32 V = FMath::RoundToInt(2 * Ext / Step) + 1;
	TArray<float> HGrid; HGrid.SetNumUninitialized(V * V);
	ParallelFor(V, [&](int32 y)
	{
		for (int32 x = 0; x < V; ++x) HGrid[y * V + x] = Layout->Landscape(-Ext + x * Step, -Ext + y * Step, false) - 0.35f;
	});
	TArray<FVector> Pos; TArray<FVector> Nrm; TArray<FVector2D> UV; TArray<FLinearColor> Col; TArray<int32> Tri; TArray<FProcMeshTangent> Tan;
	TArray<FVector2D> UV1, UV2, UV3; // textured mode: grass cover / rock weights
	auto H = [&](int32 x, int32 y) { return HGrid[FMath::Clamp(y, 0, V - 1) * V + FMath::Clamp(x, 0, V - 1)]; };
	for (int32 y = 0; y < V; ++y)
		for (int32 x = 0; x < V; ++x)
		{
			float X = -Ext + x * Step, Y = -Ext + y * Step;
			const float Z = H(x, y);
			Pos.Add(FVector(X * M2CM, Y * M2CM, Z * M2CM));
			const float HX = H(x + 1, y) - H(x - 1, y), HY = H(x, y + 1) - H(x, y - 1);
			const FVector Nn = FVector(-HX, -HY, 2 * Step).GetSafeNormal();
			Nrm.Add(Nn);
			UV.Add(FVector2D(X / 4.f, Y / 4.f));
			const float Slope = 1.f - Nn.Z;
			const float F = RWNoise2(X / 80.f, Y / 80.f, 5) * 0.5f + 0.5f;
			FLinearColor C = FMath::Lerp(FLinearColor(0.03f, 0.06f, 0.018f), FLinearColor(0.07f, 0.08f, 0.03f), F);
			C = FMath::Lerp(C, FLinearColor(0.12f, 0.11f, 0.10f), FMath::Clamp(Slope * 4.f - 0.4f, 0.f, 1.f));
			if (Z < WaterZ) C = FLinearColor(0.15f, 0.12f, 0.08f);
			C.A = 0.f;
			if (bPBR)
			{
				// distant hills: forest floor under the woods, weathered rock on steep slopes, mud by the river
				// grass and forest floor give way to bare rock above the tree line (about 340 to 460 m)
				const float Rk = FMath::Max(FMath::Clamp(Slope * 4.f - 0.4f, 0.f, 1.f), SStepT(340.f, 460.f, Z + 60.f * (F - 0.5f)));
				const float Md = Z < WaterZ ? 1.f : 0.f;
				C = FLinearColor((1.f - Rk) * (1.f - Md), 0.f, 0.f, Md * 0.9f);
				UV1.Add(FVector2D(Md, (1.f - Rk) * (1.f - Md) * (0.6f + 0.4f * F)));
				UV2.Add(FVector2D(0.f, Rk * (1.f - Md)));
				UV3.Add(FVector2D::ZeroVector);
				Tan.Add(FProcMeshTangent((FVector(1, 0, 0) - Nn * Nn.X).GetSafeNormal(), false));
			}
			Col.Add(C);
		}
	for (int32 y = 0; y < V - 1; ++y)
		for (int32 x = 0; x < V - 1; ++x)
		{
			const float CXm = -Ext + (x + 0.5f) * Step, CYm = -Ext + (y + 0.5f) * Step;
			if (FMath::Abs(CXm) < Hole && FMath::Abs(CYm) < Hole) continue;
			const int32 A = y * V + x, B = A + 1, C = A + V, D = C + 1;
			Tri.Add(A); Tri.Add(C); Tri.Add(D); Tri.Add(A); Tri.Add(D); Tri.Add(B);
		}
	if (bPBR) Backdrop->CreateMeshSection_LinearColor(0, Pos, Tri, Nrm, UV, UV1, UV2, UV3, Col, Tan, false, false);
	else Backdrop->CreateMeshSection_LinearColor(0, Pos, Tri, Nrm, UV, Col, Tan, false);
	Backdrop->SetMaterial(0, TerrainMat);
}

// ---------------- persistence ----------------

void ARWTerrain::SaveTo(TArray<uint8>& Out) const
{
	// the ground nobody has touched comes back from the map generator: only the changed chunks are saved
	TArray<uint8> Raw;
	FMemoryWriter W(Raw);
	int32 Ver = 2, NN = N, Count = 0;
	for (int32 C = 0; C < NumChunks * NumChunks; ++C) if (ChunkEdited.Num() && ChunkEdited[C]) ++Count;
	W << Ver << NN << Count;
	const int32 Side = ChunkCells + 1;
	for (int32 C = 0; C < NumChunks * NumChunks; ++C)
	{
		if (!ChunkEdited.Num() || !ChunkEdited[C]) continue;
		int32 Id = C;
		W << Id;
		const int32 X0 = (C % NumChunks) * ChunkCells, Y0 = (C / NumChunks) * ChunkCells;
		for (int32 y = 0; y < Side; ++y)
		{
			const int32 i = Idx(X0, Y0 + y);
			W.Serialize((void*)(Base.GetData() + i), sizeof(float) * Side);
			W.Serialize((void*)(Natural.GetData() + i), sizeof(float) * Side);
			W.Serialize((void*)(Layers.GetData() + i), sizeof(FLayers) * Side);
			W.Serialize((void*)(BaseComp.GetData() + i), Side);
			W.Serialize((void*)(Moist.GetData() + i), Side);
			W.Serialize((void*)(Grass.GetData() + i), Side);
		}
	}
	int32 CompSize = FCompression::CompressMemoryBound(NAME_LZ4, Raw.Num());
	TArray<uint8> Comp; Comp.SetNumUninitialized(CompSize);
	if (!FCompression::CompressMemory(NAME_LZ4, Comp.GetData(), CompSize, Raw.GetData(), Raw.Num()))
	{
		CompSize = Raw.Num(); Comp = Raw;
	}
	Comp.SetNum(CompSize);
	FMemoryWriter OW(Out);
	int32 RawSize = Raw.Num();
	OW << RawSize << CompSize;
	OW.Serialize(Comp.GetData(), CompSize);
}

void ARWTerrain::ResetEditedChunks()
{
	// back to what the generator made, in every chunk changed since the start
	const int32 Side = ChunkCells + 1;
	for (int32 C = 0; C < NumChunks * NumChunks; ++C)
	{
		if (!ChunkEdited.Num() || !ChunkEdited[C]) continue;
		const int32 X0 = (C % NumChunks) * ChunkCells, Y0 = (C / NumChunks) * ChunkCells;
		for (int32 y = 0; y < Side; ++y)
			for (int32 x = 0; x < Side; ++x)
			{
				const int32 Gx = X0 + x, Gy = Y0 + y;
				if (!Valid(Gx, Gy)) continue;
				const int32 i = Idx(Gx, Gy);
				Base[i] = Natural[i];
				if (const FGenPoint* G = GenPoints.Find(i)) { Layers[i] = G->L; BaseComp[i] = G->BaseC; Grass[i] = G->G; }
				else { Layers[i] = FLayers(); BaseComp[i] = 175; Grass[i] = (uint8)(Layout->InitGrass(PX(Gx), PX(Gy)) * 255.f); }
				Moist[i] = (uint8)(Layout->InitMoisture(PX(Gx), PX(Gy), Natural[i]) * 255.f);
				Recalc(i);
			}
		Chunks[C].bDirty = true;
		ChunkEdited[C] = false;
	}
}

bool ARWTerrain::LoadFrom(const TArray<uint8>& In)
{
	FMemoryReader R(In);
	int32 RawSize = 0, CompSize = 0;
	R << RawSize << CompSize;
	if (RawSize <= 0 || CompSize <= 0 || CompSize > In.Num()) return false;
	TArray<uint8> Comp; Comp.SetNumUninitialized(CompSize);
	R.Serialize(Comp.GetData(), CompSize);
	TArray<uint8> Raw; Raw.SetNumUninitialized(RawSize);
	if (CompSize == RawSize) Raw = Comp;
	else if (!FCompression::UncompressMemory(NAME_LZ4, Raw.GetData(), RawSize, Comp.GetData(), CompSize)) return false;
	FMemoryReader RR(Raw);
	int32 Ver = 0, NN = 0, Count = 0;
	RR << Ver << NN << Count;
	if (Ver != 2 || NN != N || Count < 0 || Count > NumChunks * NumChunks) return false;
	ResetEditedChunks();
	const int32 Side = ChunkCells + 1;
	for (int32 k = 0; k < Count; ++k)
	{
		int32 C = 0;
		RR << C;
		if (C < 0 || C >= NumChunks * NumChunks) return false;
		const int32 X0 = (C % NumChunks) * ChunkCells, Y0 = (C / NumChunks) * ChunkCells;
		for (int32 y = 0; y < Side; ++y)
		{
			const int32 i = Idx(X0, Y0 + y);
			RR.Serialize(Base.GetData() + i, sizeof(float) * Side);
			RR.Serialize(Natural.GetData() + i, sizeof(float) * Side);
			RR.Serialize(Layers.GetData() + i, sizeof(FLayers) * Side);
			RR.Serialize(BaseComp.GetData() + i, Side);
			RR.Serialize(Moist.GetData() + i, Side);
			RR.Serialize(Grass.GetData() + i, Side);
			for (int32 x = 0; x < Side; ++x) Recalc(i + x);
		}
		ChunkEdited[C] = true;
		Chunks[C].bDirty = true;
	}
	ActiveList.Reset();
	ActiveFlag.Init(false, N * N);
	// the settling queue is not in the save: ground still settling when it was saved (a pile just pushed up, a fresh cut)
	// went into the game standing as it was, out of the queue, and stayed standing too steep for good. The loose soil of the
	// loaded (worked) chunks that still stands steeper than its angle of repose - a pile just pushed up, spill, a fresh dump -
	// goes back into the queue; packed fill and the natural ground stay as they were saved, the same rule as
	// SettleAround (queued as well, cut banks of natural ground slumped and swelled on every load).
	for (int32 C = 0; C < NumChunks * NumChunks; ++C)
	{
		if (!ChunkEdited[C]) continue;
		const int32 X0 = (C % NumChunks) * ChunkCells, Y0 = (C / NumChunks) * ChunkCells;
		for (int32 y = 0; y <= ChunkCells; ++y)
			for (int32 x = 0; x <= ChunkCells; ++x)
			{
				if (!Valid(X0 + x, Y0 + y)) continue;
				const int32 Gx = X0 + x, Gy = Y0 + y;
				if (Gx < 1 || Gy < 1 || Gx >= N - 1 || Gy >= N - 1) continue;
				const int32 i = Idx(Gx, Gy);
				const FLayers& L = Layers[i];
				if (L.Count == 0 || L.Comp[L.Count - 1] >= 150 || ActiveFlag[i]) continue;
				// (only what Relax would move: steeper to a neighbour than its own angle of repose, the same test as Relax)
				const float Jit = (RWHash01((uint32)i * 747796405U + 2891336453U) - 0.5f) * 7.f;
				const float TanR = FMath::Tan(FMath::DegreesToRadians(FMath::Clamp(SurfaceState(i).Repose + Jit, 5.f, 80.f)));
				static const int32 DX[8] = {1, -1, 0, 0, 1, 1, -1, -1};
				static const int32 DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
				bool bSteep = false;
				for (int32 k = 0; k < 8 && !bSteep; ++k)
					bSteep = Height[i] - Height[Idx(Gx + DX[k], Gy + DY[k])] - TanR * (k < 4 ? CS : CS * 1.41421f) > 0.004f;
				if (bSteep) { ActiveFlag[i] = true; ActiveList.Add(i); }
			}
	}
	return true;
}

double ARWTerrain::LooseBook() const
{
	// Material present above (positive) or removed below (negative) the natural ground, in loose-equivalent m3.
	double Sum = 0;
	for (int32 i = 0; i < Layers.Num(); ++i)
	{
		const FLayers& L = Layers[i];
		for (int32 k = 0; k < L.Count; ++k) Sum += L.T[k] * CellArea * (1.0 + SoilProps((ESoil)L.Mat[k]).Swell * (L.Comp[k] / 255.0));
	}
	return Sum;
}

uint32 ARWTerrain::Checksum() const
{
	uint32 C = FCrc::MemCrc32(Height.GetData(), Height.Num() * sizeof(float));
	C = FCrc::MemCrc32(Moist.GetData(), Moist.Num(), C);
	return C;
}
