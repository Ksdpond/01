// Game framework: game mode (world setup, economy, save/load, self tests), player controller
// (rebindable keyboard/mouse controls, cameras, menus, screenshot), on-foot pawn and HUD.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/HUD.h"
#include "GameFramework/Pawn.h"
#include "RWLayout.h"
#include "RWJobs.h"
#include "RWGame.generated.h"

class ARWTerrain;
class ARWEffects;
class ARWWorld;
class ARWMachine;
class USpringArmComponent;
class UCameraComponent;

UCLASS()
class ROADWORKS_API ARWWalker : public APawn
{
	GENERATED_BODY()
public:
	ARWWalker();
	virtual void Tick(float Dt) override;
	void Init(ARWTerrain* T, const FVector& PosM, float Yaw);
	FVector PosM = FVector::ZeroVector;
	float Yaw = 0, CamPitch = -12, CamDist = 4.5f, Walk = 0;
	float InFwd = 0, InRight = 0; bool bRun = false; bool bFirst = false;
	UPROPERTY() USceneComponent* Root = nullptr;
	UPROPERTY() USceneComponent* BodyP = nullptr;
	UPROPERTY() USpringArmComponent* Arm = nullptr;
	UPROPERTY() UCameraComponent* Cam = nullptr;
	UPROPERTY() UCameraComponent* EyeCam = nullptr;
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() TArray<USceneComponent*> Legs;
	UPROPERTY() USceneComponent* ArmR = nullptr;   // right arm holding the shovel
	UPROPERTY() USceneComponent* ArmL = nullptr;
	UPROPERTY() UStaticMeshComponent* ShovelLoad = nullptr;
	bool bScripted = false;   // position driven by an animation (climbing into a cab)
	float Crouch = 0.f;       // 0 standing .. 1 kneeling / climbing pose
	float ShovelSwing = 0.f;  // shovel animation 0..1
	bool bClimbing = false;
	void BuildBody();
};

UCLASS()
class ROADWORKS_API ARWGameMode : public AGameModeBase
{
	GENERATED_BODY()
public:
	ARWGameMode();
	virtual void StartPlay() override;
	virtual void Tick(float Dt) override;

	FRWLayout Layout;
	FRWJobs Jobs;
	FRWEconomy Eco;
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() ARWEffects* Fx = nullptr;
	UPROPERTY() class ARWWater* Water = nullptr;
	// grade guide: a coloured ribbon over the active job showing cut (red/orange), on grade (green), fill (blue)
	UPROPERTY() class UProceduralMeshComponent* GuideMesh = nullptr;
	bool bGuide = true;
	float GuideTimer = 0.f;
	float GuideCut = 0.f, GuideFill = 0.f, GuideOnGrade = 0.f; // m3 still to cut / fill, share of samples on grade
	int32 GuideJob = -1;
	void UpdateGradeGuide(bool bForce);
	float AirTempC() const; // simple weather model: warm afternoons, cooler nights and rain
	// screenshot scenes (-RWScene=empty|half|full|dump): the model excavator really digs with its controls,
	// a camera watches the bucket, and the screenshot waits until the scene is ready
	FString Scene;
	bool bSceneReady = false;
	int32 ScenePhase = 0;
	float SceneT = 0.f, ScenePT = 0.f;
	double SceneBook0 = 0.0;
	bool SceneMarkSet = false; FVector SceneMarkP = FVector::ZeroVector;
	float SceneDumpLoad = 0.f;
	UPROPERTY() class ARWExcavator* SceneEx = nullptr;
	UPROPERTY() class ACameraActor* SceneCam = nullptr;
	void TickScene(float Dt);
	void TickCulvertScene(float Dt); // -RWScene=culvert: a pond draining through a pipe into a ditch
	void TickPipeScene(float Dt);    // -RWScene=pipe: pipes laid in a trench and one on the chain
	FVector CulvertSceneP = FVector::ZeroVector;
	UPROPERTY() UMaterialInterface* ClassicTerrainMat = nullptr; // vertex-colour ground (Low / Medium, or a mod's terrain_material)
	UPROPERTY() UMaterialInterface* PBRTerrainMat = nullptr;     // textured soil (High / Epic)
	bool bModTerrainMat = false;
	float WaterSourceTimer = 0.f;
	void UpdateWaterSources();
	// soil never closes the open end of a pipe: the ground there is held at the pipe's floor, what lands on it is moved aside
	float PipeMouthTimer = 0.f;
	void KeepPipeMouthsOpen();
	UPROPERTY() TArray<UStaticMeshComponent*> PipeMouthDark; // the dark of the buried pipe, seen through its open end
	void TickBuryScene(float Dt); // -RWScene=bury: a pipe with a heap of soil tipped over it
	void TickVistaScene(float Dt); // -RWScene=vista -RWCamAt=X,Y,HeightOverGround,Yaw,Pitch: a look at the landscape from anywhere
	UPROPERTY() ARWWorld* World = nullptr;
	UPROPERTY() TArray<ARWMachine*> Machines;
	// a machine's name in the level (RW_Machine): its model (or class), '#', and how many of the same came before it
	FString MachineKey(const ARWMachine* M) const;
	int32 ExportWait = -1; // frames left before -RWExportPlants / -RWExportScenery write (the machines settle on the ground first)
	UPROPERTY() ARWWalker* Walker = nullptr;
	bool bReady = false;
	int32 LastDay = 1;
	float MarkerTimer = 0.f;
	FString LastMessage; float MessageTime = 0.f;
	FVector CamM = FVector::ZeroVector;

	// settings
	int32 Quality = 2;       // 0 low .. 3 epic
	int32 ResScale = 100;    // screen percentage
	bool bLumen = true, bVSM = true;
	float Volume = 1.f;
	void ApplyGraphics();

	void Message(const FString& M);
	ARWMachine* SpawnMachine(UClass* C, int32 Size, float X, float Y, float Yaw, bool bOwned);
	ARWMachine* NearestMachine(const FVector& P, float MaxD) const;
	const FRWZone* ZoneAt(const FVector& P, ERWZone Type) const;
	bool NearRiver(const FVector& P) const;

	// facilities
	void Refuel(ARWMachine* M);
	void Repair(ARWMachine* M);
	void RentOrReturn(ARWMachine* M);
	void Buy(ARWMachine* M);
	void Upgrade(ARWMachine* M, int32 Which);
	void BuyMaterial(ARWMachine* M, ESoil Mat);
	void BuyPlot(int32 i);
	void SubmitJob(int32 i);

	bool SaveGame(const FString& Slot);
	bool LoadGame(const FString& Slot);
	void UpdateMarkers();
	void RunSelfTests();
	static ARWGameMode* Get(const UObject* WorldContext);
};

enum class ERWTrans : uint8 { None, Walk, In, Out };
enum class ERWMenu : uint8 { None, Main, Jobs, Shop, Plant, Settings, Controls, Map, Help, Mods, Inspect, Achievements, Title };

UCLASS()
class ROADWORKS_API ARWPlayerController : public APlayerController
{
	GENERATED_BODY()
public:
	ARWPlayerController();
	virtual void BeginPlay() override;
	virtual void PlayerTick(float Dt) override;

	// key bindings
	struct FAction { FName Name; FString Label; FKey Key; FKey Default; FKey Pad; FKey PadDefault; FKey Alt; }; // Alt = optional second keyboard / mouse key
	int32 RebindSlot = 0; // 0 main key, 1 second key
	// keys a player can bind (real keys and buttons only - never the virtual "Any Key" or analog axes)
	static bool IsBindableKey(const FKey& K);
	// binds K to an action slot and returns the other actions already using that key ("" if none)
	FString ApplyRebind(int32 Action, int32 Slot, const FKey& K);
	FString KeyUsers(const FKey& K, int32 Except) const;
	void ResetBinds();
	TArray<FAction> Actions;
	bool Down(FName A) const;
	bool Pressed(FName A) const;
	void LoadBinds();
	void SaveBinds();
	int32 Rebinding = -1;

	ERWMenu Menu = ERWMenu::None;
	int32 Sel = 0;
	bool bSurvey = false;
	bool bShowHelp = true;
	int32 HudMode = 0;          // 0 full, 1 minimal (one slim line), 2 nothing but messages (F4 cycles)
	bool bMenuFromTitle = false; // a page opened from the start screen goes back to it
	UPROPERTY() class ACameraActor* TitleCam = nullptr;
	float TitleT = 0.f;
	UPROPERTY() ARWMachine* Driving = nullptr;
	void EnterMachine(ARWMachine* M);
	void ExitMachine();
	// straight from one machine to another, without getting out (only those the player owns or rents)
	void SwitchMachine(int32 Dir);
	static ARWMachine* NextOperable(const TArray<ARWMachine*>& List, const ARWMachine* From, int32 Dir);
	void SetCab(bool bCab);
	TArray<FString> MenuItems() const;
	void MenuActivate(int32 Index, int32 Dir);
	ARWMachine* ContextMachine() const;

	// screenshot mode
	FString ShotPath;
	int32 ShotFrames = -1;
	int32 FrameCount = 0;
	bool CaptureViewport(const FString& Path);
	void OnShot(int32 W, int32 H, const TArray<FColor>& Colors);
	bool bShotDone = false;
	int32 ShotRequestedAt = -1;

	// ---- climbing in / out through each machine's door (RWPlayer.cpp) ----
	ERWTrans Trans = ERWTrans::None;
	float TransT = 0.f;
	UPROPERTY() ARWMachine* TransM = nullptr;
	FVector TransA = FVector::ZeroVector, TransB = FVector::ZeroVector;
	void BeginEnter(ARWMachine* M);
	void BeginExit();
	bool StepTransition(float Dt); // true while an animation is playing

	// ---- gamepad, vibration, sensitivity ----
	float MouseSens = 1.f, PadSens = 1.f;
	bool bInvertY = false, bVibration = true;
	float NavCooldown = 0.f;
	int32 RumbleHandle = 0;
	float BumpRumble = 0.f;
	float PadAxis(const FKey& K) const;
	void UpdateRumble(float Dt);
	bool PadNav(int32& OutUp, int32& OutSide, bool& bSelect, bool& bBack, float Dt);

	// ---- on-foot activities ----
	FPayload ShovelLoad;
	float ShovelTimer = 0.f, ServiceTimer = 0.f;
	UPROPERTY() ARWMachine* ServiceM = nullptr;
	int32 ServiceKind = 0;
	void FootActivities(float Dt);
	void StartService(ARWMachine* M, int32 Kind);
	ARWMachine* InspectTarget() const;

	// ---- map editor (F8, on foot) ----
	bool bEditMode = false;
	int32 EditItem = 0;
	float EditYaw = 0.f, EditScale = 1.f, EditBrush = 3.f;
	FVector EditCursor = FVector::ZeroVector;
	bool bEditCursorValid = false;
	UPROPERTY() USceneComponent* EditGhost = nullptr;
	int32 EditGhostItem = -1;
	void EditorTick(float Dt);
	void SetEditMode(bool bOn);
};

UCLASS()
class ROADWORKS_API ARWHUD : public AHUD
{
	GENERATED_BODY()
public:
	virtual void DrawHUD() override;
	UPROPERTY() UTexture2D* MapTex = nullptr;
	float MapTimer = 0.f;
private:
	float S = 1.f;
	void Panel(float X, float Y, float W, float H, FLinearColor C = FLinearColor(0.01f, 0.012f, 0.015f, 0.62f));
	void Txt(const FString& T, float X, float Y, FLinearColor C = FLinearColor::White, float Scale = 1.f, bool bBig = false);
	void Bar(float X, float Y, float W, float H, float F, FLinearColor C);
	void Gauge(float CX, float CY, float R, float F, const FString& Label, const FString& Value, FLinearColor C);
	void DrawMachine(class ARWGameMode* GM, class ARWPlayerController* PC, ARWMachine* M);
	void DrawMenu(class ARWGameMode* GM, class ARWPlayerController* PC);
	void DrawTitle(class ARWGameMode* GM, class ARWPlayerController* PC);
	void DrawMachineSlim(class ARWGameMode* GM, ARWMachine* M);
	void DrawMap(class ARWGameMode* GM, class ARWPlayerController* PC);
	void UpdateMapTexture(class ARWGameMode* GM);
	void DrawInspect(class ARWGameMode* GM, class ARWPlayerController* PC);
	void DrawEditor(class ARWGameMode* GM, class ARWPlayerController* PC);
};
