// Surface water: a shallow-water ("virtual pipes") simulation on the terrain's own 0.5 m grid.
// Water flows from a higher water surface to a lower one, fills dug channels and pits, overflows
// when they are full, soaks into the soil (wetting it), picks up mud where it runs fast over bare
// soil, and drains into the river / groundwater below the water table. Only 16 m tiles that hold
// moving water are simulated; dry and settled tiles sleep. Digging wakes the water around it.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RWTypes.h"
#include "RWWater.generated.h"

class ARWTerrain;
class UProceduralMeshComponent;
class UMaterialInterface;

UCLASS()
class ROADWORKS_API ARWWater : public AActor
{
	GENERATED_BODY()
public:
	ARWWater();
	void Init(ARWTerrain* InTerrain, UMaterialInterface* InMat);
	virtual void Tick(float Dt) override;

	// one simulation step (seconds); Tick runs fixed 1/40 s steps
	void Step(float Dt);
	// pour water (m3) onto the ground at a world point (metres)
	void AddWater(float X, float Y, float Vol, float MudLevel = 0.f);
	// the terrain changed at point i: let the water there react
	void WakeAt(int32 i);
	float DepthAt(float X, float Y) const;
	float MudAt(float X, float Y) const;
	double StandingVolume() const; // m3 of surface water above the water table
	int32 ActiveTiles() const { return Active.Num(); }
	int32 VisibleTiles() const;
	void UpdateRender(bool bAll);
	static float Permeability(ESoil M); // infiltration rate into dry soil, m/s

	struct FSource { FVector2D P; float Rate = 0.03f; }; // m3/s
	TArray<FSource> Sources;
	// culverts / drain pipes buried in an embankment: water runs from the higher end to the lower one.
	// Inverts = height of the pipe floor at each end (m). Q / Vel / FlowDepth are the last solved values.
	struct FCulvert
	{
		FVector2D In, Out;
		float InZ = 0.f, OutZ = 0.f, Diameter = 0.6f, Manning = 0.024f; // corrugated plastic
		float Q = 0.f, Vel = 0.f, FlowDepth = 0.f;
		bool bKeepMouth = false; // a built culvert's ends stay clear of soil; a pipe a machine laid can be buried entirely
	};
	TArray<FCulvert> Culverts;
	// discharge (m3/s) through a pipe: the smaller of inlet control (weir when the inlet is part-full, orifice when
	// it is drowned) and barrel friction (Manning, part-full circular section); head/inverts in metres
	static float PipeFlow(float Diameter, float Manning, float Length, float InvUp, float InvDown, float HeadUp, float HeadDown, float* OutVel = nullptr, float* OutDepth = nullptr);
	UPROPERTY() class ARWEffects* Fx = nullptr; // splash at pipe outlets
	double PipeMoved = 0; // m3 carried through pipes so far
	float RainRate = 0.f; // m/s of water falling on the ground around the camera
	FVector CamM = FVector::ZeroVector;
	bool bEnabled = true;
	double Added = 0, Soaked = 0, Drained = 0; // bookkeeping (m3) for tests and the HUD
	double TickMs = 0; // cost of the last Tick (for the performance log)

	static constexpr int32 TS = 32; // tile size in grid points (16 m)
	TArray<float> W, Mud;           // water depth (m) and muddiness (0 clear .. 1 thick mud) per terrain point

private:
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() UMaterialInterface* Mat = nullptr;
	UPROPERTY() TMap<int32, UProceduralMeshComponent*> Meshes;
	TArray<float> F;            // outflow per point towards +X, -X, +Y, -Y (m3/s)
	TArray<float> WNew, MudNew; // double buffers for the parallel update
	TArray<float> Soak;         // soil moisture gained but not yet written to the terrain
	TArray<uint8> TileOn, TileDirty, TileWet;
	TArray<float> TileIdle, TileChange;
	TArray<int32> Active;
	int32 NT = 0;
	float Acc = 0.f, RenderT = 0.f, SleepT = 0.f, RainT = 0.f, SplashT = 0.f;
	void StepCulverts(float Dt);

	int32 TileOf(int32 i) const;
	void Activate(int32 Tile);
	bool IsReservoir(int32 i) const;
	void SoakCell(int32 i, float Dt);
	void BuildTile(int32 Tile);
};
