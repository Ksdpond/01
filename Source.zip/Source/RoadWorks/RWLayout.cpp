#include "RWLayout.h"
#include "Async/ParallelFor.h"
#include "Algo/Reverse.h"
#include "Misc/ConfigCacheIni.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/Compression.h"
#include "Serialization/MemoryReader.h"
#include "Serialization/MemoryWriter.h"

static float SStep(float A, float B, float X)
{
	const float T = FMath::Clamp((X - A) / (B - A), 0.f, 1.f);
	return T * T * (3 - 2 * T);
}

// Things beyond the middle of the map are spread out over the bigger map; the middle (the work areas) stays where it is.
static FVector2D Stretch(const FVector2D& P)
{
	const float R = FMath::Max(FMath::Abs(P.X), FMath::Abs(P.Y));
	if (R <= 300.f) return P;
	return P * ((300.f + (R - 300.f) * 2.25f) / R);
}

void FRWLayout::Init()
{
	WaterZ = 0.f;
	// the seed and the shape of the mountains: same values, same map
	{
		const TCHAR* Sec = TEXT("RoadWorks.Map");
		auto Cfg = [&](const TCHAR* Key, float& V) { if (GConfig) GConfig->GetFloat(Sec, Key, V, GGameIni); };
		if (GConfig) GConfig->GetInt(Sec, TEXT("Seed"), Params.Seed, GGameIni);
		Cfg(TEXT("FootCrest"), Params.FootCrest); Cfg(TEXT("FootHeight"), Params.FootHeight);
		Cfg(TEXT("MainCrest"), Params.MainCrest); Cfg(TEXT("MainHeight"), Params.MainHeight);
		Cfg(TEXT("HighCrest"), Params.HighCrest); Cfg(TEXT("HighHeight"), Params.HighHeight);
		Cfg(TEXT("RangeWander"), Params.RangeWander); Cfg(TEXT("Ceiling"), Params.Ceiling); Cfg(TEXT("TreeLine"), Params.TreeLine);
	}
	// what was sculpted in the Unreal Editor
	SculptN = 0; Sculpt.Reset();
	if (!bIgnoreSculpt)
	{
		const int32 SculptSize = 4033;
		TArray<float> Delta;
		if (ReadSculptFile(Params.Seed, Delta, SculptSize))
		{
			int32 Big = 0;
			for (int32 i = 0; i < Delta.Num(); ++i) if (FMath::Abs(Delta[i]) > FMath::Abs(Delta[Big])) Big = i;
			SculptPeak = FVector2D(-MapHalf + (Big % SculptSize) * 2.f * MapHalf / (SculptSize - 1), -MapHalf + (Big / SculptSize) * 2.f * MapHalf / (SculptSize - 1));
			SculptPeakH = Delta[Big];
			SetSculpt(MoveTemp(Delta), SculptSize);
			RWLog(FString::Printf(TEXT("Map: sculpted changes from the Unreal Editor added to the ground, largest %.1f m at %.0f, %.0f"), SculptPeakH, SculptPeak.X, SculptPeak.Y));
		}
	}
	Zones.Reset();
	auto Add = [&](const TCHAR* Name, ERWZone T, float X, float Y, float HX, float HY, float Blend = 12.f)
	{
		FRWZone Z; Z.Name = Name; Z.Type = T; Z.C = FVector2D(X, Y); Z.HalfExt = FVector2D(HX, HY); Z.Blend = Blend;
		Zones.Add(Z);
	};
	Add(TEXT("Machine Yard"), ERWZone::Depot, -170, -165, 36, 28);
	Add(TEXT("Material Plant"), ERWZone::Plant, -60, -200, 34, 26);
	Add(TEXT("Construction Site"), ERWZone::Site, 40, -60, 60, 48, 18);
	Add(TEXT("Village"), ERWZone::Village, -190, -25, 40, 30);
	Add(TEXT("Stone Quarry"), ERWZone::Quarry, 170, 172, 52, 44, 20);
	Add(TEXT("Sand Pit"), ERWZone::SandPit, 178, -172, 42, 36, 16);
	Add(TEXT("Mud Flats"), ERWZone::MudFlat, -95, 22, 30, 18, 10);
	Add(TEXT("North Forest"), ERWZone::Forest, -140, 165, 100, 75, 10);
	Add(TEXT("Spoil Dump"), ERWZone::DumpSite, 118, 28, 22, 18, 8);
	Add(TEXT("Hill Knoll"), ERWZone::Knoll, 30, 30, 18, 18, 14);
	Add(TEXT("Land Plot East"), ERWZone::Plot, 200, -60, 30, 30, 6);
	Add(TEXT("Land Plot West"), ERWZone::Plot, -230, -200, 22, 30, 6);
	// the wide valley floor: flat ground for big construction jobs
	Add(TEXT("East Works"), ERWZone::Flat, 820, -330, 120, 85, 110);
	Add(TEXT("West Works"), ERWZone::Flat, -830, -360, 110, 90, 110);
	Add(TEXT("North Works"), ERWZone::Flat, -360, 560, 120, 80, 110);
	Add(TEXT("Valley Works"), ERWZone::Flat, 300, 640, 100, 75, 110);
	// villages further out along the valley
	Add(TEXT("Ban Na"), ERWZone::Village, 1065, -60, 45, 34, 18);
	Add(TEXT("Ban Khao"), ERWZone::Village, -1065, -700, 40, 34, 24);
	// the big open-pit mine in the foothills
	Add(TEXT("Open Pit Mine"), ERWZone::Mine, 860, 520, 280, 240, 150);
	Lakes.Reset();
	auto Lake = [&](float X, float Y, float R, bool bHigh)
	{
		FRWLake L; L.C = bHigh ? FVector2D(X, Y) : Stretch(FVector2D(X, Y)); L.R = R; L.Z = 0.f;
		// (a lake up in the hills lies somewhat below the ground around it, with its own water level, not at the bottom of a crater)
		const float Around = 0.25f * (Landscape(L.C.X + R, L.C.Y, false) + Landscape(L.C.X - R, L.C.Y, false) + Landscape(L.C.X, L.C.Y + R, false) + Landscape(L.C.X, L.C.Y - R, false));
		if (Around > 16.f) L.Z = Around - 12.f;
		Lakes.Add(L);
	};
	Lake(-390.f, -380.f, 62.f, false);
	Lake(250.f, -860.f, 74.f, false);
	Lake(-720.f, 330.f, 170.f, true); // the big lake of the valley
	Lake(620.f, -640.f, 110.f, true);
	Lake(-1250.f, 760.f, 62.f, true);
	Lake(300.f, 1050.f, 55.f, true);
	if (LevelLakes.Num()) Lakes = LevelLakes; // (the level's own: moved, resized or added in the editor)

	// limestone hills, standing clear of the work areas, the river and the rice fields
	Towers.Reset();
	// (the separate cone-shaped hills are gone: the ranges in RWMountainRange make the mountains now. Set this true to bring them back.)
	const bool bConeHills = false;
	if (bConeHills)
	{
		FRandomStream Rs(9091);
		for (int32 k = 0; k < 900 && Towers.Num() < 96; ++k)
		{
			const float A = Rs.FRand() * 2.f * PI;
			const float D = FMath::Lerp(340.f, 3600.f, FMath::Square(Rs.FRand()));
			const FVector2D C(FMath::Cos(A) * D, FMath::Sin(A) * D);
			const float Edge = FMath::Max(FMath::Abs(C.X), FMath::Abs(C.Y));
			if (Edge < 330.f || RiverDist(C.X, C.Y) < 130.f || LakeShoreDist(C.X, C.Y) < 110.f || FMath::Abs(C.Y + 118.f) < 90.f) continue;
			bool bClear = true;
			for (const FRWZone& Z : Zones) if (InZone(Z, C.X, C.Y, 100.f)) bClear = false;
			for (const FRWTower& O : Towers) if (FVector2D::Distance(O.C, C) < O.R + 90.f) bClear = false;
			if (!bClear) continue;
			FRWTower T; T.C = C;
			T.R = Rs.FRandRange(42.f, 88.f);
			T.H = T.R * Rs.FRandRange(1.1f, 1.9f) * (Edge < 1030.f ? 1.f : 1.5f);
			Towers.Add(T);
		}
	}
	// streams are cut into the bare landscape first: the work areas then flatten on top of the result
	Streams.Reset(); StreamGridD.Reset(); StreamGridZ.Reset();
	BuildStreams();

	// Flatten heights from the bare landscape at each zone centre.
	for (FRWZone& Z : Zones) Z.Z = Landscape(Z.C.X, Z.C.Y, false);
	for (FRWZone& Z : Zones)
	{
		if (Z.Type == ERWZone::SandPit) Z.Z -= 3.0f;
		if (Z.Type == ERWZone::MudFlat) Z.Z = 1.1f;
		if (Z.Type == ERWZone::Quarry) Z.Z += 3.0f;
		if (Z.Type == ERWZone::Site) Z.Z = FMath::Max(Z.Z, 3.f);
		if (Z.Type == ERWZone::Flat || Z.Type == ERWZone::Mine)
		{
			// the mean of the ground around it, so that it sits into the slope instead of standing up out of it
			float Sum = Z.Z;
			for (const float Sx : {-1.f, 0.f, 1.f}) for (const float Sy : {-1.f, 0.f, 1.f}) Sum += Landscape(Z.C.X + Sx * Z.HalfExt.X, Z.C.Y + Sy * Z.HalfExt.Y, false);
			Z.Z = FMath::Max(Sum / 10.f, 3.f);
			if (Z.Type == ERWZone::Mine)
			{
				// the rim follows the lowest side, so the pit is cut down into the ground and stands up nowhere
				float Low = 1e9f;
				for (int32 a = 0; a < 16; ++a) { const float An = a / 16.f * 2.f * PI; Low = FMath::Min(Low, Landscape(Z.C.X + FMath::Cos(An) * Z.HalfExt.X, Z.C.Y + FMath::Sin(An) * Z.HalfExt.Y, false)); }
				Z.Z = FMath::Max(Low, 3.f);
			}
		}
	}

	Roads.Reset();
	auto RoadPts = [&](const TCHAR* Name, bool bAsphalt, float HW, const TArray<FVector2D>& P, float MaxGrade = 0.f)
	{
		FRWRoad R; R.Name = Name; R.bAsphalt = bAsphalt; R.HalfW = HW; R.Pts = P; R.MaxGrade = MaxGrade;
		if (const TArray<FVector2D>* InLevel = LevelRoads.Find(Name)) if (InLevel->Num() >= 2) R.Pts = *InLevel; // the line drawn in the level
		Densify(R);
		// meets the road it starts from at that road's height
		float J = 0.f, La = 0.f;
		if (R.Pts.Num() > 2 && RoadAt(R.Pts[0].X, R.Pts[0].Y, J, La))
			for (int32 i = 0; i < FMath::Min(R.Pts.Num(), 40); ++i) R.Z[i] = FMath::Lerp(J, R.Z[i], FMath::Clamp(i / 39.f, 0.f, 1.f));
		Roads.Add(R);
	};
	auto Road = [&](const TCHAR* Name, bool bAsphalt, float HW, std::initializer_list<FVector2D> P) { RoadPts(Name, bAsphalt, HW, TArray<FVector2D>(P)); };
	Road(TEXT("Highway 7"), true, 4.0f, {{-2244, -118}, {-1960, -108}, {-1640, -122}, {-1320, -112}, {-1036, -120}, {-940, -112}, {-840, -118}, {-720, -110}, {-620, -116}, {-524, -106}, {-440, -116}, {-350, -112}, {-262, -112}, {-200, -114}, {-140, -116}, {-60, -122}, {0, -114}, {60, -120}, {140, -128}, {262, -124}, {350, -118}, {440, -130}, {524, -122}, {640, -118}, {740, -126}, {860, -116}, {950, -124}, {1036, -118}, {1340, -110}, {1660, -124}, {1980, -112}, {2244, -120}});
	Road(TEXT("Yard Access"), true, 3.5f, {{-170, -116}, {-170, -140}});
	Road(TEXT("Plant Access"), true, 3.5f, {{-60, -122}, {-60, -176}});
	Road(TEXT("Village Road"), true, 3.2f, {{-195, -114}, {-195, -60}, {-190, -30}});
	Road(TEXT("Sand Pit Track"), false, 3.5f, {{146, -128}, {160, -142}, {168, -150}});
	Road(TEXT("Quarry Haul Road"), false, 4.0f, {{62, -120}, {82, -70}, {92, -10}, {96, 60}, {100, 100}, {122, 128}, {148, 146}});
	Road(TEXT("Dump Track"), false, 3.0f, {{93, 10}, {112, 22}});
	Road(TEXT("Village Lane"), false, 2.6f, {{-190, -30}, {-150, 0}, {-110, 15}});
	Road(TEXT("Ban Na Road"), true, 3.2f, {{1065, -119}, {1065, -92}});
	{
		auto Far = [](std::initializer_list<FVector2D> P) { TArray<FVector2D> O; for (const FVector2D& V : P) O.Add(Stretch(V)); return O; };
		RoadPts(TEXT("South Loop"), false, 3.6f, Far({{232, -125}, {244, -300}, {206, -520}, {-100, -640}, {-300, -690}, {-520, -650}, {-640, -560}, {-640, -456}}));
		RoadPts(TEXT("South East Track"), false, 3.0f, Far({{206, -520}, {360, -600}, {440, -640}}));
		RoadPts(TEXT("North Forest Track"), false, 3.4f, Far({{148, 146}, {226, 270}, {214, 420}, {150, 620}, {176, 820}}));
	}
	// ---- the mountain roads: each leg planned over the ground, climbing no steeper than a loaded truck can ----
	{
		// waypoints in turn; the route between them winds to keep to the grade, and a long haul road follows the shoulder of the hill
		auto Mountain = [&](const TCHAR* Name, float HW, float Grade, const TArray<FVector2D>& Way)
		{
			// (a road the level already has is laid where the level has it: no need to plan it)
			if (const TArray<FVector2D>* InLevel = LevelRoads.Find(Name)) if (InLevel->Num() >= 2) { RoadPts(Name, false, HW, *InLevel, Grade + 0.02f); return; }
			TArray<FVector2D> All;
			for (int32 w = 0; w + 1 < Way.Num(); ++w)
			{
				TArray<FVector2D> Leg = PlanRoute(Way[w], Way[w + 1], Grade);
				if (All.Num()) Leg.RemoveAt(0);
				All.Append(Leg);
			}
			if (All.Num() >= 3) RoadPts(Name, false, HW, All, Grade + 0.02f);
		};
		const FVector2D Haul0(148, 146);
		const FRWZone* Mi = Find(ERWZone::Mine);
		const FVector2D MineGate = Mi ? Mi->C + FVector2D(-Mi->HalfExt.X - 18.f, 0.f) : FVector2D(560, 520);
		Mountain(TEXT("Mine Haul Road"), 5.f, 0.09f, {Haul0, MineGate});
		// up on the foothill ridge, along its crest
		const FVector2D R2 = CrestAt(0.f, 900.f, 1500.f) / 0.88f * 0.9f; // (bearing 0: well clear of the pit and its walls)
		Mountain(TEXT("East Ridge Road"), 3.5f, 0.11f, {MineGate, R2 * 0.88f, FVector2D(1065, -119)}); // (on the shoulder of the ridge: the crest itself is too sharp here)
		// over the shoulder of the main range to the north
		const FVector2D NEnd = Stretch(FVector2D(176, 820));
		const FVector2D N2 = CrestAt(120.f, 1000.f, 1500.f);
		Mountain(TEXT("North Ridge Road"), 3.5f, 0.11f, {NEnd, N2, FVector2D(-360, 660)});
		// south: from the loop road up on to the foothill ridge and back down to the highway
		const FVector2D S0 = Stretch(FVector2D(-300, -690));
		const FVector2D S2 = CrestAt(-140.f, 900.f, 1500.f);
		Mountain(TEXT("South Ridge Road"), 3.5f, 0.11f, {S0, S2, FVector2D(-1320, -113)});
		// spiral down the benches into the pit
		if (Mi)
		{
			TArray<FVector2D> Spiral;
			Spiral.Add(MineGate);
			const int32 NS = 34;
			for (int32 k = 0; k <= NS; ++k)
			{
				const float T = k / float(NS), A = PI + T * 2.75f * PI, Rr = FMath::Lerp(0.96f, 0.3f, T);
				Spiral.Add(Mi->C + FVector2D(FMath::Cos(A) * Mi->HalfExt.X * Rr, FMath::Sin(A) * Mi->HalfExt.Y * Rr));
			}
			RoadPts(TEXT("Pit Ramp"), false, 5.f, Spiral, 0.1f);
		}
	}

	// which cells have a road nearby (the widest road plus the reach of any road query)
	RoadMask.Init(false, RoadMaskN * RoadMaskN);
	for (const FRWRoad& R : Roads)
		for (const FVector2D& P : R.Pts)
		{
			const float Reach = R.HalfW + 26.f;
			const int32 X0 = FMath::Clamp(FMath::FloorToInt((P.X - Reach + RoadMaskHalf) / RoadMaskCell), 0, RoadMaskN - 1), X1 = FMath::Clamp(FMath::CeilToInt((P.X + Reach + RoadMaskHalf) / RoadMaskCell), 0, RoadMaskN - 1);
			const int32 Y0 = FMath::Clamp(FMath::FloorToInt((P.Y - Reach + RoadMaskHalf) / RoadMaskCell), 0, RoadMaskN - 1), Y1 = FMath::Clamp(FMath::CeilToInt((P.Y + Reach + RoadMaskHalf) / RoadMaskCell), 0, RoadMaskN - 1);
			for (int32 y = Y0; y <= Y1; ++y) for (int32 x = X0; x <= X1; ++x) RoadMask[y * RoadMaskN + x] = true;
		}

	PotholeA = FVector2D(95, -122);
	PotholeB = FVector2D(125, -125);
}

void FRWLayout::Densify(FRWRoad& R)
{
	TArray<FVector2D> D;
	for (int32 i = 0; i + 1 < R.Pts.Num(); ++i)
	{
		const FVector2D A = R.Pts[i], B = R.Pts[i + 1];
		const int32 Steps = FMath::Max(1, FMath::CeilToInt(FVector2D::Distance(A, B) / 2.f));
		for (int32 s = 0; s < Steps; ++s)
		{
			// Catmull-Rom smoothing through control points
			const float T = s / float(Steps);
			const FVector2D P0 = R.Pts[FMath::Max(i - 1, 0)], P3 = R.Pts[FMath::Min(i + 2, R.Pts.Num() - 1)];
			const float T2 = T * T, T3 = T2 * T;
			D.Add(0.5f * ((2 * A) + (-P0 + B) * T + (2 * P0 - 5 * A + 4 * B - P3) * T2 + (-P0 + 3 * A - 3 * B + P3) * T3));
		}
	}
	D.Add(R.Pts.Last());
	R.Pts = D;
	// Height profile: natural ground smoothed over +-30 m, kept above water.
	TArray<float> Raw;
	for (const FVector2D& P : R.Pts) Raw.Add(NaturalHeight(P.X, P.Y));
	R.Z.SetNum(Raw.Num());
	for (int32 i = 0; i < Raw.Num(); ++i)
	{
		float S = 0, W = 0;
		for (int32 k = -15; k <= 15; ++k)
		{
			const int32 j = FMath::Clamp(i + k, 0, Raw.Num() - 1);
			const float Wk = 1.f - FMath::Abs(k) / 16.f;
			S += Raw[j] * Wk; W += Wk;
		}
		R.Z[i] = FMath::Max(S / W, WaterZ + 1.6f);
	}
	if (R.MaxGrade > 0.f)
	{
		LimitGrade(R.Z, R.Pts, R.MaxGrade);
		float Len = 0.f, Steep = 0.f, Off = 0.f, OffRaw = 0.f, OffZ = 0.f;
		FVector2D OffAt = FVector2D::ZeroVector;
		for (int32 i = 1; i < R.Z.Num(); ++i)
		{
			const float Ds = FVector2D::Distance(R.Pts[i], R.Pts[i - 1]);
			Len += Ds;
			Steep = FMath::Max(Steep, FMath::Abs(R.Z[i] - R.Z[i - 1]) / FMath::Max(Ds, 0.1f));
			if (FMath::Abs(R.Z[i] - Raw[i]) > Off) { Off = FMath::Abs(R.Z[i] - Raw[i]); OffAt = R.Pts[i]; OffRaw = Raw[i]; OffZ = R.Z[i]; }
		}
		RWLog(FString::Printf(TEXT("Road %s: %.0f m long, climbs from %.0f to %.0f m, steepest %.1f%%, up to %.1f m from the ground (at %.0f, %.0f: ground %.0f, road %.0f)"), *R.Name, Len, R.Z[0], R.Z.Last(), Steep * 100.f, Off, OffAt.X, OffAt.Y, OffRaw, OffZ));
	}
}

void FRWLayout::LimitGrade(TArray<float>& Z, const TArray<FVector2D>& Pts, float MaxGrade)
{
	// the highest profile that stays under the ground and the lowest that stays over it, both within the grade:
	// half way between them there is about as much to cut as to fill
	const int32 N = Z.Num();
	TArray<float> Lo = Z, Hi = Z;
	for (int32 i = 1; i < N; ++i)
	{
		const float Ds = FVector2D::Distance(Pts[i], Pts[i - 1]) * MaxGrade;
		Lo[i] = FMath::Min(Lo[i], Lo[i - 1] + Ds); Hi[i] = FMath::Max(Hi[i], Hi[i - 1] - Ds);
	}
	for (int32 i = N - 2; i >= 0; --i)
	{
		const float Ds = FVector2D::Distance(Pts[i], Pts[i + 1]) * MaxGrade;
		Lo[i] = FMath::Min(Lo[i], Lo[i + 1] + Ds); Hi[i] = FMath::Max(Hi[i], Hi[i + 1] - Ds);
	}
	for (int32 i = 0; i < N; ++i) Z[i] = 0.5f * (Lo[i] + Hi[i]);
}

FVector2D FRWLayout::CrestAt(float BearingDeg, float RMin, float RMax) const
{
	const FVector2D Dir(FMath::Cos(FMath::DegreesToRadians(BearingDeg)), FMath::Sin(FMath::DegreesToRadians(BearingDeg)));
	FVector2D Best = Dir * RMin; float BestZ = -1e9f;
	for (float R = RMin; R <= RMax; R += 15.f)
	{
		const FVector2D P = Dir * R;
		if (FMath::Abs(P.X) > MapHalf - 30.f || FMath::Abs(P.Y) > MapHalf - 30.f) break;
		const float Z = Landscape(P.X, P.Y, false);
		if (Z > BestZ) { BestZ = Z; Best = P; }
	}
	return Best;
}

TArray<FVector2D> FRWLayout::PlanRoute(const FVector2D& From, const FVector2D& To, float MaxGrade, bool bWater) const
{
	// a search over a 12 m grid. A step costs its length, and much more the further it climbs over the wanted grade or the
	// steeper the hillside it has to be cut across, so that the cheapest way up a slope is a road that winds along it.
	const float Cell = 12.f, Org = -MapHalf;
	const int32 G = FMath::FloorToInt(2.f * MapHalf / Cell) + 1;
	TArray<float> H; H.SetNumUninitialized(G * G);
	ParallelFor(G, [&](int32 y) { for (int32 x = 0; x < G; ++x) H[y * G + x] = Landscape(Org + x * Cell, Org + y * Cell, false); });
	auto ToG = [&](const FVector2D& P) { return FIntPoint(FMath::Clamp(FMath::RoundToInt((P.X - Org) / Cell), 1, G - 2), FMath::Clamp(FMath::RoundToInt((P.Y - Org) / Cell), 1, G - 2)); };
	const FIntPoint A = ToG(From), B = ToG(To);
	static const FIntPoint Steps[16] = {{2,0},{2,1},{1,1},{1,2},{0,2},{-1,2},{-1,1},{-2,1},{-2,0},{-2,-1},{-1,-1},{-1,-2},{0,-2},{1,-2},{1,-1},{2,-1}}; // in order round the compass
	// each state is a cell and the direction it was entered in: a road cannot turn on the spot, so a climb has to be a real
	// long run along the slope with a proper curve at its end, not a zigzag from cell to cell (which is a straight line up the hill)
	const int32 Ns = G * G * 16;
	const FRWZone* MineZ = Find(ERWZone::Mine);
	TArray<float> Cost; Cost.Init(1e30f, Ns);
	TArray<int32> Came; Came.Init(-1, Ns);
	struct FOpen { float F; int32 I; bool operator<(const FOpen& O) const { return F < O.F; } };
	TArray<FOpen> Open;
	const int32 Start = A.Y * G + A.X, Goal = B.Y * G + B.X;
	for (int32 d = 0; d < 16; ++d) { Cost[Start * 16 + d] = 0.f; Open.HeapPush({0.f, Start * 16 + d}); }
	int32 Found = -1;
	while (Open.Num())
	{
		FOpen Cur; Open.HeapPop(Cur, EAllowShrinking::No);
		const int32 Cell0 = Cur.I / 16, Dir = Cur.I % 16;
		if (Cell0 == Goal) { Found = Cur.I; break; }
		const int32 Cx = Cell0 % G, Cy = Cell0 / G;
		if (Cx < 3 || Cy < 3 || Cx >= G - 3 || Cy >= G - 3) continue;
		const float Hc = H[Cell0], Gc = Cost[Cur.I];
		if (Cur.F > Gc + Cell * FVector2D::Distance(FVector2D(Cx, Cy), FVector2D(B.X, B.Y)) + 1.f) continue; // stale entry
		const float Side = FVector2D((H[Cell0 + 1] - H[Cell0 - 1]) / (2.f * Cell), (H[Cell0 + G] - H[Cell0 - G]) / (2.f * Cell)).Size();
		for (int32 Turn = -2; Turn <= 2; ++Turn)
		{
			// (up to 45 degrees at each step of about 24 m: a curve of some 30 m radius)
			const int32 Nd = (Dir + Turn + 16) % 16;
			const FIntPoint& St = Steps[Nd];
			const int32 Nx = Cx + St.X, Ny = Cy + St.Y, Nc = Ny * G + Nx, Ni = Nc * 16 + Nd;
			const float Len = Cell * FMath::Sqrt((float)(St.X * St.X + St.Y * St.Y));
			const float Grade = FMath::Abs(H[Nc] - Hc) / Len;
			float C = Len * (1.f + 0.25f * FMath::Abs(Turn));
			if (bWater)
			{
				// every metre it would have to climb is a metre to cut through a ridge
				const float Rise = FMath::Max(0.f, H[Nc] - Hc);
				const float Ng2 = Gc + Len + 30.f * Rise;
				if (Ng2 < Cost[Ni])
				{
					Cost[Ni] = Ng2; Came[Ni] = Cur.I;
					Open.HeapPush({(float)(Ng2 + Cell * FVector2D::Distance(FVector2D(Nx, Ny), FVector2D(B.X, B.Y))), Ni});
				}
				continue;
			}
			if (Grade > MaxGrade) C *= 1.f + 40.f * FMath::Square(Grade / MaxGrade - 1.f);
			// cutting across a steep hillside moves a lot of earth
			C *= 1.f + 1.6f * FMath::Max(0.f, Side - 0.35f);
			const float Wx = Org + Nx * Cell, Wy = Org + Ny * Cell;
			if (H[Nc] < WaterZ + 1.f) C += 200.f;                        // the river: only where it has to
			if (LakeShoreDist(Wx, Wy) < 25.f) C += 600.f;                // round a lake
			if (MineZ)
			{
				// never down into the pit (its own ramp does that), and well clear of the top of its walls
				const float Rho = FVector2D((Wx - MineZ->C.X) / MineZ->HalfExt.X, (Wy - MineZ->C.Y) / MineZ->HalfExt.Y).Size();
				if (Rho < 0.97f) continue;
				if (Rho < 1.4f && FVector2D::Distance(FVector2D(Wx, Wy), From) > 110.f && FVector2D::Distance(FVector2D(Wx, Wy), To) > 110.f) continue;
				if (Rho < 1.8f) C += 150.f * (1.8f - Rho);
			}
			if (StreamGridD.Num() && StreamDist(Wx, Wy) < 8.f) C += 40.f;
			const float Ng = Gc + C;
			if (Ng < Cost[Ni])
			{
				Cost[Ni] = Ng; Came[Ni] = Cur.I;
				Open.HeapPush({(float)(Ng + Cell * FVector2D::Distance(FVector2D(Nx, Ny), FVector2D(B.X, B.Y))), Ni});
			}
		}
	}
	TArray<FVector2D> Path;
	Path.Add(To);
	int32 At = Found >= 0 ? Came[Found] : -1;
	while (At >= 0)
	{
		const int32 Ce = At / 16;
		if (Ce == Start) break;
		Path.Add(FVector2D(Org + (Ce % G) * Cell, Org + (Ce / G) * Cell));
		At = Came[At];
	}
	Path.Add(From);
	Algo::Reverse(Path);
	return Path;
}

FString FRWLayout::SculptFile()
{
	return FPaths::ProjectContentDir() / TEXT("MapData/terrain_delta.bin");
}

// The sculpt file to read. The packaged game carries a copy from when it was packaged; started from the project's own folders
// (the launcher gives it -RWMods=<project>/Mods) it takes the project's file instead when that one is newer, so what was just
// sculpted in the Unreal Editor is in the game without packaging it again.
static FString SculptFileToRead()
{
	const FString Own = FRWLayout::SculptFile();
	if (GIsEditor) return Own;
	FString ModsDir;
	if (!FParse::Value(FCommandLine::Get(), TEXT("RWMods="), ModsDir)) return Own;
	const FString Project = FPaths::ConvertRelativePathToFull(FPaths::GetPath(ModsDir.TrimQuotes()) / TEXT("Content/MapData/terrain_delta.bin"));
	IFileManager& FM = IFileManager::Get();
	if (!FM.FileExists(*Project)) return Own;
	if (FM.FileExists(*Own) && FM.GetTimeStamp(*Own) >= FM.GetTimeStamp(*Project)) return Own;
	RWLog(FString::Printf(TEXT("Map: the project's sculpted ground (%s) is newer than the packaged one: using it"), *Project));
	return Project;
}

bool FRWLayout::ReadSculptFile(int32 Seed, TArray<float>& OutDelta, int32 Size)
{
	TArray<uint8> Bytes;
	if (!FFileHelper::LoadFileToArray(Bytes, *SculptFileToRead(), FILEREAD_Silent)) return false;
	FMemoryReader R(Bytes);
	int32 Magic = 0, FileSeed = 0, FileSize = 0, RawSize = 0, CompSize = 0;
	R << Magic << FileSeed << FileSize << RawSize << CompSize;
	if (Magic != 0x52575343 || FileSize != Size || RawSize != Size * Size * (int32)sizeof(int16) || CompSize <= 0) return false;
	if (FileSeed != Seed) { RWLog(TEXT("Map: the sculpted changes belong to another seed: not used")); return false; }
	TArray<uint8> Comp; Comp.SetNumUninitialized(CompSize);
	R.Serialize(Comp.GetData(), CompSize);
	TArray<int16> Cm; Cm.SetNumUninitialized(Size * Size);
	if (!FCompression::UncompressMemory(NAME_LZ4, Cm.GetData(), RawSize, Comp.GetData(), CompSize)) return false;
	OutDelta.SetNumUninitialized(Cm.Num());
	for (int32 i = 0; i < Cm.Num(); ++i) OutDelta[i] = Cm[i] * 0.01f;
	return true;
}

bool FRWLayout::WriteSculptFile(int32 Seed, const TArray<float>& Delta, int32 Size)
{
	if (Delta.Num() != Size * Size) return false;
	TArray<int16> Cm; Cm.SetNumUninitialized(Delta.Num());
	for (int32 i = 0; i < Delta.Num(); ++i) Cm[i] = (int16)FMath::Clamp(FMath::RoundToInt(Delta[i] * 100.f), -32767, 32767);
	int32 RawSize = Cm.Num() * sizeof(int16);
	int32 CompSize = FCompression::CompressMemoryBound(NAME_LZ4, RawSize);
	TArray<uint8> Comp; Comp.SetNumUninitialized(CompSize);
	if (!FCompression::CompressMemory(NAME_LZ4, Comp.GetData(), CompSize, Cm.GetData(), RawSize)) return false;
	TArray<uint8> Out;
	FMemoryWriter W(Out);
	int32 Magic = 0x52575343, S = Seed, Sz = Size;
	W << Magic << S << Sz << RawSize << CompSize;
	W.Serialize(Comp.GetData(), CompSize);
	return FFileHelper::SaveArrayToFile(Out, *SculptFile());
}

void FRWLayout::SetSculpt(TArray<float>&& Delta, int32 Size)
{
	Sculpt = MoveTemp(Delta);
	SculptN = Sculpt.Num() == Size * Size ? Size : 0;
}

float FRWLayout::SculptAt(float X, float Y) const
{
	if (SculptN <= 0) return 0.f;
	const float Sc = (SculptN - 1) / (2.f * MapHalf);
	const float Fx = FMath::Clamp((X + MapHalf) * Sc, 0.f, SculptN - 1.001f), Fy = FMath::Clamp((Y + MapHalf) * Sc, 0.f, SculptN - 1.001f);
	const int32 Ix = (int32)Fx, Iy = (int32)Fy;
	const float Ax = Fx - Ix, Ay = Fy - Iy;
	const float* D = Sculpt.GetData() + Iy * SculptN + Ix;
	return FMath::Lerp(FMath::Lerp(D[0], D[1], Ax), FMath::Lerp(D[SculptN], D[SculptN + 1], Ax), Ay);
}

const FRWZone* FRWLayout::Find(ERWZone T, int32 Nth) const
{
	for (const FRWZone& Z : Zones) if (Z.Type == T && Nth-- == 0) return &Z;
	return nullptr;
}

const FRWZone* FRWLayout::FindByName(const FString& Name) const
{
	for (const FRWZone& Z : Zones) if (Z.Name == Name) return &Z;
	return nullptr;
}

float FRWLayout::ZoneWeight(const FRWZone& Z, float X, float Y)
{
	const float DX = FMath::Abs(X - Z.C.X) - Z.HalfExt.X;
	const float DY = FMath::Abs(Y - Z.C.Y) - Z.HalfExt.Y;
	const float D = FMath::Max(DX, DY);
	return 1.f - SStep(0.f, Z.Blend, D);
}

bool FRWLayout::InZone(const FRWZone& Z, float X, float Y, float Margin)
{
	return FMath::Abs(X - Z.C.X) <= Z.HalfExt.X + Margin && FMath::Abs(Y - Z.C.Y) <= Z.HalfExt.Y + Margin;
}

float FRWLayout::RiverY(float X) const
{
	return 70.f + 30.f * FMath::Sin(X / 70.f) + 6.f * FMath::Sin(X / 23.f + 1.3f);
}

float FRWLayout::StreamDist(float X, float Y) const
{
	if (StreamGridD.Num() == 0) return 1e4f;
	const float Fx = FMath::Clamp((X + StreamGridHalf) / StreamGridCell, 0.f, StreamGridN - 1.001f), Fy = FMath::Clamp((Y + StreamGridHalf) / StreamGridCell, 0.f, StreamGridN - 1.001f);
	const int32 Ix = (int32)Fx, Iy = (int32)Fy;
	const float Ax = Fx - Ix, Ay = Fy - Iy;
	const float* D = StreamGridD.GetData() + Iy * StreamGridN + Ix;
	return FMath::Lerp(FMath::Lerp(D[0], D[1], Ax), FMath::Lerp(D[StreamGridN], D[StreamGridN + 1], Ax), Ay);
}

float FRWLayout::StreamBed(float X, float Y) const
{
	if (StreamGridZ.Num() == 0) return 0.f;
	const float Fx = FMath::Clamp((X + StreamGridHalf) / StreamGridCell, 0.f, StreamGridN - 1.001f), Fy = FMath::Clamp((Y + StreamGridHalf) / StreamGridCell, 0.f, StreamGridN - 1.001f);
	const int32 Ix = (int32)Fx, Iy = (int32)Fy;
	const float Ax = Fx - Ix, Ay = Fy - Iy;
	const float* Z = StreamGridZ.GetData() + Iy * StreamGridN + Ix;
	return FMath::Lerp(FMath::Lerp(Z[0], Z[1], Ax), FMath::Lerp(Z[StreamGridN], Z[StreamGridN + 1], Ax), Ay);
}

float FRWLayout::TowerAt(float X, float Y) const
{
	float Best = 0.f;
	for (const FRWTower& T : Towers)
	{
		const float Dx = X - T.C.X, Dy = Y - T.C.Y, Reach = T.R * 1.3f;
		if (FMath::Abs(Dx) > Reach || FMath::Abs(Dy) > Reach) continue;
		// a lobed outline, nearly sheer faces and a rounded top
		const float Lobed = FMath::Sqrt(Dx * Dx + Dy * Dy) * (1.f + 0.22f * RWFbm(X / 34.f, Y / 34.f, 2, 101));
		Best = FMath::Max(Best, 1.f - SStep(0.6f, 1.f, Lobed / T.R));
	}
	return Best;
}

void FRWLayout::PaddyField(const FRWZone& Z, float X, float Y, float& OutLevel, float& OutBund)
{
	const float Fx = (X - (Z.C.X - Z.HalfExt.X)) / PaddyFieldX, Fy = (Y - (Z.C.Y - Z.HalfExt.Y)) / PaddyFieldY;
	const float Ix = FMath::FloorToFloat(Fx), Iy = FMath::FloorToFloat(Fy);
	const float Ax = Fx - Ix, Ay = Fy - Iy;
	const float Edge = FMath::Min(FMath::Min(Ax, 1.f - Ax) * PaddyFieldX, FMath::Min(Ay, 1.f - Ay) * PaddyFieldY);
	OutLevel = Z.Z + 0.32f * RWNoise2(Ix * 1.7f + Z.C.X * 0.01f, Iy * 2.3f + Z.C.Y * 0.01f, 77); // each field its own terrace
	OutBund = 1.f - SStep(0.35f, 0.95f, Edge);
}

void FRWLayout::BuildStreams()
{
	struct FDef { float HalfW; std::initializer_list<FVector2D> P; };
	// head of the stream first, then down to where it meets the river or the lake
	const FDef Defs[] = {
		{2.6f, {{60, 960}, {-30, 820}, {40, 680}, {-50, 580}, {-20, 470}, {-48, 400}, {-18, 320}, {-34, 240}, {-8, 170}, {-22, 112}, {-14, 88}}},
		{2.2f, {{-900, 640}, {-760, 540}, {-620, 470}, {-470, 330}, {-400, 300}, {-360, 230}, {-320, 170}, {-300, 120}, {-286, 96}}},
		{2.4f, {{700, 920}, {560, 760}, {470, 600}, {410, 470}, {360, 390}, {380, 310}, {330, 240}, {312, 150}, {300, 100}, {296, 72}}},
		{2.0f, {{960, 520}, {800, 420}, {660, 320}, {560, 220}, {462, 140}, {432, 96}, {418, 72}}},
		{2.2f, {{-960, -220}, {-760, -280}, {-620, -300}, {-488, -310}, {-440, -330}, {-420, -340}}},
		{1.8f, {{-250, -470}, {-290, -430}, {-330, -420}, {-348, -400}}},
		{2.2f, {{940, -960}, {720, -980}, {560, -900}, {400, -880}, {330, -870}}},
		{2.0f, {{-340, -980}, {-100, -990}, {60, -940}, {170, -890}}},
		{2.0f, {{-720, 980}, {-560, 860}, {-420, 700}, {-260, 560}, {-150, 480}, {-62, 440}}},
	};
	for (const FDef& Df : Defs)
	{
		// from the head down to the mouth by the low ground, not through the ridges in between
		TArray<FVector2D> Given; for (const FVector2D& V : Df.P) Given.Add(Stretch(V));
		TArray<FVector2D> Ctrl = Given.Num() >= 2 ? PlanRoute(Given[0], Given.Last(), 1.f, true) : Given;
		// (the search works cell by cell: every third point is enough for the curve)
		{
			TArray<FVector2D> Thin;
			for (int32 i = 0; i < Ctrl.Num(); i += 3) Thin.Add(Ctrl[i]);
			if (Thin.Last() != Ctrl.Last()) Thin.Add(Ctrl.Last());
			Ctrl = Thin;
		}
		FRWStream S; S.HalfW = Df.HalfW;
		for (int32 i = 0; i + 1 < Ctrl.Num(); ++i)
		{
			const FVector2D A = Ctrl[i], B = Ctrl[i + 1];
			const FVector2D P0 = Ctrl[FMath::Max(i - 1, 0)], P3 = Ctrl[FMath::Min(i + 2, Ctrl.Num() - 1)];
			const int32 Steps = FMath::Max(1, FMath::CeilToInt(FVector2D::Distance(A, B) / 3.f));
			for (int32 k = 0; k < Steps; ++k)
			{
				const float T = k / float(Steps), T2 = T * T, T3 = T2 * T;
				S.Pts.Add(0.5f * ((2 * A) + (-P0 + B) * T + (2 * P0 - 5 * A + 4 * B - P3) * T2 + (-P0 + 3 * A - 3 * B + P3) * T3));
			}
		}
		S.Pts.Add(Ctrl.Last());
		// meanders, none at the very ends (the mouth has to reach the river)
		const int32 Np = S.Pts.Num();
		TArray<FVector2D> Bent = S.Pts;
		for (int32 i = 1; i + 1 < Np; ++i)
		{
			const FVector2D Dir = (S.Pts[i + 1] - S.Pts[i - 1]).GetSafeNormal();
			const float Fade = FMath::Min(1.f, FMath::Min(i, Np - 1 - i) / 12.f);
			Bent[i] = S.Pts[i] + FVector2D(-Dir.Y, Dir.X) * Fade * (5.f * RWNoise2(i * 0.05f, Df.HalfW, 113) + 2.f * RWNoise2(i * 0.17f, Df.HalfW, 117));
		}
		S.Pts = Bent;
		// the bed follows the ground but only ever falls on the way down, and is sunk into it
		S.Bed.SetNum(Np);
		float Prev = 1e6f;
		for (int32 i = 0; i < Np; ++i)
		{
			const float G = Landscape(S.Pts[i].X, S.Pts[i].Y, false) - 1.1f; // (no stream grid yet: this is the bare ground)
			Prev = FMath::Min(Prev - 0.004f, G);
			S.Bed[i] = FMath::Max(Prev, WaterZ - 0.45f);
		}
		TArray<float> Sm = S.Bed;
		for (int32 i = 0; i < Np; ++i)
		{
			float Sum = 0.f, Wt = 0.f;
			for (int32 k = -6; k <= 6; ++k) { const float W = 7.f - FMath::Abs(k); Sum += S.Bed[FMath::Clamp(i + k, 0, Np - 1)] * W; Wt += W; }
			Sm[i] = Sum / Wt;
		}
		S.Bed = Sm;
		Streams.Add(S);
	}
	// distance / bed grid
	TArray<float> D, Z;
	D.Init(1e4f, StreamGridN * StreamGridN); Z.Init(0.f, StreamGridN * StreamGridN);
	// (far enough for a valley to open out where a stream has to cut deep through a ridge)
	const float Reach = 260.f;
	for (const FRWStream& S : Streams)
		for (int32 i = 0; i + 3 < S.Pts.Num(); i += 3)
		{
			const FVector2D A = S.Pts[i], B = S.Pts[i + 3];
			const int32 X0 = FMath::Max(0, FMath::FloorToInt((FMath::Min(A.X, B.X) - Reach + StreamGridHalf) / StreamGridCell)), X1 = FMath::Min(StreamGridN - 1, FMath::CeilToInt((FMath::Max(A.X, B.X) + Reach + StreamGridHalf) / StreamGridCell));
			const int32 Y0 = FMath::Max(0, FMath::FloorToInt((FMath::Min(A.Y, B.Y) - Reach + StreamGridHalf) / StreamGridCell)), Y1 = FMath::Min(StreamGridN - 1, FMath::CeilToInt((FMath::Max(A.Y, B.Y) + Reach + StreamGridHalf) / StreamGridCell));
			const FVector2D AB = B - A; const float L2 = FMath::Max(AB.SizeSquared(), 1e-4f);
			for (int32 y = Y0; y <= Y1; ++y)
				for (int32 x = X0; x <= X1; ++x)
				{
					const FVector2D P(-StreamGridHalf + x * StreamGridCell, -StreamGridHalf + y * StreamGridCell);
					const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / L2, 0.f, 1.f);
					const float Dist = FVector2D::Distance(P, A + AB * T);
					const int32 k = y * StreamGridN + x;
					if (Dist < D[k]) { D[k] = Dist; Z[k] = FMath::Lerp(S.Bed[i], S.Bed[i + 3], T); }
				}
		}
	StreamGridD = MoveTemp(D); StreamGridZ = MoveTemp(Z);
}

float FRWLayout::LakeShoreDist(float X, float Y) const
{
	float Best = 1e6f;
	for (const FRWLake& L : Lakes) Best = FMath::Min(Best, FVector2D::Distance(FVector2D(X, Y), L.C) - L.R);
	return Best;
}

// A ridge with a broad rounded crest: 1 on the crest where the noise N crosses zero, 0 at |N| = 1. Width rounds the top off
// (an abs() here gives knife-edge crests, which is what made the old mountains look like saw teeth).
static float RWSoftRidge(float N, float Width)
{
	const float Top = FMath::Sqrt(1.f + Width * Width);
	return FMath::Clamp((Top - FMath::Sqrt(N * N + Width * Width)) / (Top - Width), 0.f, 1.f);
}

// A section across a range: long even slopes meeting in a broad rounded crest (not a flat-topped hump), a long rise on the
// inside and a shorter fall behind, so that no mountain is symmetrical. Crest width is a share of the slope's length.
static float RWRangeHump(float R, float Crest, float Inner, float Outer)
{
	const float D = (R - Crest) / (R < Crest ? Inner : Outer);
	if (FMath::Abs(D) >= 1.f) return 0.f;
	const float W = 0.14f, Top = FMath::Sqrt(1.f + W * W);
	const float Section = (Top - FMath::Sqrt(D * D + W * W)) / (Top - W);
	return Section * SStep(0.f, 0.3f, 1.f - FMath::Abs(D)); // and the slope flares out gently at its foot
}

// The mountains around the map: continuous ranges following the map's edge, not separate peaks.
static float RWMountainRange(float X, float Y, const FRWMapParams& P)
{
	const int32 Sd = P.Seed;
	// domain warping: the ranges wander, and nothing repeats
	const float Wx = X + P.RangeWander * RWFbm(X / 1100.f, Y / 1100.f, 2, 151 + Sd), Wy = Y + P.RangeWander * RWFbm(X / 1100.f + 37.f, Y / 1100.f - 11.f, 2, 153 + Sd);
	// distance out from the middle, with the square map's corners rounded
	const float Ax = FMath::Abs(Wx), Ay = FMath::Abs(Wy);
	const float R = FMath::Pow(FMath::Square(Ax * Ax) + FMath::Square(Ay * Ay), 0.25f);
	if (R < 240.f) return 0.f;
	const float A = FMath::Atan2(Wy, Wx), Ca = FMath::Cos(A), Sa = FMath::Sin(A);
	// how high each stretch of the range stands (sampled on a circle: no seam all the way round), high and low summits in turn
	const float Along = RWFbm(Ca * 2.4f, Sa * 2.4f, 2, 155 + Sd), Along2 = RWFbm(Ca * 5.5f + 3.f, Sa * 5.5f - 2.f, 2, 157 + Sd);
	// three ranges one behind the other: the foothill ridge at the edge of the map, the main range, the high range far behind
	const float H1 = P.FootHeight * RWRangeHump(R, P.FootCrest + 130.f * Along2, 800.f, 560.f) * (0.72f + 0.28f * Along2);
	const float H2 = P.MainHeight * RWRangeHump(R, P.MainCrest + 220.f * Along, 1250.f, 1100.f) * (0.76f + 0.34f * Along);
	const float H3 = P.HighHeight * RWRangeHump(R, P.HighCrest + 300.f * Along2, 1500.f, 1700.f) * (0.8f + 0.26f * Along2);
	const float Top = FMath::Max3(H1, H2, H3);
	const float Massif = Top + 0.22f * (H1 + H2 + H3 - Top); // valleys stay between the ranges, they do not fill in
	// the blend from the plain into the hills: long, low slopes at the foot
	const float Foot = 14.f * SStep(250.f, 820.f, R) * (1.f + 0.5f * RWFbm(Wx / 300.f, Wy / 300.f, 2, 159 + Sd));
	// weights of the three sizes of shape (70 / 23 / 7): they shape the height, they do not set it
	const float Low = 0.75f + 0.25f * RWFbm(Wx / 1400.f, Wy / 1400.f, 2, 161 + Sd);
	// spurs and gullies running down the slopes (the noise moves slowly outwards, quickly around), plus a wandering branch ridge
	const float Spur = RWSoftRidge(RWFbm(Ca * 13.f + R / 950.f, Sa * 13.f - R / 1350.f, 2, 163 + Sd), 0.2f);
	const float Branch = RWSoftRidge(RWFbm(Wx / 460.f, Wy / 460.f, 2, 165 + Sd), 0.26f);
	const float Medium = 0.62f * Spur + 0.38f * Branch;
	const float High = 0.5f + 0.5f * RWFbm(X / 130.f, Y / 130.f, 2, 167 + Sd);
	// (tuned from the first look: at a plain 23 % the spurs hardly showed, the hills read as smooth domes. The medium
	// shapes are stretched around their mean so that the slopes carry real gullies, while the 70/23/7 weights stay.)
	// (the foothills stay smooth, the gullies only open up as the ground rises: that is the blend into the slopes)
	const float Rugged = SStep(40.f, 320.f, Massif);
	float M = Massif * (0.70f * Low + 0.23f * (0.45f + 1.7f * Rugged * (Medium - 0.45f)) + 0.07f * High) * 1.45f;
	M = FMath::Max(M, 0.f);
	// a soft ceiling: the highest ground rounds over instead of running to a point
	const float Cap = P.Ceiling;
	M = Cap * (1.f - FMath::Exp(-M / Cap));
	// rock faces only in some places: a stretch of hillside steps up abruptly along a wandering line
	if (M > 60.f)
	{
		const float Rocky = SStep(0.22f, 0.5f, RWFbm(Wx / 640.f + 9.f, Wy / 640.f + 5.f, 2, 171 + Sd));
		if (Rocky > 0.f) M += Rocky * FMath::Min(1.f, (M - 60.f) / 120.f) * 16.f * SStep(-0.05f, 0.05f, RWFbm(Wx / 170.f, Wy / 170.f, 2, 173 + Sd));
	}
	return M + Foot;
}

float FRWLayout::Landscape(float X, float Y, bool bDetail) const
{
	// (the mountains themselves are RWMountainRange, above)
	float H = 6.f + 5.f * RWFbm(X / 110.f, Y / 110.f, 2, 11);
	const float Edge = FMath::Max(FMath::Abs(X), FMath::Abs(Y));
	// the rise behind the plain to the north: broad and low-frequency, it runs on into the range around the map
	const float North = SStep(120.f, 250.f, Y) * (30.f + 14.f * RWFbm(X / 170.f, Y / 170.f, 2, 23));
	H += North;
	if (Edge > 230.f)
	{
		H += RWMountainRange(X, Y, Params);
		// the highway keeps to a broad valley through the foothills
		if (Edge > 480.f)
		{
			const float Pass = (1.f - SStep(40.f, 190.f, FMath::Abs(Y + 118.f))) * SStep(480.f, 640.f, Edge) * (1.f - SStep(2400.f, 3000.f, Edge));
			if (Pass > 0.f) H = FMath::Lerp(H, FMath::Min(H, 10.f + 4.f * RWFbm(X / 90.f, Y / 90.f, 2, 143)), Pass);
		}
	}
	if (bDetail)
	{
		// Detail fades out at the playable border so the far backdrop mesh lines up.
		const float DW = 1.f - SStep(MapHalf - 22.f, MapHalf - 4.f, Edge);
		H += DW * (1.6f * RWFbm(X / 24.f, Y / 24.f, 3, 47) + 0.25f * RWFbm(X / 5.f, Y / 5.f, 2, 59) + SStep(120.f, 250.f, Y) * 3.f * RWFbm(X / 45.f, Y / 45.f, 2, 67));
	}
	// Streams: a small valley floor, then the channel itself down to the bed.
	if (StreamGridD.Num() && Edge < StreamGridHalf)
	{
		const float SD = StreamDist(X, Y);
		if (SD < 258.f)
		{
			const float Bed = StreamBed(X, Y);
			// a small valley floor; where the stream has cut deep through a ridge, its sides then rise at a slope a hillside can hold
			H = FMath::Min(H, Bed + 1.4f + 0.09f * FMath::Min(SD, 38.f) + 0.75f * FMath::Max(0.f, SD - 14.f) + 6.f * FMath::Max(0.f, SD - 160.f));
			if (SD < 40.f)
			{
				H = FMath::Lerp(FMath::Min(H, Bed + 1.4f + 0.09f * SD), H, SStep(6.f, 38.f, SD));
				H = FMath::Lerp(Bed, H, SStep(2.f, 5.5f, SD));
			}
		}
	}
	// The lakes: each sits in its own basin, the shore opening wider the deeper the basin has to be cut.
	for (const FRWLake& L : Lakes)
	{
		const float Dx = X - L.C.X, Dy = Y - L.C.Y;
		if (FMath::Abs(Dx) > L.R + 700.f || FMath::Abs(Dy) > L.R + 700.f) continue;
		const float LakeD = FMath::Sqrt(Dx * Dx + Dy * Dy) * (1.f + 0.12f * RWNoise2(X / 40.f, Y / 40.f, 141));
		if (LakeD < L.R + 700.f)
		{
			// (the slope opens out far from the lake, so that this never ends in a step)
			H = FMath::Min(H, L.Z + 1.2f + 0.05f * FMath::Max(0.f, LakeD - L.R) + 0.5f * FMath::Max(0.f, LakeD - L.R - 30.f) + 4.f * FMath::Max(0.f, LakeD - L.R - 400.f));
			H = FMath::Lerp(L.Z - 3.f, H, SStep(L.R - 14.f, L.R + 4.f, LakeD));
		}
	}
	// River valley and channel.
	const float RD = RiverDist(X, Y);
	const float Valley = SStep(9.f, 55.f + 0.25f * FMath::Max(0.f, Edge - 500.f), RD); // a wider valley where the hills are high
	H = FMath::Lerp(FMath::Min(H, 2.2f + RWFbm(X / 40.f, Y / 40.f, 2, 71)), H, Valley);
	const float Channel = SStep(4.f, 10.f, RD);
	H = FMath::Lerp(WaterZ - 2.4f, H, Channel);
	return H;
}

float FRWLayout::NaturalHeight(float X, float Y) const
{
	// (what was sculpted in the editor goes on at the end, over the zones: the editor measures it against this ground with its
	// zones, so a hill sculpted on the work site or in the yard is in the game as it is in the editor - added first, the
	// zones' levelling used to flatten it away again)
	float H = Landscape(X, Y, true);
	for (const FRWZone& Z : Zones)
	{
		const float W = ZoneWeight(Z, X, Y);
		if (W <= 0.f) continue;
		switch (Z.Type)
		{
		case ERWZone::Depot:
		case ERWZone::Plant:
		case ERWZone::Village:
		case ERWZone::DumpSite:
		case ERWZone::Plot:
			H = FMath::Lerp(H, Z.Z + 0.15f * RWFbm(X / 9.f, Y / 9.f, 2, 3), W);
			break;
		case ERWZone::Flat:
			H = FMath::Lerp(H, Z.Z + 0.25f * RWFbm(X / 14.f, Y / 14.f, 2, 3), W);
			break;
		case ERWZone::Mine:
		{
			// an open pit: benches stepping down in rings to a flat floor, the outline not quite an ellipse
			const FVector2D Dn((X - Z.C.X) / Z.HalfExt.X, (Y - Z.C.Y) / Z.HalfExt.Y);
			const float Rho = Dn.Size() * (1.f + 0.07f * RWFbm(X / 90.f, Y / 90.f, 2, 19));
			// (its own round edge instead of the zone's square one)
			const float WMine = 1.f - SStep(1.f, 1.f + Z.Blend / FMath::Max(Z.HalfExt.X, Z.HalfExt.Y), Rho);
			if (WMine <= 0.f) break;
			const int32 Benches = 6;
			const float BenchH = 12.f, T = FMath::Clamp((0.93f - Rho) / 0.93f * (Benches + 1.2f), 0.f, Benches + 0.f);
			const int32 K = FMath::FloorToInt(T);
			const float Level = -BenchH * (K + SStep(0.f, 0.26f, T - K)); // each bench: a rock face, then its flat
			H = FMath::Lerp(H, Z.Z + Level + 0.25f * RWFbm(X / 9.f, Y / 9.f, 2, 21), WMine);
			break;
		}
		case ERWZone::Site:
			H = FMath::Lerp(H, Z.Z + 0.9f * RWFbm(X / 18.f, Y / 18.f, 3, 5), W * 0.85f);
			break;
		case ERWZone::SandPit:
			H = FMath::Lerp(H, Z.Z + 1.2f * RWFbm(X / 14.f, Y / 14.f, 3, 7) + 2.5f * SStep(20.f, 40.f, FMath::Abs(X - Z.C.X)), W);
			break;
		case ERWZone::MudFlat:
			H = FMath::Lerp(H, Z.Z + 0.25f * RWFbm(X / 6.f, Y / 6.f, 2, 9), W);
			break;
		case ERWZone::Quarry:
		{
			// A rock hill with a bench cut into the south face and a flat working floor.
			const float D = FVector2D::Distance(FVector2D(X, Y), Z.C + FVector2D(10, 25));
			const float Hill = Z.Z + 22.f * (1.f - SStep(10.f, 60.f, D)) + 3.f * RWFbm(X / 12.f, Y / 12.f, 3, 13);
			const float Floor = Z.Z + 0.3f * RWFbm(X / 7.f, Y / 7.f, 2, 15);
			const float Bench = Z.Z + 7.f;
			const float FloorW = 1.f - SStep(-6.f, 4.f, (Y - (Z.C.Y - 5.f)));
			float Q = FMath::Lerp(Hill, Floor, FloorW);
			const float BenchW = (1.f - SStep(4.f, 9.f, Y - (Z.C.Y - 5.f))) * (1.f - FloorW);
			Q = FMath::Lerp(Q, FMath::Min(Q, Bench), BenchW);
			H = FMath::Lerp(H, FMath::Max(Q, Floor), W);
			break;
		}
		case ERWZone::Knoll:
		{
			const float D = FVector2D::Distance(FVector2D(X, Y), Z.C);
			H += 7.5f * (1.f - SStep(0.f, Z.HalfExt.X + 6.f, D)) * (1.f + 0.15f * RWFbm(X / 5.f, Y / 5.f, 2, 17));
			break;
		}
		case ERWZone::Paddy:
		{
			float Level = Z.Z, Bund = 0.f;
			PaddyField(Z, X, Y, Level, Bund);
			H = FMath::Lerp(H, Level + 0.42f * Bund, W);
			break;
		}
		default: break;
		}
	}
	return H + SculptAt(X, Y);
}

bool FRWLayout::RoadAt(float X, float Y, float& OutZ, float& OutLat, const FRWRoad** OutRoad, float Extra) const
{
	if (RoadMask.Num() > 0 && Extra <= 20.f)
	{
		const int32 Mx = FMath::RoundToInt((X + RoadMaskHalf) / RoadMaskCell), My = FMath::RoundToInt((Y + RoadMaskHalf) / RoadMaskCell);
		if (Mx < 0 || My < 0 || Mx >= RoadMaskN || My >= RoadMaskN || !RoadMask[My * RoadMaskN + Mx]) return false;
	}
	float Best = 1e9f;
	bool bHit = false;
	for (const FRWRoad& R : Roads)
	{
		for (int32 i = 0; i + 1 < R.Pts.Num(); ++i)
		{
			const FVector2D A = R.Pts[i], B = R.Pts[i + 1];
			const FVector2D AB = B - A;
			const float L2 = AB.SizeSquared();
			const float T = L2 > 0 ? FMath::Clamp(FVector2D::DotProduct(FVector2D(X, Y) - A, AB) / L2, 0.f, 1.f) : 0.f;
			const float D = FVector2D::Distance(FVector2D(X, Y), A + AB * T);
			if (D < R.HalfW + Extra && D < Best)
			{
				Best = D; OutLat = D; OutZ = FMath::Lerp(R.Z[i], R.Z[i + 1], T); bHit = true;
				if (OutRoad) *OutRoad = &R;
			}
		}
	}
	return bHit;
}

float FRWLayout::RoadInfluence(float X, float Y, float& OutZ) const
{
	float Lat;
	const FRWRoad* R = nullptr;
	if (RoadAt(X, Y, OutZ, Lat, &R, 8.f)) return 1.f - SStep(R->HalfW, R->HalfW + 8.f, Lat);
	return 0.f;
}

ESoil FRWLayout::Strata(float X, float Y, float D) const
{
	if (D < 0) D = 0;
	float Mtn = SStep(150.f, 240.f, Y);
	for (const FRWZone& Z : Zones)
	{
		const float W = ZoneWeight(Z, X, Y);
		if (W < 0.5f) continue;
		if (Z.Type == ERWZone::Mine && FVector2D((X - Z.C.X) / Z.HalfExt.X, (Y - Z.C.Y) / Z.HalfExt.Y).SizeSquared() > 1.1f) continue;
		switch (Z.Type)
		{
		case ERWZone::Quarry: return D < 0.18f ? ESoil::SmallRock : ESoil::LargeRock;
		case ERWZone::Mine: return D < 0.3f ? ESoil::Laterite : (D < 3.f ? ESoil::SmallRock : ESoil::LargeRock);
		case ERWZone::SandPit: return D < 5.5f ? ESoil::Sand : ESoil::Clay;
		case ERWZone::MudFlat: return D < 1.1f ? ESoil::Mud : ESoil::Clay;
		case ERWZone::Knoll: if (D > 0.3f) return D < 3.f ? ESoil::Laterite : ESoil::SmallRock; break;
		case ERWZone::Paddy: return D < 0.3f ? ESoil::Mud : ESoil::Clay;
		default: break;
		}
	}
	if (RiverDist(X, Y) < 12.f) return D < 1.2f ? ESoil::Sand : ESoil::Clay;
	if (StreamDist(X, Y) < 7.f) return D < 0.5f ? ESoil::Gravel : (D < 1.5f ? ESoil::Sand : ESoil::Clay);
	if (FMath::Max(FMath::Abs(X), FMath::Abs(Y)) > 300.f && TowerAt(X, Y) > 0.15f) return D < 0.2f ? ESoil::SmallRock : ESoil::LargeRock; // limestone
	const float Sc = 1.f - 0.7f * Mtn;
	const float Top = (0.35f + 0.12f * RWNoise2(X / 13.f, Y / 13.f, 81)) * Sc;
	if (D < Top) return ESoil::DrySoil;
	const float Sub = Top + (1.3f + 0.6f * RWNoise2(X / 31.f, Y / 31.f, 83)) * Sc;
	if (D < Sub) return RWNoise2(X / 45.f, Y / 45.f, 85) > -0.1f ? ESoil::Laterite : ESoil::Clay;
	// old river sand lens under the clay/laterite in about half of the area (0 - 1.4 m thick)
	const float SandT = FMath::Max(0.f, RWNoise2(X / 37.f, Y / 37.f, 87) + 0.05f) * 1.4f * Sc;
	if (D < Sub + SandT) return ESoil::Sand;
	const float G0 = Sub + SandT;
	if (D < G0 + 1.8f * Sc) return ESoil::Gravel;
	if (D < G0 + 3.2f * Sc) return ESoil::SmallRock;
	return ESoil::LargeRock;
}

float FRWLayout::InitMoisture(float X, float Y, float H) const
{
	float M = 0.18f + 0.06f * RWNoise2(X / 20.f, Y / 20.f, 91);
	const float RD = RiverDist(X, Y);
	M = FMath::Max(M, 0.75f * (1.f - SStep(6.f, 26.f, RD)));
	if (H < WaterZ + 0.05f) M = 1.f;
	if (const FRWZone* Mud = Find(ERWZone::MudFlat)) M = FMath::Max(M, 0.88f * ZoneWeight(*Mud, X, Y));
	M = FMath::Max(M, 0.7f * (1.f - SStep(4.f, 18.f, StreamDist(X, Y))));
	for (const FRWZone& Z : Zones) if (Z.Type == ERWZone::Paddy) M = FMath::Max(M, 0.8f * ZoneWeight(Z, X, Y));
	return FMath::Clamp(M, 0.f, 1.f);
}

float FRWLayout::InitGrass(float X, float Y) const
{
	float G = 0.75f + 0.25f * RWFbm(X / 15.f, Y / 15.f, 2, 93);
	for (const FRWZone& Z : Zones)
	{
		if (Z.Type == ERWZone::Forest || Z.Type == ERWZone::Knoll || Z.Type == ERWZone::Plot) continue;
		if (Z.Type == ERWZone::Paddy)
		{
			// rice in the fields, rough grass along the bunds
			const float W = ZoneWeight(Z, X, Y);
			if (W > 0.f) { float Lv, Bund; PaddyField(Z, X, Y, Lv, Bund); G = FMath::Lerp(G, FMath::Lerp(0.97f, 0.7f, Bund), W); }
			continue;
		}
		G *= 1.f - ZoneWeight(Z, X, Y) * (Z.Type == ERWZone::Site ? 0.55f : 1.f);
	}
	if (RiverDist(X, Y) < 10.f) G *= 0.3f;
	if (StreamDist(X, Y) < 4.f) G *= 0.25f;
	if (FMath::Max(FMath::Abs(X), FMath::Abs(Y)) > 300.f)
	{
		// the faces of a limestone hill are bare rock; only its top and foot carry soil
		const float Tw = TowerAt(X, Y);
		if (Tw > 0.f) G *= 1.f - FMath::Clamp(4.f * Tw * (1.f - Tw) * 1.6f, 0.f, 1.f);
	}
	return FMath::Clamp(G, 0.f, 1.f);
}
