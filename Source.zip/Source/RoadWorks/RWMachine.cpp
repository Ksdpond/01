#include "RWMachine.h"
#include "RWVehicleXml.h"
#include "Misc/Paths.h"
#include "RWTerrain.h"
#include "RWLoc.h"
#include "RWEffects.h"
#include "RWAudio.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Components/SpotLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/StaticMesh.h"
#include "RWMeshGen.h"
#include "RWMods.h"
#include "Algo/Reverse.h"
#include "Algo/MinElement.h"

UMaterialInterface* ARWMachine::GPaint = nullptr;
UMaterialInterface* ARWMachine::GGlass = nullptr;
UMaterialInterface* ARWMachine::GEmissive = nullptr;
UStaticMesh* ARWMachine::GCube = nullptr;
UStaticMesh* ARWMachine::GCyl = nullptr;
UStaticMesh* ARWMachine::GSphere = nullptr;
UStaticMesh* ARWMachine::GCone = nullptr;
float ARWMachine::TimeScale = 30.f;
const FRWModMachine* ARWMachine::PendingMod = nullptr;
TFunction<float(float, float, float)> ARWMachine::GroundOverride;
TFunction<bool(ARWMachine*, FVector&)> ARWMachine::CollisionResolver;
TFunction<int32(const FVector&, float, const FVector&, float)> ARWMachine::TreeHitter;
TFunction<bool(const FVector&, float&)> ARWMachine::DesignGrade;

const TArray<FMachineSpec>& MachineCatalog()
{
	static TArray<FMachineSpec> C = {
		{EMachineKind::Excavator, 0, TEXT("Mini Excavator 5t"), 65000, 350, FLinearColor(0.40f, 0.24f, 0.012f)},
		{EMachineKind::Excavator, 1, TEXT("Crawler Excavator 22t"), 210000, 900, FLinearColor(0.42f, 0.25f, 0.01f)},
		{EMachineKind::Excavator, 2, TEXT("Heavy Excavator 36t"), 340000, 1400, FLinearColor(0.38f, 0.23f, 0.01f)},
		{EMachineKind::DumpTruck, 0, TEXT("Tipper Truck 6x4 (15t)"), 120000, 600, FLinearColor(0.30f, 0.025f, 0.018f)},
		{EMachineKind::DumpTruck, 1, TEXT("Haul Truck 8x4 (25t)"), 185000, 850, FLinearColor(0.50f, 0.47f, 0.43f)},
		{EMachineKind::Bulldozer, 1, TEXT("Crawler Dozer 20t"), 260000, 1100, FLinearColor(0.42f, 0.26f, 0.012f)},
		{EMachineKind::WheelLoader, 1, TEXT("Wheel Loader 3.2m3"), 230000, 950, FLinearColor(0.42f, 0.26f, 0.012f)},
		{EMachineKind::Grader, 1, TEXT("Motor Grader 3.7m"), 280000, 1150, FLinearColor(0.42f, 0.27f, 0.012f)},
		{EMachineKind::Roller, 1, TEXT("Vibratory Roller 12t"), 140000, 650, FLinearColor(0.45f, 0.25f, 0.012f)},
		{EMachineKind::Paver, 1, TEXT("Asphalt Paver 3-6m"), 310000, 1300, FLinearColor(0.44f, 0.30f, 0.015f)},
		{EMachineKind::WaterTruck, 1, TEXT("Water Truck 12000L"), 110000, 500, FLinearColor(0.05f, 0.12f, 0.28f)},
		{EMachineKind::Crane, 1, TEXT("Mobile Crane 40t"), 520000, 2200, FLinearColor(0.42f, 0.33f, 0.012f)},
	};
	return C;
}

void FHydCyl::Update()
{
	if (!A || !B || !Barrel || !Rod) return;
	const FVector PA = A->GetComponentTransform().TransformPosition(ALocal);
	const FVector PB = B->GetComponentTransform().TransformPosition(BLocal);
	const FVector D = PB - PA;
	const float L = D.Size();
	if (L < 1.f) return;
	const FVector Dir = D / L;
	const FQuat Q = FRotationMatrix::MakeFromZ(Dir).ToQuat();
	const float BL = FMath::Min(BarrelLen, L * 0.95f);
	const FVector BS = Barrel->GetComponentScale();
	Barrel->SetWorldLocationAndRotation(PA + Dir * BL * 0.5f, Q);
	Barrel->SetWorldScale3D(FVector(BS.X, BS.Y, BL / 100.f));
	const float RL = FMath::Max(L - BL * 0.15f, 10.f);
	const FVector RS = Rod->GetComponentScale();
	Rod->SetWorldLocationAndRotation(PB - Dir * RL * 0.5f, Q);
	Rod->SetWorldScale3D(FVector(RS.X, RS.Y, RL / 100.f));
}

ARWMachine::ARWMachine()
{
	PrimaryActorTick.bCanEverTick = true;
	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;
	Body = CreateDefaultSubobject<USceneComponent>(TEXT("Body"));
	Body->SetupAttachment(Root);
	Arm = CreateDefaultSubobject<USpringArmComponent>(TEXT("Arm"));
	Arm->SetupAttachment(Root);
	Arm->bDoCollisionTest = false;
	Arm->bUsePawnControlRotation = false;
	Arm->bInheritPitch = false; Arm->bInheritRoll = false; Arm->bInheritYaw = true;
	Arm->bEnableCameraLag = true; Arm->CameraLagSpeed = 8.f;
	Arm->SetRelativeLocation(FVector(0, 0, 250));
	ThirdCam = CreateDefaultSubobject<UCameraComponent>(TEXT("ThirdCam"));
	ThirdCam->SetupAttachment(Arm);
	ThirdCam->SetFieldOfView(70.f);
	CabCam = CreateDefaultSubobject<UCameraComponent>(TEXT("CabCam"));
	CabCam->SetupAttachment(Body);
	CabCam->SetFieldOfView(100.f); // wide: the bucket, the tracks and the ground around them all in view
	CabCam->SetAutoActivate(false);
	Synth = CreateDefaultSubobject<URWEngineSynth>(TEXT("Synth"));
	Synth->SetupAttachment(Body);
	AutoPossessPlayer = EAutoReceiveInput::Disabled;
}

void ARWMachine::BeginPlay()
{
	Super::BeginPlay();
}

UStaticMesh* ARWMachine::MeshFor(EShape S)
{
	switch (S)
	{
	case EShape::Cylinder: return GCyl;
	case EShape::Sphere: return GSphere;
	case EShape::Cone: return GCone;
	default: return GCube;
	}
}

UStaticMeshComponent* ARWMachine::MeshPart(USceneComponent* Parent, UStaticMesh* Mesh, const FVector& LocM, const FRotator& Rot, UMaterialInterface* Mat, const FVector& Scale)
{
	UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
	C->SetStaticMesh(Mesh ? Mesh : GCube);
	C->SetMaterial(0, Mat ? Mat : PaintMID);
	C->SetupAttachment(Parent ? Parent : Body);
	C->SetRelativeLocation(LocM * M2CM);
	C->SetRelativeRotation(Rot);
	C->SetRelativeScale3D(Scale);
	C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	C->SetGenerateOverlapEvents(false);
	C->RegisterComponent();
	return C;
}

UStaticMeshComponent* ARWMachine::Part(USceneComponent* Parent, EShape Shape, const FVector& LocM, const FVector& SizeM, const FRotator& Rot, UMaterialInterface* Mat, bool bUnit)
{
	UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
	// Detailed geometry: real rounded-edge boxes and bevelled cylinders built at true size.
	UStaticMesh* Detailed = nullptr;
	if (!bUnit && Shape == EShape::Cube && SizeM.GetMin() > 0.004f) Detailed = FRWMeshGen::RoundBox(SizeM);
	if (!bUnit && Shape == EShape::Cylinder && FMath::IsNearlyEqual(SizeM.X, SizeM.Y, 0.01f) && SizeM.X > 0.02f) Detailed = FRWMeshGen::RoundCyl(SizeM.X, SizeM.Z);
	C->SetStaticMesh(Detailed ? Detailed : MeshFor(Shape));
	C->SetMaterial(0, Mat ? Mat : PaintMID);
	C->SetupAttachment(Parent ? Parent : Body);
	C->SetRelativeLocation(LocM * M2CM);
	C->SetRelativeRotation(Rot);
	C->SetRelativeScale3D(Detailed ? FVector::OneVector : SizeM);
	C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	C->SetGenerateOverlapEvents(false);
	C->bCastDynamicShadow = SizeM.GetMax() > 0.15f;
	C->RegisterComponent();
	return C;
}

USceneComponent* ARWMachine::Pivot(USceneComponent* Parent, const FVector& LocM, const FRotator& Rot)
{
	USceneComponent* P = NewObject<USceneComponent>(this);
	P->SetupAttachment(Parent ? Parent : Body);
	P->SetRelativeLocation(LocM * M2CM);
	P->SetRelativeRotation(Rot);
	P->RegisterComponent();
	return P;
}

void ARWMachine::SetPaint(const FLinearColor& C)
{
	// Keep HDR/invalid input from producing non-physical paint colors.
	if (!FMath::IsFinite(C.R) || !FMath::IsFinite(C.G) || !FMath::IsFinite(C.B)) return;
	if (PaintMID) PaintMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(
		FMath::Clamp(C.R, 0.f, 1.f), FMath::Clamp(C.G, 0.f, 1.f),
		FMath::Clamp(C.B, 0.f, 1.f), 1.f));
}

void ARWMachine::Setup(ARWTerrain* InTerrain, ARWEffects* InFx, int32 InSize, const FVector& P, float YawDeg)
{
	Terrain = InTerrain; Fx = InFx; Size = InSize;
	PosM = P; Yaw = YawDeg;
	auto MakeMID = [&](FLinearColor Col, float Metal, float Rough) {
		if (!GPaint) return static_cast<UMaterialInstanceDynamic*>(nullptr);
		UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(GPaint, this);
		if (!M) return M;
		M->SetVectorParameterValue(TEXT("Color"), Col);
		M->SetScalarParameterValue(TEXT("Metallic"), Metal);
		M->SetScalarParameterValue(TEXT("Roughness"), Rough);
		return M;
	};
	PaintMID = MakeMID(FLinearColor(0.6f, 0.4f, 0.02f), 0.25f, 0.28f);
	DarkMID = MakeMID(FLinearColor(0.025f, 0.025f, 0.027f), 0.2f, 0.55f);
	SteelMID = MakeMID(FLinearColor(0.35f, 0.35f, 0.34f), 1.f, 0.42f);
	ChromeMID = MakeMID(FLinearColor(0.85f, 0.85f, 0.85f), 1.f, 0.13f);
	// Optional scalar inputs: effective only if M_Paint exposes these parameters.
	if (PaintMID) {
		PaintMID->SetScalarParameterValue(TEXT("ClearCoat"), 0.8f);
		PaintMID->SetScalarParameterValue(TEXT("ClearCoatRoughness"), 0.18f);
		PaintMID->SetScalarParameterValue(TEXT("ScratchIntensity"), 0.12f);
	}
	if (ChromeMID) {
		ChromeMID->SetScalarParameterValue(TEXT("ClearCoat"), 0.f);
		ChromeMID->SetScalarParameterValue(TEXT("ScratchIntensity"), 0.035f);
		ChromeMID->SetScalarParameterValue(TEXT("Oil"), 0.f);
	}
	RubberMID = MakeMID(FLinearColor(0.018f, 0.018f, 0.018f), 0.f, 0.88f);
	SeatMID = MakeMID(FLinearColor(0.03f, 0.03f, 0.035f), 0.f, 0.7f);
	GlassMID = GGlass ? UMaterialInstanceDynamic::Create(GGlass, this) : nullptr;
	GaugeMID = GEmissive ? UMaterialInstanceDynamic::Create(GEmissive, this) : nullptr;
	if (GaugeMID) {
		GaugeMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.2f, 0.6f, 1.f));
		GaugeMID->SetScalarParameterValue(TEXT("Strength"), 0.f);
	}
	BeaconMID = GEmissive ? UMaterialInstanceDynamic::Create(GEmissive, this) : nullptr;
	if (BeaconMID) BeaconMID->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.f, 0.45f, 0.02f));
	for (const FMachineSpec& S : MachineCatalog())
		if (S.Kind == Kind && S.Size == Size) { Model = S.Name; Price = S.Price; RentPerDay = S.RentPerDay; SetPaint(S.Color); }
	const FRWModMachine* MD = PendingMod;
	if (MD) FRWMods::PreBuild(this, *MD);
	Build();
	if (MD) FRWMods::PostBuild(this, *MD);
	Fuel = FuelCap * 0.8f;
	Radius2D = FMath::Max(Radius2D, 1.5f);
	if (Synth)
	{
		FRWSoundFiles::Load(); // (the recorded sounds, once, before any machine's sound starts)
		Synth->Pitch = Kind == EMachineKind::Excavator && Size == 0 ? 1.6f : 1.f;
		Synth->Start();
	}
	// settle suspension
	for (int32 k = 0; k < 30; ++k) SuspensionStep(1.f / 60.f);
	ApplyTransform();
}

float ARWMachine::GroundAt(float X, float Y) const
{
	float H = Terrain ? Terrain->HeightAt(X, Y) : 0.f;
	if (GroundOverride) H = FMath::Max(H, GroundOverride(X, Y, PosM.Z));
	return H;
}

FVector ARWMachine::LocalToWorldM(const FVector& L) const
{
	return GetActorTransform().TransformPosition(L * M2CM) * CM2M;
}

FVector ARWMachine::BodyToWorldM(const FVector& L) const
{
	return Body->GetComponentTransform().TransformPosition(L * M2CM) * CM2M;
}

FVector ARWMachine::WorldToBodyM(const FVector& W) const
{
	return Body->GetComponentTransform().InverseTransformPosition(W * M2CM) * CM2M;
}

FVector ARWMachine::EntryWorld() const
{
	// cab doors are on the left side of each cab; follow the cab (excavator / crane houses swing)
	FVector Door, Out;
	if (DoorPivot && CabRoot)
	{
		Door = DoorPivot->GetComponentLocation() * CM2M;
		Out = -CabRoot->GetRightVector();
	}
	else
	{
		Door = LocalToWorldM(FVector(0, -Radius2D * 0.55f, 1.f));
		Out = -Right2();
	}
	Out.Z = 0; Out = Out.GetSafeNormal();
	FVector P = Door + Out * 1.1f;
	P.Z = GroundAt(P.X, P.Y);
	return P;
}

FVector ARWMachine::SeatWorld() const
{
	if (CabCam) return CabCam->GetComponentLocation() * CM2M - FVector(0, 0, 0.75f);
	return PosM + FVector(0, 0, 2.f);
}

float ARWMachine::HydSpeedScale() const
{
	if (!bEngineOn) return 0.f;
	float S = 0.25f + 0.75f * RpmFrac();
	S *= 1.f + 0.2f * UpHyd;
	if (Condition < 0.3f) S *= 0.6f;
	return S;
}

void ARWMachine::ToggleEngine()
{
	if (bEngineOn) { bEngineOn = false; Cranking = 0; return; }
	if (Fuel <= 0.1f) { Warning = TEXT("Out of fuel"); return; }
	if (Condition < 0.05f) { Warning = TEXT("Engine needs repair"); return; }
	Cranking = 1.1f;
}

void ARWMachine::AddWheel(const FVector2D& Local, float R, float W, bool bSteer, bool bDriven, bool bFrontFrame, bool bDual)
{
	FRWWheel Wh;
	Wh.Local = Local; Wh.Radius = R; Wh.Width = bDual ? W * 2.1f : W; Wh.bSteer = bSteer; Wh.bDriven = bDriven; Wh.bFront = bFrontFrame; Wh.bDual = bDual;
	Wh.Pivot = Pivot(Root, FVector(Local.X, Local.Y, R));
	Wh.Spinner = Pivot(Wh.Pivot, FVector::ZeroVector);
	const float Side = Local.Y > 0 ? 1.f : -1.f;
	// moulded tyre with real tread blocks + dished steel rim with wheel nuts (outer face toward the side)
	UStaticMesh* TyreM = FRWMeshGen::Tyre(R, W, TyreStyle);
	UStaticMesh* RimM = FRWMeshGen::Rim(R, W);
	const FRotator Face = Side > 0 ? FRotator::ZeroRotator : FRotator(0, 180, 0);
	MeshPart(Wh.Spinner, TyreM, FVector::ZeroVector, Face, RubberMID);
	MeshPart(Wh.Spinner, RimM, FVector::ZeroVector, Face, SteelMID);
	if (bDual)
	{
		MeshPart(Wh.Spinner, TyreM, FVector(0, -Side * W * 1.08f, 0), Face, RubberMID);
		MeshPart(Wh.Spinner, RimM, FVector(0, -Side * W * 1.08f, 0), Face, SteelMID);
	}
	Wheels.Add(Wh);
}

void ARWMachine::AddTracks(float Length, float Gauge, float Width, float Height, int32 RoadWheels)
{
	Drive = EDrive::Tracked;
	TrackGauge = Gauge; TrackLength = Length; TrackWidth = Width;
	const float R = Height * 0.5f;
	for (int32 s = 0; s < 2; ++s)
	{
		const float Y = (s == 0 ? -1.f : 1.f) * Gauge * 0.5f;
		// frame, sprocket, idler, rollers
		Part(Root, EShape::Cube, FVector(0, Y, R), FVector(Length - 2 * R, Width * 0.55f, Height * 0.7f), FRotator::ZeroRotator, DarkMID);
		MeshPart(Root, FRWMeshGen::Sprocket(Height * 0.48f, Width * 0.6f), FVector(-(Length * 0.5f - R), Y, R), FRotator::ZeroRotator, DarkMID);
		Part(Root, EShape::Cylinder, FVector((Length * 0.5f - R), Y, R), FVector(Height * 0.9f, Height * 0.9f, Width * 0.7f), FRotator(0, 0, 90), SteelMID);
		for (int32 k = 0; k < 6; ++k)
		{
			const float A = k / 6.f * 2 * PI;
			Part(Root, EShape::Cube, FVector(-(Length * 0.5f - R) + FMath::Cos(A) * R * 0.95f, Y, R + FMath::Sin(A) * R * 0.95f), FVector(0.12f, Width * 0.5f, 0.12f), FRotator(FMath::RadiansToDegrees(A), 0, 0), SteelMID);
		}
		for (int32 k = 0; k < RoadWheels; ++k)
		{
			const float X = FMath::Lerp(-(Length * 0.5f - R * 1.6f), Length * 0.5f - R * 1.6f, k / float(FMath::Max(1, RoadWheels - 1)));
			Part(Root, EShape::Cylinder, FVector(X, Y, 0.22f), FVector(0.34f, 0.34f, Width * 0.6f), FRotator(0, 0, 90), SteelMID)->bCastDynamicShadow = false;
			FRWWheel Wh; Wh.Local = FVector2D(X, Y); Wh.Radius = 0.2f; Wh.Width = Width; Wh.bTrack = true; Wh.bDriven = true;
			Wheels.Add(Wh);
		}
		USceneComponent* Holder = Pivot(Root, FVector::ZeroVector);
		(s == 0 ? ShoesL : ShoesR) = Holder;
	}
	BuildTrackShoes(Width);
}

void ARWMachine::BuildTrackShoes(float Width)
{
	// (re)creates the shoe chain for the current loop shape; ~0.19 m pitch like real excavator shoes
	for (int32 s = 0; s < 2; ++s)
	{
		TArray<UStaticMeshComponent*>& Comps = s == 0 ? ShoeCompsL : ShoeCompsR;
		for (UStaticMeshComponent* C : Comps) if (C) C->DestroyComponent();
		Comps.Reset();
		USceneComponent* Holder = s == 0 ? ShoesL : ShoesR;
		if (!Holder) continue;
		float Rad, Half, CX, Zc; TrackLoop(Rad, Half, CX, Zc);
		const float Loop = TrackPaths[s].Len > 0.f ? TrackPaths[s].Len : 4.f * Half + 2.f * PI * Rad;
		const int32 Count = ModelTrackLinkCount[s] > 0
			? FMath::Clamp(ModelTrackLinkCount[s], 8, 200)
			: FMath::Clamp(FMath::RoundToInt(Loop / TrackShoePitch), 8, 200);
		UStaticMesh* Mesh = TrackShoeMesh[s] ? TrackShoeMesh[s] : FRWMeshGen::TrackShoe(0.19f, Width);
		for (int32 k = 0; k < Count; ++k)
		{
			UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
			C->SetStaticMesh(Mesh);
			C->SetMaterial(0, TrackShoeMat ? TrackShoeMat : SteelMID);
			C->SetupAttachment(Holder);
			C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			C->SetMobility(EComponentMobility::Movable);
			C->bCastDynamicShadow = true;
			C->RegisterComponent();
			Comps.Add(C);
		}
	}
	LastShoeTravelL = LastShoeTravelR = 1e9f;
	UpdateTrackVisuals();
}

bool ARWMachine::bNoHoses = false;

int32 ARWMachine::AddHose(USceneComponent* A, const FVector& OffA, USceneComponent* B, const FVector& OffB, float Radius, float Length, const FVector& LoopDir)
{
	if (!A || !B || bNoHoses) return INDEX_NONE;
	FHose H; H.A = A; H.OffA = OffA; H.B = B; H.OffB = OffB; H.Radius = Radius; H.Length = FMath::Max(Length, 0.1f);
	H.LoopDir = LoopDir.GetSafeNormal(); if (H.LoopDir.IsNearlyZero()) H.LoopDir = FVector(0, 0, 1);
	H.MinBend = FMath::Max(Radius * 5.f, 0.08f); // minimum bend radius = 2.5x the hose diameter
	for (int32 k = 0; k < 14; ++k)
	{
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
		C->SetStaticMesh(GCyl);
		C->SetMaterial(0, RubberMID);
		C->SetupAttachment(Root);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->SetMobility(EComponentMobility::Movable);
		C->RegisterComponent();
		H.Segs.Add(C);
	}
	return Hoses.Add(H);
}

float ARWMachine::HoseReach(USceneComponent* Joint, float Lo, float Hi, USceneComponent* A, const FVector& OffA, USceneComponent* B, const FVector& OffB) const
{
	if (!Joint || !A || !B) return 1.f;
	const FRotator Keep = Joint->GetRelativeRotation();
	float Best = 0.f;
	for (int32 k = 0; k <= 8; ++k)
	{
		Joint->SetRelativeRotation(FRotator(FMath::Lerp(Lo, Hi, k / 8.f), Keep.Yaw, Keep.Roll));
		const FVector PA = A->GetComponentTransform().TransformPosition(OffA * M2CM), PB = B->GetComponentTransform().TransformPosition(OffB * M2CM);
		Best = FMath::Max(Best, (float)FVector::Dist(PA, PB) * CM2M);
	}
	Joint->SetRelativeRotation(Keep);
	return Best;
}

void ARWMachine::HoseCurve(const FHose& H, float Sag, TArray<FVector>& Out)
{
	// service loop: the hose leaves both fittings bowing out along its loop direction and spreading
	// apart, so slack forms a round teardrop loop (like a real hose) instead of a kink. Sag = loop size.
	const FVector P0 = H.A->GetComponentTransform().TransformPosition(H.OffA * M2CM) * CM2M;
	const FVector P1 = H.B->GetComponentTransform().TransformPosition(H.OffB * M2CM) * CM2M;
	const FVector D = (P1 - P0).GetSafeNormal();
	FVector N = H.A->GetComponentTransform().TransformVectorNoScale(H.LoopDir);
	N = (N - D * FVector::DotProduct(N, D)).GetSafeNormal();
	if (N.IsNearlyZero()) N = FVector::UpVector;
	// cubic Bezier controls: straight when there is no slack, opening into a round loop as the slack grows
	const float Span = FVector::Dist(P0, P1);
	const FVector C1 = P0 + D * (Span / 3.f - Sag * H.Spread) + N * Sag, C2 = P1 - D * (Span / 3.f - Sag * H.Spread) + N * Sag;
	Out.SetNum(H.Segs.Num() + 1);
	for (int32 k = 0; k < Out.Num(); ++k)
	{
		const float t = k / float(Out.Num() - 1), u = 1.f - t;
		Out[k] = P0 * (u * u * u) + C1 * (3.f * u * u * t) + C2 * (3.f * u * t * t) + P1 * (t * t * t);
	}
}

void ARWMachine::UpdateHoses()
{
	TArray<FVector> Pts;
	for (FHose& H : Hoses)
	{
		if (!H.A || !H.B) continue;
		{
			const FVector Q0 = H.A->GetComponentTransform().TransformPosition(H.OffA * M2CM), Q1 = H.B->GetComponentTransform().TransformPosition(H.OffB * M2CM);
			if (Q0.Equals(H.LastP0, 0.1f) && Q1.Equals(H.LastP1, 0.1f)) continue; // parked machine: nothing to do
			H.LastP0 = Q0; H.LastP1 = Q1;
		}
		auto LenOf = [&](float Sg) { HoseCurve(H, Sg, Pts); float L = 0.f; for (int32 k = 1; k < Pts.Num(); ++k) L += FVector::Dist(Pts[k - 1], Pts[k]); return L; };
		auto Bend = [&]()
		{
			// tightest bend along the hose (segment length / turning angle)
			float R = 1e9f;
			for (int32 k = 1; k + 1 < Pts.Num(); ++k)
			{
				const FVector A = Pts[k] - Pts[k - 1], B = Pts[k + 1] - Pts[k];
				const float Ang = FMath::Acos(FMath::Clamp(FVector::DotProduct(A.GetSafeNormal(), B.GetSafeNormal()), -1.f, 1.f));
				if (Ang > 1e-3f) R = FMath::Min(R, 0.5f * (A.Size() + B.Size()) / Ang);
			}
			return R;
		};
		// for each loop shape, find the loop size that gives the hose its real length (it never stretches;
		// at full reach it runs straight), then keep the shape with the gentlest bend
		H.bTaut = LenOf(0.f) >= H.Length;
		float BestR = -1.f, BestSag = 0.f, BestSpread = 0.5f;
		for (const float Sp : {0.5f, 0.9f, 1.4f, 2.f, 2.8f, 3.8f})
		{
			H.Spread = Sp;
			float Lo = 0.f, Hi = H.Length;
			if (!H.bTaut) for (int32 it = 0; it < 16; ++it) { const float Mid = (Lo + Hi) * 0.5f; (LenOf(Mid) < H.Length ? Lo : Hi) = Mid; }
			const float Sg = H.bTaut ? 0.f : (Lo + Hi) * 0.5f;
			LenOf(Sg);
			const float R = Bend();
			if (R > BestR) { BestR = R; BestSag = Sg; BestSpread = Sp; }
			if (H.bTaut) break;
		}
		H.Spread = BestSpread; H.Sag = BestSag;
		H.CurveLen = LenOf(H.Sag);
		H.MinRadius = Bend();
		for (int32 k = 0; k < H.Segs.Num(); ++k)
		{
			const FVector A = Pts[k], B = Pts[k + 1];
			const float L = FVector::Dist(A, B);
			const FVector Dir = L > 1e-4f ? (B - A) / L : FVector::UpVector;
			// cylinder mesh is 1 m tall along Z, centred: overlap a little so bends have no gaps
			H.Segs[k]->SetWorldTransform(FTransform(FRotationMatrix::MakeFromZ(Dir).ToQuat(), (A + B) * 0.5f * M2CM, FVector(H.Radius * 2.f, H.Radius * 2.f, L * 1.12f)));
		}
	}
}
void ARWMachine::SetTrackPath(int32 Side, const TArray<FVector2D>& Pts, float Y)
{
	// the chain is the convex hull around the wheels (like a belt), walked clockwise from the front of the bottom run
	FTrackPath& T = TrackPaths[Side];
	T.P.Reset(); T.S.Reset(); T.Len = 0.f; T.Y = Y;
	TArray<FVector2D> V = Pts;
	if (V.Num() < 3) return;
	V.Sort([](const FVector2D& A, const FVector2D& B) { return A.X < B.X || (A.X == B.X && A.Y < B.Y); });
	auto Cross = [](const FVector2D& O, const FVector2D& A, const FVector2D& B) { return (A.X - O.X) * (B.Y - O.Y) - (A.Y - O.Y) * (B.X - O.X); };
	TArray<FVector2D> H; H.SetNum(V.Num() * 2);
	int32 k = 0;
	for (int32 i = 0; i < V.Num(); ++i) { while (k >= 2 && Cross(H[k - 2], H[k - 1], V[i]) <= 0) --k; H[k++] = V[i]; }
	for (int32 i = V.Num() - 2, t = k + 1; i >= 0; --i) { while (k >= t && Cross(H[k - 2], H[k - 1], V[i]) <= 0) --k; H[k++] = V[i]; }
	H.SetNum(FMath::Max(k - 1, 0)); // counter-clockwise, no repeat
	if (H.Num() < 3) return;
	Algo::Reverse(H); // clockwise in (x forward, z up): bottom runs front -> rear
	// start at the front-most point of the lowest stretch
	const float MinZ = Algo::MinElementBy(H, [](const FVector2D& P) { return P.Y; })->Y;
	int32 Start = 0; float BestX = -1e9f;
	for (int32 i = 0; i < H.Num(); ++i) if (H[i].Y < MinZ + 0.01f && H[i].X > BestX) { BestX = H[i].X; Start = i; }
	for (int32 i = 0; i < H.Num(); ++i) T.P.Add(H[(Start + i) % H.Num()]);
	const FVector2D First = T.P[0];
	T.P.Add(First);
	T.S.Add(0.f);
	for (int32 i = 1; i < T.P.Num(); ++i) T.S.Add(T.S.Last() + FVector2D::Distance(T.P[i - 1], T.P[i]));
	T.Len = T.S.Last();
}

// The artist supplies one GLB node per link, in chain order. Preserve that closed loop rather
// than convex-hulling the points: hulls cut across concave top runs / rollers.
// Input is already in the RoadWorks (forward X, up Z) metre coordinate frame.
void ARWMachine::SetOrderedTrackPath(int32 Side, const TArray<FVector2D>& Pts, float Y)
{
	if (Side < 0 || Side > 1 || Pts.Num() < 8) return;
	FTrackPath& T = TrackPaths[Side];
	T.P = Pts;
	// The visual code expects a clockwise loop from the lower front run.
	double Area2 = 0.0;
	for (int32 i = 0; i < T.P.Num(); ++i)
	{
		const FVector2D& A = T.P[i];
		const FVector2D& B = T.P[(i + 1) % T.P.Num()];
		Area2 += (double)A.X * B.Y - (double)B.X * A.Y;
	}
	if (Area2 > 0.0) Algo::Reverse(T.P);
	const FVector2D FirstPt = T.P[0]; // (a copy: adding an element of the same array can move it while it is added)
	T.P.Add(FirstPt);
	T.S.Reset(); T.S.Add(0.f);
	for (int32 i = 1; i < T.P.Num(); ++i)
		T.S.Add(T.S.Last() + FVector2D::Distance(T.P[i - 1], T.P[i]));
	T.Len = T.S.Last();
	T.Y = Y;
}

void ARWMachine::TrackLoop(float& Rad, float& Half, float& CX, float& Zc) const
{
	if (TrackLoopHalf > 0.f)
	{
		Rad = TrackRadOverride; Half = TrackLoopHalf; CX = TrackLoopCX; Zc = TrackLoopZc;
		return;
	}
	Rad = TrackRadOverride > 0.f ? TrackRadOverride : 0.5f * FMath::Max(0.45f, TrackLength * 0.13f);
	Half = FMath::Max(TrackLength * 0.5f - Rad, 0.1f);
	CX = 0.f;
	Zc = TrackShoeZ + Rad;
}

void ARWMachine::UpdateTrackVisuals()
{
	float Rad, Lx, CX, Zc; TrackLoop(Rad, Lx, CX, Zc);
	for (int32 s = 0; s < 2; ++s)
	{
		const TArray<UStaticMeshComponent*>& Comps = s == 0 ? ShoeCompsL : ShoeCompsR;
		const int32 Count = Comps.Num();
		if (Count == 0) continue; // wheel spinners are updated after this loop regardless
		const float Travel = s == 0 ? TrackTravelL : TrackTravelR;
		float& Last = s == 0 ? LastShoeTravelL : LastShoeTravelR;
		if (FMath::Abs(Travel - Last) < 0.002f) continue; // nothing moved
		Last = Travel;
		const FTrackPath& TP = TrackPaths[s];
		if (TP.Len > 0.f)
		{
			// shoes ride the wheel-wrapping path; each lies along its stretch with the grouser outwards
			const float SP = TP.Len / Count;
			int32 Seg = 0;
			float U0 = FMath::Fmod(Travel, SP); if (U0 < 0) U0 += SP;
			const int32 First = FMath::FloorToInt((Travel - U0) / SP + 0.5f);
			for (int32 k = 0; k < Count; ++k)
			{
				const float U = FMath::Min(U0 + k * SP, TP.Len - 0.00001f); // bounded within the closed loop
				while (Seg < TP.S.Num() - 2 && TP.S[Seg + 1] < U) ++Seg;
				const FVector2D A = TP.P[Seg], B = TP.P[Seg + 1];
				const float SL = FMath::Max(TP.S[Seg + 1] - TP.S[Seg], 1e-4f);
				const FVector2D Q = FMath::Lerp(A, B, FMath::Clamp((U - TP.S[Seg]) / SL, 0.f, 1.f));
				const FVector2D D = (B - A) / SL;
				const float Ang = FMath::RadiansToDegrees(FMath::Atan2(-D.Y, -D.X));
				// keep each component on the same shoe as the chain moves (no popping)
				const int32 Idx = ((k - First) % Count + Count) % Count;
				Comps[Idx]->SetRelativeTransform(FTransform(FRotator(Ang, 0, 0), FVector(Q.X, TP.Y, Q.Y) * M2CM, FVector(SP / TrackShoePitch, 1.f, 1.f)));
			}
			// Do not return/continue before the shared wheel-spinner update below.
		}
		else
		{
		const float Y = (s == 0 ? -1.f : 1.f) * TrackGauge * 0.5f;
		// chain: bottom run (front -> rear), rear wrap, top run (rear -> front), front wrap
		const float Straight = 2 * Lx;
		const float Loop = 2 * Straight + 2 * PI * Rad;
		const float ShoePitch = Loop / Count;
		for (int32 k = 0; k < Count; ++k)
		{
			float U = FMath::Fmod(k * ShoePitch + Travel, Loop); if (U < 0) U += Loop;
			FVector P; float Ang;
			if (U < Straight) { P = FVector(CX + Lx - U, Y, Zc - Rad); Ang = 0; }
			else if (U < Straight + PI * Rad) { const float A = (U - Straight) / Rad; P = FVector(CX - Lx - FMath::Sin(A) * Rad, Y, Zc - FMath::Cos(A) * Rad); Ang = -FMath::RadiansToDegrees(A); }
			else if (U < 2 * Straight + PI * Rad) { P = FVector(CX - Lx + (U - Straight - PI * Rad), Y, Zc + Rad); Ang = 180; }
			else { const float A = (U - 2 * Straight - PI * Rad) / Rad; P = FVector(CX + Lx + FMath::Sin(A) * Rad, Y, Zc + FMath::Cos(A) * Rad); Ang = 180 - FMath::RadiansToDegrees(A); }
			Comps[k]->SetRelativeTransform(FTransform(FRotator(Ang, 0, 0), P * M2CM, FVector(ShoePitch / TrackShoePitch, 1.f, 1.f)));
		}
		}
	}
	// sprockets, idlers and rollers of a model undercarriage turn with their track
	for (const FSpinner& Sp : TrackSpinners)
	{
		if (!Sp.P) continue;
		const float Travel = Sp.bLeft ? TrackTravelL : TrackTravelR;
		const float Deg = FMath::RadiansToDegrees(Travel / FMath::Max(Sp.Radius, 0.05f));
		Sp.P->SetRelativeRotation(Sp.Rest * FRotator(-Deg, 0, 0).Quaternion()); // same sense as the road wheels
	}
}

void ARWMachine::AddCab(USceneComponent* Parent, const FVector& L, const FVector& S, bool bRops)
{
	CabRoot = Pivot(Parent, L);
	const float T = 0.06f;
	// corner posts
	for (int32 i = 0; i < 4; ++i)
	{
		const float X = (i < 2 ? 0.5f : -0.5f) * S.X, Y = ((i & 1) ? 0.5f : -0.5f) * S.Y;
		Part(CabRoot, EShape::Cube, FVector(X, Y, 0), FVector(T, T, S.Z), FRotator::ZeroRotator, DarkMID);
	}
	Part(CabRoot, EShape::Cube, FVector(0, 0, S.Z * 0.5f + 0.03f), FVector(S.X + 0.06f, S.Y + 0.06f, 0.07f), FRotator::ZeroRotator, PaintMID);
	Part(CabRoot, EShape::Cube, FVector(0, 0, -S.Z * 0.5f), FVector(S.X, S.Y, 0.08f), FRotator::ZeroRotator, DarkMID);
	// glass
	Part(CabRoot, EShape::Cube, FVector(S.X * 0.5f, 0, 0.02f), FVector(0.015f, S.Y - T, S.Z - 0.1f), FRotator::ZeroRotator, GlassMID)->bCastDynamicShadow = false;
	Part(CabRoot, EShape::Cube, FVector(-S.X * 0.5f, 0, 0.1f), FVector(0.015f, S.Y - T, S.Z * 0.75f), FRotator::ZeroRotator, GlassMID)->bCastDynamicShadow = false;
	Part(CabRoot, EShape::Cube, FVector(0, S.Y * 0.5f, 0.05f), FVector(S.X - T, 0.015f, S.Z * 0.85f), FRotator::ZeroRotator, GlassMID)->bCastDynamicShadow = false;
	// door (left side) with hinge at front
	DoorPivot = Pivot(CabRoot, FVector(S.X * 0.45f, -S.Y * 0.5f, 0));
	Part(DoorPivot, EShape::Cube, FVector(-S.X * 0.45f, 0, 0.05f), FVector(S.X * 0.85f, 0.015f, S.Z * 0.85f), FRotator::ZeroRotator, GlassMID)->bCastDynamicShadow = false;
	Part(DoorPivot, EShape::Cube, FVector(-S.X * 0.45f, -0.01f, -S.Z * 0.38f), FVector(S.X * 0.86f, 0.04f, 0.06f), FRotator::ZeroRotator, PaintMID);
	Part(DoorPivot, EShape::Cube, FVector(-S.X * 0.86f, -0.01f, 0.05f), FVector(0.05f, 0.04f, S.Z * 0.85f), FRotator::ZeroRotator, DarkMID);
	Part(DoorPivot, EShape::Cube, FVector(-S.X * 0.7f, -0.04f, 0.0f), FVector(0.12f, 0.03f, 0.03f), FRotator::ZeroRotator, ChromeMID);
	// interior: seat, console, gauges, joysticks / wheel
	Part(CabRoot, EShape::Cube, FVector(-S.X * 0.15f, 0, -S.Z * 0.3f), FVector(0.5f, 0.5f, 0.12f), FRotator::ZeroRotator, SeatMID);
	Part(CabRoot, EShape::Cube, FVector(-S.X * 0.38f, 0, -S.Z * 0.05f), FVector(0.1f, 0.5f, 0.6f), FRotator(10, 0, 0), SeatMID);
	Part(CabRoot, EShape::Cube, FVector(S.X * 0.38f, 0, -S.Z * 0.22f), FVector(0.22f, S.Y * 0.8f, 0.25f), FRotator(-20, 0, 0), DarkMID);
	for (int32 g = 0; g < 3; ++g)
		Part(CabRoot, EShape::Cylinder, FVector(S.X * 0.31f, -0.25f + g * 0.25f, -S.Z * 0.1f), FVector(0.11f, 0.11f, 0.01f), FRotator(70, 0, 0), GaugeMID)->bCastDynamicShadow = false;
	Part(CabRoot, EShape::Cylinder, FVector(-S.X * 0.12f, -0.33f, -S.Z * 0.18f), FVector(0.04f, 0.04f, 0.22f), FRotator::ZeroRotator, DarkMID);
	Part(CabRoot, EShape::Cylinder, FVector(-S.X * 0.12f, 0.33f, -S.Z * 0.18f), FVector(0.04f, 0.04f, 0.22f), FRotator::ZeroRotator, DarkMID);
	Part(CabRoot, EShape::Sphere, FVector(-S.X * 0.12f, -0.33f, -S.Z * 0.05f), FVector(0.07f), FRotator::ZeroRotator, SeatMID);
	Part(CabRoot, EShape::Sphere, FVector(-S.X * 0.12f, 0.33f, -S.Z * 0.05f), FVector(0.07f), FRotator::ZeroRotator, SeatMID);
	// wiper
	WiperPivot = Pivot(CabRoot, FVector(S.X * 0.5f + 0.03f, 0, -S.Z * 0.4f));
	Part(WiperPivot, EShape::Cube, FVector(0, 0, S.Z * 0.3f), FVector(0.02f, 0.025f, S.Z * 0.6f), FRotator::ZeroRotator, DarkMID)->bCastDynamicShadow = false;
	// mirrors
	for (int32 s = -1; s <= 1; s += 2)
	{
		Part(CabRoot, EShape::Cube, FVector(S.X * 0.45f, s * (S.Y * 0.5f + 0.18f), S.Z * 0.15f), FVector(0.03f, 0.36f, 0.03f), FRotator::ZeroRotator, DarkMID);
		Part(CabRoot, EShape::Cube, FVector(S.X * 0.45f, s * (S.Y * 0.5f + 0.36f), S.Z * 0.15f), FVector(0.05f, 0.2f, 0.3f), FRotator(0, s * 15.f, 0), DarkMID);
		Part(CabRoot, EShape::Cube, FVector(S.X * 0.45f - 0.03f, s * (S.Y * 0.5f + 0.36f), S.Z * 0.15f), FVector(0.01f, 0.17f, 0.26f), FRotator(0, s * 15.f, 0), ChromeMID);
	}
	// rotating beacon
	Part(CabRoot, EShape::Cylinder, FVector(-S.X * 0.3f, S.Y * 0.3f, S.Z * 0.5f + 0.12f), FVector(0.14f, 0.14f, 0.16f), FRotator::ZeroRotator, BeaconMID)->bCastDynamicShadow = false;
	BeaconLight = NewObject<UPointLightComponent>(this);
	BeaconLight->SetupAttachment(CabRoot);
	BeaconLight->SetRelativeLocation(FVector(-S.X * 0.3f, S.Y * 0.3f, S.Z * 0.5f + 0.35f) * M2CM);
	BeaconLight->SetLightColor(FLinearColor(1.f, 0.5f, 0.05f));
	BeaconLight->SetIntensity(0.f);
	BeaconLight->SetAttenuationRadius(900.f);
	BeaconLight->SetCastShadows(false);
	BeaconLight->RegisterComponent();
	if (bRops) Part(CabRoot, EShape::Cube, FVector(0, 0, S.Z * 0.5f + 0.1f), FVector(S.X * 0.9f, S.Y * 0.9f, 0.05f), FRotator::ZeroRotator, DarkMID);

	// seated eye position
	CabCam->AttachToComponent(CabRoot, FAttachmentTransformRules::KeepRelativeTransform);
	CabCam->SetRelativeLocation(FVector(-S.X * 0.1f, 0, S.Z * 0.12f) * M2CM);
	// headlights + work lights on the cab roof
	AddLamp(CabRoot, FVector(S.X * 0.5f, -S.Y * 0.35f, S.Z * 0.5f + 0.05f), FRotator(-18, 0, 0), 9000, true);
	AddLamp(CabRoot, FVector(S.X * 0.5f, S.Y * 0.35f, S.Z * 0.5f + 0.05f), FRotator(-18, 0, 0), 9000, true);
	AddLamp(CabRoot, FVector(-S.X * 0.5f, 0, S.Z * 0.5f + 0.05f), FRotator(-25, 180, 0), 6000, true);
}

void ARWMachine::AddLamp(USceneComponent* Parent, const FVector& L, const FRotator& Dir, float Intensity, bool bWork)
{
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(GEmissive, this);
	M->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.f, 0.93f, 0.8f));
	M->SetScalarParameterValue(TEXT("Strength"), 0.f);
	LampMIDs.Add(M);
	USceneComponent* P = Pivot(Parent, L, Dir);
	Part(P, EShape::Cube, FVector(-0.05f, 0, 0), FVector(0.1f, 0.22f, 0.14f), FRotator::ZeroRotator, DarkMID);
	Part(P, EShape::Cube, FVector(0.002f, 0, 0), FVector(0.02f, 0.18f, 0.11f), FRotator::ZeroRotator, M)->bCastDynamicShadow = false;
	USpotLightComponent* S = NewObject<USpotLightComponent>(this);
	S->SetupAttachment(P);
	S->SetRelativeLocation(FVector(10, 0, 0));
	S->SetIntensityUnits(ELightUnits::Lumens);
	S->SetIntensity(0.f);
	S->SetAttenuationRadius(bWork ? 4500.f : 7000.f);
	S->SetOuterConeAngle(bWork ? 50.f : 32.f);
	S->SetInnerConeAngle(bWork ? 25.f : 14.f);
	S->SetLightColor(FLinearColor(1.f, 0.94f, 0.82f));
	S->SetCastShadows(Lamps.Num() < 1);
	S->ComponentTags.Add(FName(*FString::SanitizeFloat(Intensity)));
	S->RegisterComponent();
	Lamps.Add(S);
}

void ARWMachine::AddLampAt(USceneComponent* Parent, const FVector& L, const FRotator& Dir, float Lumens, float OuterDeg, float RangeM, const FLinearColor& Color, bool bWork)
{
	// (the switch code dims a glow material per lamp; the model's own glass stays as it is)
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(GEmissive, this);
	M->SetScalarParameterValue(TEXT("Strength"), 0.f);
	LampMIDs.Add(M);
	USpotLightComponent* S = NewObject<USpotLightComponent>(this);
	S->SetupAttachment(Pivot(Parent, L, Dir));
	S->SetIntensityUnits(ELightUnits::Lumens);
	S->SetIntensity(0.f);
	S->SetAttenuationRadius(FMath::Clamp(RangeM, 5.f, 200.f) * M2CM);
	S->SetOuterConeAngle(FMath::Clamp(OuterDeg, 5.f, 80.f));
	S->SetInnerConeAngle(FMath::Clamp(OuterDeg, 5.f, 80.f) * 0.5f);
	S->SetLightColor(Color);
	S->SetCastShadows(Lamps.Num() < 1);
	S->ComponentTags.Add(FName(*FString::SanitizeFloat(FMath::Clamp(Lumens, 100.f, 100000.f))));
	S->RegisterComponent();
	Lamps.Add(S);
	(void)bWork;
}

FHydCyl ARWMachine::MakeCyl(USceneComponent* A, const FVector& ALocalM, USceneComponent* B, const FVector& BLocalM, float Radius, float BarrelLen)
{
	FHydCyl C;
	C.A = A; C.ALocal = ALocalM * M2CM; C.B = B; C.BLocal = BLocalM * M2CM; C.BarrelLen = BarrelLen * M2CM;
	C.Barrel = Part(Body, EShape::Cylinder, FVector::ZeroVector, FVector(Radius * 2, Radius * 2, 1), FRotator::ZeroRotator, PaintMID, true);
	C.Rod = Part(Body, EShape::Cylinder, FVector::ZeroVector, FVector(Radius * 1.1f, Radius * 1.1f, 1), FRotator::ZeroRotator, ChromeMID, true);
	C.Barrel->SetUsingAbsoluteLocation(true); C.Barrel->SetUsingAbsoluteRotation(true); C.Barrel->SetUsingAbsoluteScale(true);
	C.Rod->SetUsingAbsoluteLocation(true); C.Rod->SetUsingAbsoluteRotation(true); C.Rod->SetUsingAbsoluteScale(true);
	C.Barrel->SetWorldScale3D(FVector(Radius * 2, Radius * 2, 1));
	C.Rod->SetWorldScale3D(FVector(Radius * 1.1f, Radius * 1.1f, 1));
	return C;
}

FString ARWMachine::HelpText() const
{
	return TR(TEXT("W/S drive   A/D steer   Space brake   I engine   Z/X throttle   L lights   O door   P hood   C camera   Enter exit"));
}

void ARWMachine::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Terrain) return;
	Dt = FMath::Clamp(Dt, 0.001f, 0.05f);
	SimStep(Dt);
}

void ARWMachine::SimStep(float Dt)
{
	Warning.Reset();
	const int32 Sub = 2;
	for (int32 s = 0; s < Sub; ++s)
	{
		DriveStep(Dt / Sub);
		SuspensionStep(Dt / Sub);
	}
	// Load XML before WorkTick so native tool limits/speeds apply to soil physics.
	// Do not infer a folder from ModId: IDs may differ from directory names.
	if (!bVehicleXmlChecked)
	{
		bVehicleXmlChecked = true;
		if (bXmlControlRequested)
		{
			VehicleXml = MakeUnique<FRWVehicleXml>();
			const FString Config = FPaths::Combine(ModFolder, TEXT("vehicle.xml"));
			bXmlControlValid = VehicleXml->Load(Config, this);
			UE_LOG(LogTemp, Log, TEXT("RWXML: vehicle=%s source=XML path=%s status=%s legacyControlFallback=DISABLED"),
				*ModId, *Config, bXmlControlValid ? TEXT("BOUND") : TEXT("REJECTED"));
		}
		else if (!ModId.IsEmpty())
		{
			UE_LOG(LogTemp, Log, TEXT("RWXML: vehicle=%s source=LEGACY (explicit default)"), *ModId);
			// the controls stay the machine's own; a vehicle.xml beside the mod may still give its masses (only <mass> is read)
			const FString Config = FPaths::Combine(ModFolder, TEXT("vehicle.xml"));
			if (!ModFolder.IsEmpty() && FPaths::FileExists(Config)) FRWVehicleXml::LoadMassOnly(Config, this);
		}
	}
	WorkTick(Dt);
	StabilityStep(Dt); // (after the tool: its soil force is this frame's; before ApplyTransform, which shows any tip)
	EngineStep(Dt, 0.f, 0.f);
	GroundEffects(Dt);
	ApplyTransform();
	UpdateWheelVisuals(Dt);
	if (Drive == EDrive::Tracked) UpdateTrackVisuals();
	VisualTick(Dt);
	// Generic XML SceneComponent joints update after native visuals. Avoid binding
	// the same component both here and through a native control in XML.
	if (bXmlControlValid && VehicleXml) VehicleXml->Update(this, Dt);
	for (FHydCyl& C : Cyls) C.Update();
	UpdateHoses();

	// cab details
	DoorAngle = FMath::FInterpTo(DoorAngle, bDoorOpen ? -75.f : 0.f, Dt, 4.f);
	if (DoorPivot) DoorPivot->SetRelativeRotation(FRotator(0, DoorAngle, 0));
	HoodAngle = FMath::FInterpTo(HoodAngle, bHoodOpen ? 55.f : 0.f, Dt, 3.f);
	if (HoodPivot) HoodPivot->SetRelativeRotation(FRotator(HoodAngle, 0, 0));
	if (bWipers || WiperPhase > 0.01f)
	{
		WiperPhase += Dt * 2.2f;
		if (!bWipers && FMath::Fmod(WiperPhase, 2 * PI) < 0.1f) WiperPhase = 0;
		if (WiperPivot) WiperPivot->SetRelativeRotation(FRotator(0, 0, 55.f * FMath::Sin(WiperPhase) - 0.f));
	}
	const float LampOn = bLights && (bEngineOn || Cranking > 0) ? 1.f : 0.f;
	for (int32 k = 0; k < Lamps.Num(); ++k)
	{
		const float I = Lamps[k]->ComponentTags.Num() ? FCString::Atof(*Lamps[k]->ComponentTags[0].ToString()) : 8000.f;
		Lamps[k]->SetIntensity(I * LampOn);
		LampMIDs[k]->SetScalarParameterValue(TEXT("Strength"), 40.f * LampOn);
	}
	if (GaugeMID) GaugeMID->SetScalarParameterValue(TEXT("Strength"), (bEngineOn || Cranking > 0) ? 3.f : 0.f);
	if (BeaconLight)
	{
		const float B = (bEngineOn && bBeacon) ? FMath::Pow(FMath::Max(0.f, FMath::Sin(GetWorld()->GetTimeSeconds() * 7.f)), 4.f) : 0.f;
		BeaconLight->SetIntensity(B * 3000.f);
		if (BeaconMID) BeaconMID->SetScalarParameterValue(TEXT("Strength"), 5.f + B * 60.f * (bEngineOn ? 1.f : 0.f));
	}
	if (Synth)
	{
		// the key turned: the engine starting; switched off (or stalled, out of fuel): the engine stopping
		const bool bRunningNow = bEngineOn || Cranking > 0.f;
		if (bRunningNow && !bSoundRunning) Synth->StartCount.fetch_add(1);
		if (!bRunningNow && bSoundRunning) Synth->StopCount.fetch_add(1);
		bSoundRunning = bRunningNow;
		Synth->Rpm.store(bEngineOn ? Rpm : (Cranking > 0 ? 180.f : 0.f));
		Synth->Load.store(FMath::Clamp(EngineLoad, 0.f, 1.f));
		Synth->Hyd.store(HydLoad);
		Synth->TrackSpeed.store(Drive == EDrive::Tracked ? FMath::Max(FMath::Abs(TrackSpeedL), FMath::Abs(TrackSpeedR)) : 0.f);
		const bool bCrunch = GroundMat == ESoil::Gravel || GroundMat == ESoil::SmallRock || GroundMat == ESoil::LargeRock;
		Synth->Gravel.store(FMath::Clamp(FMath::Abs(Speed) / 6.f, 0.f, 1.f) * (bCrunch ? 1.f : 0.25f));
	}
	// Per-machine accumulator: a static local incorrectly shares updates across all vehicles.
	MaterialUpdateAccumulator += Dt;
	if (MaterialUpdateAccumulator >= 0.5f) {
		MaterialUpdateAccumulator = FMath::Fmod(MaterialUpdateAccumulator, 0.5f);
		ApplyDirt();
	}
}

void ARWMachine::ApplyDirt()
{
	Wear = FMath::Clamp(1.f - Condition, 0.f, 1.f) * 0.8f + FMath::Min(Hours / 4000.f, 0.2f);
	for (UMaterialInstanceDynamic* M : {PaintMID, DarkMID, SteelMID, RubberMID, ChromeMID})
	{
		if (!M) continue;
		M->SetScalarParameterValue(TEXT("Dirt"), FMath::Clamp(Dirt, 0.f, 1.f));
		M->SetScalarParameterValue(TEXT("Wear"), Wear);
	}
	// Chrome receives much less dirt and wear than exposed painted/track surfaces.
	if (ChromeMID) {
		ChromeMID->SetScalarParameterValue(TEXT("Dirt"), FMath::Clamp(Dirt * 0.12f, 0.f, 1.f));
		ChromeMID->SetScalarParameterValue(TEXT("Wear"), Wear * 0.08f);
		ChromeMID->SetScalarParameterValue(TEXT("Oil"), FMath::Clamp(Dirt * 0.15f + Wear * 0.12f, 0.f, 1.f));
	}
}

void ARWMachine::EngineStep(float Dt, float, float)
{
	if (Cranking > 0)
	{
		Cranking -= Dt;
		Rpm = 200.f;
		if (Cranking <= 0) { bEngineOn = Fuel > 0; Rpm = IdleRpm * 1.25f; }
		return;
	}
	if (!bEngineOn) { Rpm = FMath::FInterpTo(Rpm, 0.f, Dt, 3.f); EngineLoad = 0; return; }
	const float WorkKW = WorkPowerKW();
	const float Avail = PowerKW * (1.f + 0.15f * UpEngine) * (Condition < 0.3f ? 0.7f : 1.f);
	EngineLoad = FMath::Clamp((DrivePowerKW + WorkKW) / Avail + 0.05f, 0.f, 1.3f);
	if (bHandThrottle || Drive == EDrive::Tracked)
	{
		const float Target = IdleRpm + ThrottleDial * (MaxRpm - IdleRpm) - FMath::Max(0.f, EngineLoad - 0.5f) * 380.f;
		Rpm = FMath::FInterpTo(Rpm, Target, Dt, 3.f);
	}
	const float GameHours = Dt * TimeScale / 3600.f;
	const float RpmF = Rpm / MaxRpm;
	const float Burn = FuelRate * (0.12f + 0.88f * FMath::Min(EngineLoad, 1.f)) * (0.4f + 0.6f * RpmF) * GameHours;
	Fuel = FMath::Max(0.f, Fuel - Burn);
	Hours += GameHours;
	const float WearRate = (0.0012f + 0.004f * EngineLoad + (bStuck ? 0.01f : 0.f) + (HydLoad > 1.f ? 0.01f : 0.f)) * GameHours;
	Condition = FMath::Max(0.f, Condition - WearRate);
	WearCostAccum += WearRate * Price * 0.08f;
	if (Fuel <= 0.f) { bEngineOn = false; Warning = TEXT("Engine stopped: out of fuel"); }
	if (Condition <= 0.02f) { bEngineOn = false; Warning = TEXT("Engine failure: repair at the machine yard"); }
	if (Fuel < FuelCap * 0.1f) Warning = TEXT("Low fuel");
}

void ARWMachine::DriveStep(float Dt)
{
	const float M = Mass();
	const float Mu = Traction * (1.f + 0.08f * UpTraction);
	const float GradeF = M * GRAV * FMath::Sin(FMath::DegreesToRadians(GroundPitch));
	float Nsum = 0, RollF = 0;
	for (const FRWWheel& W : Wheels)
	{
		Nsum += W.Load;
		RollF += W.Load * 0.04f;
	}
	if (Nsum < 1.f) Nsum = M * GRAV;
	const FSoilState Gs = Terrain ? Terrain->SurfaceState(Terrain->IndexAt(PosM.X, PosM.Y)) : FSoilState();
	RollF = Nsum * Gs.RollRes * (Drive == EDrive::Tracked ? 0.8f : 1.f) + StepRes + DrawbarLoad;
	const float Avail = bEngineOn ? PowerKW * (1.f + 0.15f * UpEngine) * (Condition < 0.3f ? 0.7f : 1.f) : 0.f;
	float Drv = 0.f;
	WheelSlip = 0.f;

	const float Throttle = bEngineOn ? InThrottle : 0.f;
	if (FMath::Abs(Throttle) > 0.05f) bParkBrake = false;
	float BrakeIn = InBrake;

	if (Drive == EDrive::Tracked)
	{
		// Hydrostatic drive: lever sets track speed; force limited by power and track/soil shear strength.
		const float SpeedScale = 0.35f + 0.65f * RpmFrac();
		const float CmdV = (Throttle >= 0 ? MaxSpeedF : MaxSpeedR) * Throttle * SpeedScale;
		const float CmdYaw = InSteer * 28.f * SpeedScale * (1.f - 0.4f * FMath::Abs(Throttle));
		// what the tracks can hold on this ground, and what the engine can push with
		const float Grip = Mu * Nsum;
		const float Fdrive = FMath::Min(Avail * 1000.f / FMath::Max(FMath::Abs(Speed), 0.7f), Grip);
		float Need = M * (CmdV - Speed) / 0.45f + RollF * FMath::Sign(CmdV - Speed + 1e-4f) * (FMath::Abs(CmdV) > 0.01f ? 1.f : 0.f) + GradeF;
		// the brake pedal, the parking brake and a stopped engine (the spring-applied brakes): the tracks are held still
		const bool bBraked = !bEngineOn || BrakeIn > 0.05f || (bParkBrake && FMath::Abs(Throttle) <= 0.05f);
		if (bBraked) Need = M * (0 - Speed) / 0.3f + GradeF;
		// Holding the machine back (going down a slope, slowing down, standing on a slope) is done by the hydrostatic
		// circuit and the brakes, not by the engine's power: it reaches the grip of the tracks at any speed. Only driving
		// forward against a load is limited by the engine. (Taking power / speed for both made the braking weaker the faster
		// the machine ran downhill, and nothing at all with the engine off - a crawler then rolled away down any slope.)
		const bool bHolding = bBraked || FMath::Abs(CmdV) < 0.05f || Need * Speed < 0.f;
		const float Fmax = bHolding ? Grip : Fdrive;
		float F = FMath::Clamp(Need, -Fmax, Fmax);
		if (FMath::Abs(Need) > Fmax && Fmax > 0) WheelSlip = FMath::Clamp(1.f - Fmax / FMath::Abs(Need), 0.f, 1.f) * (FMath::Abs(CmdV) > 0.05f ? 1.f : 0.f);
		float Acc = (F - GradeF) / M;
		const float Res = RollF / M;
		const float NewV = Speed + Acc * Dt;
		// resistance opposes motion but cannot reverse it
		if (FMath::Abs(NewV) <= Res * Dt) Speed = 0; else Speed = NewV - FMath::Sign(NewV) * Res * Dt * (FMath::Abs(CmdV) > 0.01f ? 0.f : 1.f);
		DrivePowerKW = FMath::Abs(F * Speed) / 1000.f + FMath::Abs(CmdYaw) * 0.6f;
		const float YawAcc = (CmdYaw - YawRate) * 4.f * FMath::Clamp(Mu / 0.6f, 0.3f, 1.2f);
		YawRate += YawAcc * Dt;
		const float Om = FMath::DegreesToRadians(YawRate);
		const float SlipMul = 1.f + WheelSlip * 2.f;
		TrackSpeedL = (Speed + Om * TrackGauge * 0.5f) * SlipMul;
		TrackSpeedR = (Speed - Om * TrackGauge * 0.5f) * SlipMul;
		TrackTravelL += TrackSpeedL * Dt; TrackTravelR += TrackSpeedR * Dt;
	}
	else
	{
		// Automatic gearbox with torque converter.
		if (Throttle > 0.05f && Gear <= 0 && Speed > -0.4f) Gear = 1;
		if (Throttle < -0.05f && Gear > 0 && Speed < 0.4f) Gear = -1;
		if (Throttle < -0.05f && Gear > 0) BrakeIn = FMath::Max(BrakeIn, -Throttle);
		if (Throttle > 0.05f && Gear < 0 && Speed < -0.4f) BrakeIn = FMath::Max(BrakeIn, Throttle);
		const float Pedal = (Gear > 0 ? FMath::Max(Throttle, 0.f) : Gear < 0 ? FMath::Max(-Throttle, 0.f) : 0.f) * (BrakeIn > 0.05f ? 0.f : 1.f);
		const float R = Wheels.Num() ? Wheels[0].Radius : 0.6f;
		const int32 GI = FMath::Clamp(Gear > 0 ? Gear : 0, 0, Ratios.Num() - 1);
		const float Ratio = (Ratios.Num() ? Ratios[GI] : 10.f) * FinalDrive;
		const float WheelRpm = FMath::Abs(Speed) / R * 60.f / (2.f * PI) * Ratio;
		const float Stall = IdleRpm + (MaxRpm * 0.82f - IdleRpm) * Pedal;
		if (bEngineOn)
		{
			const float Target = FMath::Max(WheelRpm, Stall);
			Rpm = FMath::FInterpTo(Rpm, FMath::Min(Target, MaxRpm * 1.02f), Dt, 6.f);
		}
		const float TorquePeak = Avail * 1000.f / (1500.f * 2.f * PI / 60.f);
		const float RpmN = (Rpm - 1400.f) / 900.f;
		const float Torque = TorquePeak * FMath::Clamp(1.f - 0.3f * RpmN * RpmN, 0.4f, 1.f);
		const float Conv = FMath::Lerp(2.3f, 1.f, FMath::Clamp(WheelRpm / FMath::Max(Rpm, 1.f), 0.f, 1.f));
		float Fd = bEngineOn ? Pedal * Torque * Ratio * Conv * 0.85f / R : 0.f;
		if (WheelRpm > MaxRpm * 1.01f) Fd = 0;
		if (ShiftTimer > 0.35f && Gear > 0) Fd *= 0.15f; // torque interruption while the gearbox shifts
		Fd = FMath::Min(Fd, Avail * 1000.f * 0.85f / FMath::Max(FMath::Abs(Speed), 0.5f) * Conv);
		float DrivenN = 0; int32 NDriven = 0;
		for (const FRWWheel& W : Wheels) if (W.bDriven) { DrivenN += W.Load; ++NDriven; }
		if (NDriven == 0) DrivenN = Nsum;
		const float Fmax = Mu * DrivenN;
		if (Fd > Fmax) { WheelSlip = FMath::Clamp((Fd - Fmax) / Fd, 0.f, 1.f); Fd = Fmax * 0.88f; }
		const float Dir = Gear < 0 ? -1.f : 1.f;
		DrivePowerKW = Fd * FMath::Abs(Speed) / 1000.f + Pedal * 12.f;
		// brakes: capacity sized for the empty machine; limited by tyre grip
		const float Bf = FMath::Min(BrakeDecel * EmptyMass * 1.2f, Mu * Nsum) * FMath::Clamp(BrakeIn + (bParkBrake ? 1.f : 0.f), 0.f, 1.f);
		const float Engine = (bEngineOn && Pedal < 0.05f) ? 0.02f * Nsum : 0.f; // engine braking
		const float Res = (RollF + Bf + Engine) / M;
		const float NewV = Speed + (Fd * Dir - GradeF) / M * Dt;
		if (FMath::Abs(NewV) <= Res * Dt && Fd < Res * M) Speed = 0; else Speed = NewV - FMath::Sign(NewV) * Res * Dt;
		// auto shift
		ShiftTimer -= Dt;
		if (Gear > 0 && ShiftTimer <= 0)
		{
			if (Rpm > MaxRpm * 0.92f && Gear < NumGears) { Gear++; ShiftTimer = 0.8f; }
			else if (Rpm < IdleRpm * 1.5f && Gear > 1) { Gear--; ShiftTimer = 0.8f; }
		}
		// steering
		if (Drive == EDrive::Articulated)
		{
			Artic = FMath::FInterpConstantTo(Artic, InSteer * MaxSteer, Dt, bEngineOn ? 30.f : 0.f);
			const float A = FMath::DegreesToRadians(Artic);
			YawRate = FMath::RadiansToDegrees(Speed * FMath::Sin(A) / (Wheelbase * 0.5f * (1.f + FMath::Cos(A))));
		}
		else
		{
			const float Lim = FMath::Lerp(MaxSteer, MaxSteer * 0.25f, FMath::Clamp(FMath::Abs(Speed) / 20.f, 0.f, 1.f));
			SteerAngle = FMath::FInterpConstantTo(SteerAngle, InSteer * Lim, Dt, 45.f);
			YawRate = FMath::RadiansToDegrees(Speed * FMath::Tan(FMath::DegreesToRadians(SteerAngle)) / Wheelbase);
		}
		// lateral grip limit (understeer / slide)
		const float LatAcc = FMath::Abs(Speed * FMath::DegreesToRadians(YawRate));
		const float LatMax = Mu * GRAV * 0.95f;
		if (LatAcc > LatMax && LatAcc > 0) { YawRate *= LatMax / LatAcc; WheelSlip = FMath::Max(WheelSlip, 0.3f); }
		for (FRWWheel& W : Wheels) W.Spin += (Speed / W.Radius * (1.f + (W.bDriven ? WheelSlip * 3.f : 0.f))) * Dt * 57.2958f;
	}
	Drv = 0; (void)Drv;
	// Integrate pose
	Yaw += YawRate * Dt;
	const FVector Move = Fwd2() * Speed * Dt;
	FVector NewPos = PosM + Move;
	if (Terrain)
	{
		NewPos.X = FMath::Clamp(NewPos.X, -ARWTerrain::Half + 3.f, ARWTerrain::Half - 3.f);
		NewPos.Y = FMath::Clamp(NewPos.Y, -ARWTerrain::Half + 3.f, ARWTerrain::Half - 3.f);
	}
	PosM.X = NewPos.X; PosM.Y = NewPos.Y;
	FVector Push;
	if (CollisionResolver && CollisionResolver(this, Push))
	{
		PosM += Push;
		Speed *= 0.3f;
	}
	Odometer += FMath::Abs(Speed) * Dt;
	// stuck detection (emerges from ruts, step resistance and traction)
	if (FMath::Abs(InThrottle) > 0.5f && FMath::Abs(Speed) < 0.15f && bEngineOn && (WheelSlip > 0.3f || StepRes > 0.25f * Nsum)) StuckTime += Dt; else StuckTime = FMath::Max(0.f, StuckTime - Dt * 2.f);
	bStuck = StuckTime > 2.f;
}

void ARWMachine::SuspensionStep(float Dt)
{
	if (!Terrain || Wheels.Num() == 0) return;
	const float CY = FMath::Cos(FMath::DegreesToRadians(Yaw)), SY = FMath::Sin(FMath::DegreesToRadians(Yaw));
	const int32 Nw = Wheels.Num();
	// 1) sample ground under each wheel (wheel-shape aware) and fit the ground plane.
	double Sxx = 0, Syy = 0, Sxy = 0, Sx = 0, Sy = 0, Sz = 0, Sxz = 0, Syz = 0;
	TArray<float, TInlineAllocator<16>> G; G.SetNum(Nw);
	TArray<FVector2D, TInlineAllocator<16>> LP; LP.SetNum(Nw);
	StepRes = 0.f;
	const float Dir = Speed >= 0 ? 1.f : -1.f;
	for (int32 k = 0; k < Nw; ++k)
	{
		FRWWheel& W = Wheels[k];
		FVector2D L = W.Local;
		float WYaw = 0.f;
		if (Drive == EDrive::Articulated && W.bFront)
		{
			const float A = FMath::DegreesToRadians(Artic * 0.5f);
			L = FVector2D(L.X * FMath::Cos(A) - L.Y * FMath::Sin(A), L.X * FMath::Sin(A) + L.Y * FMath::Cos(A));
			WYaw = Artic * 0.5f;
		}
		else if (Drive == EDrive::Articulated)
		{
			const float A = FMath::DegreesToRadians(-Artic * 0.5f);
			L = FVector2D(L.X * FMath::Cos(A) - L.Y * FMath::Sin(A), L.X * FMath::Sin(A) + L.Y * FMath::Cos(A));
		}
		LP[k] = L;
		const float WX = PosM.X + CY * L.X - SY * L.Y, WY = PosM.Y + SY * L.X + CY * L.Y;
		const float R = W.Radius;
		float Best = -1e9f;
		if (W.bTrack)
		{
			// a track shoe chain spans the bumps between rollers: rest on the high points, averaged over ~0.7 m
			float Mx = -1e9f, Sum = 0.f;
			for (int32 s = -2; s <= 2; ++s) { const float H = GroundAt(WX + CY * s * 0.18f, WY + SY * s * 0.18f); Mx = FMath::Max(Mx, H); Sum += H; }
			Best = FMath::Lerp(Sum / 5.f, Mx, 0.6f);
		}
		else
		for (int32 s = -2; s <= 2; ++s)
		{
			const float O = s * R * 0.3f;
			const float Lift = R - FMath::Sqrt(FMath::Max(R * R - O * O, 0.f));
			Best = FMath::Max(Best, GroundAt(WX + CY * O, WY + SY * O) - Lift);
		}
		G[k] = Best;
		W.Ground = Best;
		// step ahead of the wheel (ruts, kerbs, spoil heaps)
		const float Ahead = GroundAt(WX + CY * R * 0.85f * Dir, WY + SY * R * 0.85f * Dir) - R * 0.12f;
		const float Step = Ahead - Best;
		if (Step > 0.03f) StepRes += W.Load * FMath::Clamp(Step / (R * 0.75f), 0.f, 1.6f) * (W.bTrack ? 0.25f : 1.f);
		if (W.Pivot && !W.bTrack) W.Pivot->SetRelativeRotation(FRotator(0, (W.bSteer ? SteerAngle : 0.f) + WYaw, 0));
		Sxx += L.X * L.X; Syy += L.Y * L.Y; Sxy += L.X * L.Y; Sx += L.X; Sy += L.Y; Sz += Best; Sxz += L.X * Best; Syz += L.Y * Best;
	}
	// least squares plane z = a + b x + c y
	FMatrix Mtx(FPlane(Nw, Sx, Sy, 0), FPlane(Sx, Sxx, Sxy, 0), FPlane(Sy, Sxy, Syy, 0), FPlane(0, 0, 0, 1));
	const float Det = Mtx.Determinant();
	float A = Sz / Nw, B = 0, C = 0;
	if (FMath::Abs(Det) > 1e-4f)
	{
		const FMatrix Inv = Mtx.Inverse();
		const FVector4 Rhs(Sz, Sxz, Syz, 0);
		A = Inv.M[0][0] * Rhs.X + Inv.M[1][0] * Rhs.Y + Inv.M[2][0] * Rhs.Z;
		B = Inv.M[0][1] * Rhs.X + Inv.M[1][1] * Rhs.Y + Inv.M[2][1] * Rhs.Z;
		C = Inv.M[0][2] * Rhs.X + Inv.M[1][2] * Rhs.Y + Inv.M[2][2] * Rhs.Z;
	}
	// tracks/wheels rest on the high points: lift plane so no contact point is buried
	float MaxPen = 0;
	for (int32 k = 0; k < Nw; ++k) MaxPen = FMath::Max(MaxPen, G[k] - (A + B * LP[k].X + C * LP[k].Y));
	A += MaxPen * (Drive == EDrive::Tracked ? 0.85f : 0.4f);
	// The undercarriage is a heavy rigid frame: it rocks onto the ground plane with inertia
	// (spring-damper on height, pitch and roll) instead of snapping to every terrain facet.
	const float TPitch = FMath::RadiansToDegrees(FMath::Atan(B)), TRoll = -FMath::RadiansToDegrees(FMath::Atan(C));
	if (!bFrameInit || FMath::Abs(RootZ - A) > 0.6f) { RootZ = A; GroundPitch = TPitch; GroundRoll = TRoll; RootVz = PitchVel = RollVel = 0.f; bFrameInit = true; }
	const float Wn = Drive == EDrive::Tracked ? 9.f : 14.f, Zeta = 0.75f;
	auto Spring = [&](float& X, float& V, float Target, float W)
	{
		V += (W * W * (Target - X) - 2.f * Zeta * W * V) * Dt;
		X += V * Dt;
	};
	Spring(RootZ, RootVz, A, Wn * 1.4f);
	Spring(GroundPitch, PitchVel, TPitch, Wn);
	Spring(GroundRoll, RollVel, TRoll, Wn);
	RootZ = FMath::Max(RootZ, A - 0.05f); // never sink into the ground
	PosM.Z = RootZ;

	// 2) sprung body: heave / pitch / roll with spring-dampers at every contact point.
	const float M = Mass();
	const float K = EmptyMass * GRAV / (Nw * SpringSag);
	const float Cd = 2.f * 0.45f * FMath::Sqrt(K * EmptyMass / Nw);
	const float Iy = M * (Wheelbase * Wheelbase / 10.f + 0.6f), Ix = M * (TrackGauge * TrackGauge / 8.f + 0.4f);
	float Fz = 0, Ty = 0, Tx = 0;
	const float Sag0 = SpringSag;
	for (int32 k = 0; k < Nw; ++k)
	{
		FRWWheel& W = Wheels[k];
		const float Dev = G[k] - (A + B * LP[k].X + C * LP[k].Y);
		const float Q = BodyZ + LP[k].X * FMath::DegreesToRadians(Pitch) - LP[k].Y * FMath::DegreesToRadians(Roll);
		const float Qd = BodyVz + LP[k].X * FMath::DegreesToRadians(PitchRate) - LP[k].Y * FMath::DegreesToRadians(RollRate);
		const float DevVel = (Dev - W.Comp) / FMath::Max(Dt, 1e-4f);
		W.Comp = Dev;
		float F = K * (Sag0 + Dev - Q) + Cd * (FMath::Clamp(DevVel, -3.f, 3.f) - Qd);
		F = FMath::Max(F, 0.f);
		W.Load = F;
		Fz += F; Ty += F * LP[k].X; Tx += -F * LP[k].Y;
	}
	// accelerating / braking pitches the body (dive & squat), starting and stopping makes it rock
	const float RawAcc = (Speed - PrevSpeed) / FMath::Max(Dt, 1e-4f);
	PrevSpeed = Speed;
	SmoothAcc = FMath::Lerp(SmoothAcc, FMath::Clamp(RawAcc, -6.f, 6.f), FMath::Clamp(Dt * 8.f, 0.f, 1.f));
	const float AccLong = SmoothAcc;
	const float AccLat = Speed * FMath::DegreesToRadians(YawRate);
	BodyVz += (Fz / M - GRAV) * Dt;
	PitchRate += FMath::RadiansToDegrees((Ty - M * AccLong * CgHeight) / Iy) * Dt;
	RollRate += FMath::RadiansToDegrees((Tx + M * AccLat * CgHeight * 0.6f) / Ix) * Dt;
	// vibration (rollers, rough tracks)
	if (VibrationLevel > 0) BodyVz += FMath::Sin(GetWorld() ? GetWorld()->GetTimeSeconds() * 180.f : 0.f) * VibrationLevel * Dt * 4.f;
	BodyZ = FMath::Clamp(BodyZ + BodyVz * Dt, -0.3f, 0.25f);
	Pitch = FMath::Clamp(Pitch + PitchRate * Dt, -6.f, 6.f);
	Roll = FMath::Clamp(Roll + RollRate * Dt, -6.f, 6.f);
	if (FMath::Abs(BodyZ) >= 0.299f) BodyVz *= 0.5f;
}

void ARWMachine::GroundEffects(float Dt)
{
	if (!Terrain) return;
	const float CY = FMath::Cos(FMath::DegreesToRadians(Yaw)), SY = FMath::Sin(FMath::DegreesToRadians(Yaw));
	const int32 Ci = Terrain->IndexAt(PosM.X, PosM.Y);
	GroundMat = Terrain->SurfaceMat(Ci);
	GroundMoist = Terrain->MoistureAt(Ci);
	GroundComp = Terrain->SurfaceComp(Ci);
	float MuSum = 0; int32 MuN = 0; float SinkSum = 0;
	LastDust += Dt;
	for (FRWWheel& W : Wheels)
	{
		FVector2D L = W.Local;
		if (Drive == EDrive::Articulated)
		{
			const float A = FMath::DegreesToRadians((W.bFront ? 1.f : -1.f) * Artic * 0.5f);
			L = FVector2D(L.X * FMath::Cos(A) - L.Y * FMath::Sin(A), L.X * FMath::Sin(A) + L.Y * FMath::Cos(A));
		}
		const float WX = PosM.X + CY * L.X - SY * L.Y, WY = PosM.Y + SY * L.X + CY * L.Y;
		if (!Terrain->InBounds(WX, WY)) continue;
		const int32 i = Terrain->IndexAt(WX, WY);
		const FSoilState S = Terrain->SurfaceState(i);
		MuSum += S.Friction; ++MuN;
		const float Moist = Terrain->MoistureAt(i);
		// imprint every ~0.35 m of travel, or continuously while spinning
		const FVector2D Here(WX, WY);
		const bool bMoved = FVector2D::Distance(Here, W.LastImprint) > 0.35f;
		const bool bSpin = WheelSlip > 0.25f && FMath::Abs(InThrottle) > 0.3f;
		W.RutSpinTimer = bSpin ? FMath::Min(W.RutSpinTimer + Dt, 0.4f) : 0.f;
		const bool bSpinStep = bSpin && W.RutSpinTimer >= 0.20f;
		const float SpinElapsed = W.RutSpinTimer;
		if (bMoved || bSpinStep)
		{
			W.LastImprint = Here;
			W.RutSpinTimer = 0.f;
			// One shared terrain-contact solver for every machine; no rail-like
			// centerline carving. The contact patch is rasterized as an area.
			// A highly unloaded/unsupported wheel must NOT imprint a deep pit.
			const float ExpectedGround = RootZ +
				FMath::Tan(FMath::DegreesToRadians(GroundPitch)) * L.X -
				FMath::Tan(FMath::DegreesToRadians(GroundRoll)) * L.Y;
			const float SupportGap = ExpectedGround - W.Ground;
			const float MaxGap = W.bTrack ? 0.30f : 0.22f;
			if (W.Load > 1.f && SupportGap <= MaxGap)
			{
				const int32 RoadRollersPerSide = FMath::Max(1, Wheels.Num() / 2);
				const float ContactL = W.bTrack
					? FMath::Max(TrackLength / RoadRollersPerSide, ARWTerrain::CS * 0.7f)
					: FMath::Max(W.Radius * 0.55f, 0.16f);
				const float Pass = bMoved ? 1.f : FMath::Clamp(SpinElapsed * 2.f, 0.f, 0.40f);
				const FVector2D Forward(CY, SY);
				if (W.bDual && !W.bTrack)
				{
					// AddWheel() widens W.Width to 2.1x for dual tyres.
					// The inner tyre is offset towards the vehicle centre.
					const float TyreWidth = W.Width / 2.1f;
					const FVector2D Side(-SY, CY);
					const FVector2D Inner = Here - Side * FMath::Sign(W.Local.Y) * TyreWidth * 1.08f;
					Terrain->ApplyContactRut(Here, Forward, ContactL, TyreWidth, W.Load * 0.5f, WheelSlip, Pass, false, W.Radius * 0.6f);
					Terrain->ApplyContactRut(Inner, Forward, ContactL, TyreWidth, W.Load * 0.5f, WheelSlip, Pass, false, W.Radius * 0.6f);
				}
				else
				{
					Terrain->ApplyContactRut(Here, Forward, ContactL, W.Width, W.Load, WheelSlip, Pass, W.bTrack, W.Radius * 0.6f);
				}
			}
			// a spinning wheel digs until the axle/belly rests on the ground (about 0.7 x radius below the surroundings)
			const float Around = FMath::Max(Terrain->HeightAt(WX + (-SY) * (W.Width + 0.8f), WY + CY * (W.Width + 0.8f)), Terrain->HeightAt(WX - (-SY) * (W.Width + 0.8f), WY - CY * (W.Width + 0.8f)));
			const bool bCanDig = Around - Terrain->Height[i] < W.Radius * 0.7f;
			if (bSpin && W.Load > 1.f && SupportGap <= MaxGap && bCanDig && SoilProps(Terrain->SurfaceMat(i)).bDiggable && Terrain->SurfaceMat(i) != ESoil::Asphalt)
			{
				// spinning tyres/tracks dig themselves in and throw material behind
				FPayload Thrown;
				Terrain->RemoveAt(i, 0.012f * WheelSlip, Thrown);
				if (Fx && Thrown.Total() > 0) Fx->SpawnSoil(FVector(WX - CY * W.Radius * FMath::Sign(Speed + 0.01f), WY - SY * W.Radius * FMath::Sign(Speed + 0.01f), Terrain->HeightAt(WX, WY) + W.Radius * 0.6f), FVector(-CY, -SY, 0.6f) * 3.5f * FMath::Sign(InThrottle) , Thrown, 0.15f);
			}
		}
		W.Sink = FMath::Max(0.f, Terrain->HeightAt(WX + CY * 1.0f, WY + SY * 1.0f) - W.Ground);
		SinkSum += FMath::Min(W.Sink, 1.f);
		// dust & mud
		if (Fx && FMath::Abs(Speed) > 1.2f && Moist < 0.3f && Terrain->SurfaceMat(i) != ESoil::Asphalt && LastDust > 0.05f && FMath::FRand() < FMath::Abs(Speed) * 0.04f)
			Fx->SpawnDust(FVector(WX - CY * W.Radius * FMath::Sign(Speed), WY - SY * W.Radius * FMath::Sign(Speed), W.Ground + 0.3f), 0.8f + FMath::Abs(Speed) * 0.08f, FVector(-CY, -SY, 0) * Speed * 0.2f);
		if (Moist > 0.55f && FMath::Abs(Speed) > 0.2f) Dirt = FMath::Min(1.f, Dirt + Dt * 0.01f * FMath::Abs(Speed) * Moist);
	}
	if (LastDust > 0.05f) LastDust = 0;
	// crawler tracks leave their grouser pattern on soft ground (not on asphalt or hard-packed surfaces)
	if (Drive == EDrive::Tracked && Fx && TrackLength > 0.f)
	{
		for (int32 s = 0; s < 2; ++s)
		{
			const float LX = -TrackLength * 0.5f + 0.5f, LY = (s == 0 ? -1.f : 1.f) * TrackGauge * 0.5f;
			const float PX = PosM.X + CY * LX - SY * LY, PY = PosM.Y + SY * LX + CY * LY;
			if (!Terrain->InBounds(PX, PY) || FVector2D::Distance(FVector2D(PX, PY), LastPrint[s]) < 0.95f) continue;
			// Visual impressions must not appear beneath a suspended track over a gap.
			const float ExpectedZ = RootZ +
				FMath::Tan(FMath::DegreesToRadians(GroundPitch)) * LX -
				FMath::Tan(FMath::DegreesToRadians(GroundRoll)) * LY;
			if (ExpectedZ - Terrain->HeightAt(PX, PY) > 0.30f) continue;
			LastPrint[s] = FVector2D(PX, PY);
			const int32 j = Terrain->IndexAt(PX, PY);
			const ESoil G = Terrain->SurfaceMat(j);
			const bool bHard = G == ESoil::Asphalt || G == ESoil::LargeRock || (Terrain->SurfaceComp(j) > 0.88f && Terrain->MoistureAt(j) < 0.35f);
			if (bHard || Terrain->Height[j] < Terrain->WaterZ) continue;
			// pressed deeper into soft ground; the imprint follows the machine's own heading, with the small wander of a real track
			const FSoilState PrS = Terrain->SurfaceState(j);
			const float Press = FMath::Clamp(40.f / FMath::Max(PrS.Bearing, 10.f) + Terrain->MoistureAt(j), 0.35f, 1.6f);
			const float Wander = RWNoise2(PX * 0.31f, PY * 0.31f, 213);
			const FVector2D Side(-SY, CY);
			const FVector2D PrP = FVector2D(PX, PY) + Side * (Wander * 0.04f);
			// laid on the ground under it, across the whole width of the track: neither over the rut nor buried in its sides
			const float Zp = (Terrain->HeightAt(PrP.X, PrP.Y) + Terrain->HeightAt(PrP.X + Side.X * TrackWidth * 0.4f, PrP.Y + Side.Y * TrackWidth * 0.4f) + Terrain->HeightAt(PrP.X - Side.X * TrackWidth * 0.4f, PrP.Y - Side.Y * TrackWidth * 0.4f)) / 3.f;
			Fx->AddTrackPrint(FVector(PrP.X, PrP.Y, Zp), Yaw + Wander * 1.6f + YawRate * 0.05f, Terrain->NormalAt(PX, PY), TrackWidth * 0.95f, G, Press);
		}
	}
	if (MuN) Traction = FMath::Lerp(Traction, MuSum / MuN, 0.2f);
	Sinkage = Wheels.Num() ? SinkSum / Wheels.Num() : 0.f;
	if (GroundMoist < 0.3f && Dirt > 0) Dirt = FMath::Max(0.f, Dirt - Dt * 0.0005f);
}

void ARWMachine::UpdateWheelVisuals(float Dt)
{
	for (FRWWheel& W : Wheels)
	{
		if (!W.Pivot || W.bTrack) continue;
		FVector2D L = W.Local;
		if (Drive == EDrive::Articulated)
		{
			const float A = FMath::DegreesToRadians((W.bFront ? 1.f : -1.f) * Artic * 0.5f);
			L = FVector2D(L.X * FMath::Cos(A) - L.Y * FMath::Sin(A), L.X * FMath::Sin(A) + L.Y * FMath::Cos(A));
		}
		// Wheel centre follows the ground in the tilted root frame
		const float Plane = RootZ + FMath::Tan(FMath::DegreesToRadians(GroundPitch)) * L.X - FMath::Tan(FMath::DegreesToRadians(-GroundRoll)) * L.Y;
		const float Dz = (W.Ground - Plane);
		W.Pivot->SetRelativeLocation(FVector(L.X, L.Y, Dz + W.Radius) * M2CM);
		if (W.Spinner) W.Spinner->SetRelativeRotation(FRotator(-W.Spin, 0, 0));
	}
}

void ARWMachine::ApplyTransform()
{
	const FVector ActLoc = FVector(PosM.X, PosM.Y, RootZ) * M2CM;
	const FQuat ActRot = FRotator(GroundPitch, Yaw, GroundRoll).Quaternion();
	// tipped by its weight and the soil's force (StabilityStep): about the support edge TipDir points to (machine frame)
	const float Cy = FMath::Cos(FMath::DegreesToRadians(Yaw)), Sy = FMath::Sin(FMath::DegreesToRadians(Yaw));
	const bool bTip = TipAngle > 0.01f;
	const FVector2D EdgeW(TipDir.X * Cy - TipDir.Y * Sy, TipDir.X * Sy + TipDir.Y * Cy);
	const float RotAngle = bTip ? TipAngle : PropAngle;
	if (RotAngle > 0.01f)
	{
		// rotate the whole machine about that edge of its tracks (U points from the edge back towards the centre)
		const FVector U = bTip ? FVector(-EdgeW.X, -EdgeW.Y, 0.f) : FVector(PropDir.X, PropDir.Y, 0.f);
		const float PivotD = bTip ? TipPivot : PropPivot;
		const FVector Axis = FVector::CrossProduct(FVector::UpVector, U).GetSafeNormal();
		const FQuat Q(Axis, -FMath::DegreesToRadians(RotAngle));
		const FVector PivotP = ActLoc - U * PivotD * M2CM;
		SetActorLocationAndRotation(PivotP + Q.RotateVector(ActLoc - PivotP), Q * ActRot);
	}
	else SetActorLocationAndRotation(ActLoc, ActRot);
	if (Drive == EDrive::Tracked)
	{
		// crawlers have no suspension: house and undercarriage are one rigid frame riding the ground plane
		Body->SetRelativeLocation(FVector::ZeroVector);
		Body->SetRelativeRotation(FRotator::ZeroRotator);
		return;
	}
	Body->SetRelativeLocation(FVector(0, 0, BodyZ * M2CM));
	Body->SetRelativeRotation(FRotator(Pitch, 0, Roll));
}

void ARWMachine::MassParts(TArray<FMassPart>& Out) const
{
	// a machine with no parts of its own: all its mass at its centre of gravity height (the payload with it)
	const bool bXml = XmlMassKg.Contains(TEXT("total"));
	FMassPart P; P.Name = TEXT("machine"); P.Kg = bXml ? XmlMassKg[TEXT("total")] : EmptyMass;
	P.At = GetActorTransform().TransformPosition(FVector(0.f, 0.f, CgHeight) * M2CM) * CM2M;
	P.Source = bXml ? TEXT("vehicle.xml") : ModId.IsEmpty() ? TEXT("built-in machine list") : TEXT("mod.json mass_kg");
	Out.Add(P);
	if (PayloadKg() > 0.f) { FMassPart L = P; L.Name = TEXT("load"); L.Kg = PayloadKg(); L.Source = TEXT("what it carries"); Out.Add(L); }
}

void ARWMachine::StabilityStep(float Dt)
{
	if (Drive != EDrive::Tracked || Wheels.Num() == 0 || !FMath::IsFinite(Dt) || Dt <= 0.f) { TipAngle = TipRate = 0.f; return; }
	TArray<FMassPart> Parts;
	MassParts(Parts);
	// everything in the machine's frame as it is drawn now (any tip it already has included): gravity then leans in that
	// frame as the machine tips, which is what brings it back (or carries it on over)
	const FTransform AT = GetActorTransform();
	const FVector Gm = AT.InverseTransformVectorNoScale(FVector(0.f, 0.f, -GRAV));
	double M = 0.0; FVector Sum = FVector::ZeroVector, Fs = FVector::ZeroVector, Mo = FVector::ZeroVector;
	TArray<FVector, TInlineAllocator<12>> Loc;
	for (const FMassPart& P : Parts)
	{
		const FVector L = AT.InverseTransformPosition(P.At * M2CM) * CM2M;
		Loc.Add(L);
		M += P.Kg; Sum += L * P.Kg;
		const FVector F = Gm * P.Kg;
		Fs += F; Mo += FVector::CrossProduct(L, F);
	}
	if (M <= 1.0) return;
	TotalMassKg = (float)M;
	ComLocal = Sum / M;
	// the soil's force on the tool
	FVector ToolAtW = PosM;
	FVector Ft = ToolForceN(ToolAtW);
	if (!TestToolForceN.IsNearlyZero()) { Ft = TestToolForceN; ToolAtW = TestToolAt; }
	if (!Ft.IsNearlyZero())
	{
		const FVector L = AT.InverseTransformPosition(ToolAtW * M2CM) * CM2M, F = AT.InverseTransformVectorNoScale(Ft);
		Fs += F; Mo += FVector::CrossProduct(L, F);
	}
	// the support: the tracks' footprint (the road wheels' run, out to the tracks' outer edges)
	float Xf = -1e9f, Xr = 1e9f;
	for (const FRWWheel& Wh : Wheels) { Xf = FMath::Max(Xf, (float)Wh.Local.X); Xr = FMath::Min(Xr, (float)Wh.Local.X); }
	Xf = FMath::Max(Xf, TrackLength * 0.5f); Xr = FMath::Min(Xr, -TrackLength * 0.5f);
	const float Yr = TrackGauge * 0.5f + TrackWidth * 0.5f, Yl = -Yr;
	// where the line of the resultant meets the ground plane (z = 0 here): its moment about that point has no x / y part
	if (Fs.Z > -1.f) { StabilityMargin = -1.f; return; } // (nothing presses it on the ground: lifted clear)
	const float Px = (float)(-Mo.Y / Fs.Z), Py = (float)(Mo.X / Fs.Z);
	WeightAt = FVector2D(Px, Py);
	const float Edge[4] = {Xf - Px, Px - Xr, Py - Yl, Yr - Py}; // front, rear, left, right
	const FVector2D Out[4] = {FVector2D(1.f, 0.f), FVector2D(-1.f, 0.f), FVector2D(0.f, -1.f), FVector2D(0.f, 1.f)};
	const float Dist[4] = {Xf, -Xr, -Yl, Yr};
	int32 Worst = 0;
	for (int32 e = 1; e < 4; ++e) if (Edge[e] < Edge[Worst]) Worst = e;
	StabilityMargin = Edge[Worst];
	// the ground's reaction on each corner (the resultant shared out by where it meets the support)
	const float W = (float)-Fs.Z;
	const float ShareX = FMath::Clamp((Px - Xr) / FMath::Max(Xf - Xr, 0.1f), 0.f, 1.f), ShareY = FMath::Clamp((Py - Yl) / FMath::Max(Yr - Yl, 0.1f), 0.f, 1.f);
	CornerLoad[0] = W * ShareX * (1.f - ShareY); CornerLoad[1] = W * ShareX * ShareY; CornerLoad[2] = W * (1.f - ShareX) * (1.f - ShareY); CornerLoad[3] = W * (1.f - ShareX) * ShareY;
	if (!bStabilityLogged)
	{
		bStabilityLogged = true;
		FString S;
		for (const FMassPart& P : Parts) S += FString::Printf(TEXT(" %s %.0f kg (%s);"), *P.Name, P.Kg, *P.Source);
		RWLog(FString::Printf(TEXT("Stability %s: %.0f kg in all -%s support %.2f..%.2f x %.2f..%.2f m"), *Model, M, *S, Xr, Xf, Yl, Yr));
	}
	// tipping: only past an edge, about that edge, by the real moment; back down when the moment turns
	if (TipAngle <= 0.f)
	{
		TipRate = 0.f;
		if (StabilityMargin >= 0.f) return;
		TipDir = Out[Worst]; TipPivot = Dist[Worst];
	}
	const float Over = FVector2D::DotProduct(WeightAt, TipDir) - TipPivot; // m past the edge (negative: back inside)
	float I = 0.f;
	for (int32 k = 0; k < Parts.Num(); ++k) I += Parts[k].Kg * (FMath::Square(FVector2D::DotProduct(FVector2D(Loc[k]), TipDir) - TipPivot) + FMath::Square((float)Loc[k].Z));
	I = FMath::Max(I, 1000.f);
	TipRate += FMath::RadiansToDegrees(W * Over / I) * Dt;
	TipRate *= 1.f - FMath::Min(0.8f * Dt, 0.5f); // (the tracks' rubbing and the frame flexing take a little out)
	// the working tool on the ground is a support too: tipping towards it stops where it bears on the ground (the machine
	// then rests on its tracks' edge and its bucket)
	if (TipRate > 0.f && Terrain)
	{
		FVector ToolW = PosM;
		ToolForceN(ToolW);
		const FVector ToolL = AT.InverseTransformPosition(ToolW * M2CM) * CM2M;
		if (FVector2D::DotProduct(FVector2D(ToolL), TipDir) > TipPivot + 0.2f && Terrain->InBounds(ToolW.X, ToolW.Y) && ToolW.Z <= Terrain->HeightAt(ToolW.X, ToolW.Y) + 0.05f)
			TipRate = 0.f;
	}
	TipAngle += TipRate * Dt;
	if (TipAngle <= 0.f) { TipAngle = 0.f; TipRate = 0.f; } // back on its tracks
	if (TipAngle > 30.f) { TipAngle = 30.f; TipRate = FMath::Min(TipRate, 0.f); Warning = TEXT("MACHINE OVERTURNING"); }
	else if (TipAngle > 0.5f) Warning = TEXT("TIPPING - lower the load / bring it in");
}

void ARWMachine::SerializeState(FArchive& Ar)
{
	Ar << PosM << Yaw << Fuel << Condition << Hours << Odometer << bOwned << bRented << UpEngine << UpHyd << UpTraction << UpTool << Dirt << ThrottleDial << bLights << bEngineOn << LastServiceHours;
}
