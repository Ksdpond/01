// Everything the game builds in its world (buildings, rocks, road lines, bridges, water, props, the machines, soil heaps and the
// excavation at the site) written out for the Unreal Editor, so that the level shows the same scene and all of it can be edited
// there: -RWExportScenery=<file> while the game runs, then RWMapTools::ImportScenery in the editor (Tools/make_level_visuals.py).
//
// Every part of the scenery has an id (RWTagScenery, as soon as the game has built it) and belongs to an object (a house, the
// yard, a pole, a 500 m square of road lines...). The level keeps them (RW_Scenery actors); when the game starts it reads the
// level and moves, turns, rescales, removes or changes the model or material of each part the way it was left in the editor
// (RWApplyLevelScenery). Machines (RW_Machine), heaps (RW_Pile) and the dig (RW_Dig) are read by RWMapTools::ReadLevelLayout.
#pragma once

#include "CoreMinimal.h"

class UWorld;
class FRWLayout;

// the file: magic, version, meshes, images, materials, objects, items, heaps, digs (see RWScenery.cpp)
static constexpr int32 RWSceneryMagic = 0x5257534E;
static constexpr int32 RWSceneryVersion = 2;

// object kinds in the file and in the level ("RWKind:" tag)
enum class ERWSceneryKind : uint8 { WorldParts = 0, WholeActor = 1, Machine = 2 };

// gives each part of the scenery the game has just built its id (component tag "RWID:", whole actors "RWObj:")
void RWTagScenery(UWorld* World);
// the level's edits over the tagged scenery; a part or object the level does not have any more is removed
void RWApplyLevelScenery(UWorld* World, const FRWLayout& Layout);
// writes the file; returns the number of drawn objects (instances count one each), -1 on failure
int32 RWExportScenery(UWorld* World, const FString& File);

// shared with the editor's import
FString RWTagValue(const TArray<FName>& Tags, const TCHAR* Prefix);
FString RWTransformText(const FTransform& X);
bool RWParseTransform(const FString& S, FTransform& X);
bool RWNearlySame(const FTransform& A, const FTransform& B);  // within a centimetre / a thousandth
FString RWInstancesText(const TArray<FTransform>& Instances); // a short fingerprint of a list of instances
