#include "RWGame.h"
#include "RHI.h"
#include "RWTerrain.h"
#include "RWEffects.h"
#include "RWWorld.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWAudio.h"
#include "Engine/World.h"
#include "Engine/Canvas.h"
#include "Engine/Font.h"
#include "Engine/Engine.h"
#include "Engine/Texture2D.h"
#include "Engine/GameViewportClient.h"
#include "UnrealClient.h"
#include "Camera/CameraComponent.h"
#include "Camera/CameraActor.h"
#include "GameFramework/SpringArmComponent.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/CommandLine.h"
#include "Modules/ModuleManager.h"
#include "HAL/PlatformMisc.h"
#include "InputCoreTypes.h"
#include "RWLoc.h"
#include "RWMods.h"
#include "RWPlatform.h"

// ============================================================================================
// Player controller
// ============================================================================================
ARWPlayerController::ARWPlayerController()
{
	bShowMouseCursor = false;
	auto A = [&](const TCHAR* N, const TCHAR* L, const FKey& K, const FKey& P = FKey()) { Actions.Add({FName(N), L, K, K, P, P, FKey()}); };
	A(TEXT("Forward"), TEXT("Drive forward / walk"), EKeys::W);
	A(TEXT("Back"), TEXT("Brake / reverse / walk back"), EKeys::S);
	A(TEXT("Left"), TEXT("Steer left"), EKeys::A);
	A(TEXT("Right"), TEXT("Steer right"), EKeys::D);
	A(TEXT("Brake"), TEXT("Service brake"), EKeys::SpaceBar, EKeys::Gamepad_LeftShoulder);
	A(TEXT("Run"), TEXT("Run (on foot)"), EKeys::LeftShift, EKeys::Gamepad_LeftThumbstick);
	A(TEXT("SwingL"), TEXT("Swing / slew left"), EKeys::Q);
	A(TEXT("SwingR"), TEXT("Swing / slew right"), EKeys::E);
	A(TEXT("A1Up"), TEXT("Boom / blade / arm / body UP"), EKeys::R);
	A(TEXT("A1Down"), TEXT("Boom / blade / arm / body DOWN"), EKeys::F);
	A(TEXT("A2Up"), TEXT("Stick out / blade tilt / telescope out"), EKeys::T);
	A(TEXT("A2Down"), TEXT("Stick in / blade tilt / telescope in"), EKeys::G);
	A(TEXT("A3Up"), TEXT("Bucket dump / hoist up"), EKeys::Y);
	A(TEXT("A3Down"), TEXT("Bucket curl / hoist down"), EKeys::H);
	A(TEXT("Engine"), TEXT("Start / stop engine"), EKeys::I, EKeys::Gamepad_RightThumbstick);
	A(TEXT("ThrDown"), TEXT("Hand throttle down"), EKeys::Z);
	A(TEXT("ThrUp"), TEXT("Hand throttle up"), EKeys::X);
	A(TEXT("Tool"), TEXT("Change attachment / ripper / hook"), EKeys::B, EKeys::Gamepad_FaceButton_Right);
	A(TEXT("Work"), TEXT("Tool on/off (hammer, spray, paving, vibration...)"), EKeys::V, EKeys::Gamepad_FaceButton_Bottom);
	A(TEXT("Lights"), TEXT("Head & work lights"), EKeys::L, EKeys::Gamepad_DPad_Up);
	A(TEXT("Door"), TEXT("Open / close cab door"), EKeys::O);
	A(TEXT("Hood"), TEXT("Open / close engine hood"), EKeys::P);
	A(TEXT("Wipers"), TEXT("Wipers"), EKeys::N);
	A(TEXT("Camera"), TEXT("Third person / cab camera"), EKeys::C, EKeys::Gamepad_Special_Left);
	A(TEXT("EnterExit"), TEXT("Get in / out of machine"), EKeys::Enter, EKeys::Gamepad_FaceButton_Top);
	A(TEXT("Use"), TEXT("Use facility (fuel, repair, shop, materials, water)"), EKeys::U, EKeys::Gamepad_FaceButton_Left);
	A(TEXT("Inspect"), TEXT("Inspect / service the machine (on foot)"), EKeys::Tab, EKeys::Gamepad_DPad_Down);
	A(TEXT("Jobs"), TEXT("Job board"), EKeys::J, EKeys::Gamepad_DPad_Right);
	A(TEXT("Map"), TEXT("Map"), EKeys::M, EKeys::Gamepad_DPad_Left);
	A(TEXT("Survey"), TEXT("Survey mode (design a road)"), EKeys::K);
	A(TEXT("Save"), TEXT("Quick save"), EKeys::F5);
	A(TEXT("Load"), TEXT("Quick load"), EKeys::F9);
	A(TEXT("Help"), TEXT("Show / hide key help"), EKeys::F1);
	A(TEXT("TimeWarp"), TEXT("Time x1 / x10"), EKeys::Equals);
	A(TEXT("Menu"), TEXT("Main menu"), EKeys::Escape, EKeys::Gamepad_Special_Right);
	A(TEXT("Editor"), TEXT("Map editor (on foot): place buildings, trees, grass"), EKeys::F8);
	A(TEXT("Guide"), TEXT("Grade guide on/off (cut / fill colours on the ground)"), EKeys::F7);
	A(TEXT("BucketDebug"), TEXT("Debug: show the bucket cavity and soil (pink)"), EKeys::F6);
	A(TEXT("NextMachine"), TEXT("Switch to the next machine (without getting out)"), EKeys::F2);
	A(TEXT("PrevMachine"), TEXT("Switch to the previous machine (without getting out)"), EKeys::F3);
	A(TEXT("HudMode"), TEXT("HUD: full / minimal / hidden"), EKeys::F4);
}

static FString BindFile() { return FPaths::ProjectSavedDir() / TEXT("Config") / TEXT("RoadWorksControls.txt"); }

void ARWPlayerController::LoadBinds()
{
	TArray<FString> Lines;
	if (!FFileHelper::LoadFileToStringArray(Lines, *BindFile())) return;
	for (const FString& L : Lines)
	{
		FString K, V;
		if (!L.Split(TEXT("="), &K, &V)) continue;
		if (K == TEXT("MouseSens")) { MouseSens = FCString::Atof(*V); continue; }
		if (K == TEXT("PadSens")) { PadSens = FCString::Atof(*V); continue; }
		if (K == TEXT("InvertY")) { bInvertY = V.ToBool(); continue; }
		if (K == TEXT("Vibration")) { bVibration = V.ToBool(); continue; }
		// Name=MainKey|PadButton|SecondKey (older files have no second key)
		TArray<FString> Parts; V.ParseIntoArray(Parts, TEXT("|"), false);
		for (FAction& A : Actions)
			if (A.Name.ToString() == K)
			{
				if (Parts.Num() > 0) { const FKey Key(*Parts[0]); if (Key.IsValid() && IsBindableKey(Key)) A.Key = Key; }
				if (Parts.Num() > 1 && !Parts[1].IsEmpty()) { const FKey P(*Parts[1]); A.Pad = P.IsValid() && IsBindableKey(P) ? P : FKey(); }
				if (Parts.Num() > 2 && !Parts[2].IsEmpty()) { const FKey S2(*Parts[2]); A.Alt = S2.IsValid() && IsBindableKey(S2) ? S2 : FKey(); }
			}
	}
	MouseSens = FMath::Clamp(MouseSens, 0.1f, 4.f);
	PadSens = FMath::Clamp(PadSens, 0.1f, 4.f);
}

void ARWPlayerController::SaveBinds()
{
	FString Out;
	for (const FAction& A : Actions) Out += A.Name.ToString() + TEXT("=") + A.Key.GetFName().ToString() + TEXT("|") + (A.Pad.IsValid() ? A.Pad.GetFName().ToString() : FString(TEXT("None"))) + TEXT("|") + (A.Alt.IsValid() ? A.Alt.GetFName().ToString() : FString(TEXT("None"))) + LINE_TERMINATOR;
	Out += FString::Printf(TEXT("MouseSens=%.2f%sPadSens=%.2f%sInvertY=%s%sVibration=%s%s"), MouseSens, LINE_TERMINATOR, PadSens, LINE_TERMINATOR, bInvertY ? TEXT("true") : TEXT("false"), LINE_TERMINATOR, bVibration ? TEXT("true") : TEXT("false"), LINE_TERMINATOR);
	FFileHelper::SaveStringToFile(Out, *BindFile());
}

bool ARWPlayerController::IsBindableKey(const FKey& K)
{
	// "Any Key" is a virtual key that counts as pressed whenever any key is pressed - binding it was the
	// cause of the "Any Key" bug in the controls menu. Analog axes and touch can't be bound to buttons either.
	if (!K.IsValid() || K == EKeys::AnyKey || K == EKeys::Invalid) return false;
	if (K.IsAxis1D() || K.IsAxis2D() || K.IsAxis3D() || K.IsTouch() || K.IsAnalog() || K.IsGesture()) return false;
	return true;
}

FString ARWPlayerController::KeyUsers(const FKey& K, int32 Except) const
{
	if (!K.IsValid()) return FString();
	FString Out;
	for (int32 i = 0; i < Actions.Num(); ++i)
	{
		if (i == Except) continue;
		const FAction& A = Actions[i];
		if (A.Key == K || A.Alt == K || A.Pad == K) Out += (Out.IsEmpty() ? TEXT("") : TEXT(", ")) + TR(A.Label);
	}
	return Out;
}

FString ARWPlayerController::ApplyRebind(int32 Action, int32 Slot, const FKey& K)
{
	if (!Actions.IsValidIndex(Action) || !IsBindableKey(K)) return FString();
	FAction& A = Actions[Action];
	if (Slot == 2) A.Pad = K;
	else if (Slot == 1) A.Alt = K;
	else A.Key = K;
	SaveBinds();
	return KeyUsers(K, Action);
}

void ARWPlayerController::ResetBinds()
{
	for (FAction& A : Actions) { A.Key = A.Default; A.Pad = A.PadDefault; A.Alt = FKey(); }
	SaveBinds();
}

bool ARWPlayerController::Down(FName N) const
{
	for (const FAction& A : Actions) if (A.Name == N) return IsInputKeyDown(A.Key) || (A.Pad.IsValid() && IsInputKeyDown(A.Pad)) || (A.Alt.IsValid() && IsInputKeyDown(A.Alt));
	return false;
}

bool ARWPlayerController::Pressed(FName N) const
{
	for (const FAction& A : Actions) if (A.Name == N) return WasInputKeyJustPressed(A.Key) || (A.Pad.IsValid() && WasInputKeyJustPressed(A.Pad)) || (A.Alt.IsValid() && WasInputKeyJustPressed(A.Alt));
	return false;
}

void ARWPlayerController::BeginPlay()
{
	Super::BeginPlay();
	SetInputMode(FInputModeGameOnly());
	LoadBinds();
	const TCHAR* Cmd = FCommandLine::Get();
	FString V;
	if (FParse::Value(Cmd, TEXT("RWShot="), V)) ShotPath = V;
	else
	{
		TArray<FString> Tok;
		FString(Cmd).ParseIntoArrayWS(Tok);
		for (int32 i = 0; i + 1 < Tok.Num(); ++i)
			if (Tok[i] == TEXT("--screenshot") || Tok[i] == TEXT("-screenshot")) ShotPath = Tok[i + 1].TrimQuotes();
	}
	if ((ShotPath.IsEmpty() || FParse::Param(Cmd, TEXT("RWTitle"))) && !FParse::Param(Cmd, TEXT("rwtest")) && !FParse::Value(Cmd, TEXT("RWScene="), V)) { Menu = ERWMenu::Title; Sel = 0; }
	if (!ShotPath.IsEmpty())
	{
		ShotFrames = 120;
		FParse::Value(Cmd, TEXT("RWBenchFrames="), ShotFrames); // longer runs for measuring the frame rate
		UGameViewportClient::OnScreenshotCaptured().AddUObject(this, &ARWPlayerController::OnShot);
		bShowHelp = true;
		RWLog(FString::Printf(TEXT("Screenshot mode: %s"), *ShotPath));
	}
}

void ARWPlayerController::OnShot(int32 W, int32 H, const TArray<FColor>& Colors)
{
	if (bShotDone || ShotPath.IsEmpty() || Colors.Num() != W * H) return;
	TArray<FColor> Bmp = Colors;
	for (FColor& C : Bmp) C.A = 255;
	IImageWrapperModule& IW = FModuleManager::LoadModuleChecked<IImageWrapperModule>(TEXT("ImageWrapper"));
	TSharedPtr<IImageWrapper> Wr = IW.CreateImageWrapper(EImageFormat::PNG);
	if (!Wr.IsValid() || !Wr->SetRaw(Bmp.GetData(), Bmp.Num() * sizeof(FColor), W, H, ERGBFormat::BGRA, 8)) return;
	const TArray64<uint8> Png = Wr->GetCompressed(0);
	IFileManager::Get().MakeDirectory(*FPaths::GetPath(ShotPath), true);
	bShotDone = FFileHelper::SaveArrayToFile(Png, *ShotPath);
	RWLog(FString::Printf(TEXT("Screenshot %dx%d -> %s (%s)"), W, H, *ShotPath, bShotDone ? TEXT("ok") : TEXT("FAILED")));
}

bool ARWPlayerController::CaptureViewport(const FString& Path)
{
	if (!GEngine || !GEngine->GameViewport || !GEngine->GameViewport->Viewport) return false;
	FViewport* VP = GEngine->GameViewport->Viewport;
	TArray<FColor> Bmp;
	if (!VP->ReadPixels(Bmp) || Bmp.Num() == 0) return false;
	const FIntPoint Sz = VP->GetSizeXY();
	for (FColor& C : Bmp) C.A = 255;
	IImageWrapperModule& IW = FModuleManager::LoadModuleChecked<IImageWrapperModule>(TEXT("ImageWrapper"));
	TSharedPtr<IImageWrapper> W = IW.CreateImageWrapper(EImageFormat::PNG);
	if (!W.IsValid() || !W->SetRaw(Bmp.GetData(), Bmp.Num() * sizeof(FColor), Sz.X, Sz.Y, ERGBFormat::BGRA, 8)) return false;
	const TArray64<uint8> Png = W->GetCompressed(0);
	IFileManager::Get().MakeDirectory(*FPaths::GetPath(Path), true);
	const bool bOk = FFileHelper::SaveArrayToFile(Png, *Path);
	RWLog(FString::Printf(TEXT("Screenshot %dx%d -> %s (%s)"), Sz.X, Sz.Y, *Path, bOk ? TEXT("ok") : TEXT("FAILED")));
	return bOk;
}

void ARWPlayerController::SetCab(bool bCab)
{
	if (!Driving) return;
	Driving->bCabView = bCab;
	Driving->ThirdCam->SetActive(!bCab);
	Driving->CabCam->SetActive(bCab);
}

void ARWPlayerController::EnterMachine(ARWMachine* M)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!M || !GM) return;
	Driving = M;
	if (GM->Walker) GM->Walker->SetActorHiddenInGame(true);
	SetCab(M->bCabView);
	SetViewTargetWithBlend(M, 0.35f);
	if (!M->CanOperate()) GM->Message(TRF(TEXT("{0} is for rent (${1}/day) or sale (${2}) - press U at the Machine Yard to rent or buy."), TR(M->Model), RWNum(M->RentPerDay), RWNum(M->Price)));
}

ARWMachine* ARWPlayerController::NextOperable(const TArray<ARWMachine*>& List, const ARWMachine* From, int32 Dir)
{
	TArray<ARWMachine*> Mine;
	for (ARWMachine* M : List) if (M && M->CanOperate()) Mine.Add(M);
	if (Mine.Num() == 0) return nullptr;
	const int32 At = Mine.IndexOfByKey(From);
	if (At == INDEX_NONE) return Mine[0];
	return Mine[(At + (Dir >= 0 ? 1 : Mine.Num() - 1)) % Mine.Num()];
}

void ARWPlayerController::SwitchMachine(int32 Dir)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!Driving || !GM) return;
	ARWMachine* Next = NextOperable(GM->Machines, Driving, Dir);
	if (!Next || Next == Driving) { GM->Message(TEXT("No other machine of yours to switch to")); return; }
	// the one being left stops where it is, engine as it was, brake on
	ARWMachine* Old = Driving;
	Old->InThrottle = Old->InSteer = Old->InBrake = 0; Old->InA1 = Old->InA2 = Old->InA3 = Old->InA4 = 0;
	Old->bParkBrake = true;
	EnterMachine(Next);
	GM->Message(TRF(TEXT("Now operating: {0}"), TR(Next->Model)));
}

void ARWPlayerController::ExitMachine()
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!Driving || !GM || !GM->Walker) return;
	ARWMachine* M = Driving;
	M->InThrottle = M->InSteer = M->InBrake = 0; M->InA1 = M->InA2 = M->InA3 = M->InA4 = 0;
	M->bParkBrake = true;
	const FVector Side = M->LocalToWorldM(FVector(0, -(M->Radius2D * 0.75f + 1.2f), 0));
	GM->Walker->PosM = FVector(Side.X, Side.Y, GM->Terrain->HeightAt(Side.X, Side.Y));
	GM->Walker->Yaw = M->Yaw;
	GM->Walker->SetActorHiddenInGame(false);
	SetViewTargetWithBlend(GM->Walker, 0.35f);
	Driving = nullptr;
}

ARWMachine* ARWPlayerController::ContextMachine() const
{
	if (Driving) return Driving;
	ARWGameMode* GM = ARWGameMode::Get(this);
	return (GM && GM->Walker) ? GM->NearestMachine(GM->Walker->PosM, 9.f) : nullptr;
}

TArray<FString> ARWPlayerController::MenuItems() const
{
	TArray<FString> I;
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!GM) return I;
	switch (Menu)
	{
	case ERWMenu::Title:
		I = {TR(TEXT("Start work at the site")), TR(TEXT("Continue saved game")), TR(TEXT("Graphics, language & world settings")), TR(TEXT("Controls (rebind keys)")), TR(TEXT("Mods (custom machines)")), TR(TEXT("How to play")), TR(TEXT("Quit to desktop"))};
		break;
	case ERWMenu::Main:
		I = {TR(TEXT("Resume")), TR(TEXT("Save game  (F5)")), TR(TEXT("Load game  (F9)")), TR(TEXT("Graphics, language & world settings")), TR(TEXT("Controls (rebind keys)")), TR(TEXT("Mods (custom machines)")), TR(TEXT("Achievements")), TR(TEXT("How to play")), TR(TEXT("Quit to desktop"))};
		break;
	case ERWMenu::Jobs:
		for (const FRWJob& J : GM->Jobs.Jobs)
		{
			if (J.bPlayer && J.Stakes.Num() < 2 && !J.bAccepted) { I.Add(TR(TEXT("[ survey ]  Your own road - place stakes with K, then publish here"))); continue; }
			const FString St = J.bDone ? TR(TEXT("DONE")) : J.bAccepted ? RWNum(J.Progress * 100.f) + TEXT("%") : TR(TEXT("open"));
			I.Add(FString::Printf(TEXT("[%s]  %s  -  %s   ~$%s"), *St, *TR(FRWJobs::TypeName(J.Type)), *TR(J.Title), *RWNum(J.EstimatedPay())));
		}
		I.Add(TR(TEXT("Close")));
		break;
	case ERWMenu::Shop:
	{
		ARWMachine* M = ContextMachine();
		if (!M) { I = {TR(TEXT("Stand next to a machine (or sit in it) to use the yard")), TR(TEXT("Close"))}; break; }
		I.Add(TRF(TEXT("Refuel {0}  ({1} L, ${2})"), TR(M->Model), RWNum(M->FuelCap - M->Fuel), RWNum((M->FuelCap - M->Fuel) * GM->Eco.FuelPrice)));
		I.Add(TRF(TEXT("Service & repair  (condition {0}%, ${1})"), RWNum(M->Condition * 100.f), RWNum((1.f - M->Condition) * M->Price * 0.1f + M->WearCostAccum)));
		I.Add(M->bOwned ? TR(TEXT("(owned)")) : M->bRented ? TR(TEXT("Return rented machine")) : TRF(TEXT("Rent  (${0} / day)"), RWNum(M->RentPerDay)));
		I.Add(M->bOwned ? TR(TEXT("(owned)")) : TRF(TEXT("Buy  (${0})"), RWNum(M->Price)));
		const int32 L[4] = {M->UpEngine, M->UpHyd, M->UpTraction, M->UpTool};
		const TCHAR* N[4] = {TEXT("Engine power +15%"), TEXT("Hydraulic flow +20%"), TEXT("Tyres / track shoes +8% grip"), TEXT("Bigger bucket / body +15-20%")};
		for (int32 k = 0; k < 4; ++k) I.Add(TRF(TEXT("Upgrade: {0}   L{1}/3  (${2})"), TR(N[k]), FString::FromInt(L[k]), RWNum(M->Price * 0.06f * (L[k] + 1))));
		I.Add(GM->Eco.Plots[0] ? TR(TEXT("Land Plot East: owned")) : TR(TEXT("Buy land: Plot East  ($80,000)  +5% contract pay, yard lease income")));
		I.Add(GM->Eco.Plots[1] ? TR(TEXT("Land Plot West: owned")) : TR(TEXT("Buy land: Plot West  ($60,000)  +5% contract pay, yard lease income")));
		I.Add(TR(TEXT("Close")));
		break;
	}
	case ERWMenu::Plant:
		for (ESoil M : {ESoil::Gravel, ESoil::Sand, ESoil::Laterite, ESoil::SmallRock, ESoil::Asphalt})
			I.Add(TRF(TEXT("Load {0}   (${1} per m3)"), TR(SoilProps(M).Name), RWNum(FRWEconomy::MaterialPrice(M))));
		I.Add(TR(TEXT("Close")));
		break;
	case ERWMenu::Settings:
	{
		static const TCHAR* Q[4] = {TEXT("Low"), TEXT("Medium"), TEXT("High"), TEXT("Epic")};
		const FString On = TR(TEXT("On")), Off = TR(TEXT("Off"));
		I.Add(TRF(TEXT("Language:  < {0} >"), GRWLang == 1 ? FString(TEXT("ไทย (Thai)")) : FString(TEXT("English"))));
		I.Add(TRF(TEXT("Quality preset:  < {0} >"), TR(Q[GM->Quality])));
		I.Add(TRF(TEXT("Resolution scale (TSR upscaling):  < {0}% >"), FString::FromInt(GM->ResScale)));
		I.Add(TRF(TEXT("Lumen global illumination:  < {0} >"), GM->bLumen ? On : Off));
		I.Add(TRF(TEXT("Virtual shadow maps:  < {0} >"), GM->bVSM ? On : Off));
		I.Add(TRF(TEXT("Time speed:  < x{0} >"), RWNum(GM->World->TimeMul)));
		I.Add(TRF(TEXT("Automatic weather:  < {0} >"), GM->World->bAutoWeather ? On : Off));
		I.Add(TRF(TEXT("Weather now:  < {0} >"), TR(GM->World->WeatherName())));
		I.Add(TRF(TEXT("Master volume:  < {0}% >"), RWNum(GM->Volume * 100.f)));
		I.Add(TRF(TEXT("Mouse sensitivity:  < {0} >"), RWNum(MouseSens, 1)));
		I.Add(TRF(TEXT("Controller sensitivity:  < {0} >"), RWNum(PadSens, 1)));
		I.Add(TRF(TEXT("Invert look Y:  < {0} >"), bInvertY ? On : Off));
		I.Add(TRF(TEXT("Controller vibration:  < {0} >"), bVibration ? On : Off));
		I.Add(TR(TEXT("DLSS: NVIDIA plugin not installed - TSR is used instead")));
		I.Add(TR(TEXT("Back")));
		break;
	}
	case ERWMenu::Controls:
		for (int32 i = 0; i < Actions.Num(); ++i)
		{
			const FAction& A = Actions[i];
			// "(!)" marks a key that another action also uses
			const bool bClash = !KeyUsers(A.Key, i).IsEmpty() || (A.Alt.IsValid() && !KeyUsers(A.Alt, i).IsEmpty());
			I.Add(FString::Printf(TEXT("%-48s  [%s]  [%s]   [%s]%s"), *TR(A.Label), *A.Key.GetDisplayName().ToString(), A.Alt.IsValid() ? *A.Alt.GetDisplayName().ToString() : TEXT("-"), A.Pad.IsValid() ? *A.Pad.GetDisplayName().ToString() : TEXT("-"), bClash ? TEXT("  (!)") : TEXT("")));
		}
		I.Add(TR(TEXT("Reset all to defaults")));
		I.Add(TR(TEXT("Back")));
		break;
	case ERWMenu::Help:
		I.Add(TR(TEXT("Back")));
		break;
	case ERWMenu::Mods:
		for (const FRWModInfo& Md : FRWMods::Mods)
			I.Add(FString(Md.bEnabled ? TEXT("[ON]   ") : TEXT("[OFF]  ")) + (Md.Error.IsEmpty() ? TRF(TEXT("{0}  v{1}  by {2}  -  {3} machine(s)"), Md.Name, Md.Version, Md.Author, FString::FromInt(Md.Machines)) : TRF(TEXT("{0}  -  ERROR: {1}"), Md.Name, Md.Error)));
		if (FRWMods::Mods.Num() == 0) I.Add(TR(TEXT("No mods installed - put mod folders in the Mods directory")));
		I.Add(TR(TEXT("Back")));
		break;
	case ERWMenu::Inspect:
	{
		I.Add(TR(TEXT("Field service: grease, check fluids, tighten bolts  (+5% condition, $60)")));
		I.Add(TR(TEXT("Refuel from jerry can  (20 L, $28)")));
		I.Add(TR(TEXT("Wash off mud and dirt  ($15)")));
		I.Add(TR(TEXT("Close")));
		break;
	}
	case ERWMenu::Achievements:
		for (const FRWAchievement& Ach : FRWPlatform::Achievements())
			I.Add(FString::Printf(TEXT("%s  %s  -  %s"), Ach.bUnlocked ? TEXT("[X]") : TEXT("[  ]"), *TR(Ach.Name), *TR(Ach.Desc)));
		I.Add(TR(TEXT("Back")));
		break;
	default: break;
	}
	return I;
}

void ARWPlayerController::MenuActivate(int32 Index, int32 Dir)
{
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!GM) return;
	const int32 Count = MenuItems().Num();
	const bool bLast = Index == Count - 1;
	switch (Menu)
	{
	case ERWMenu::Title:
		if (Dir != 0) return;
		RWLog(FString::Printf(TEXT("Start screen: choice %d"), Index));
		bMenuFromTitle = Index >= 2 && Index <= 5;
		if (Index == 0) Menu = ERWMenu::None;
		if (Index == 1) { GM->LoadGame(TEXT("quick")); Menu = ERWMenu::None; }
		if (Index == 2) { Menu = ERWMenu::Settings; Sel = 0; }
		if (Index == 3) { Menu = ERWMenu::Controls; Sel = 0; }
		if (Index == 4) { Menu = ERWMenu::Mods; Sel = 0; }
		if (Index == 5) { Menu = ERWMenu::Help; Sel = 0; }
		if (Index == 6) ConsoleCommand(TEXT("quit"));
		break;
	case ERWMenu::Main:
		if (Dir != 0) return;
		bMenuFromTitle = false;
		if (Index == 0) Menu = ERWMenu::None;
		if (Index == 1) { GM->SaveGame(TEXT("quick")); Menu = ERWMenu::None; }
		if (Index == 2) { GM->LoadGame(TEXT("quick")); Menu = ERWMenu::None; }
		if (Index == 3) { Menu = ERWMenu::Settings; Sel = 0; }
		if (Index == 4) { Menu = ERWMenu::Controls; Sel = 0; }
		if (Index == 5) { Menu = ERWMenu::Mods; Sel = 0; }
		if (Index == 6) { Menu = ERWMenu::Achievements; Sel = 0; }
		if (Index == 7) { Menu = ERWMenu::Help; Sel = 0; }
		if (Index == 8) ConsoleCommand(TEXT("quit"));
		break;
	case ERWMenu::Jobs:
		if (Dir != 0) return;
		if (bLast) { Menu = ERWMenu::None; return; }
		{
			FRWJob& J = GM->Jobs.Jobs[Index];
			if (J.bDone) { GM->Message(TEXT("Already completed and paid")); return; }
			if (!J.bAccepted)
			{
				if (J.bPlayer) { if (J.Stakes.Num() < 2) { GM->Message(TEXT("Survey at least 2 stakes first (K, then Enter at each point)")); return; } GM->Jobs.PublishPlayerRoad(); GM->Message(TEXT("Your road design is staked out - start building!")); return; }
				GM->Jobs.Accept(Index); GM->Message(TRF(TEXT("Accepted: {0}"), TR(J.Title))); return;
			}
			if (GM->Jobs.CanSubmit(J)) GM->SubmitJob(Index);
			else { GM->Jobs.Tracked = Index; GM->Message(TRF(TEXT("Tracking {0} - {1}"), TR(J.Title), J.Status)); }
		}
		break;
	case ERWMenu::Shop:
	{
		if (Dir != 0) return;
		ARWMachine* M = ContextMachine();
		if (bLast || !M) { Menu = ERWMenu::None; return; }
		switch (Index)
		{
		case 0: GM->Refuel(M); break;
		case 1: GM->Repair(M); break;
		case 2: GM->RentOrReturn(M); break;
		case 3: GM->Buy(M); break;
		case 4: case 5: case 6: case 7: GM->Upgrade(M, Index - 4); break;
		case 8: GM->BuyPlot(0); break;
		case 9: GM->BuyPlot(1); break;
		}
		break;
	}
	case ERWMenu::Plant:
	{
		if (Dir != 0) return;
		if (bLast) { Menu = ERWMenu::None; return; }
		const ESoil Mats[5] = {ESoil::Gravel, ESoil::Sand, ESoil::Laterite, ESoil::SmallRock, ESoil::Asphalt};
		GM->BuyMaterial(ContextMachine(), Mats[Index]);
		break;
	}
	case ERWMenu::Settings:
	{
		if (bLast && Dir == 0) { Menu = ERWMenu::Main; Sel = 3; return; }
		const int32 D = Dir == 0 ? 1 : Dir;
		switch (Index)
		{
		case 0: GRWLang = 1 - GRWLang; RWLocSaveSetting(); break;
		case 1: GM->Quality = (GM->Quality + D + 4) % 4; break;
		case 2: GM->ResScale = FMath::Clamp(GM->ResScale + D * 10, 50, 100); break;
		case 3: GM->bLumen = !GM->bLumen; break;
		case 4: GM->bVSM = !GM->bVSM; break;
		case 5: { const float S[4] = {1.f, 4.f, 10.f, 30.f}; int32 k = 0; for (int32 i = 0; i < 4; ++i) if (FMath::IsNearlyEqual(S[i], GM->World->TimeMul)) k = i; GM->World->TimeMul = S[(k + D + 4) % 4]; break; }
		case 6: GM->World->bAutoWeather = !GM->World->bAutoWeather; break;
		case 7: GM->World->SetWeather((GM->World->Weather + D + 4) % 4); break;
		case 8: GM->Volume = FMath::Clamp(GM->Volume + D * 0.1f, 0.f, 1.f); for (ARWMachine* M : GM->Machines) if (M && M->Synth) M->Synth->Master.store(GM->Volume); break;
		case 9: MouseSens = FMath::Clamp(MouseSens + D * 0.1f, 0.1f, 4.f); SaveBinds(); break;
		case 10: PadSens = FMath::Clamp(PadSens + D * 0.1f, 0.1f, 4.f); SaveBinds(); break;
		case 11: bInvertY = !bInvertY; SaveBinds(); break;
		case 12: bVibration = !bVibration; SaveBinds(); break;
		}
		GM->ApplyGraphics();
		break;
	}
	case ERWMenu::Controls:
		if (bLast) { if (Dir == 0) { Menu = ERWMenu::Main; Sel = 4; } return; }
		if (Index == Count - 2) { if (Dir == 0) { ResetBinds(); GM->Message(TEXT("All controls reset to defaults")); } return; }
		// Enter = new main key, Right = new second key, Left = clear the second key
		if (Dir < 0) { Actions[Index].Alt = FKey(); SaveBinds(); return; }
		Rebinding = Index; RebindSlot = Dir > 0 ? 1 : 0;
		break;
	case ERWMenu::Help:
		Menu = ERWMenu::Main; Sel = 7;
		break;
	case ERWMenu::Mods:
		if (Dir != 0) return;
		if (bLast) { Menu = ERWMenu::Main; Sel = 5; }
		else if (FRWMods::Mods.IsValidIndex(Index)) { FRWMods::SetEnabled(Index, !FRWMods::Mods[Index].bEnabled); GM->Message(TEXT("Mod setting saved - restart the game to apply it")); }
		break;
	case ERWMenu::Achievements:
		if (bLast && Dir == 0) { Menu = ERWMenu::Main; Sel = 6; }
		break;
	case ERWMenu::Inspect:
		if (Dir != 0) return;
		if (bLast) { Menu = ERWMenu::None; return; }
		StartService(InspectTarget(), Index);
		Menu = ERWMenu::None;
		break;
	default: break;
	}
}

void ARWPlayerController::PlayerTick(float Dt)
{
	Super::PlayerTick(Dt);
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (!GM || !GM->bReady) return;
	++FrameCount;
	// screenshot mode also measures the frame rate (second half of its frames, after the world has settled)
	static double BenchT0 = 0.0; static int32 BenchF0 = 0;
	if (ShotFrames > 0 && FrameCount == ShotFrames / 2) { BenchT0 = FPlatformTime::Seconds(); BenchF0 = FrameCount; }
	if (ShotFrames > 0 && FrameCount >= ShotFrames && (GM->Scene.IsEmpty() || GM->bSceneReady))
	{
		if (ShotRequestedAt < 0)
		{
			if (FrameCount > BenchF0 && BenchF0 > 0) RWLog(FString::Printf(TEXT("Bench: %.1f ms per frame (%.0f FPS) over %d frames; game %.1f, render %.1f, GPU %.1f ms"), (FPlatformTime::Seconds() - BenchT0) * 1000.0 / (FrameCount - BenchF0), (FrameCount - BenchF0) / (FPlatformTime::Seconds() - BenchT0), FrameCount - BenchF0,
				FPlatformTime::ToMilliseconds(GGameThreadTime), FPlatformTime::ToMilliseconds(GRenderThreadTime), FPlatformTime::ToMilliseconds(RHIGetGPUFrameCycles())));
			// The viewport client grabs the finished frame (scene + HUD) and hands it to OnShot.
			FScreenshotRequest::RequestScreenshot(ShotPath, false, false);
			ShotRequestedAt = FrameCount;
		}
		else if (bShotDone || FrameCount > ShotRequestedAt + 90)
		{
			if (!bShotDone && !IFileManager::Get().FileExists(*ShotPath)) RWLog(TEXT("Screenshot request timed out"));
			ShotFrames = -2;
			FGenericPlatformMisc::RequestExit(false);
		}
	}
	// ---- key rebinding capture ----
	if (Rebinding >= 0)
	{
		TArray<FKey> All; EKeys::GetAllKeys(All);
		for (const FKey& K : All)
		{
			// EKeys::GetAllKeys also lists the virtual "Any Key", which is "pressed" with every key: skip it
			if (!IsBindableKey(K) || !WasInputKeyJustPressed(K)) continue;
			// Esc / controller B cancel; keyboard & mouse keys go to the chosen key slot, controller buttons to the pad slot
			if (K != EKeys::Escape && K != EKeys::Gamepad_FaceButton_Right)
			{
				const FString Clash = ApplyRebind(Rebinding, K.IsGamepadKey() ? 2 : RebindSlot, K);
				if (ARWGameMode* G = ARWGameMode::Get(this))
					G->Message(Clash.IsEmpty() ? TRF(TEXT("{0} set to {1}"), TR(Actions[Rebinding].Label), K.GetDisplayName().ToString()) : TRF(TEXT("{0} is also used by: {1}"), K.GetDisplayName().ToString(), Clash));
			}
			Rebinding = -1;
			break;
		}
		return;
	}
	float MX = 0, MY = 0;
	GetInputMouseDelta(MX, MY);
	MX *= MouseSens; MY *= MouseSens * (bInvertY ? -1.f : 1.f);
	// right stick looks around (sensitivity adjustable)
	const float PadLook = 150.f * PadSens * Dt;
	MX += PadAxis(EKeys::Gamepad_RightX) * PadLook;
	MY += PadAxis(EKeys::Gamepad_RightY) * PadLook * (bInvertY ? -1.f : 1.f);
	const bool bWorkMode = IsInputKeyDown(EKeys::Gamepad_RightShoulder); // hold RB: sticks drive the hydraulics
	const bool bWheelUp = WasInputKeyJustPressed(EKeys::MouseScrollUp), bWheelDn = WasInputKeyJustPressed(EKeys::MouseScrollDown);
	UpdateRumble(Dt);

	// -RWTitleStart=<frame>: "start" is chosen on the start screen at that frame (to check what the player sees next)
	{
		static int32 AutoStart = -2;
		if (AutoStart == -2) { AutoStart = -1; FParse::Value(FCommandLine::Get(), TEXT("RWTitleStart="), AutoStart); }
		if (AutoStart > 0 && FrameCount == AutoStart && Menu == ERWMenu::Title) MenuActivate(0, 0);
	}
	// leaving the start screen: back to the machine's own camera (this used to wait for the menu code, which no longer runs
	// once "start" has closed the menus - the view then stayed up on the hill)
	if (Menu != ERWMenu::Title && TitleCam)
	{
		TitleCam->Destroy(); TitleCam = nullptr;
		if (Driving) SetViewTarget(Driving); else if (GetPawn()) SetViewTarget(GetPawn());
	}
	// ---- menus ----
	if (Menu != ERWMenu::None)
	{
		if (Driving) { Driving->InThrottle = Driving->InSteer = 0; Driving->InA1 = Driving->InA2 = Driving->InA3 = Driving->InA4 = 0; }
		if (GM->Walker) { GM->Walker->InFwd = GM->Walker->InRight = 0; }
		const int32 Count = MenuItems().Num();
		int32 PUp = 0, PSide = 0; bool bPSel = false, bPBack = false;
		PadNav(PUp, PSide, bPSel, bPBack, Dt);
		if (WasInputKeyJustPressed(EKeys::Up) || bWheelUp || PUp > 0) Sel = (Sel - 1 + FMath::Max(Count, 1)) % FMath::Max(Count, 1);
		if (WasInputKeyJustPressed(EKeys::Down) || bWheelDn || PUp < 0) Sel = (Sel + 1) % FMath::Max(Count, 1);
		// (the start screen ignores the first second: the click or key that started the game must not choose for the player)
		const bool bTitleWait = Menu == ERWMenu::Title && FrameCount < 90;
		// the start screen looks out over the valley from the hill above the site, turning slowly
		if (Menu == ERWMenu::Title)
		{
			if (!TitleCam)
			{
				TitleCam = GetWorld()->SpawnActor<ACameraActor>();
				if (TitleCam && TitleCam->GetCameraComponent()) TitleCam->GetCameraComponent()->SetFieldOfView(62.f);
				SetViewTarget(TitleCam);
			}
			TitleT += Dt;
			const FVector Eye(-30.f, -150.f, GM->Terrain ? GM->Terrain->HeightAt(-30.f, -150.f) + 38.f : 40.f);
			if (TitleCam) TitleCam->SetActorLocationAndRotation(Eye * M2CM, FRotator(-9.f, 52.f + 14.f * FMath::Sin(TitleT * 0.05f), 0.f));
		}
		if (!bTitleWait && (WasInputKeyJustPressed(EKeys::Enter) || WasInputKeyJustPressed(EKeys::SpaceBar) || (Menu != ERWMenu::Title && WasInputKeyJustPressed(EKeys::LeftMouseButton)) || bPSel)) MenuActivate(Sel, 0);
		if (WasInputKeyJustPressed(EKeys::Left) || PSide < 0) MenuActivate(Sel, -1);
		if (WasInputKeyJustPressed(EKeys::Right) || PSide > 0) MenuActivate(Sel, 1);
		if (Menu == ERWMenu::Jobs && (WasInputKeyJustPressed(EKeys::BackSpace) || WasInputKeyJustPressed(EKeys::Gamepad_FaceButton_Left)) && GM->Jobs.Jobs.IsValidIndex(Sel)) { GM->Jobs.Abandon(Sel); GM->Message(TEXT("Job abandoned")); }
		if (WasInputKeyJustPressed(EKeys::Escape) || bPBack || WasInputKeyJustPressed(EKeys::Gamepad_Special_Right) || (Menu == ERWMenu::Map && Pressed(TEXT("Map"))) || (Menu == ERWMenu::Jobs && Pressed(TEXT("Jobs"))) || (Menu == ERWMenu::Inspect && WasInputKeyJustPressed(EKeys::Tab)))
		{
			if (Menu == ERWMenu::Title) { /* the start screen stays until a choice is made */ }
			else Menu = (Menu == ERWMenu::Settings || Menu == ERWMenu::Controls || Menu == ERWMenu::Help || Menu == ERWMenu::Mods || Menu == ERWMenu::Achievements) ? (bMenuFromTitle ? ERWMenu::Title : ERWMenu::Main) : ERWMenu::None;
		}
		Sel = FMath::Clamp(Sel, 0, FMath::Max(MenuItems().Num() - 1, 0));
		return;
	}

	// ---- climbing in / out of a cab (animation owns the character meanwhile) ----
	if (StepTransition(Dt))
	{
		if (GM->Walker) { GM->Walker->Yaw += MX * 0.f; GM->CamM = GM->Walker->PosM; }
		return;
	}

	// ---- global keys ----
	if (Pressed(TEXT("Menu"))) { Menu = ERWMenu::Main; Sel = 0; return; }
	if (!Driving && Pressed(TEXT("Inspect")))
	{
		if (InspectTarget()) { Menu = ERWMenu::Inspect; Sel = 0; }
		else GM->Message(TEXT("Walk up to a machine to inspect it"));
		return;
	}
	if (Pressed(TEXT("Jobs"))) { Menu = ERWMenu::Jobs; Sel = FMath::Max(GM->Jobs.Tracked, 0); return; }
	if (Pressed(TEXT("Map"))) { Menu = ERWMenu::Map; return; }
	if (Pressed(TEXT("Help"))) bShowHelp = !bShowHelp;
	if (Pressed(TEXT("HudMode")))
	{
		HudMode = (HudMode + 1) % 3;
		static const TCHAR* Names[3] = {TEXT("HUD: full"), TEXT("HUD: minimal"), TEXT("HUD: hidden (F4 to show)")};
		GM->Message(Names[HudMode]);
	}
	if (Pressed(TEXT("BucketDebug"))) { if (ARWExcavator* DE = Cast<ARWExcavator>(Driving)) { DE->bDebugBucket = !DE->bDebugBucket; DE->FillKey = -1; } }
	if (Pressed(TEXT("Guide"))) { GM->bGuide = !GM->bGuide; GM->UpdateGradeGuide(false); GM->Message(GM->bGuide ? TEXT("Grade guide on") : TEXT("Grade guide off")); }
	if (Pressed(TEXT("Save"))) GM->SaveGame(TEXT("quick"));
	if (Pressed(TEXT("Load"))) GM->LoadGame(TEXT("quick"));
	if (Pressed(TEXT("TimeWarp"))) { GM->World->TimeMul = GM->World->TimeMul > 1.f ? 1.f : 10.f; GM->Message(TRF(TEXT("Time speed x{0}"), RWNum(GM->World->TimeMul))); }
	if (Pressed(TEXT("Survey"))) { bSurvey = !bSurvey; GM->Message(bSurvey ? TEXT("SURVEY MODE: Enter = place stake, Backspace = remove, PgUp/PgDn = stake height, ,/. = road width, K = done") : TEXT("Survey mode off")); }
	const FVector Here = Driving ? Driving->PosM : (GM->Walker ? GM->Walker->PosM : FVector::ZeroVector);
	if (Pressed(TEXT("Use")))
	{
		ARWMachine* M = ContextMachine();
		bool bOwnPlot = false;
		for (int32 p = 0; p < 2; ++p) if (GM->Eco.Plots[p]) if (const FRWZone* Z = GM->Layout.Find(ERWZone::Plot, p)) bOwnPlot |= FRWLayout::InZone(*Z, Here.X, Here.Y, 2.f);
		if (GM->ZoneAt(Here, ERWZone::Depot) || bOwnPlot) { Menu = ERWMenu::Shop; Sel = 0; }
		else if (GM->ZoneAt(Here, ERWZone::Plant)) { Menu = ERWMenu::Plant; Sel = 0; }
		else if (ARWWaterTruck* WT = Cast<ARWWaterTruck>(M))
		{
			if (GM->NearRiver(Here)) { WT->Water = WT->WaterCap; GM->Message(TEXT("Water tank filled from the river")); }
			else GM->Message(TEXT("Drive next to the river to pump water"));
		}
		else GM->Message(TEXT("No facility here. Machine Yard = fuel/repair/rent/buy/upgrades.  Material Plant = buy materials.  River = water."));
	}
	if (bSurvey)
	{
		if (Pressed(TEXT("EnterExit"))) { GM->Jobs.AddStake(FVector2D(Here.X, Here.Y)); GM->UpdateMarkers(); GM->Message(TRF(TEXT("Stake {0} placed"), FString::FromInt(GM->Jobs.PlayerRoad() ? GM->Jobs.PlayerRoad()->Stakes.Num() : 0))); }
		if (WasInputKeyJustPressed(EKeys::BackSpace)) { GM->Jobs.RemoveStake(); GM->UpdateMarkers(); }
		FRWJob* PR = GM->Jobs.PlayerRoad();
		if (PR && !PR->bAccepted)
		{
			bool bCh = false;
			if (PR->Offsets.Num() && WasInputKeyJustPressed(EKeys::PageUp)) { PR->Offsets.Last() += 0.1f; bCh = true; }
			if (PR->Offsets.Num() && WasInputKeyJustPressed(EKeys::PageDown)) { PR->Offsets.Last() -= 0.1f; bCh = true; }
			if (WasInputKeyJustPressed(EKeys::Comma)) { PR->HalfW = FMath::Clamp(PR->HalfW - 0.25f, 2.f, 6.f); bCh = true; }
			if (WasInputKeyJustPressed(EKeys::Period)) { PR->HalfW = FMath::Clamp(PR->HalfW + 0.25f, 2.f, 6.f); bCh = true; }
			if (bCh) { GM->Jobs.RebuildPlayerRoad(); GM->UpdateMarkers(); }
		}
	}

	if (Driving && !GM->Scene.IsEmpty()) return; // a screenshot scene is operating the machine
	if (Driving)
	{
		ARWMachine* M = Driving;
		if (!bSurvey && Pressed(TEXT("EnterExit"))) { BeginExit(); return; }
		const bool bOp = M->CanOperate();
		M->InThrottle = (Down(TEXT("Forward")) ? 1.f : 0.f) - (Down(TEXT("Back")) ? 1.f : 0.f);
		M->InSteer = (Down(TEXT("Right")) ? 1.f : 0.f) - (Down(TEXT("Left")) ? 1.f : 0.f);
		M->InBrake = Down(TEXT("Brake")) ? 1.f : 0.f;
		M->InA1 = (Down(TEXT("A1Up")) ? 1.f : 0.f) - (Down(TEXT("A1Down")) ? 1.f : 0.f);
		M->InA2 = (Down(TEXT("A2Up")) ? 1.f : 0.f) - (Down(TEXT("A2Down")) ? 1.f : 0.f);
		M->InA3 = (Down(TEXT("A3Up")) ? 1.f : 0.f) - (Down(TEXT("A3Down")) ? 1.f : 0.f);
		M->InA4 = (Down(TEXT("SwingR")) ? 1.f : 0.f) - (Down(TEXT("SwingL")) ? 1.f : 0.f);
		// controller: triggers = throttle / brake-reverse, left stick = steer & travel; hold RB for the
		// ISO joystick pattern (left: swing & stick, right: boom & bucket / blade)
		const float LX = PadAxis(EKeys::Gamepad_LeftX), LY = PadAxis(EKeys::Gamepad_LeftY);
		const float RX = PadAxis(EKeys::Gamepad_RightX), RY = PadAxis(EKeys::Gamepad_RightY);
		const float RT = PadAxis(EKeys::Gamepad_RightTriggerAxis), LT = PadAxis(EKeys::Gamepad_LeftTriggerAxis);
		M->InThrottle = FMath::Clamp(M->InThrottle + RT - LT + (bWorkMode ? 0.f : LY), -1.f, 1.f);
		if (bWorkMode)
		{
			M->InA4 = FMath::Clamp(M->InA4 + LX, -1.f, 1.f);
			M->InA2 = FMath::Clamp(M->InA2 + LY, -1.f, 1.f);
			M->InA1 = FMath::Clamp(M->InA1 - RY, -1.f, 1.f);
			M->InA3 = FMath::Clamp(M->InA3 + RX, -1.f, 1.f);
			MX = 0; MY = 0; // sticks are busy with the hydraulics
		}
		else M->InSteer = FMath::Clamp(M->InSteer + LX, -1.f, 1.f);
		if (Pressed(TEXT("Engine")))
		{
			if (!bOp) GM->Message(TRF(TEXT("You don't have the key: rent (${0}/day) or buy at the Machine Yard (press U there)"), RWNum(M->RentPerDay)));
			else M->ToggleEngine();
		}
		if (Down(TEXT("ThrUp"))) M->ThrottleDial = FMath::Min(1.f, M->ThrottleDial + Dt * 0.6f);
		if (Down(TEXT("ThrDown"))) M->ThrottleDial = FMath::Max(0.f, M->ThrottleDial - Dt * 0.6f);
		if (Pressed(TEXT("Lights"))) M->bLights = !M->bLights;
		if (Pressed(TEXT("Door"))) M->bDoorOpen = !M->bDoorOpen;
		if (Pressed(TEXT("Hood"))) M->bHoodOpen = !M->bHoodOpen;
		if (Pressed(TEXT("Wipers"))) M->bWipers = !M->bWipers;
		if (Pressed(TEXT("Tool"))) M->ToolCycle();
		if (Pressed(TEXT("NextMachine"))) { SwitchMachine(1); return; }
		if (Pressed(TEXT("PrevMachine"))) { SwitchMachine(-1); return; }
		if (Pressed(TEXT("Work")))
		{
			if (ARWGrader* Gr = Cast<ARWGrader>(M)) { Gr->bAutoGrade = !Gr->bAutoGrade; GM->Message(Gr->bAutoGrade ? TEXT("Machine control ON: blade follows the design grade") : TEXT("Machine control off")); }
			else M->WorkToggle();
		}
		if (Pressed(TEXT("Camera"))) SetCab(!M->bCabView);
		if (M->bCabView)
		{
			M->CabYaw = FMath::Clamp(M->CabYaw + MX * 1.6f, -160.f, 160.f);
			M->CabPitch = FMath::Clamp(M->CabPitch + MY * 1.6f, -70.f, 50.f);
			M->CabCam->SetRelativeRotation(FRotator(M->CabPitch, M->CabYaw, 0));
		}
		else
		{
			M->CamYaw += MX * 2.f;
			M->CamPitch = FMath::Clamp(M->CamPitch + MY * 2.f, -80.f, 8.f);
			if (bWheelUp) M->CamDist = FMath::Max(4.f, M->CamDist * 0.88f);
			if (bWheelDn) M->CamDist = FMath::Min(70.f, M->CamDist * 1.13f);
			// excavators: orbit the upper structure so the camera follows the swing
			float Extra = 0.f;
			if (ARWExcavator* E = Cast<ARWExcavator>(M)) Extra = E->Swing;
			if (ARWCrane* Cr = Cast<ARWCrane>(M)) Extra = Cr->Slew;
			M->Arm->SetRelativeRotation(FRotator(M->CamPitch, M->CamYaw + Extra, 0));
			M->Arm->TargetArmLength = M->CamDist * M2CM;
		}
		GM->CamM = M->PosM;
	}
	else if (ARWWalker* W = GM->Walker)
	{
		W->InFwd = FMath::Clamp((Down(TEXT("Forward")) ? 1.f : 0.f) - (Down(TEXT("Back")) ? 1.f : 0.f) + PadAxis(EKeys::Gamepad_LeftY), -1.f, 1.f);
		W->InRight = FMath::Clamp((Down(TEXT("Right")) ? 1.f : 0.f) - (Down(TEXT("Left")) ? 1.f : 0.f) + PadAxis(EKeys::Gamepad_LeftX), -1.f, 1.f);
		if (Pressed(TEXT("Editor"))) SetEditMode(!bEditMode);
		if (bEditMode) EditorTick(Dt); else FootActivities(Dt);
		W->bRun = Down(TEXT("Run"));
		W->Yaw += MX * 2.f;
		W->CamPitch = FMath::Clamp(W->CamPitch + MY * 2.f, -80.f, 60.f);
		if (bWheelUp) W->CamDist = FMath::Max(1.5f, W->CamDist * 0.88f);
		if (bWheelDn) W->CamDist = FMath::Min(30.f, W->CamDist * 1.13f);
		if (Pressed(TEXT("Camera"))) { W->bFirst = !W->bFirst; W->Cam->SetActive(!W->bFirst); W->EyeCam->SetActive(W->bFirst); }
		if (!bSurvey && Pressed(TEXT("EnterExit")))
		{
			if (ARWMachine* M = GM->NearestMachine(W->PosM, 7.f)) BeginEnter(M);
		}
		GM->CamM = W->PosM;
	}
}

// ============================================================================================
// HUD
// ============================================================================================
static UFont* HudFont(bool bBig) { return RWFont(bBig); }

void ARWHUD::Panel(float X, float Y, float W, float H, FLinearColor C)
{
	DrawRect(C, X * S, Y * S, W * S, H * S);
	DrawRect(FLinearColor(1.f, 0.55f, 0.05f, 0.85f), X * S, Y * S, 3.f * S, H * S);
}

void ARWHUD::Txt(const FString& T, float X, float Y, FLinearColor C, float Scale, bool bBig)
{
	UFont* F = HudFont(bBig);
	const float Sc = Scale * S * (bBig ? 1.25f : 1.08f);
	DrawText(T, FLinearColor(0, 0, 0, 0.8f), X * S + 1.5f, Y * S + 1.5f, F, Sc);
	DrawText(T, C, X * S, Y * S, F, Sc);
}

void ARWHUD::Bar(float X, float Y, float W, float H, float F, FLinearColor C)
{
	DrawRect(FLinearColor(1, 1, 1, 0.12f), X * S, Y * S, W * S, H * S);
	DrawRect(C, X * S, Y * S, W * S * FMath::Clamp(F, 0.f, 1.f), H * S);
}

void ARWHUD::Gauge(float CX, float CY, float R, float F, const FString& Label, const FString& Value, FLinearColor C)
{
	const int32 Segs = 32;
	const float A0 = FMath::DegreesToRadians(135.f), A1 = FMath::DegreesToRadians(405.f);
	DrawRect(FLinearColor(0, 0, 0, 0.0f), 0, 0, 0, 0);
	for (int32 i = 0; i < Segs; ++i)
	{
		const float Ta = FMath::Lerp(A0, A1, i / float(Segs)), Tb = FMath::Lerp(A0, A1, (i + 1) / float(Segs));
		const bool bOn = (i + 0.5f) / Segs <= F;
		DrawLine((CX + FMath::Cos(Ta) * R) * S, (CY + FMath::Sin(Ta) * R) * S, (CX + FMath::Cos(Tb) * R) * S, (CY + FMath::Sin(Tb) * R) * S, bOn ? C : FLinearColor(1, 1, 1, 0.18f), 4.f * S);
	}
	const float An = FMath::Lerp(A0, A1, FMath::Clamp(F, 0.f, 1.f));
	DrawLine(CX * S, CY * S, (CX + FMath::Cos(An) * R * 0.85f) * S, (CY + FMath::Sin(An) * R * 0.85f) * S, FLinearColor(1.f, 0.3f, 0.1f), 3.f * S);
	Txt(Value, CX - R * 0.55f, CY + R * 0.15f, FLinearColor::White, 0.9f);
	Txt(Label, CX - R * 0.55f, CY + R * 0.55f, FLinearColor(0.7f, 0.75f, 0.8f), 0.65f);
}

void ARWHUD::UpdateMapTexture(ARWGameMode* GM)
{
	const int32 R = 256;
	if (!MapTex) { MapTex = UTexture2D::CreateTransient(R, R, PF_B8G8R8A8); MapTex->SRGB = true; MapTex->UpdateResource(); }
	TArray<FColor> Px; Px.SetNumUninitialized(R * R);
	ARWTerrain* T = GM->Terrain;
	for (int32 y = 0; y < R; ++y)
		for (int32 x = 0; x < R; ++x)
		{
			const float WX = -ARWTerrain::Half + (x + 0.5f) * (2 * ARWTerrain::Half / R);
			const float WY = ARWTerrain::Half - (y + 0.5f) * (2 * ARWTerrain::Half / R);
			const int32 i = T->IndexAt(WX, WY);
			FLinearColor C = SoilProps(T->SurfaceMat(i)).Color;
			C = FMath::Lerp(C, FLinearColor(0.05f, 0.09f, 0.025f), T->Grass[i] / 255.f);
			const FVector N = T->NormalAt(WX, WY);
			const float Shade = FMath::Clamp(0.55f + 0.9f * FVector::DotProduct(N, FVector(-0.5f, 0.5f, 0.7f).GetSafeNormal()) - 0.4f, 0.35f, 1.3f);
			C *= Shade * 2.2f;
			if (T->Height[i] < T->WaterZ - 0.1f) C = FLinearColor(0.03f, 0.1f, 0.2f);
			C.A = 1.f;
			Px[y * R + x] = C.ToFColor(true);
		}
	void* Data = MapTex->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
	FMemory::Memcpy(Data, Px.GetData(), Px.Num() * 4);
	MapTex->GetPlatformData()->Mips[0].BulkData.Unlock();
	MapTex->UpdateResource();
}

void ARWHUD::DrawMap(ARWGameMode* GM, ARWPlayerController* PC)
{
	MapTimer -= GetWorld()->GetDeltaSeconds();
	if (!MapTex || MapTimer <= 0.f) { UpdateMapTexture(GM); MapTimer = 3.f; }
	const float Size = 900.f, X0 = (Canvas->SizeX / S - Size) * 0.5f, Y0 = 90.f;
	Panel(X0 - 12, Y0 - 50, Size + 24, Size + 64);
	Txt(TR(TEXT("MAP  (M or Esc to close)")), X0, Y0 - 42, FLinearColor(1.f, 0.7f, 0.2f), 1.f, true);
	DrawTexture(MapTex, X0 * S, Y0 * S, Size * S, Size * S, 0, 0, 1, 1);
	auto ToMap = [&](float WX, float WY) { return FVector2D(X0 + (WX + ARWTerrain::Half) / (2 * ARWTerrain::Half) * Size, Y0 + (ARWTerrain::Half - WY) / (2 * ARWTerrain::Half) * Size); };
	for (const FRWZone& Z : GM->Layout.Zones)
	{
		const FVector2D P = ToMap(Z.C.X - Z.HalfExt.X, Z.C.Y + Z.HalfExt.Y);
		Txt(TR(Z.Name), P.X, P.Y - 18, FLinearColor(1, 1, 1, 0.9f), 0.7f);
	}
	for (const FRWJob& J : GM->Jobs.Jobs)
	{
		if (!J.bAccepted || J.bDone) continue;
		const FVector2D A = ToMap(J.C.X - J.Half.X, J.C.Y + J.Half.Y), B = ToMap(J.C.X + J.Half.X, J.C.Y - J.Half.Y);
		const FLinearColor C(1.f, 0.4f, 0.05f);
		DrawLine(A.X * S, A.Y * S, B.X * S, A.Y * S, C, 2 * S); DrawLine(B.X * S, A.Y * S, B.X * S, B.Y * S, C, 2 * S);
		DrawLine(B.X * S, B.Y * S, A.X * S, B.Y * S, C, 2 * S); DrawLine(A.X * S, B.Y * S, A.X * S, A.Y * S, C, 2 * S);
		for (int32 i = 0; i + 1 < J.Path.Num(); i += 1)
		{
			const FVector2D P = ToMap(J.Path[i].X, J.Path[i].Y), Q = ToMap(J.Path[i + 1].X, J.Path[i + 1].Y);
			DrawLine(P.X * S, P.Y * S, Q.X * S, Q.Y * S, C, 2 * S);
		}
	}
	for (ARWMachine* M : GM->Machines)
	{
		if (!M) continue;
		const FVector2D P = ToMap(M->PosM.X, M->PosM.Y);
		const FLinearColor C = M->bOwned ? FLinearColor(1.f, 0.85f, 0.1f) : M->bRented ? FLinearColor(0.3f, 1.f, 0.4f) : FLinearColor(0.7f, 0.7f, 0.7f);
		DrawRect(C, (P.X - 4) * S, (P.Y - 4) * S, 8 * S, 8 * S);
	}
	const FVector Me = PC->Driving ? PC->Driving->PosM : GM->Walker->PosM;
	const FVector2D P = ToMap(Me.X, Me.Y);
	DrawRect(FLinearColor(0.1f, 0.8f, 1.f), (P.X - 6) * S, (P.Y - 6) * S, 12 * S, 12 * S);
	Txt(TR(TEXT("You")), P.X + 8, P.Y - 10, FLinearColor(0.1f, 0.8f, 1.f), 0.8f);
	Txt(TR(TEXT("Yellow = your machines   Green = rented   Grey = for rent/sale   Orange = active jobs")), X0, Y0 + Size + 2, FLinearColor(0.8f, 0.8f, 0.8f), 0.7f);
}

void ARWHUD::DrawMachine(ARWGameMode* GM, ARWPlayerController* PC, ARWMachine* M)
{
	// compact machine card (bottom-left): small, translucent, only what matters right now
	const float H = Canvas->SizeY / S;
	const FString Tool = M->ToolText();
	// wrap the tool line on its double-space separators
	TArray<FString> ToolLines; { TArray<FString> Bits; Tool.ParseIntoArray(Bits, TEXT("  "), true); FString L; for (FString& B : Bits) { B.TrimStartAndEndInline(); if (L.Len() + B.Len() > 58 && !L.IsEmpty()) { ToolLines.Add(L); L.Reset(); } L += (L.IsEmpty() ? TEXT("") : TEXT("   ")) + B; } if (!L.IsEmpty()) ToolLines.Add(L); }
	const bool bSlip = M->WheelSlip > 0.1f || M->Sinkage > 0.03f;
	FVector GP; float DZ;
	const bool bGps = M->GradePoint(GP) && ARWMachine::DesignGrade && ARWMachine::DesignGrade(GP, DZ);
	const bool bRemain = bGps && GM->bGuide && GM->GuideCut + GM->GuideFill > 0.01f;
	const float W = 470.f, Ht = 112.f + (bSlip ? 18.f : 0.f) + (bGps ? 18.f : 0.f) + (bRemain ? 18.f : 0.f) + FMath::Min(ToolLines.Num(), 3) * 17.f;
	const float X = 16.f, Y = H - Ht - 16.f;
	DrawRect(FLinearColor(0.01f, 0.012f, 0.016f, 0.42f), X * S, Y * S, W * S, Ht * S);
	DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.9f), X * S, Y * S, W * S, 2.f * S);
	// title row
	const FString Own = M->bOwned ? TR(TEXT("OWNED")) : M->bRented ? TR(TEXT("RENTED")) : TRF(TEXT("FOR RENT ${0}/day"), RWNum(M->RentPerDay));
	Txt(TR(M->Model), X + 10, Y + 5, FLinearColor(1.f, 0.78f, 0.3f), 0.62f, true);
	Txt(Own, X + W - 10 - Own.Len() * 7.2f, Y + 9, FLinearColor(0.65f, 0.7f, 0.75f), 0.52f);
	const FLinearColor EngC = M->Cranking > 0 ? FLinearColor(1.f, 0.8f, 0.2f) : M->bEngineOn ? FLinearColor(0.35f, 1.f, 0.4f) : FLinearColor(1.f, 0.4f, 0.3f);
	DrawRect(EngC, (X + 12) * S, (Y + 35) * S, 7 * S, 7 * S);
	Txt(M->Cranking > 0 ? TR(TEXT("CRANKING")) : M->bEngineOn ? TR(TEXT("ENGINE RUNNING")) : TR(TEXT("ENGINE OFF (I)")), X + 24, Y + 29, EngC, 0.52f);
	// two small dials
	auto Dial = [&](float CX, float CY, float R, float F, const FString& Val, const FString& Lab, FLinearColor C)
	{
		const float A0 = FMath::DegreesToRadians(135.f), A1 = FMath::DegreesToRadians(405.f);
		for (int32 i = 0; i < 24; ++i)
		{
			const float Ta = FMath::Lerp(A0, A1, i / 24.f), Tb = FMath::Lerp(A0, A1, (i + 1) / 24.f);
			DrawLine((CX + FMath::Cos(Ta) * R) * S, (CY + FMath::Sin(Ta) * R) * S, (CX + FMath::Cos(Tb) * R) * S, (CY + FMath::Sin(Tb) * R) * S, (i + 0.5f) / 24.f <= F ? C : FLinearColor(1, 1, 1, 0.15f), 3.f * S);
		}
		Txt(Val, CX - Val.Len() * 4.2f, CY - 9, FLinearColor::White, 0.6f);
		Txt(Lab, CX - Lab.Len() * 3.2f, CY + 8, FLinearColor(0.65f, 0.7f, 0.75f), 0.46f);
	};
	const float Kmh = FMath::Abs(M->Speed) * 3.6f;
	Dial(X + 40, Y + 78, 25, M->Rpm / 2400.f, FString::Printf(TEXT("%.0f"), M->Rpm), TR(TEXT("rpm")), FLinearColor(0.3f, 0.8f, 1.f));
	Dial(X + 104, Y + 78, 25, Kmh / (M->Drive == EDrive::Tracked ? 12.f : 80.f), FString::Printf(TEXT("%.1f"), Kmh), TR(TEXT("km/h")), FLinearColor(0.4f, 1.f, 0.5f));
	const FString Gear = M->Drive == EDrive::Tracked ? (M->InThrottle < 0 ? TEXT("REV") : TEXT("HST")) : M->Gear < 0 ? TEXT("R") : M->Gear == 0 ? TEXT("N") : FString::FromInt(M->Gear);
	Txt(TRF(TEXT("Gear {0}   Throttle {1}%"), Gear, RWNum(M->ThrottleDial * 100.f)), X + 12, Y + 104 - 2, FLinearColor(0.85f, 0.85f, 0.85f), 0.5f);
	// 2 x 2 bars
	auto MiniBar = [&](float BX, float BY, const FString& Lab, float F, FLinearColor C, const FString& Val)
	{
		Txt(Lab, BX, BY - 4, FLinearColor(0.7f, 0.72f, 0.75f), 0.48f);
		DrawRect(FLinearColor(1, 1, 1, 0.1f), (BX + 62) * S, (BY + 2) * S, 70 * S, 6 * S);
		DrawRect(C, (BX + 62) * S, (BY + 2) * S, 70 * S * FMath::Clamp(F, 0.f, 1.f), 6 * S);
		if (!Val.IsEmpty()) Txt(Val, BX + 136, BY - 4, FLinearColor(0.9f, 0.9f, 0.9f), 0.48f);
	};
	const float GX = X + 150, GX2 = X + 310;
	MiniBar(GX, Y + 36, TR(TEXT("Fuel")), M->Fuel / M->FuelCap, FLinearColor(1.f, 0.7f, 0.1f), RWNum(M->Fuel) + TEXT(" L"));
	MiniBar(GX2, Y + 36, TR(TEXT("Condition")), M->Condition, M->Condition > 0.4f ? FLinearColor(0.3f, 0.9f, 0.3f) : FLinearColor(1.f, 0.2f, 0.1f), RWNum(M->Condition * 100.f) + TEXT("%"));
	MiniBar(GX, Y + 54, TR(TEXT("Engine load")), M->EngineLoad, FLinearColor(1.f, 0.4f, 0.2f), FString());
	MiniBar(GX2, Y + 54, TR(TEXT("Hydraulics")), M->HydLoad, M->HydLoad > 1.f ? FLinearColor(1.f, 0.1f, 0.1f) : FLinearColor(0.3f, 0.6f, 1.f), FString());
	float LY = Y + 70;
	Txt(TRF(TEXT("Ground: {0}   moisture {1}%   compaction {2}%"), TR(SoilName(M->GroundMat, M->GroundMoist)), RWNum(M->GroundMoist * 100.f), RWNum(M->GroundComp * 100.f)), GX, LY, FLinearColor(0.85f, 0.8f, 0.7f), 0.48f);
	LY = Y + 104;
	if (bSlip) { Txt(TRF(TEXT("Traction {0}   wheel slip {1}%   rut {2} cm   payload {3} t"), RWNum(M->Traction, 2), RWNum(M->WheelSlip * 100.f), RWNum(M->Sinkage * 100.f), RWNum(M->PayloadKg() / 1000.f, 1)), X + 12, LY + 16, FLinearColor(0.85f, 0.8f, 0.7f), 0.48f); LY += 18; }
	if (bGps)
	{
		const float D = GP.Z - DZ;
		const FString G = FMath::Abs(D) < 0.03f ? TR(TEXT("ON GRADE")) : D > 0 ? TRF(TEXT("ABOVE GRADE  {0} m  (cut)"), RWNum(D, 2)) : TRF(TEXT("BELOW GRADE  {0} m  (fill)"), RWNum(-D, 2));
		Txt(TRF(TEXT("GPS machine control: {0}"), G), X + 12, LY + 16, FMath::Abs(D) < 0.03f ? FLinearColor(0.3f, 1.f, 0.3f) : FLinearColor(1.f, 0.85f, 0.2f), 0.5f);
		LY += 18;
		if (GM->bGuide && GM->GuideCut + GM->GuideFill > 0.01f) { Txt(TRF(TEXT("Remaining: cut {0} m3 - fill {1} m3 - on grade {2}%"), RWNum(GM->GuideCut), RWNum(GM->GuideFill), RWNum(GM->GuideOnGrade * 100.f)), X + 12, LY + 16, FLinearColor(0.75f, 0.85f, 1.f), 0.5f); LY += 18; }
	}
	for (int32 i = 0; i < FMath::Min(ToolLines.Num(), 3); ++i) Txt(ToolLines[i], X + 12, LY + 16 + i * 17, FLinearColor(0.9f, 0.95f, 1.f), 0.5f);
	FString Flags;
	if (M->bLights) Flags += TR(TEXT("LIGHTS")) + TEXT("  ");
	if (M->bWipers) Flags += TR(TEXT("WIPERS")) + TEXT("  ");
	if (M->bDoorOpen) Flags += TR(TEXT("DOOR OPEN")) + TEXT("  ");
	if (M->bHoodOpen) Flags += TR(TEXT("HOOD OPEN")) + TEXT("  ");
	if (M->bCabView) Flags += TR(TEXT("CAB VIEW")) + TEXT("  ");
	if (!Flags.IsEmpty()) Txt(Flags, X + W + 8, H - 34, FLinearColor(0.7f, 0.8f, 0.9f), 0.5f);
	FString Warn = TR(M->Warning);
	if (M->bStuck) Warn = TR(TEXT("STUCK! Dig out the ruts, rock back and forth, or lighten the load"));
	else if (M->WheelSlip > 0.35f) Warn = TRF(TEXT("WHEEL SPIN {0}%"), RWNum(M->WheelSlip * 100.f));
	if (!Warn.IsEmpty()) Txt(Warn, Canvas->SizeX / S * 0.5f - 260, 140, FLinearColor(1.f, 0.3f, 0.2f), 0.8f, true);
}
void ARWHUD::DrawMachineSlim(ARWGameMode* GM, ARWMachine* M)
{
	// minimal HUD: one line at the bottom - engine, rpm, speed, fuel, and the grade if there is a design
	const float H = Canvas->SizeY / S;
	FVector GP; float DZ;
	FString G;
	if (M->GradePoint(GP) && ARWMachine::DesignGrade && ARWMachine::DesignGrade(GP, DZ))
	{
		const float D = GP.Z - DZ;
		G = FMath::Abs(D) < 0.03f ? TR(TEXT("ON GRADE")) : D > 0 ? TRF(TEXT("cut {0} m"), RWNum(D, 2)) : TRF(TEXT("fill {0} m"), RWNum(-D, 2));
	}
	const FString L = FString::Printf(TEXT("%s   %s   %.0f rpm   %.1f km/h   %s %.0f L   %s"), *TR(M->Model), M->bEngineOn ? *TR(TEXT("ENGINE RUNNING")) : *TR(TEXT("ENGINE OFF (I)")), M->Rpm, FMath::Abs(M->Speed) * 3.6f, *TR(TEXT("Fuel")), M->Fuel, *G);
	const float W = FMath::Min(1100.f, 24.f + L.Len() * 8.4f);
	DrawRect(FLinearColor(0.01f, 0.012f, 0.016f, 0.4f), 14 * S, (H - 44) * S, W * S, 30 * S);
	DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.9f), 14 * S, (H - 44) * S, 3 * S, 30 * S);
	Txt(L, 26, H - 40, FLinearColor(0.93f, 0.95f, 0.97f), 0.62f);
}

void ARWHUD::DrawTitle(ARWGameMode* GM, ARWPlayerController* PC)
{
	// the start screen: the living world behind, a dark band on the left with the name and the choices
	const float SW = Canvas->SizeX / S, SH = Canvas->SizeY / S;
	const int32 Bands = 96;
	for (int32 k = 0; k < Bands; ++k)
	{
		// (whole pixels, edge to edge: overlapping bands would show as stripes)
		const float Px0 = FMath::FloorToFloat(SW * 0.46f * S * k / Bands), Px1 = FMath::FloorToFloat(SW * 0.46f * S * (k + 1) / Bands);
		const float A = 0.8f * FMath::Square(1.f - k / float(Bands));
		DrawRect(FLinearColor(0.004f, 0.006f, 0.009f, A), Px0, 0, Px1 - Px0, SH * S);
	}
	DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.95f), 90 * S, 210 * S, 6 * S, 120 * S);
	Txt(TEXT("ROADWORKS"), 112, 200, FLinearColor(1.f, 0.78f, 0.3f), 2.6f, true);
	Txt(TR(TEXT("Heavy equipment & earthworks simulator")), 116, 290, FLinearColor(0.85f, 0.88f, 0.92f), 0.95f);
	const TArray<FString> Items = PC->MenuItems();
	for (int32 i = 0; i < Items.Num(); ++i)
	{
		const float Y = 400 + i * 54;
		const bool bSel = i == PC->Sel;
		if (bSel)
		{
			DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.28f), 100 * S, (Y - 6) * S, 560 * S, 46 * S);
			DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 1.f), 100 * S, (Y - 6) * S, 4 * S, 46 * S);
		}
		Txt(Items[i], 124, Y, bSel ? FLinearColor::White : FLinearColor(0.75f, 0.78f, 0.82f), 1.05f, bSel);
	}
	Txt(TR(TEXT("Up / Down to choose, Enter to select")), 116, SH - 80, FLinearColor(0.6f, 0.64f, 0.7f), 0.7f);
	Txt(FString::Printf(TEXT("%d %s"), GM->Machines.Num(), *TR(TEXT("machines in the fleet"))), SW - 360, SH - 80, FLinearColor(0.6f, 0.64f, 0.7f), 0.7f);
}

void ARWHUD::DrawMenu(ARWGameMode* GM, ARWPlayerController* PC)
{
	const TArray<FString> Items = PC->MenuItems();
	static const TCHAR* Titles[] = {TEXT(""), TEXT("MAIN MENU"), TEXT("JOB BOARD   Enter = accept / submit / track,  Backspace = abandon"), TEXT("MACHINE YARD"), TEXT("MATERIAL PLANT - LOADING BAY"), TEXT("SETTINGS   Left/Right to change"), TEXT("CONTROLS   Enter = main key   Right = second key   Left = clear second key   Esc = back"), TEXT(""), TEXT("HOW TO PLAY"), TEXT("MODS   Enter = switch on / off"), TEXT("MACHINE INSPECTION"), TEXT("ACHIEVEMENTS"), TEXT("")};
	const float W = 1100, X0 = (Canvas->SizeX / S - W) * 0.5f, Y0 = 110;
	const float RowH = PC->Menu == ERWMenu::Controls ? 21.f : 30.f;
	const float Hh = 90 + Items.Num() * RowH + (PC->Menu == ERWMenu::Jobs || PC->Menu == ERWMenu::Help || PC->Menu == ERWMenu::Mods || PC->Menu == ERWMenu::Inspect ? 240 : 40);
	Panel(X0, Y0, W, Hh, FLinearColor(0.01f, 0.012f, 0.016f, 0.8f));
	Txt(TR(Titles[(int32)PC->Menu]), X0 + 24, Y0 + 14, FLinearColor(1.f, 0.7f, 0.2f), 1.f, true);
	for (int32 i = 0; i < Items.Num(); ++i)
	{
		const float Y = Y0 + 64 + i * RowH;
		if (i == PC->Sel) DrawRect(FLinearColor(1.f, 0.55f, 0.05f, 0.35f), (X0 + 16) * S, (Y - 2) * S, (W - 32) * S, (RowH - 2) * S);
		FString T = Items[i];
		if (PC->Menu == ERWMenu::Controls && PC->Rebinding == i) T = TR(TEXT(">>> press a new key (Esc cancels) <<<"));
		Txt(T, X0 + 30, Y, i == PC->Sel ? FLinearColor::White : FLinearColor(0.8f, 0.82f, 0.85f), PC->Menu == ERWMenu::Controls ? 0.72f : 0.9f);
	}
	const float DY = Y0 + 70 + Items.Num() * RowH;
	if (PC->Menu == ERWMenu::Jobs && GM->Jobs.Jobs.IsValidIndex(PC->Sel))
	{
		const FRWJob& J = GM->Jobs.Jobs[PC->Sel];
		Txt(TRF(TEXT("{0}  -  client: {1}"), TR(J.Title), TR(J.Client)), X0 + 30, DY, FLinearColor(1.f, 0.8f, 0.4f), 0.9f);
		Txt(TR(J.Desc), X0 + 30, DY + 30, FLinearColor(0.85f, 0.85f, 0.85f), 0.75f);
		if (J.bAccepted) { Txt(J.Status, X0 + 30, DY + 58, FLinearColor(0.6f, 0.9f, 1.f), 0.75f); Bar(X0 + 30, DY + 90, 500, 14, J.Progress, FLinearColor(1.f, 0.6f, 0.1f)); Txt(TRF(TEXT("progress {0}%   quality {1}%"), RWNum(J.Progress * 100.f), RWNum(J.Quality * 100.f)), X0 + 545, DY + 84, FLinearColor::White, 0.75f); }
		Txt(J.RatePerUnit > 0 ? TRF(TEXT("Pay: base ${0} x quality + ${1} per unit of work"), RWNum(J.BasePay), RWNum(J.RatePerUnit)) : TRF(TEXT("Pay: base ${0} x quality"), RWNum(J.BasePay)), X0 + 30, DY + 116, FLinearColor(0.7f, 1.f, 0.7f), 0.75f);
		int32 k = 0;
		for (const FString& L : GM->Eco.Ledger) { if (k > 2) break; Txt(L, X0 + 30, DY + 146 + k * 20, FLinearColor(0.7f, 0.7f, 0.7f), 0.65f); ++k; }
	}
	if (PC->Menu == ERWMenu::Help)
	{
		const TCHAR* L[] = {
			TEXT("1. Accept a contract on the job board (J). Orange stakes mark the work; the GPS line on the dashboard shows cut/fill to design."),
			TEXT("2. Dig with the excavator: R/F boom, T/G stick, Y/H bucket, Q/E swing. Swing over a truck bed and dump (Y) to load it."),
			TEXT("3. Haul with the dump truck, raise the body (R) to tip. Push and spread with the dozer blade, finish with the grader."),
			TEXT("4. Compact with the roller (V = vibration) - near 45% moisture compacts best; the water truck adds moisture."),
			TEXT("5. Roads: clear trees, cut subgrade, 20 cm laterite, 15 cm gravel, 5 cm asphalt (paver), roll each layer. Then submit."),
			TEXT("6. The Machine Yard (U) sells fuel, repairs, rentals, machines, upgrades and land. The Material Plant sells materials."),
			TEXT("Rain softens the ground: heavy machines rut and can get stuck. Saving (F5) stores the whole reshaped terrain.")};
		for (int32 i = 0; i < UE_ARRAY_COUNT(L); ++i) Txt(TR(L[i]), X0 + 30, DY + i * 26, FLinearColor(0.85f, 0.85f, 0.85f), 0.72f);
	}
	if (PC->Menu == ERWMenu::Mods)
	{
		const TArray<FString> Dirs = FRWMods::SearchDirs();
		Txt(TR(TEXT("Mod folders (each mod is a folder with mod.json - see README_MODDING.md):")), X0 + 30, DY, FLinearColor(0.85f, 0.85f, 0.85f), 0.72f);
		for (int32 i = 0; i < Dirs.Num() && i < 3; ++i) Txt(Dirs[i], X0 + 30, DY + 26 + i * 24, FLinearColor(0.6f, 0.9f, 1.f), 0.7f);
		Txt(TR(TEXT("Mod machines appear in the second row of the Machine Yard. Restart the game after adding a mod.")), X0 + 30, DY + 110, FLinearColor(0.7f, 1.f, 0.7f), 0.72f);
	}
	if (PC->Menu == ERWMenu::Inspect) DrawInspect(GM, PC);
	if (PC->Menu == ERWMenu::Shop || PC->Menu == ERWMenu::Plant)
	{
		Txt(TRF(TEXT("Company funds: ${0}"), RWNum(GM->Eco.Money)), X0 + 30, DY, FLinearColor(0.6f, 1.f, 0.6f), 0.85f);
	}
}

void ARWHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas) return;
	S = Canvas->SizeY / 1080.f;
	ARWGameMode* GM = ARWGameMode::Get(this);
	ARWPlayerController* PC = Cast<ARWPlayerController>(PlayerOwner);
	if (!GM || !PC || !GM->bReady) { if (Canvas) Txt(TR(TEXT("Preparing construction site...")), 60, 60, FLinearColor::White, 1.f, true); return; }
	const float SW = Canvas->SizeX / S;
	static float Fps = 60.f;
	const float Dt = FMath::Max(GetWorld()->GetDeltaSeconds(), 1e-3f);
	Fps = FMath::Lerp(Fps, 1.f / Dt, 0.05f);
	if (PC->Menu == ERWMenu::Title) { DrawTitle(GM, PC); return; }
	const int32 Hr = FMath::FloorToInt(GM->World->TimeOfDay), Mn = FMath::FloorToInt((GM->World->TimeOfDay - Hr) * 60.f);
	const int32 Mode = PC->Menu == ERWMenu::None ? PC->HudMode : 0;
	if (Mode < 2)
	{
		// one slim strip across the top-left: money, clock, weather, temperature, frame rate
		const FString Line = TEXT("$ ") + RWNum(GM->Eco.Money) + TEXT("    ") + TRF(TEXT("Day {0}  {1}   {2}   x{3}"), FString::FromInt(GM->World->Day), FString::Printf(TEXT("%02d:%02d"), Hr, Mn), TR(GM->World->WeatherName()), RWNum(GM->World->TimeMul)) + FString::Printf(TEXT("   %.0f%sC   %.0f FPS"), GM->AirTempC(), TEXT("\u00B0"), Fps);
		const float Wl = FMath::Min(760.f, 24.f + Line.Len() * 8.6f);
		DrawRect(FLinearColor(0.01f, 0.012f, 0.016f, 0.42f), 14 * S, 14 * S, Wl * S, 30 * S);
		DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.9f), 14 * S, 14 * S, 3 * S, 30 * S);
		Txt(Line, 26, 18, FLinearColor(0.93f, 0.95f, 0.97f), 0.66f);
	}
	if (Mode == 0 && GM->Jobs.Jobs.IsValidIndex(GM->Jobs.Tracked))
	{
		// the job being tracked: a small card in the top-right corner
		const FRWJob& J = GM->Jobs.Jobs[GM->Jobs.Tracked];
		const float Wc = 440.f, X = SW - Wc - 14;
		DrawRect(FLinearColor(0.01f, 0.012f, 0.016f, 0.42f), X * S, 14 * S, Wc * S, 58 * S);
		DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.9f), X * S, 14 * S, Wc * S, 2 * S);
		Txt(TR(J.Title).Left(48), X + 12, 19, FLinearColor(1.f, 0.78f, 0.35f), 0.62f);
		const FString Tag = J.bDone ? TR(TEXT("PAID")) : GM->Jobs.CanSubmit(J) ? TR(TEXT("READY - submit (J)")) : RWNum(J.Progress * 100.f) + TEXT("%");
		Txt(Tag, X + Wc - 12 - Tag.Len() * 7.f, 19, FLinearColor::White, 0.6f);
		DrawRect(FLinearColor(1, 1, 1, 0.12f), (X + 12) * S, 44 * S, (Wc - 24) * S, 5 * S);
		DrawRect(FLinearColor(1.f, 0.62f, 0.12f, 0.95f), (X + 12) * S, 44 * S, (Wc - 24) * S * FMath::Clamp(J.Progress, 0.f, 1.f), 5 * S);
		Txt(J.Status.Left(70), X + 12, 51, FLinearColor(0.75f, 0.85f, 0.95f), 0.5f);
	}
	if (GM->MessageTime > 0 && !GM->LastMessage.IsEmpty())
	{
		const float Wd = FMath::Min(1100.f, 24.f + GM->LastMessage.Len() * 8.8f);
		DrawRect(FLinearColor(0.01f, 0.012f, 0.016f, 0.5f), (SW - Wd) * 0.5f * S, 60 * S, Wd * S, 30 * S);
		Txt(GM->LastMessage, (SW - Wd) * 0.5f + 12, 64, FLinearColor(1.f, 0.95f, 0.82f), 0.68f);
	}
	if (PC->Driving && Mode == 0) DrawMachine(GM, PC, PC->Driving);
	else if (PC->Driving && Mode == 1) DrawMachineSlim(GM, PC->Driving);
	else if (GM->Walker)
	{
		if (ARWMachine* M = GM->NearestMachine(GM->Walker->PosM, 7.f))
		{
			const FString Own = M->bOwned ? TR(TEXT("owned")) : M->bRented ? TR(TEXT("rented")) : TRF(TEXT("for rent ${0}/day or sale ${1} - press U at the yard"), RWNum(M->RentPerDay), RWNum(M->Price));
			Panel(SW * 0.5f - 400, Canvas->SizeY / S - 170, 800, 40);
			Txt(TRF(TEXT("[Enter] operate {0}  ({1})"), TR(M->Model), Own), SW * 0.5f - 386, Canvas->SizeY / S - 164, FLinearColor::White, 0.82f);
		}
	}
	if (PC->bSurvey)
	{
		FRWJob* PR = GM->Jobs.PlayerRoad();
		Panel(SW - 560, 140, 544, 150);
		Txt(TR(TEXT("SURVEY MODE")), SW - 544, 146, FLinearColor(1.f, 0.6f, 0.1f), 1.f, true);
		Txt(TRF(TEXT("Stakes: {0}   road width {1} m   last stake height {2} m"), FString::FromInt(PR ? PR->Stakes.Num() : 0), RWNum(PR ? PR->HalfW * 2 : 0.f, 1), RWNum(PR && PR->Offsets.Num() ? PR->Offsets.Last() : 0.f, 1)), SW - 544, 184, FLinearColor::White, 0.72f);
		Txt(TR(TEXT("Enter: stake here   Backspace: remove   PgUp/PgDn: height")), SW - 544, 210, FLinearColor(0.8f, 0.8f, 0.8f), 0.68f);
		Txt(TR(TEXT(", / . : width    J: publish the road on the job board")), SW - 544, 234, FLinearColor(0.8f, 0.8f, 0.8f), 0.68f);
		Txt(TRF(TEXT("Estimated contract value: ${0}"), RWNum(PR ? PR->BasePay : 0.f)), SW - 544, 258, FLinearColor(0.6f, 1.f, 0.6f), 0.68f);
	}
	if (PC->bShowHelp && PC->Menu == ERWMenu::None && Mode == 0)
	{
		const FString H = PC->Driving ? PC->Driving->HelpText() : TR(TEXT("WASD walk  Shift run  Mouse look  Enter get in machine  C camera  K survey  U use facility"));
		const FString H2 = TR(TEXT("J jobs   M map   Esc menu   F5 save   F9 load   = time x10   F1 hide help   F4 HUD"));
		// small, faint key help in the bottom-right corner (F1 hides it)
		const float Wd = FMath::Min(1200.f, FMath::Max(H.Len(), H2.Len()) * 7.4f + 24);
		DrawRect(FLinearColor(0.01f, 0.012f, 0.015f, 0.38f), (SW - Wd - 16) * S, (Canvas->SizeY / S - 54) * S, Wd * S, 42 * S);
		Txt(H, SW - Wd - 6, Canvas->SizeY / S - 51, FLinearColor(0.85f, 0.85f, 0.85f, 0.85f), 0.52f);
		Txt(H2, SW - Wd - 6, Canvas->SizeY / S - 33, FLinearColor(0.7f, 0.7f, 0.7f, 0.85f), 0.52f);
	}
	if (PC->bEditMode && PC->Menu == ERWMenu::None) DrawEditor(GM, PC);
	if (PC->Menu == ERWMenu::Map) DrawMap(GM, PC);
	else if (PC->Menu != ERWMenu::None) DrawMenu(GM, PC);
}