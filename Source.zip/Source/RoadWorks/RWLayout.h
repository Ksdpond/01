// World design: landscape height function, soil strata, zones, rivers and roads.
// Pure C++ so the terrain, world props, jobs and tests can all share it.
#pragma once

#include "CoreMinimal.h"
#include "RWTypes.h"

enum class ERWZone : uint8
{
	Depot, Plant, Site, Village, Quarry, SandPit, MudFlat, Forest, DumpSite, Knoll, Plot, Paddy, Flat, Mine
};

// a stream running down from the hills to the river or the lake (densified centre line, bed height at each point)
struct FRWStream
{
	TArray<FVector2D> Pts;
	TArray<float> Bed;
	float HalfW = 2.5f;
};

// a steep forested limestone hill standing out of the plain
struct FRWTower
{
	FVector2D C = FVector2D::ZeroVector;
	float R = 60.f, H = 100.f;
};

struct FRWZone
{
	FString Name;
	ERWZone Type;
	FVector2D C;
	FVector2D HalfExt;
	float Blend = 12.f;
	float Z = 0.f; // computed flatten height
};

struct FRWRoad
{
	FString Name;
	TArray<FVector2D> Pts;
	TArray<float> Z;   // profile height at each densified point
	float HalfW = 3.5f;
	bool bAsphalt = true;
	float MaxGrade = 0.f; // steepest the road may climb (rise / run); 0 = follows the ground
};

// Everything that shapes the mountains: the same values and seed always give the same map ([RoadWorks.Map] in DefaultGame.ini)
struct FRWMapParams
{
	int32 Seed = 0;
	float FootCrest = 1150.f, FootHeight = 170.f;   // foothill ridge: distance from the middle of the map, height
	float MainCrest = 1950.f, MainHeight = 560.f;   // main range
	float HighCrest = 3400.f, HighHeight = 1050.f;  // high range behind the map's edge
	float RangeWander = 260.f;                      // how far the ranges wander off their line (m)
	float Ceiling = 1700.f;                         // the highest ground rounds over towards this
	float TreeLine = 480.f;                         // the forest stops around this height
};

class ROADWORKS_API FRWLayout
{
public:
	void Init();

	static constexpr float MapHalf = 2250.f; // the map spans [-MapHalf, MapHalf]: 4500 x 4500 m

	FRWMapParams Params;
	float WaterZ = 0.f;
	TArray<FRWZone> Zones;
	TArray<FRWRoad> Roads;
	TArray<FRWStream> Streams;
	TArray<FRWTower> Towers;
	// reservoirs: centre and radius (m); their surface is at the water table
	struct FRWLake { FVector2D C; float R; float Z = 0.f; }; // Z: the surface of its water
	TArray<FRWLake> Lakes;
	// metres from the shore of the nearest reservoir (negative in the water)
	float LakeShoreDist(float X, float Y) const;

	// metres to the nearest stream (large when there is none near), and its bed height there
	float StreamDist(float X, float Y) const;
	float StreamBed(float X, float Y) const;
	// how much of a limestone hill stands here (0..1): its steep faces are rock
	float TowerAt(float X, float Y) const;
	// one rice field of a paddy zone: its water-free floor level and how much of a bund (0..1) stands at this point
	static constexpr float PaddyFieldX = 38.f;
	static constexpr float PaddyFieldY = 28.f;
	static void PaddyField(const FRWZone& Z, float X, float Y, float& OutLevel, float& OutBund);

	const FRWZone* Find(ERWZone T, int32 Nth = 0) const;
	const FRWZone* FindByName(const FString& Name) const;
	static float ZoneWeight(const FRWZone& Z, float X, float Y);
	static bool InZone(const FRWZone& Z, float X, float Y, float Margin = 0.f);

	float RiverY(float X) const;
	float RiverDist(float X, float Y) const { return FMath::Abs(Y - RiverY(X)); }

	// Landscape without roads (used inside and outside the playable area).
	float Landscape(float X, float Y, bool bDetail) const;
	// Natural surface including zones (no road layers).
	float NaturalHeight(float X, float Y) const;
	// Road query: returns true if (X,Y) is within a road, with profile height and lateral distance.
	bool RoadAt(float X, float Y, float& OutZ, float& OutLat, const FRWRoad** OutRoad = nullptr, float Extra = 0.f) const;
	float RoadInfluence(float X, float Y, float& OutZ) const;

	ESoil Strata(float X, float Y, float Depth) const;
	float InitMoisture(float X, float Y, float H) const;
	float InitGrass(float X, float Y) const;

	// Pot-holed stretch of the main road used by the repair job.
	FVector2D PotholeA, PotholeB;

	// A route over the bare landscape that climbs no steeper than MaxGrade wherever it can: it winds up a slope instead of going straight at it.
	// (bWater: the way water would take instead, keeping to the low ground and climbing as little as it can)
	TArray<FVector2D> PlanRoute(const FVector2D& From, const FVector2D& To, float MaxGrade, bool bWater = false) const;
	// Where the ridge at this bearing lies (highest ground between RMin and RMax from the middle of the map).
	FVector2D CrestAt(float BearingDeg, float RMin, float RMax) const;
	// Heights the road profile may take: follows Raw but never climbs faster than MaxGrade, as much cut as fill.
	static void LimitGrade(TArray<float>& Z, const TArray<FVector2D>& Pts, float MaxGrade);

	// Sculpted changes from the Unreal Editor's Landscape (see RWMapTools), added on top of the generated ground; none = none yet.
	void SetSculpt(TArray<float>&& Delta, int32 Size);
	bool bIgnoreSculpt = false; // (the editor's own comparison needs the plain generated ground)
	FVector2D SculptPeak = FVector2D::ZeroVector; float SculptPeakH = 0.f; // where the largest sculpted change is
	// What the map's level (edited in the Unreal Editor) holds, used instead of what the generator would make: set before Init.
	TArray<FRWLake> LevelLakes;
	TMap<FString, TArray<FVector2D>> LevelRoads; // by road name
	TArray<FVector> LevelTrees;                  // where the forest stands (x, y) and how big (z = scale)
	// every tree and plant placed in the level, by model (bTree: it can be pushed over)
	struct FLevelPlants { FString Mesh; bool bTree = false; TArray<FTransform> Instances; };
	TArray<FLevelPlants> LevelPlants;
	// the scenery as edited in the level (RW_Scenery actors, see RWScenery.h): each part of what the game builds by its id,
	// each object by its name with where it was (Anchor) and where it is now; Mesh / Mats only when changed in the editor
	struct FLevelComp { bool bInst = false; bool bMoved = false; FTransform X; TArray<FTransform> Inst; FString Mesh; TArray<FString> Mats; };
	struct FLevelObj { uint8 Kind = 0; FTransform Anchor, Now; };
	TMap<FString, FLevelComp> LevelComps;
	TMap<FString, FLevelObj> LevelObjs;
	// the machines placed in the level (RW_Machine): where each starts, by its key (model or class, '#', number)
	TMap<FString, FTransform> LevelMachines;
	// soil heaps (RW_Pile) and the excavation already under way at the start (RW_Dig: x, y, yaw); bLevelPiles: the level
	// says where they are (and an empty list then means none)
	struct FLevelPile { FVector P = FVector::ZeroVector; float R = 5.f, H = 2.f; uint8 Soil = 0; };
	bool bLevelPiles = false;
	TArray<FLevelPile> LevelPiles;
	TArray<FVector> LevelDigs;
	static FString SculptFile();
	static bool ReadSculptFile(int32 Seed, TArray<float>& OutDelta, int32 Size);
	static bool WriteSculptFile(int32 Seed, const TArray<float>& Delta, int32 Size);
	float SculptAt(float X, float Y) const;
	bool HasSculpt() const { return SculptN > 0; }

private:
	TArray<float> Sculpt;
	int32 SculptN = 0;
	void Densify(FRWRoad& R);
	void BuildStreams();
	// stream distance / bed on a 4 m grid, so the height function stays fast
	TArray<float> StreamGridD, StreamGridZ;
	static constexpr int32 StreamGridN = 1151;
	static constexpr float StreamGridCell = 4.f;
	static constexpr float StreamGridHalf = 2300.f;
	// cells (8 m) with a road nearby: most places on this map have none, and need no search through every road
	TBitArray<> RoadMask;
	static constexpr int32 RoadMaskN = 576;
	static constexpr float RoadMaskCell = 8.f;
	static constexpr float RoadMaskHalf = 2300.f;
};
