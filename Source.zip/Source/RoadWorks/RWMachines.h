// Concrete machines. Each one owns its working tool and the soil interaction for it.
#pragma once

#include "CoreMinimal.h"
#include "RWMachine.h"
#include "RWMachines.generated.h"

// Loose objects: felled logs, boulders, concrete barriers, culvert pipes. Can be carried by grapple or crane.
UCLASS()
class ROADWORKS_API ARWProp : public AActor
{
	GENERATED_BODY()
public:
	ARWProp();
	virtual void Tick(float Dt) override;
	void Init(int32 InType, ARWTerrain* InTerrain, const FVector& PosM, float YawDeg);
	int32 Type = 0; // 0 log, 1 boulder, 2 barrier, 3 pipe
	float MassKg = 800.f;
	bool bCarried = false;
	FVector VelM = FVector::ZeroVector;
	float FallAngle = 0.f; // trees falling over
	float FallYaw = 0.f;
	// a felled tree is cleared away this many seconds after it has come down on the ground (0: it stays); LyingTime counts
	static constexpr float FelledTreeLife = 15.f;
	float RemoveAfter = 0.f;
	float LyingTime = 0.f;
	// a felled tree's bumper: it rests on the ground along its whole length (its trunk near the stump, its crown further up,
	// which gives a little) and tilts with the ground, instead of lying flat 0.22 m over the ground under its stump - which
	// put half a tree model's crown, and its top end on a slope, into the ground. LieTilt: how far its top end is raised (deg).
	float LieTilt = 0.f;
	// the height (m) the trunk's line must be at, at its stump end P, so that no part of the bumper is in the ground, and the tilt
	float LogRestZ(const FVector& P, float& OutTilt) const;
	float RockSize = 1.f; // a boulder's size (1 = about 1.5 x 1.3 x 1.1 m)
	void SetRockSize(float S);
	// a rock with its own model, as it was placed in the level (WorldX: where the model stood, turned and scaled); its size
	// and weight come from the model (stone of 2650 kg/m3 filling about half its box)
	void SetRockModel(UStaticMesh* M, const TArray<UMaterialInterface*>& Mats, const FTransform& WorldX);
	// a felled trunk's length (m)
	float LogLength() const;
	// the model and its place on the prop, for saved games (its mesh and materials when they are assets, else empty)
	void GetLook(FString& OutMesh, FString& OutMats, FTransform& OutRel) const;
	void SetLook(const FString& InMesh, const FString& InMats, const FTransform& InRel, float InRockSize, float InMass);
	// pushed by a machine moving at V (m/s) through the point P with a reach of R; false if it is not touched
	// HalfH: half the height of what pushes (a blade, a bucket, a track), centred on P.Z: it only moves the prop where the
	// two really meet - a blade lifted over a trunk passes over it. A pushed prop keeps sliding a little once it is let go.
	bool Push(const FVector& P, float R, const FVector& V, float Dt, float HalfH = 0.6f);
	int32 PushedFrames = 0; // frames since the last push (sliding on its own after that)
	UPROPERTY() UStaticMeshComponent* Mesh = nullptr;
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	static TArray<TWeakObjectPtr<ARWProp>> All;
	FVector PosM() const { return GetActorLocation() * CM2M; }
	FString Label() const;
	// ---- pipe laying (Type 3): set down by a machine, a pipe stays where it is laid (soil can bury it), joins the pipe
	// next to it end to end, and water runs through the whole run. The actor sits at the middle of the pipe's underside.
	static constexpr float PipeLen = 3.f;
	static constexpr float PipeDia = 0.9f;
	static constexpr float PipeMaxStep = 0.3f; // m: more height difference than this between two ends and they do not join
	bool bLaid = false;
	bool bWasCarried = false;
	void PipeEnds(FVector& A, FVector& B) const; // floor of the pipe at each end, metres
	void LayPipe();
	// the soil over a pipe: how thick it is at the thinnest place (m, negative = part of the pipe shows), and the ground under
	// and around a laid pipe that a bucket cannot go through (digging stops on the pipe)
	float PipeCover() const;
	void UpdatePipeFloor();
	void ClearPipeFloor();
	virtual void Destroyed() override;
	TArray<int32> PipeFloorCells;
	bool bPipeBuried = false;
	struct FPipeRun { FVector In = FVector::ZeroVector, Out = FVector::ZeroVector; int32 Count = 0; };
	static void PipeRuns(TArray<FPipeRun>& Out); // joined pipes, highest end first
};

// An excavator bucket's real dimensions (built-in sizes, or "bucket" / "attachments" in a mod.json).
struct FBucketSpec
{
	FString Id, Name, Type = TEXT("standard"); // standard, grading, trenching, heavy
	float Width = 1.2f;    // cutting edge width (m) = dig and grading coverage
	float Capacity = 1.1f; // heaped loose m3
	float Depth = 0.6f;    // mouth to back of the shell (m) - shapes the backside grading surface
	float MassKg = 900.f;
	float Hardness = 1.f;  // heavy-duty / rock buckets break hard ground more easily (<1 = easier)
};

// Shared bucket physics (excavator, loader).
struct FBucketTool
{
	float Width = 1.2f, Capacity = 1.0f;
	float Depth = 0.6f, MassKg = 900.f, CutEase = 1.f;
	// backside grading
	FPayload GradeCarry;      // soil scraped off the high spots, dragged along to fill the low ones
	bool bGrading = false;
	float GradedWidth = 0.f;  // width of the strip being smoothed this frame (m)
	float Grade(ARWTerrain* T, const FVector& Tip, const FVector& Pivot, const FVector& Lat, const FVector& TipVel, const FVector& Mouth, float Dt);
	// swinging with the bucket on the ground: its side plate sweeps the surface flat and pushes the soil aside
	bool bSweeping = false;
	float SweptVol = 0.f; // m3 pushed aside so far (tests / HUD)
	float Sweep(ARWTerrain* T, const FVector& Tip, const FVector& Pivot, const FVector& TipVel, const FVector& Mouth, float Dt);
	FPayload Load;
	float Resist = 0.f, CutRate = 0.f, Penetration = 0.f;
	bool bBlocked = false;
	// how well the bucket meets the soil: 1 = mouth straight into the cut, 0 = dragging the flat bottom
	float Attack = 0.f;
	// last material the teeth broke out, how deep below the natural ground, and where (for breakout chunks)
	ESoil CutMat = ESoil::DrySoil; float CutDepth = 0.f, CutTimer = 0.f, CutMoist = 0.f;
	FVector LowestOfBack(const FVector& Tip, const FVector& Pivot, const FVector& Mouth) const; // the point of the bucket's back that meets the ground first
	FVector BreakAt = FVector::ZeroVector;
	float Shake = 0.f; // smoothed bucket acceleration (m/s2): fast swings shake heaped soil off the top
	// soil forces (see RWSoilMech): what the ground pushes back with, and the most this machine's hydraulics can push
	float DigForceN = 0.f, DigHorizN = 0.f, DigVertN = 0.f;
	float ForceLimitN = 150000.f;
	float ForceFrac() const { return ForceLimitN > 1.f ? DigForceN / ForceLimitN : 0.f; }
	// Returns resistance: 2 x (soil force / force limit), so 0 = free and 2 = stalled. Positions/vectors in metres.
	float Dig(ARWTerrain* T, const FVector& Tip, const FVector& Heel, const FVector& Lat, const FVector& TipVel, const FVector& Mouth, float Power, float Dt);
	// HoldLoose: loose m3 the bucket holds in its present attitude, with the soil at its angle of repose and level with
	// the lip; anything above that runs over the lip like water over a weir. Negative = judge by the mouth angle alone.
	// Along (optional): half the edge the soil leaves over (world, m) - the lumps are spread along that edge instead of all
	// round At, so none of them start back over the bucket's floor
	float Spill(ARWEffects* Fx, const FVector& At, const FVector& Vel, const FVector& Mouth, float Dt, float HoldLoose = -1.f, const FVector& Along = FVector::ZeroVector);
};

UCLASS()
class ROADWORKS_API ARWExcavator : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWExcavator() { Kind = EMachineKind::Excavator; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual float PayloadKg() const override { return Bucket.Load.MassKg(); }
	virtual void ToolCycle() override;
	virtual void WorkToggle() override;
	virtual bool GradePoint(FVector& Out) const override;
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return WorkKW; }
	// stability: undercarriage, house (with its counterweight), boom, stick, bucket and its load, each where it is now; the
	// masses from vehicle.xml when it gives them, otherwise the machine's mass (mod.json / built-in list) split by estimate
	virtual void MassParts(TArray<FMassPart>& Out) const override;
	// the soil resists the bucket's movement: as hard as it digs, no harder than the hydraulics can push
	virtual FVector ToolForceN(FVector& AtWorld) const override;

	float S = 1.f; // size scale
	float Swing = 0, BoomA = 25, ArmA = -95, BktA = -60;
	float VSwing = 0, VBoom = 0, VArm = 0, VBkt = 0;
	float Lb = 5.7f, La = 2.9f, Lk = 1.45f;
	int32 Tool = 0; // 0 bucket, 1 breaker, 2 grapple, 3 auger
	bool bToolActive = false;
	float HammerAcc = 0.f, WorkKW = 0.f, GrappleClose = 0.f;
	FBucketTool Bucket;
	// bucket attachments this machine can carry (built-in standard / grading / trenching / heavy + mod buckets)
	TArray<FBucketSpec> BucketSpecs;
	int32 BucketIdx = 0;
	float BaseEmptyMass = 0.f;
	void ApplyBucket(int32 Idx);
	void BuildBucketMesh();
	FVector LastTip = FVector::ZeroVector;
	FVector LastTipVel = FVector::ZeroVector;
	float ChunkAcc = 0.f; // broken-out volume waiting to show as breakout chunks
	float PourAcc = 0.f;  // poured volume waiting to show as a stream of clods
	float DebrisT = 0.f;  // time since the last bits fell off a heaped bucket
	float TrickleT = 0.f, SinceCut = 99.f; // fine soil trickling off a loaded bucket (strongest right after the cut)
	int32 DbgBranch = -1; float DbgInto = 0.f, DbgPen = 0.f, DbgBelly = 0.f, DbgBellyGap = 0.f;
	FVector LastBelly = FVector::ZeroVector; // last bucket decision: 0 dig, 1 back-grade, 2 side-sweep, 3 bearing
	// which side of the pin-to-teeth line the bucket shell is on, in the bucket's frame: +1 = +Z (built-in buckets,
	// mouth faces -Z), -1 = -Z (e.g. the CX250D model, mouth faces +Z). Measured from the model when it is rigged.
	float BucketSign = 1.f;
	// a model bucket's real shell, measured from its vertices: (x along the bucket, depth of the steel on the shell
	// side) in metres from the back plate to the teeth. Empty for built-in buckets (their shell is a known curve).
	TArray<FVector2D> BucketProfile;
	float BucketRimZ = 0.02f;      // how far into the shell the rim of the side plates dips (m, bucket frame): level-full stands here
	float BucketInnerFrac = 0.86f; // inside width between the side plates, as a share of the bucket's width
	// A model bucket's own steel (bucket frame, metres): its triangles, 3 points each - and, measured from them with rays,
	// per slice along the bucket: x, the depth of the INSIDE of the floor (shell side) and the inside half width between the
	// side plates. The soil drawn in the bucket keeps to these. Empty for built-in buckets (their shell is a known curve).
	TArray<FVector> BucketSteel;
	TArray<FVector> BucketInside;
	float BucketYMid = 0.f;
	// the first steel triangle a ray from O along D (unit) meets within MaxT; its distance in OutT
	static bool RaySteel(const TArray<FVector>& Tris, const FVector& O, const FVector& D, float MaxT, float& OutT);
	float InsideHalfAt(float X, float Def) const; // inside half width at x along the bucket (Def where it is not known)
	// Where soil leaves the bucket (world, m): over the lower edge of the opening while the mouth faces up, out through the
	// opening when it faces down, or (bAtTeeth) off the outside of the teeth - just outside the steel, never inside the shell
	// (soil started inside fell straight through the bucket's own floor). Side -1..1: across the inside width.
	FVector SoilExitAt(float Side, bool bAtTeeth = false) const;
	// (the exit in the bucket's (x, z) plane: the lowest edge, as close to it as soil falling from there misses the bucket's
	// own steel - kept until the bucket moves)
	FVector2D FindSoilExit(const FTransform& BT, bool bAtTeeth) const;
	mutable FTransform ExitBT[2];
	mutable FVector2D ExitAt2D[2];
	mutable bool bExitKnown[2] = {false, false};
	// Test B: the points of the drawn soil that lie outside the bucket's steel (through the floor or a side plate, past the
	// teeth or the back), of how many points, and the furthest one out (m)
	void SoilOutsideSteel(int32& Outside, int32& Total, float& Worst) const;
	FVector MouthDir() const; // world direction the bucket opening faces
	float MouthUpInput() const; // bucket input that turns the opening upwards from the current pose
	bool bDebugBucket = false; // F6: show the bucket cavity box and the soil in bright pink
	static constexpr bool bPropLift = false; // pressing the bucket down lifts the machine (switched off on request)
	// scripted operator (tests / screenshot scenes): drives the real controls - open, lower, dig until the bucket
	// holds TargetFrac of its capacity, curl and lift; with bDump it then swings and dumps down to DumpTo.
	// Returns true when finished. Phase / PhaseT are the caller's state (start both at 0).
	bool AutoDig(float Dt, float TargetFrac, bool bDump, float DumpTo, int32& Phase, float& PhaseT);
	TWeakObjectPtr<ARWProp> Held;
	TWeakObjectPtr<ARWProp> InBucket; // a rock or a felled trunk scooped up by the bucket
	float InBucketLen = 0.f;           // (a trunk: its length, it lies across the bucket)
	UPROPERTY() TArray<UStaticMeshComponent*> HeapClods; // lumps on top of the heaped load
	void UpdateHeapClods();
	// soil inside the bucket shaped by the bucket's own cross-section: fills from the bottom of the shell up to a
	// level surface (stays level when the bucket tilts), heaps above the rim when overloaded
	UPROPERTY() class UProceduralMeshComponent* FillMesh = nullptr;
	int32 FillKey = -1;
	float FillLevelFrac = 0.f; // share of the struck (level-full) volume inside the shell (tests / HUD)
	// surface grid cells along and across the bucket
	static constexpr int32 FillNT = 56;
	static constexpr int32 FillNW = 40;
	int32 FillBaseVerts = 0;   // vertices of the soil body (surface, skirts); the loose grains and lumps come after
	double FillBuiltAt = 0.0;  // when the soil mesh was last rebuilt
	void UpdateBucketFill();
	// the soil-holding cross-section, in the bucket's (x, z) plane, closed across the mouth from lip to back edge
	void BuildFillPoly(TArray<FVector2D>& Poly) const;
	// loose m3 the bucket can hold in its present attitude before soil runs over the lip
	float BucketHoldLoose() const;
	float DragSpeed = 0.f; // m/s: the machine being pulled along when the soil force beats its tracks' grip
	FVector DragVel = FVector::ZeroVector; // that slide as a velocity
	// a pipe slung on a chain under the bucket: V picks up / sets down, B turns it a quarter
	TWeakObjectPtr<ARWProp> Slung;
	FVector2D SlingOff = FVector2D::ZeroVector, SlingVel = FVector2D::ZeroVector;
	FVector SlingLastTipVel = FVector::ZeroVector;
	float SlingYaw = 0.f;
	UPROPERTY() UStaticMeshComponent* SlingMesh = nullptr;
	bool SlingGrab();     // the nearest pipe within reach of the bucket; false if there is none
	void SlingRelease();
	void SlingTick(const FVector& Tip, const FVector& TipVel, float Dt);

	UPROPERTY() USceneComponent* House = nullptr;
	UPROPERTY() USceneComponent* BoomP = nullptr;
	UPROPERTY() USceneComponent* ArmP = nullptr;
	UPROPERTY() USceneComponent* BucketP = nullptr;
	UPROPERTY() TArray<USceneComponent*> ToolRoots;
	UPROPERTY() UStaticMeshComponent* Heap = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* HeapMID = nullptr;
	UPROPERTY() USceneComponent* JawL = nullptr;
	UPROPERTY() USceneComponent* JawR = nullptr;
	UPROPERTY() USceneComponent* Auger = nullptr;
	FVector TipWorld() const;

	// ---- rig built from a modder's 3D model (RWModelRig.cpp) ----
	bool BuildFromModel();
	void UpdateAims();
	bool bModelRig = false;
	float BoomLo = -50.f, BoomHi = 62.f, ArmLo = -158.f, ArmHi = -28.f, BktLo = -165.f, BktHi = 40.f;
	struct FAim { USceneComponent* P = nullptr; USceneComponent* Target = nullptr; FTransform RestRel; FVector Axis = FVector::ForwardVector; };
	TArray<FAim> Aims;
	// bucket four-bar linkage: arm link (pin C on the stick) + bucket link (pin B on the bucket) meet at D,
	// where the bucket cylinder's rod is pinned. Solved every frame from the bucket angle.
	struct FLinkage
	{
		bool bOn = false;
		USceneComponent* ArmLink = nullptr; USceneComponent* BktLink = nullptr;
		int32 RodAim = -1;
		FVector2D A, B0, C, D0, Dprev; float L1 = 0, L2 = 0, BktRest = 0, Y = 0;
	} Link;
	void UpdateLinkage();
	UPROPERTY() TArray<USceneComponent*> RigPivots;
};

UCLASS()
class ROADWORKS_API ARWDumpTruck : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWDumpTruck() { Kind = EMachineKind::DumpTruck; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual bool TryReceive(const FVector& P, ESoil M, float Vol, float Moist) override;
	virtual float PayloadKg() const override { return Load.MassKg(); }
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return FMath::Abs(BedVel) > 0.1f ? 40.f : 0.f; }

	FPayload Load;
	float Capacity = 10.f; // heaped loose m3
	float BedAngle = 0, BedVel = 0, BedLen = 4.6f, BedW = 2.3f, BedH = 1.0f;
	float Spilled = 0.f, Delivered = 0.f;
	FVector BedPivotL = FVector::ZeroVector;
	UPROPERTY() USceneComponent* BedP = nullptr;
	UPROPERTY() USceneComponent* GateP = nullptr;
	UPROPERTY() UStaticMeshComponent* Heap = nullptr;
	UPROPERTY() UStaticMeshComponent* HeapTop = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* HeapMID = nullptr;
};

UCLASS()
class ROADWORKS_API ARWDozer : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWDozer() { Kind = EMachineKind::Bulldozer; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual void ToolCycle() override { if (bHasRipper) bRipper = !bRipper; }
	virtual bool GradePoint(FVector& Out) const override;
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return 20.f + FMath::Abs(BladeVel) * 30.f; }
	// a mod's own 3D model: the push frame turns about its trunnion pins to raise and lower the blade
	bool BuildFromModel();
	UPROPERTY() USceneComponent* CFrameP = nullptr;
	float CFrameL = 1.f, CFrameA0 = 0.f, CFramePinZ = 0.f;
	bool bHasRipper = true;

	float BladeH = 0.6f, BladeVel = 0, BladeTilt = 0, BladeW = 3.4f, BladeX = 2.9f;
	// XML native controls configure the existing physics channel, not a second transform owner.
	float RWBladeLiftSpeed = 0.45f, RWBladeLiftMin = -0.45f, RWBladeLiftMax = 1.2f;
	float RWBladeTiltSpeed = 6.f, RWBladeTiltMin = -8.f, RWBladeTiltMax = 8.f;
	bool bRWXmlLiftBound = false, bRWXmlTiltBound = false;
	float BladeTall = 1.3f; // the blade's own height over its cutting edge (m): what it pushes, and nothing above it
	float RipperH = 0.f; bool bRipper = false;
	float PileVol = 0.f, CutTotal = 0.f;
	UPROPERTY() USceneComponent* BladeP = nullptr;
	UPROPERTY() USceneComponent* RipperP = nullptr;
};

UCLASS()
class ROADWORKS_API ARWLoader : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWLoader() { Kind = EMachineKind::WheelLoader; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual float PayloadKg() const override { return Bucket.Load.MassKg(); }
	virtual bool GradePoint(FVector& Out) const override;
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return WorkKW; }

	float LiftA = -40, TiltA = 5, VLift = 0, VTilt = 0, WorkKW = 0;
	float ArmLen = 3.1f;
	FBucketTool Bucket;
	FVector LastLip = FVector::ZeroVector;
	UPROPERTY() USceneComponent* FrontP = nullptr;
	UPROPERTY() USceneComponent* RearP = nullptr;
	UPROPERTY() USceneComponent* LiftP = nullptr;
	UPROPERTY() USceneComponent* BucketP = nullptr;
	UPROPERTY() UStaticMeshComponent* Heap = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* HeapMID = nullptr;
	FVector LipWorld() const;
};

UCLASS()
class ROADWORKS_API ARWGrader : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWGrader() { Kind = EMachineKind::Grader; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual bool GradePoint(FVector& Out) const override;
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return 15.f + Carried * 20.f; }

	float BladeH = 0.25f, BladeYaw = 30.f, BladeW = 3.7f, BladeX = 0.4f, BladeVel = 0.f;
	float Carried = 0.f; FPayload CarriedLoad;
	bool bAutoGrade = false;
	UPROPERTY() USceneComponent* BladeP = nullptr;
};

UCLASS()
class ROADWORKS_API ARWRoller : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWRoller() { Kind = EMachineKind::Roller; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual void WorkToggle() override { bVibe = !bVibe; }
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return bVibe ? 35.f : 0.f; }
	bool bVibe = false;
	int32 Passes = 0;
	FVector2D LastPass = FVector2D(1e9, 1e9);
	float DrumR = 0.76f, DrumW = 2.13f, DrumX = 1.55f;
};

UCLASS()
class ROADWORKS_API ARWPaver : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWPaver() { Kind = EMachineKind::Paver; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual void WorkToggle() override { bPaving = !bPaving; }
	virtual bool TryReceive(const FVector& P, ESoil M, float Vol, float Moist) override;
	virtual float PayloadKg() const override { return Hopper.MassKg(); }
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return bPaving ? 45.f : 5.f; }
	FPayload Hopper;
	float HopperCap = 12.f;
	bool bPaving = false;
	float Thick = 0.06f, ScreedW = 3.0f, Laid = 0.f;
	FVector2D LastLay = FVector2D(1e9, 1e9);
	UPROPERTY() USceneComponent* ScreedL = nullptr;
	UPROPERTY() USceneComponent* ScreedR = nullptr;
	UPROPERTY() UStaticMeshComponent* HopperHeap = nullptr;
};

UCLASS()
class ROADWORKS_API ARWWaterTruck : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWWaterTruck() { Kind = EMachineKind::WaterTruck; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual void WorkToggle() override { bSpray = !bSpray; }
	virtual float PayloadKg() const override { return Water; }
	virtual void SerializeState(FArchive& Ar) override;
	float Water = 12000.f, WaterCap = 12000.f;
	bool bSpray = false;
};

UCLASS()
class ROADWORKS_API ARWCrane : public ARWMachine
{
	GENERATED_BODY()
public:
	ARWCrane() { Kind = EMachineKind::Crane; bHandThrottle = false; }
	virtual void Build() override;
	virtual void WorkTick(float Dt) override;
	virtual void VisualTick(float Dt) override;
	virtual FString HelpText() const override;
	virtual FString ToolText() const override;
	virtual void WorkToggle() override;
	virtual void ToolCycle() override;
	virtual void SerializeState(FArchive& Ar) override;
	virtual float WorkPowerKW() const override { return WorkKW; }
	float Slew = 0, Luff = 20, Tele = 11, Rope = 4, WorkKW = 0, Outrig = 0;
	bool bOutriggers = false;
	TWeakObjectPtr<ARWProp> Hooked;
	float AllowedKg() const;
	float Radius() const;
	FVector HookWorld() const;
	UPROPERTY() USceneComponent* Upper = nullptr;
	UPROPERTY() USceneComponent* BoomP = nullptr;
	UPROPERTY() TArray<USceneComponent*> Sections;
	UPROPERTY() UStaticMeshComponent* RopeMesh = nullptr;
	UPROPERTY() USceneComponent* HookP = nullptr;
	UPROPERTY() TArray<USceneComponent*> OutriggerBeams;
};
