#include "RWWorld.h"
#include "Serialization/MemoryWriter.h"
#include "Misc/FileHelper.h"
#include "HAL/FileManager.h"
#include "RWTerrain.h"
#include "RWLayout.h"
#include "RWEffects.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWAudio.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyAtmosphereComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Components/VolumetricCloudComponent.h"
#include "Components/PostProcessComponent.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/World.h"
#include "RWMeshGen.h"
#include "RWMods.h"
#include "RWFab.h"
#include "ProceduralMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Misc/CommandLine.h"
#include "Misc/ScopeExit.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystem.h"
#include "EngineUtils.h"
#include "LandscapeProxy.h"
#include "Misc/PackageName.h"
#include "Engine/StaticMesh.h"

ARWWorld::ARWWorld()
{
	PrimaryActorTick.bCanEverTick = true;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	Sun = CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("Sun"));
	Sun->SetupAttachment(RootComponent);
	Moon = CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("Moon"));
	Moon->SetupAttachment(RootComponent);
	Atmos = CreateDefaultSubobject<USkyAtmosphereComponent>(TEXT("Atmos"));
	Atmos->SetupAttachment(RootComponent);
	SkyLight = CreateDefaultSubobject<USkyLightComponent>(TEXT("SkyLight"));
	SkyLight->SetupAttachment(RootComponent);
	Fog = CreateDefaultSubobject<UExponentialHeightFogComponent>(TEXT("Fog"));
	Fog->SetupAttachment(RootComponent);
	Clouds = CreateDefaultSubobject<UVolumetricCloudComponent>(TEXT("Clouds"));
	Clouds->SetupAttachment(RootComponent);
	Post = CreateDefaultSubobject<UPostProcessComponent>(TEXT("Post"));
	Post->SetupAttachment(RootComponent);
	Ambient = CreateDefaultSubobject<URWAmbientSynth>(TEXT("Ambient"));
	Ambient->SetupAttachment(RootComponent);
}

UMaterialInstanceDynamic* ARWWorld::Mat(const FLinearColor& C, float Rough, float Metal)
{
	const FLinearColor Key(C.R, C.G, C.B, Rough + Metal * 10.f);
	if (UMaterialInstanceDynamic** F = MatCache.Find(Key)) return *F;
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(PaintMat, this);
	M->SetVectorParameterValue(TEXT("Color"), C);
	M->SetScalarParameterValue(TEXT("Roughness"), Rough);
	M->SetScalarParameterValue(TEXT("Metallic"), Metal);
	MatCache.Add(Key, M);
	return M;
}

UStaticMeshComponent* ARWWorld::Box(const FVector& C, const FVector& S, float Yaw, const FLinearColor& Col, bool bObstacle, float Rough, float Metal, UStaticMesh* Mesh, const FRotator& Extra)
{
	UStaticMeshComponent* B = NewObject<UStaticMeshComponent>(this);
	UStaticMesh* Detailed = nullptr;
	if (!Mesh && S.GetMin() > 0.01f) Detailed = FRWMeshGen::RoundBox(S, FMath::Min(0.08f, S.GetMin() * 0.2f));
	else if (Mesh == ARWMachine::GCyl && FMath::IsNearlyEqual(S.X, S.Y, 0.01f)) Detailed = FRWMeshGen::RoundCyl(S.X, S.Z);
	B->SetStaticMesh(Detailed ? Detailed : (Mesh ? Mesh : ARWMachine::GCube));
	B->SetMaterial(0, Mat(Col, Rough, Metal));
	B->SetupAttachment(RootComponent);
	B->SetMobility(EComponentMobility::Movable);
	B->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	B->SetWorldLocationAndRotation(C * M2CM, (FRotator(0, Yaw, 0).Quaternion() * Extra.Quaternion()).Rotator());
	B->SetWorldScale3D(Detailed ? FVector::OneVector : S);
	B->RegisterComponent();
	if (!CurObj.IsNone()) CompObj.Add(B, CurObj);
	if (bObstacle) Obstacles.Add({FVector2D(C.X, C.Y), FVector2D(S.X * 0.5f, S.Y * 0.5f), Yaw, CurObj});
	return B;
}

void ARWWorld::Build(const FRWLayout* InLayout, ARWTerrain* InTerrain, ARWEffects* InFx, UMaterialInterface* Paint, UMaterialInterface* WaterMat, UMaterialInterface* CloudMat)
{
	Layout = InLayout; Terrain = InTerrain; Fx = InFx; PaintMat = Paint;
	// ---- lighting ----
	Sun->SetMobility(EComponentMobility::Movable);
	Sun->SetIntensity(10.f);
	Sun->SetAtmosphereSunLight(true);
	Sun->SetAtmosphereSunLightIndex(0);
	Sun->SetLightColor(FLinearColor(1.f, 0.96f, 0.9f));
	Sun->SetDynamicShadowCascades(4);
	Sun->DynamicShadowDistanceMovableLight = 40000.f;
	Sun->SetCastShadows(true);
	Moon->SetMobility(EComponentMobility::Movable);
	Moon->SetIntensity(0.06f);
	Moon->SetLightColor(FLinearColor(0.55f, 0.65f, 1.f));
	Moon->SetAtmosphereSunLight(true);
	Moon->SetAtmosphereSunLightIndex(1);
	Moon->SetCastShadows(true);
	SkyLight->SetMobility(EComponentMobility::Movable);
	SkyLight->bRealTimeCapture = true;
	SkyLight->SourceType = SLS_CapturedScene;
	SkyLight->SetIntensity(1.f);
	SkyLight->bLowerHemisphereIsBlack = false;
	SkyLight->SetLowerHemisphereColor(FLinearColor(0.05f, 0.045f, 0.04f));
	Fog->SetFogDensity(0.011f); // humid tropical air: the far ranges fade into a soft haze
	Fog->SetFogHeightFalloff(0.08f);
	Fog->SetVolumetricFog(true);
	Fog->SetVolumetricFogScatteringDistribution(0.4f);
	Fog->SetWorldLocation(FVector(0, 0, 0));
	if (CloudMat) Clouds->SetMaterial(CloudMat);
	Clouds->SetLayerBottomAltitude(2.f);
	Clouds->SetLayerHeight(6.f);
	Post->bUnbound = true;
	FPostProcessSettings& P = Post->Settings;
	P.bOverride_AutoExposureMinBrightness = true; P.AutoExposureMinBrightness = -1.5f;
	P.bOverride_AutoExposureMaxBrightness = true; P.AutoExposureMaxBrightness = 12.f;
	P.bOverride_AutoExposureBias = true; P.AutoExposureBias = 0.0f;
	P.bOverride_AutoExposureSpeedUp = true; P.AutoExposureSpeedUp = 2.f;
	P.bOverride_BloomIntensity = true; P.BloomIntensity = 0.35f;
	P.bOverride_VignetteIntensity = true; P.VignetteIntensity = 0.25f;
	P.bOverride_AmbientOcclusionIntensity = true; P.AmbientOcclusionIntensity = 0.6f;
	P.bOverride_ScreenSpaceReflectionQuality = true; P.ScreenSpaceReflectionQuality = 60.f;
	P.bOverride_SceneFringeIntensity = true; P.SceneFringeIntensity = 0.15f;
	P.bOverride_FilmGrainIntensity = true; P.FilmGrainIntensity = 0.05f;
	P.bOverride_ColorSaturation = true; P.ColorSaturation = FVector4(1.02f, 1.02f, 1.02f, 1.f);
	P.bOverride_LumenFinalGatherQuality = true; P.LumenFinalGatherQuality = 1.f;
	P.bOverride_LumenSceneLightingQuality = true; P.LumenSceneLightingQuality = 1.f;
	P.bOverride_DynamicGlobalIlluminationMethod = true; P.DynamicGlobalIlluminationMethod = EDynamicGlobalIlluminationMethod::Lumen;
	P.bOverride_ReflectionMethod = true; P.ReflectionMethod = EReflectionMethod::Lumen;
	// ---- river water (flat translucent plane at the water table) ----
	WaterPlane = NewObject<UStaticMeshComponent>(this, TEXT("Water"));
	WaterPlane->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane")));
	WaterPlane->SetMaterial(0, WaterMat);
	WaterPlane->SetupAttachment(RootComponent);
	WaterPlane->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	WaterPlane->SetCastShadow(false);
	WaterPlane->SetWorldLocation(FVector(0, 0, (Layout->WaterZ - 0.15f) * M2CM));
	WaterPlane->SetWorldScale3D(FVector(14000.f, 14000.f, 1.f));
	WaterPlane->RegisterComponent();
	Ambient->Start();
	Markers = NewObject<UInstancedStaticMeshComponent>(this, TEXT("Markers"));
	Markers->SetStaticMesh(ARWMachine::GCube);
	{
		UMaterialInstanceDynamic* MM = UMaterialInstanceDynamic::Create(ARWMachine::GEmissive, this);
		MM->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.f, 0.25f, 0.02f));
		MM->SetScalarParameterValue(TEXT("Strength"), 2.f);
		Markers->SetMaterial(0, MM);
	}
	Markers->SetupAttachment(RootComponent);
	Markers->SetMobility(EComponentMobility::Movable);
	Markers->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Markers->SetCastShadow(false);
	Markers->RegisterComponent();
	FoliageMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_Foliage.M_Foliage"));
	FRWFab::Scan(); // trees / grass / rocks / water added to the project from Fab
	if (FRWFab::Water && WaterPlane)
	{
		// the river / pond surface: a sheet whose UVs follow the world, so the pack's ripples keep their real size
		WaterPlane->SetStaticMesh(FRWMeshGen::WaterSheet(14000.f, 14.f));
		WaterPlane->SetWorldScale3D(FVector::OneVector);
		WaterPlane->SetMaterial(0, FRWFab::Water);
	}
	Buildings();
	PlantTrees();
	StreamsAndPaddies(FRWFab::Water ? FRWFab::Water : WaterMat);
	RoadMarkings();
	ScatterRocks();
	// the low plants by where they stand; the ones on ground already worked (the pit, the heaps) are not there
	IndexLowPlants();
	RefreshLowPlants();
	GrassHISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, TEXT("Grass"));
	{
		UStaticMesh* GM = FRWMods::ReplacementMesh(TEXT("grass"));
		const bool bFabGrass = !GM && FRWFab::Grass.Num() > 0;
		if (bFabGrass)
		{
			// Fab grass keeps its own materials and real size; extra variants get their own instance lists
			GM = FRWFab::Grass[0];
			FabGrassScale.Add(1.f);
			for (int32 v = 1; v < FRWFab::Grass.Num(); ++v)
			{
				UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(this);
				H->SetStaticMesh(FRWFab::Grass[v]);
				H->SetupAttachment(RootComponent);
				H->SetMobility(EComponentMobility::Movable);
				H->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				H->SetCastShadow(false);
				H->SetCullDistances(0, 4200);
				H->WorldPositionOffsetDisableDistance = 2500;
				H->bAffectDistanceFieldLighting = false;
				H->bAffectDynamicIndirectLighting = false;
				H->RegisterComponent();
				FabGrassH.Add(H);
				FabGrassScale.Add(1.f);
			}
		}
		GrassHISM->SetStaticMesh(GM ? GM : FRWMeshGen::GrassTuft());
		UMaterialInstanceDynamic* GMat = UMaterialInstanceDynamic::Create(FoliageMat ? FoliageMat : PaintMat, this);
		GMat->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.075f, 0.17f, 0.03f));
		GMat->SetScalarParameterValue(TEXT("Roughness"), 0.75f);
		if (!GM) GrassHISM->SetMaterial(0, GMat);
		// the rice keeps the upright blades made for it
		RiceHISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, TEXT("Rice"));
		RiceHISM->SetStaticMesh(FRWMeshGen::GrassTuft());
		RiceHISM->SetMaterial(0, GMat);
		RiceHISM->SetupAttachment(RootComponent);
		RiceHISM->SetMobility(EComponentMobility::Movable);
		RiceHISM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		RiceHISM->SetCastShadow(false);
		RiceHISM->SetCullDistances(0, 4200);
		RiceHISM->RegisterComponent();
	}
	GrassHISM->SetupAttachment(RootComponent);
	GrassHISM->SetMobility(EComponentMobility::Movable);
	GrassHISM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GrassHISM->SetCastShadow(false);
	GrassHISM->SetCullDistances(0, 4200);
	GrassHISM->RegisterComponent();
	// -RWHide=far,fab,paddy,stream,backdrop: leave things out, to measure what each costs in frame rate
	{
		FString Hide;
		FParse::Value(FCommandLine::Get(), TEXT("RWHide="), Hide, false);
		if (Hide.Contains(TEXT("far"))) for (auto* H : FarCrowns) H->SetVisibility(false);
		if (Hide.Contains(TEXT("fab"))) for (auto* H : FabTreeH) H->SetVisibility(false);
		if (Hide.Contains(TEXT("stream")) && StreamWater) StreamWater->SetVisibility(false);
		if (Hide.Contains(TEXT("paddy"))) { TArray<UStaticMeshComponent*> Cs; GetComponents(Cs); for (auto* C : Cs) if (C && C->GetStaticMesh() && C->GetStaticMesh()->GetName() == TEXT("Plane") && C != WaterPlane) C->SetVisibility(false); }
		if (Hide.Contains(TEXT("backdrop")) && Terrain->Backdrop) Terrain->Backdrop->SetVisibility(false);
		if (Hide.Contains(TEXT("grass"))) { GrassHISM->SetVisibility(false); for (auto* H : FabGrassH) H->SetVisibility(false); }
		if (Hide.Contains(TEXT("terrain"))) for (auto* C : Terrain->ChunkComps) C->SetVisibility(false);
	}
	UpdateSky(0.f);
}

void ARWWorld::UpdateGrass(const FVector& Cam)
{
	// grass tufts follow the camera; dug, driven or built-over ground has no grass left
	if (!GrassHISM) return;
	// many grass models: hand the new tufts over a few models per frame, so walking or driving never stutters
	if (GrassApplyNext < GrassSplit.Num())
	{
		const int32 Last = FMath::Min(GrassApplyNext + 8, GrassSplit.Num());
		for (; GrassApplyNext < Last; ++GrassApplyNext)
		{
			UHierarchicalInstancedStaticMeshComponent* H = GrassApplyNext == 0 ? GrassHISM : FabGrassH[GrassApplyNext - 1];
			H->ClearInstances();
			if (GrassSplit[GrassApplyNext].Num()) H->AddInstances(GrassSplit[GrassApplyNext], false);
		}
		return;
	}
	if (FVector::Dist2D(Cam, LastGrassCam) < 6.f) return;
	LastGrassCam = Cam;
	float R = 34.f, Step = 0.55f;
	FParse::Value(FCommandLine::Get(), TEXT("RWGrassR="), R);       // for measuring what the grass costs
	FParse::Value(FCommandLine::Get(), TEXT("RWGrassStep="), Step);
	TArray<FTransform> Rice;
	TArray<FTransform> T;
	T.Reserve(10000);
	const int32 N = FMath::CeilToInt(R / Step);
	for (int32 gy = -N; gy <= N; ++gy)
		for (int32 gx = -N; gx <= N; ++gx)
		{
			const float BX = FMath::FloorToFloat(Cam.X / Step) * Step + gx * Step, BY = FMath::FloorToFloat(Cam.Y / Step) * Step + gy * Step;
			const int32 HX = FMath::RoundToInt(BX / Step), HY = FMath::RoundToInt(BY / Step);
			const float J1 = RWNoise2(HX * 0.73f, HY * 0.91f, 17) * 0.5f + 0.5f, J2 = RWNoise2(HX * 1.37f, HY * 0.53f, 23) * 0.5f + 0.5f;
			const float X = BX + (J1 - 0.5f) * Step, Y = BY + (J2 - 0.5f) * Step;
			if (FVector2D::DistSquared(FVector2D(X, Y), FVector2D(Cam.X, Cam.Y)) > R * R || !Terrain->InBounds(X, Y)) continue;
			const int32 i = Terrain->IndexAt(X, Y);
			const float G = Terrain->Grass[i] / 255.f;
			if (G < 0.3f || J1 * J2 * 2.f > G + 0.2f || Terrain->Height[i] < Terrain->WaterZ + 0.1f) continue;
			// rice stands in the fields, in place of grass
			if (RiceHISM && Terrain->SurfaceMat(i) == ESoil::Mud)
			{
				bool bPaddy = false;
				for (const FRWZone& Z : Layout->Zones) if (Z.Type == ERWZone::Paddy && FRWLayout::InZone(Z, X, Y)) { bPaddy = true; break; }
				if (bPaddy)
				{
					const float Sr = (0.6f + 0.7f * J2) * (0.6f + 0.6f * G);
					Rice.Add(FTransform(FRotator(0, J1 * 360.f, 0), FVector(X, Y, Terrain->Height[i] - 0.02f) * M2CM, FVector(Sr, Sr, Sr * (0.8f + 0.5f * J1))));
					continue;
				}
			}
			const float S = FabGrassScale.Num() ? (0.7f + 0.5f * J2) * (0.7f + 0.4f * G) : (0.6f + 0.7f * J2) * (0.6f + 0.6f * G);
			T.Add(FTransform(FRotator(0, J1 * 360.f, 0), FVector(X, Y, Terrain->Height[i] - 0.02f) * M2CM, FVector(S, S, S * (0.8f + 0.5f * J1))));
		}
	if (RiceHISM)
	{
		RiceHISM->ClearInstances();
		if (Rice.Num()) RiceHISM->AddInstances(Rice, false);
	}
	if (FabGrassH.Num() == 0)
	{
		GrassHISM->ClearInstances();
		GrassHISM->AddInstances(T, false);
		return;
	}
	// many grass models: each meadow is its own mix of a few of them, as grass grows in nature, and every model has its place on the map
	const int32 NV = FabGrassH.Num() + 1;
	GrassSplit.Reset(); GrassSplit.SetNum(NV);
	GrassApplyNext = 0;
	for (int32 k = 0; k < T.Num(); ++k)
	{
		const FVector L = T[k].GetLocation() * CM2M;
		const float Region = RWNoise2(L.X / 90.f, L.Y / 90.f, 31) * 0.5f + 0.5f, Patch = RWNoise2(L.X / 3.f, L.Y / 3.f, 33);
		const int32 v = FMath::Abs(FMath::FloorToInt(Region * NV * 2.f + Patch * 7.f)) % NV;
		GrassSplit[v].Add(T[k]);
	}
}

void ARWWorld::RoadMarkings()
{
	// painted lines on the asphalt roads: yellow dashed centre line, solid white edge lines
	auto MakeLines = [&](const TCHAR* Name, const FLinearColor& C) -> UInstancedStaticMeshComponent*
	{
		UInstancedStaticMeshComponent* I = NewObject<UInstancedStaticMeshComponent>(this, Name);
		I->SetStaticMesh(FRWMeshGen::RoundBox(FVector(2.04f, 0.12f, 0.012f), 0.004f));
		I->SetMaterial(0, Mat(C, 0.55f));
		I->SetupAttachment(RootComponent);
		I->SetMobility(EComponentMobility::Movable);
		I->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		I->SetCastShadow(false);
		I->RegisterComponent();
		return I;
	};
	LineWhite = MakeLines(TEXT("LineWhite"), FLinearColor(0.75f, 0.75f, 0.72f));
	LineYellow = MakeLines(TEXT("LineYellow"), FLinearColor(0.75f, 0.5f, 0.03f));
	TArray<FTransform> W, Yl;
	for (const FRWRoad& R : Layout->Roads)
	{
		if (!R.bAsphalt) continue;
		for (int32 i = 0; i + 1 < R.Pts.Num(); ++i)
		{
			const FVector2D A = R.Pts[i], B = R.Pts[i + 1];
			const FVector2D D = (B - A).GetSafeNormal(), Nn(-D.Y, D.X);
			const float Yaw = FMath::RadiansToDegrees(FMath::Atan2(D.Y, D.X));
			const FVector2D M = (A + B) * 0.5f;
			auto Put = [&](TArray<FTransform>& Out, const FVector2D& P)
			{
				if (!Terrain->InBounds(P.X, P.Y) || Terrain->SurfaceMat(Terrain->IndexAt(P.X, P.Y)) != ESoil::Asphalt) return;
				Out.Add(FTransform(FRotator(0, Yaw, 0), FVector(P.X, P.Y, Terrain->HeightAt(P.X, P.Y) + 0.006f) * M2CM));
			};
			if (i % 4 < 2) Put(Yl, M);
			for (int32 s = -1; s <= 1; s += 2) Put(W, M + Nn * s * (R.HalfW - 0.25f));
		}
	}
	LineWhite->AddInstances(W, false);
	LineYellow->AddInstances(Yl, false);
}

void ARWWorld::ScatterRocks()
{
	RockHISM = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, TEXT("Rocks"));
	UStaticMesh* RM = FRWMods::ReplacementMesh(TEXT("rock"));
	float RockNorm = 1.f; // Fab rocks: scaled so the largest side is about 1 m at instance scale 1, own materials
	const bool bFabRock = !RM && FRWFab::Rock.Num() > 0;
	if (bFabRock)
	{
		RM = FRWFab::Rock[0];
		RockNorm = 100.f / FMath::Max(2.f * (float)RM->GetBounds().BoxExtent.GetMax(), 1.f);
	}
	RockHISM->SetStaticMesh(RM ? RM : FRWMeshGen::Rock(1.f, 3));
	if (!bFabRock) RockHISM->SetMaterial(0, Mat(FLinearColor(0.17f, 0.16f, 0.15f), 0.85f));
	RockHISM->SetupAttachment(RootComponent);
	RockHISM->SetMobility(EComponentMobility::Movable);
	RockHISM->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	RockHISM->RegisterComponent();
	FRandomStream Rs(777);
	TArray<FTransform> T;
	const FRWZone* Q = Layout->Find(ERWZone::Quarry);
	for (int32 k = 0; k < 9000 && T.Num() < 4500; ++k)
	{
		FVector2D P;
		const float Pick = Rs.FRand();
		if (Q && Pick < 0.35f) P = Q->C + FVector2D(Rs.FRandRange(-Q->HalfExt.X, Q->HalfExt.X), Rs.FRandRange(-Q->HalfExt.Y, Q->HalfExt.Y));
		else if (Pick < 0.65f) { const float X = Rs.FRandRange(-1010.f, 1010.f); P = FVector2D(X, Layout->RiverY(X) + (Rs.FRand() > 0.5f ? 1.f : -1.f) * Rs.FRandRange(6.f, 14.f)); }
		else P = FVector2D(Rs.FRandRange(-1010.f, 1010.f), Rs.FRandRange(-1010.f, 1010.f));
		if (Pick >= 0.65f && P.Y < 150.f && FMath::Max(FMath::Abs(P.X), FMath::Abs(P.Y)) < 450.f) continue; // on the plain only by the river and in the quarry
		if (!Terrain->InBounds(P.X, P.Y)) continue;
		float RZ; if (Layout->RoadInfluence(P.X, P.Y, RZ) > 0.05f) continue;
		bool bBlocked = false;
		for (const FRWZone& Z : Layout->Zones) if (Z.Type != ERWZone::Quarry && Z.Type != ERWZone::Forest && FRWLayout::InZone(Z, P.X, P.Y, 4.f)) bBlocked = true;
		if (bBlocked) continue;
		const float S = FMath::Pow(Rs.FRand(), 2.f) * 1.6f + 0.25f;
		T.Add(FTransform(FRotator(Rs.FRandRange(-20.f, 20.f), Rs.FRand() * 360.f, Rs.FRandRange(-20.f, 20.f)), FVector(P.X, P.Y, Terrain->HeightAt(P.X, P.Y) + S * 0.12f) * M2CM, FVector(S, S * Rs.FRandRange(0.7f, 1.2f), S * Rs.FRandRange(0.5f, 0.9f)) * RockNorm));
	}
	RockHISM->AddInstances(T, false);
}

void ARWWorld::Stockpile(float X, float Y, float R, float H, ESoil M)
{
	PileDefs.Add({FVector(X, Y, Terrain->HeightAt(X, Y)), R, H, M});
	const int32 CX = Terrain->ToGrid(X), CY = Terrain->ToGrid(Y);
	const int32 RR = FMath::CeilToInt(R / ARWTerrain::CS);
	for (int32 dy = -RR; dy <= RR; ++dy)
		for (int32 dx = -RR; dx <= RR; ++dx)
		{
			if (!Terrain->Valid(CX + dx, CY + dy)) continue;
			const float D = FVector2D(dx, dy).Size() * ARWTerrain::CS;
			if (D > R) continue;
			const float T = H * (1.f - D / R) + 0.05f * FMath::FRand();
			Terrain->DepositAt(Terrain->Idx(CX + dx, CY + dy), M, T * ARWTerrain::CellArea, M == ESoil::Sand ? 0.25f : 0.12f, 40);
		}
}

void ARWWorld::House(float X, float Y, float Yaw, const FLinearColor& Wall, const FLinearColor& Roof)
{
	// every part of one house is one object in the level (moved, turned or removed there as a whole)
	const FName Outer = CurObj;
	CurObj = FName(*FString::Printf(TEXT("House_%d"), HouseN++));
	ON_SCOPE_EXIT { CurObj = Outer; };
	const float Z = Terrain->HeightAt(X, Y);
	if (UStaticMesh* HM = FRWMods::ReplacementMesh(TEXT("house")))
	{
		// a mod supplied its own house model (pivot at the ground, metres x 100 = cm)
		Box(FVector(X, Y, Z), FVector(1.f), Yaw, Wall, true, 0.6f, 0.f, HM);
		Obstacles.Last().Half = FVector2D(4.f, 3.f);
		return;
	}
	// a Thai country house: timber on stilts with an open space underneath, a steep roof and an outside stair
	const FVector F(FMath::Cos(FMath::DegreesToRadians(Yaw)), FMath::Sin(FMath::DegreesToRadians(Yaw)), 0);
	const FVector Rt(-F.Y, F.X, 0);
	const FLinearColor Stilt(0.09f, 0.055f, 0.03f), Deck(0.13f, 0.08f, 0.045f), Trim(0.2f, 0.13f, 0.07f);
	const float FloorZ = Z + 2.3f, WallH = 2.3f, TopZ = FloorZ + WallH;
	Obstacles.Add({FVector2D(X, Y), FVector2D(4.2f, 3.3f), Yaw, CurObj});
	for (int32 a = -1; a <= 1; ++a)
		for (int32 b = -1; b <= 1; ++b)
			Box(FVector(X, Y, Z + 0.5f * (FloorZ - Z + 0.2f)) + F * (a * 3.8f) + Rt * (b * 2.8f), FVector(0.24f, 0.24f, FloorZ - Z + 0.2f), Yaw, Stilt, false, 0.85f);
	Box(FVector(X, Y, FloorZ) + Rt * 0.7f, FVector(8.8f, 7.8f, 0.16f), Yaw, Deck, false, 0.8f);                        // floor, wider on the veranda side
	Box(FVector(X, Y, FloorZ + 0.5f * WallH) - Rt * 0.4f, FVector(8.f, 5.2f, WallH), Yaw, Wall, false, 0.85f);          // room
	// plank lines and shuttered windows on the long wall, the door between them
	for (int32 k = 0; k < 5; ++k) Box(FVector(X, Y, FloorZ + 0.25f + k * 0.45f) + Rt * 2.23f, FVector(8.02f, 0.02f, 0.03f), Yaw, Wall * 0.6f, false, 0.9f);
	Box(FVector(X, Y, FloorZ + 1.05f) + Rt * 2.24f, FVector(1.0f, 0.05f, 2.05f), Yaw, FLinearColor(0.05f, 0.03f, 0.018f), false);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Box(FVector(X, Y, FloorZ + 1.3f) + Rt * 2.24f + F * (s * 2.5f), FVector(1.1f, 0.05f, 1.0f), Yaw, FLinearColor(0.012f, 0.012f, 0.012f), false, 0.8f);
		Box(FVector(X, Y, FloorZ + 1.3f) + Rt * 2.3f + F * (s * 3.25f), FVector(0.45f, 0.05f, 1.05f), Yaw, Trim, false, 0.8f); // an open shutter
		Box(FVector(X, Y, FloorZ + 1.3f) + Rt * 2.3f + F * (s * 1.75f), FVector(0.45f, 0.05f, 1.05f), Yaw, Trim, false, 0.8f);
	}
	// veranda rail and posts
	Box(FVector(X, Y, FloorZ + 0.85f) + Rt * 4.5f, FVector(8.8f, 0.08f, 0.08f), Yaw, Trim, false, 0.8f);
	for (int32 k = -2; k <= 2; ++k) Box(FVector(X, Y, FloorZ + 1.2f) + Rt * 4.5f + F * (k * 2.1f), FVector(0.14f, 0.14f, 2.4f), Yaw, Stilt, false, 0.85f);
	// the steep gable roof with its overhang, closed at both ends
	const float Span = 3.9f, Pitch = 42.f, Slab = Span / FMath::Cos(FMath::DegreesToRadians(Pitch)), RoofH = Span * FMath::Tan(FMath::DegreesToRadians(Pitch));
	const FVector Ridge = FVector(X, Y, TopZ) + Rt * 0.7f;
	Box(Ridge + Rt * (Span * 0.5f) + FVector(0, 0, RoofH * 0.5f), FVector(9.6f, Slab, 0.12f), Yaw, Roof, false, 0.7f, 0.f, nullptr, FRotator(0, 0, Pitch));
	Box(Ridge - Rt * (Span * 0.5f) + FVector(0, 0, RoofH * 0.5f), FVector(9.6f, Slab, 0.12f), Yaw, Roof, false, 0.7f, 0.f, nullptr, FRotator(0, 0, -Pitch));
	for (int32 s = -1; s <= 1; s += 2)
	{
		// the triangle under the roof at each end: polygon in its own X,Z, spanning -1..1 and 0..1
		UStaticMesh* GableMesh = FRWMeshGen::Profile(TEXT("house_gable"), {FVector2D(-1.f, 0.f), FVector2D(1.f, 0.f), FVector2D(0.f, 1.f)}, 1.f);
		Box(Ridge + F * (s * 4.f) - FVector(0, 0, 0.02f), FVector(Span - 0.06f, 0.08f, RoofH - 0.04f), Yaw + 90.f, Wall, false, 0.85f, 0.f, GableMesh);
	}
	Box(Ridge + FVector(0, 0, RoofH + 0.04f), FVector(9.7f, 0.22f, 0.1f), Yaw, Roof * 0.6f, false, 0.7f);
	// outside stair up to the veranda
	for (int32 k = 0; k < 7; ++k)
		Box(FVector(X, Y, Z + 0.15f + k * 0.32f) + Rt * (6.9f - k * 0.3f) + F * 2.8f, FVector(1.2f, 0.28f, 0.05f), Yaw, Deck, false, 0.8f);
	for (int32 s = -1; s <= 1; s += 2)
		Box(FVector(X, Y, Z + 1.15f) + Rt * 6.0f + F * (2.8f + s * 0.62f), FVector(0.07f, 2.9f, 0.1f), Yaw, Stilt, false, 0.85f, 0.f, nullptr, FRotator(0, 0, -47));
	// the spirit house on its post in front of the compound
	const FVector Shrine = FVector(X, Y, Z) + Rt * 8.2f - F * 2.6f;
	const FLinearColor Gold(0.6f, 0.38f, 0.07f), Cream(0.72f, 0.66f, 0.52f);
	Box(Shrine + FVector(0, 0, 0.7f), FVector(0.2f, 0.2f, 1.4f), Yaw, Cream, false, 0.7f);
	Box(Shrine + FVector(0, 0, 1.42f), FVector(0.75f, 0.75f, 0.06f), Yaw, Cream, false, 0.7f);
	Box(Shrine + FVector(0, 0, 1.7f), FVector(0.48f, 0.48f, 0.5f), Yaw, Cream, false, 0.7f);
	Box(Shrine + FVector(0, 0, 2.08f), FVector(0.72f, 0.72f, 0.26f), Yaw + 45.f, Gold, false, 0.35f, 0.7f, ARWMachine::GCone);
	Box(Shrine + FVector(0, 0, 2.36f), FVector(0.32f, 0.32f, 0.34f), Yaw + 45.f, Gold, false, 0.35f, 0.7f, ARWMachine::GCone);
}

void ARWWorld::Buildings()
{
	UStaticMesh* Cyl = ARWMachine::GCyl;
	auto Gz = [&](float X, float Y) { return Terrain->HeightAt(X, Y); };
	// (each building, yard and pole is one object in the level's editable scenery)
	ON_SCOPE_EXIT { CurObj = NAME_None; };
	// ---- machine yard ----
	{
		CurObj = TEXT("Yard");
		const FVector2D C(-170, -165);
		float Z = Gz(-186, -183);
		Box(FVector(-186, -183, Z + 4.f), FVector(22, 14, 8), 0, FLinearColor(0.32f, 0.34f, 0.36f), true, 0.45f, 0.6f);
		Box(FVector(-186, -183, Z + 8.25f), FVector(23, 15, 0.5f), 0, FLinearColor(0.15f, 0.17f, 0.2f), false, 0.4f, 0.7f);
		Box(FVector(-186, -175.95f, Z + 3.f), FVector(12, 0.1f, 6), 0, FLinearColor(0.55f, 0.4f, 0.05f), false, 0.5f);
		Box(FVector(-186, -175.9f, Z + 7.f), FVector(9, 0.1f, 1.2f), 0, FLinearColor(0.8f, 0.8f, 0.8f), false);
		Z = Gz(-152, -188);
		Box(FVector(-152, -188, Z + 1.3f), FVector(6.1f, 2.45f, 2.6f), 0, FLinearColor(0.7f, 0.7f, 0.68f), true, 0.5f, 0.3f);
		Box(FVector(-152, -188, Z + 3.9f), FVector(6.1f, 2.45f, 2.6f), 0, FLinearColor(0.15f, 0.3f, 0.55f), false, 0.5f, 0.3f);
		Box(FVector(-145, -188, Z + 1.3f), FVector(6.1f, 2.45f, 2.6f), 0, FLinearColor(0.7f, 0.7f, 0.68f), true, 0.5f, 0.3f);
		// fuel station
		Z = Gz(-148, -150);
		Box(FVector(-148, -150, Z + 5.2f), FVector(10, 7, 0.4f), 0, FLinearColor(0.75f, 0.75f, 0.75f), false, 0.3f, 0.5f);
		for (int32 k = 0; k < 4; ++k) Box(FVector(-148 + (k & 1 ? 4.f : -4.f), -150 + (k & 2 ? 2.8f : -2.8f), Z + 2.6f), FVector(0.3f, 0.3f, 5.2f), 0, FLinearColor(0.8f, 0.8f, 0.8f), true, 0.3f, 0.6f);
		Box(FVector(-148, -150, Z + 0.8f), FVector(0.9f, 0.6f, 1.6f), 0, FLinearColor(0.6f, 0.05f, 0.03f), true, 0.4f);
		Box(FVector(-140, -158, Z + 1.3f), FVector(2.6f, 2.6f, 7.f), 0, FLinearColor(0.6f, 0.6f, 0.58f), true, 0.4f, 0.6f, Cyl, FRotator(0, 0, 90));
		// perimeter fence posts
		for (int32 k = 0; k < 36; ++k)
		{
			const float X = C.X - 36 + k * 2.f, Y = C.Y - 28.5f;
			Box(FVector(X, Y, Gz(X, Y) + 1.f), FVector(0.06f, 0.06f, 2.f), 0, FLinearColor(0.4f, 0.4f, 0.4f), false, 0.4f, 0.8f);
		}
		Box(FVector(C.X, C.Y - 28.5f, Gz(C.X, C.Y - 28.5f) + 1.f), FVector(72.f, 0.02f, 1.9f), 0, FLinearColor(0.35f, 0.36f, 0.35f), true, 0.5f, 0.8f);
	}
	// ---- material plant ----
	{
		CurObj = TEXT("Plant");
		for (int32 k = 0; k < 4; ++k)
		{
			const float X = -80.f + k * 5.f, Y = -214.f;
			const float Z = Gz(X, Y);
			Box(FVector(X, Y, Z + 8.f), FVector(4.f, 4.f, 10.f), 0, FLinearColor(0.62f, 0.62f, 0.6f), true, 0.35f, 0.7f, Cyl);
			Box(FVector(X, Y, Z + 13.6f), FVector(4.f, 4.f, 1.4f), 0, FLinearColor(0.55f, 0.55f, 0.52f), false, 0.4f, 0.7f, ARWMachine::GCone);
			for (int32 l = 0; l < 4; ++l) Box(FVector(X + (l & 1 ? 1.5f : -1.5f), Y + (l & 2 ? 1.5f : -1.5f), Z + 1.5f), FVector(0.25f, 0.25f, 3.f), 0, FLinearColor(0.3f, 0.3f, 0.3f), false, 0.5f, 0.7f);
		}
		float Z = Gz(-50, -215);
		Box(FVector(-50, -215, Z + 3.f), FVector(2.8f, 2.8f, 12.f), 0, FLinearColor(0.2f, 0.2f, 0.21f), true, 0.5f, 0.6f, Cyl, FRotator(-5, 0, 90));
		Box(FVector(-62, -206, Z + 6.f), FVector(16.f, 1.0f, 0.5f), 90, FLinearColor(0.25f, 0.27f, 0.3f), false, 0.5f, 0.5f, nullptr, FRotator(-18, 0, 0));
		Box(FVector(-40, -212, Z + 2.f), FVector(6.f, 4.f, 4.f), 0, FLinearColor(0.75f, 0.72f, 0.65f), true, 0.6f);
		Box(FVector(-60, -185, Gz(-60, -185) + 0.15f), FVector(4.f, 14.f, 0.3f), 0, FLinearColor(0.3f, 0.3f, 0.3f), false, 0.5f, 0.6f); // weighbridge
		// the heaps of material: where the level puts them (RW_Pile), otherwise the plant's own four
		if (Layout->bLevelPiles)
			for (const FRWLayout::FLevelPile& P : Layout->LevelPiles) Stockpile(P.P.X, P.P.Y, FMath::Max(P.R, 0.5f), FMath::Max(P.H, 0.1f), (ESoil)P.Soil);
		else
		{
			Stockpile(-40, -190, 7.f, 3.5f, ESoil::Gravel);
			Stockpile(-28, -204, 7.f, 3.0f, ESoil::Sand);
			Stockpile(-86, -188, 6.f, 2.8f, ESoil::Laterite);
			Stockpile(-80, -198, 5.f, 2.2f, ESoil::SmallRock);
		}
	}
	// ---- village ----
	{
		CurObj = NAME_None; // (each house is its own object)
		// weathered teak and painted board; clay-tile orange, red and rusting tin roofs
		const FLinearColor Walls[4] = {FLinearColor(0.19f, 0.11f, 0.06f), FLinearColor(0.25f, 0.15f, 0.08f), FLinearColor(0.14f, 0.085f, 0.05f), FLinearColor(0.46f, 0.42f, 0.33f)};
		const FLinearColor Roofs[3] = {FLinearColor(0.42f, 0.13f, 0.045f), FLinearColor(0.3f, 0.07f, 0.04f), FLinearColor(0.3f, 0.22f, 0.17f)};
		int32 k = 0;
		for (float Y = -48.f; Y <= -5.f; Y += 13.f)
			for (int32 s = -1; s <= 1; s += 2, ++k)
				House(-195.f + s * 11.f, Y, s > 0 ? 180.f : 0.f, Walls[k % 4], Roofs[k % 3]);
		House(-165.f, -12.f, 90.f, Walls[1], Roofs[0]);
		House(-220.f, -40.f, 90.f, Walls[2], Roofs[2]);
		// the other villages: two rows of houses on either side of their lane
		int32 Nth = 0;
		for (const FRWZone& V : Layout->Zones)
		{
			if (V.Type != ERWZone::Village || Nth++ == 0) continue;
			for (float Y = V.C.Y - V.HalfExt.Y + 8.f; Y <= V.C.Y + V.HalfExt.Y - 8.f; Y += 13.f)
				for (int32 s = -1; s <= 1; s += 2, ++k)
					House(V.C.X + s * 11.f, Y, s > 0 ? 180.f : 0.f, Walls[k % 4], Roofs[k % 3]);
		}
	}
	// ---- site office ----
	{
		CurObj = TEXT("SiteOffice");
		const float Z = Gz(5, -98);
		Box(FVector(5, -98, Z + 1.3f), FVector(6.1f, 2.45f, 2.6f), 0, FLinearColor(0.8f, 0.8f, 0.78f), true, 0.5f, 0.3f);
		Box(FVector(12, -98, Z + 1.2f), FVector(1.2f, 1.2f, 2.4f), 0, FLinearColor(0.1f, 0.35f, 0.15f), true, 0.5f);
	}
	// ---- quarry crusher ----
	{
		CurObj = TEXT("Crusher");
		const float Z = Gz(140, 150);
		Box(FVector(140, 150, Z + 3.f), FVector(6, 5, 6), 20, FLinearColor(0.5f, 0.35f, 0.05f), true, 0.5f, 0.4f);
		Box(FVector(130, 146, Z + 5.f), FVector(18, 1.2f, 0.5f), 20, FLinearColor(0.3f, 0.3f, 0.32f), false, 0.5f, 0.5f, nullptr, FRotator(-15, 0, 0));
	}
	// ---- culvert pipes under the haul road river crossing ----
	for (const FRWRoad& R : Layout->Roads)
	{
		if (R.bAsphalt) continue;
		int32 Best = -1; float BD = 1e9f;
		for (int32 i = 0; i < R.Pts.Num(); ++i) { const float D = Layout->RiverDist(R.Pts[i].X, R.Pts[i].Y); if (D < BD) { BD = D; Best = i; } }
		if (Best >= 0 && BD < 5.f)
		{
			CurObj = FName(*FString::Printf(TEXT("Culvert_%d"), FMath::RoundToInt(R.Pts[Best].X)));
			const FVector2D P = R.Pts[Best];
			for (int32 s = -1; s <= 1; s += 2)
				Box(FVector(P.X + s * 1.6f, P.Y, Layout->WaterZ + 0.2f), FVector(1.8f, 1.8f, 12.f), 0, FLinearColor(0.42f, 0.41f, 0.38f), false, 0.8f, 0.f, Cyl, FRotator(90, 90, 0));
		}
	}
	// ---- power poles along the highway ----
	if (Layout->Roads.Num())
	{
		const FRWRoad& R = Layout->Roads[0];
		for (int32 i = 0; i < R.Pts.Num(); i += 20)
		{
			const FVector2D P = R.Pts[i] + FVector2D(0, 7.5f);
			if (FMath::Abs(P.X) > ARWTerrain::Half - 6.f) continue;
			CurObj = FName(*FString::Printf(TEXT("Pole_%d"), i / 20));
			const float Z = Gz(P.X, P.Y);
			Box(FVector(P.X, P.Y, Z + 5.f), FVector(0.28f, 0.28f, 10.f), 0, FLinearColor(0.2f, 0.14f, 0.09f), true, 0.8f, 0.f, Cyl);
			Box(FVector(P.X, P.Y, Z + 9.6f), FVector(0.15f, 2.2f, 0.15f), 0, FLinearColor(0.2f, 0.14f, 0.09f), false, 0.8f);
		}
	}
	// ---- an excavation already under way at the site (previous shift): where the level puts it (RW_Dig) ----
	CurObj = NAME_None;
	if (Layout->bLevelPiles)
		for (const FVector& D : Layout->LevelDigs) Excavation(D.X, D.Y, D.Z);
	else
		Excavation(62.f, -36.f, 0.f);
}

void ARWWorld::Excavation(float X0, float Y0, float Yaw)
{
	DigDefs.Add(FVector(X0, Y0, Yaw));
	const float Cy = FMath::Cos(FMath::DegreesToRadians(Yaw)), Sy = FMath::Sin(FMath::DegreesToRadians(Yaw));
	auto At = [&](float Dx, float Dy) { return FVector2D(X0 + Dx * Cy - Dy * Sy, Y0 + Dx * Sy + Dy * Cy); };
	FPayload Spoil;
	if (FMath::Abs(Yaw) < 0.01f)
	{
		for (int32 dy = -10; dy <= 10; ++dy)
			for (int32 dx = -12; dx <= 12; ++dx)
			{
				const int32 i = Terrain->IndexAt(X0 + dx * 0.5f, Y0 + dy * 0.5f);
				const float Edge = FMath::Min(1.f, FMath::Min(12 - FMath::Abs(dx), 10 - FMath::Abs(dy)) / 4.f);
				Terrain->RemoveAt(i, 1.4f * Edge, Spoil);
			}
	}
	else
	{
		// turned: every ground cell under the pit once, by where it lies in the pit
		TSet<int32> Done;
		for (float Ly = -5.f; Ly <= 5.f; Ly += 0.25f)
			for (float Lx = -6.f; Lx <= 6.f; Lx += 0.25f)
			{
				const FVector2D P = At(Lx, Ly);
				if (!Terrain->InBounds(P.X, P.Y)) continue;
				const int32 i = Terrain->IndexAt(P.X, P.Y);
				if (Done.Contains(i)) continue;
				Done.Add(i);
				const float Edge = FMath::Min(1.f, FMath::Min(12.f - FMath::Abs(Lx * 2.f), 10.f - FMath::Abs(Ly * 2.f)) / 4.f);
				Terrain->RemoveAt(i, 1.4f * Edge, Spoil);
			}
	}
	const FVector2D S1 = At(0.f, -9.5f), S2 = At(8.f, -8.5f);
	Terrain->DepositDisc(S1.X, S1.Y, 3.2f, Spoil.Take(Spoil.Total() * 0.6f));
	Terrain->DepositDisc(S2.X, S2.Y, 2.5f, Spoil);
}

void ARWWorld::PlantTrees()
{
	auto MakeH = [&](const TCHAR* Name, UStaticMesh* Mesh, const FLinearColor& Col, float Rough, bool bShadow)
	{
		UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(this, Name);
		H->SetStaticMesh(Mesh);
		H->SetMaterial(0, Mat(Col, Rough));
		H->SetupAttachment(RootComponent);
		H->SetMobility(EComponentMobility::Movable);
		H->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		H->SetCastShadow(bShadow);
		H->RegisterComponent();
		return H;
	};
	// mods can replace each environment piece with their own model (see Mods/README_MODDING.md)
	auto Rep = [](const TCHAR* Key, UStaticMesh* Def) { UStaticMesh* R = FRWMods::ReplacementMesh(Key); return R ? R : Def; };
	Trunks = MakeH(TEXT("Trunks"), Rep(TEXT("tree_trunk"), FRWMeshGen::TreeTrunk(1, 1, 1)), FLinearColor(0.06f, 0.04f, 0.025f), 0.9f, true);
	Conifers = MakeH(TEXT("Conifers"), Rep(TEXT("tree_conifer_crown"), FRWMeshGen::ConiferCrown(1, 1, 1)), FLinearColor(0.035f, 0.065f, 0.028f), 0.8f, true);
	Broadleaf = MakeH(TEXT("Broadleaf"), Rep(TEXT("tree_broadleaf_crown"), FRWMeshGen::BroadleafCrown(1, 2)), FLinearColor(0.06f, 0.10f, 0.03f), 0.75f, true);
	FarTrees = MakeH(TEXT("FarTrees"), Rep(TEXT("far_tree"), FRWMeshGen::ConiferCrown(1, 1, 3)), FLinearColor(0.02f, 0.042f, 0.016f), 0.9f, false);
	Bushes = MakeH(TEXT("Bushes"), Rep(TEXT("bush"), FRWMeshGen::BroadleafCrown(1, 5)), FLinearColor(0.04f, 0.06f, 0.02f), 0.85f, false);
	if (FoliageMat)
	{
		// two-sided foliage shading for crowns and bushes
		for (UHierarchicalInstancedStaticMeshComponent* H : {Conifers, Broadleaf, FarTrees, Bushes})
		{
			UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(FoliageMat, this);
			FLinearColor C(0.04f, 0.07f, 0.025f);
			if (UMaterialInstanceDynamic* Old = Cast<UMaterialInstanceDynamic>(H->GetMaterial(0))) Old->GetVectorParameterValue(FHashedMaterialParameterInfo(TEXT("Color")), C);
			M->SetVectorParameterValue(TEXT("Color"), C);
			H->SetMaterial(0, M);
		}
	}
	// whole-plant models from the Content packs (FRWFab): each model gets its own instance list and keeps its own
	// materials. A mod that replaces the crowns still wins. With only one tree type, it stands in for the other.
	const bool bModTrees = FRWMods::Replacements.Contains(TEXT("tree_conifer_crown")) || FRWMods::Replacements.Contains(TEXT("tree_broadleaf_crown"));
	auto FabH = [&](UStaticMesh* M, bool bShadow)
	{
		UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(this);
		H->SetStaticMesh(M);
		H->SetupAttachment(RootComponent);
		H->SetMobility(EComponentMobility::Movable);
		H->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		H->SetCastShadow(bShadow);
		H->WorldPositionOffsetDisableDistance = 8000; // wind sway only within 80 m
		H->SetCullDistances(18000, 20000); // not drawn past 200 m: measured about 73 -> 87 FPS on the plants in this map
		H->RegisterComponent();
		FabTreeH.Add(H);
		return FabTreeH.Num() - 1;
	};
	TArray<int32> FabConifer, FabBroad, FabBush;
	if (!bModTrees)
	{
		const TArray<UStaticMesh*>& LC = FRWFab::Conifer.Num() ? FRWFab::Conifer : FRWFab::Broadleaf;
		const TArray<UStaticMesh*>& LB = FRWFab::Broadleaf.Num() ? FRWFab::Broadleaf : FRWFab::Conifer;
		for (UStaticMesh* M : LC) FabConifer.Add(FabH(M, true));
		if (&LC == &LB) FabBroad = FabConifer;
		else for (UStaticMesh* M : LB) FabBroad.Add(FabH(M, true));
	}
	if (!FRWMods::Replacements.Contains(TEXT("bush"))) for (UStaticMesh* M : FRWFab::Bush) FabBush.Add(FabH(M, true));
	// coconut palms, bananas and bamboo: built here, drawn and felled the same way as the pack's trees
	TArray<int32> FabPalm, FabBanana, FabBamboo, FabUnder, FabProp;
	if (!bModTrees)
	{
		UMaterialInterface* PlantMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Environment/M_ThaiPlant.M_ThaiPlant"));
		auto PlantH = [&](UStaticMesh* M) { const int32 C = FabH(M, true); FabTreeH[C]->SetMaterial(0, PlantMat ? PlantMat : (UMaterialInterface*)Mat(FLinearColor(0.1f, 0.2f, 0.04f), 0.7f)); return C; };
		// the packs' real palms and bananas when they are there, the ones built here otherwise; no pack has bamboo
		for (UStaticMesh* M : FRWFab::Palm) FabPalm.Add(FabH(M, true));
		if (FabPalm.Num() == 0) for (int32 s = 0; s < 3; ++s) FabPalm.Add(PlantH(FRWMeshGen::ThaiPlant(0, s)));
		for (UStaticMesh* M : FRWFab::Banana) FabBanana.Add(FabH(M, true));
		if (FabBanana.Num() == 0) for (int32 s = 0; s < 2; ++s) FabBanana.Add(PlantH(FRWMeshGen::ThaiPlant(1, s)));
		for (int32 s = 0; s < 2; ++s) FabBamboo.Add(PlantH(FRWMeshGen::ThaiPlant(2, s)));
		// low plants on the forest floor and things on the ground: these only matter close by
		for (UStaticMesh* M : FRWFab::Understory)
		{
			const int32 C = FabH(M, false);
			FabTreeH[C]->SetCullDistances(11000, 13000);
			FabTreeH[C]->WorldPositionOffsetDisableDistance = 4000;
			FabUnder.Add(C);
		}
		for (UStaticMesh* M : FRWFab::GroundProp)
		{
			const int32 C = FabH(M, false);
			FabTreeH[C]->SetCullDistances(6000, 7000);
			FabProp.Add(C);
		}
	}
	// the canopy seen from afar: simple crowns in a few greens. Close up (under 190 m) their material draws nothing, the real trees are there
	UMaterialInterface* FarMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Environment/M_FarCrown.M_FarCrown"));
	const FLinearColor FarGreens[3] = {FLinearColor(0.045f, 0.1f, 0.024f), FLinearColor(0.065f, 0.135f, 0.028f), FLinearColor(0.095f, 0.165f, 0.034f)};
	for (int32 c = 0; c < 3; ++c)
	{
		UHierarchicalInstancedStaticMeshComponent* H = MakeH(*FString::Printf(TEXT("FarCrown%d"), c), Rep(TEXT("far_tree"), FRWMeshGen::FarCrown(c + 1)), FarGreens[c], 0.9f, false);
		if (FarMat)
		{
			UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(FarMat, this);
			M->SetVectorParameterValue(TEXT("Color"), FarGreens[c]);
			H->SetMaterial(0, M);
		}
		H->SetCullDistances(420000, 450000);
		H->bAffectDynamicIndirectLighting = false;
		H->bAffectDistanceFieldLighting = false;
		FarCrowns.Add(H);
	}
	// the same greens as simple conifers, for the mountain forests: on the high ground of the map and beyond it
	for (int32 c = 0; c < 3; ++c)
	{
		UHierarchicalInstancedStaticMeshComponent* H = MakeH(*FString::Printf(TEXT("FarRing%d"), c), Rep(TEXT("far_tree"), FRWMeshGen::ConiferCrown(1, 1, 3 + c)), FarGreens[c], 0.9f, false);
		// the mountain forest is a darker, cooler green than the lowland trees
		UMaterialInstanceDynamic* MR = UMaterialInstanceDynamic::Create(FarMat ? FarMat : (UMaterialInterface*)FoliageMat, this);
		MR->SetVectorParameterValue(TEXT("Color"), FarGreens[c] * FLinearColor(0.6f, 0.68f, 0.72f, 1.f));
		H->SetMaterial(0, MR);
		H->SetCullDistances(760000, 800000);
		H->bAffectDynamicIndirectLighting = false;
		H->bAffectDistanceFieldLighting = false;
		FarCrowns.Add(H);
	}
	TArray<TArray<FTransform>> FarT; FarT.SetNum(6);
	TArray<TArray<FTransform>> FabT; FabT.SetNum(FabTreeH.Num());
	FRandomStream Rs(4242);
	TreeGrid.SetNum(TreeGridN * TreeGridN);
	const FRWZone* Forest = Layout->Find(ERWZone::Forest);
	TArray<FTransform> TT, TC, TB, TF, TBu;
	// Kinds: a plant list to choose from instead of the forest trees (with its own height range)
	auto TryTree = [&](float X, float Y, const TArray<int32>* Kinds = nullptr, float HMin = 0.f, float HMax = 0.f) -> bool
	{
		const float Lim = ARWTerrain::Half - 4.f;
		if (!Terrain->InBounds(X, Y) || FMath::Abs(X) > Lim || FMath::Abs(Y) > Lim) return false;
		if (Layout->RiverDist(X, Y) < 11.f || Layout->StreamDist(X, Y) < 6.f) return false;
		if (Layout->LakeShoreDist(X, Y) < 8.f) return false;
		float RZ; if (Layout->RoadInfluence(X, Y, RZ) > 0.05f) return false;
		for (const FRWZone& Z : Layout->Zones)
			if (Z.Type != ERWZone::Forest && Z.Type != ERWZone::Knoll && Z.Type != ERWZone::Plot && FRWLayout::InZone(Z, X, Y, 6.f)) return false;
		const FVector N = Terrain->NormalAt(X, Y);
		if (N.Z < 0.72f) return false;
		const float Z = Terrain->HeightAt(X, Y);
		// the forest thins out and stops at the tree line, below the bare rock and snow
		if (!Kinds && Z > Layout->Params.TreeLine - 90.f && Rs.FRand() < FMath::Clamp((Z - (Layout->Params.TreeLine - 90.f)) / 180.f, 0.f, 1.f)) return false;
		FRWTree T; T.P = FVector2D(X, Y); T.Z = Z; T.bAlive = true;
		// the valley floor keeps some broadleaf trees; everything from the foothills up is conifer forest
		T.H = Kinds ? Rs.FRandRange(HMin, HMax) : Rs.FRandRange(9.f, 22.f);
		T.bConifer = !Kinds && Rs.FRand() < FMath::Lerp(0.75f, 0.98f, FMath::Clamp((Z - 8.f) / 40.f, 0.f, 1.f)); // the higher, the more conifers
		T.Trunk = TT.Num(); T.Crown = 0;
		const TArray<int32>& FabList = Kinds ? *Kinds : (T.bConifer ? FabConifer : FabBroad);
		if (FabList.Num())
		{
			// a whole tree from the Content packs, scaled to this tree's height, standing on the ground
			const int32 C = FabList[Rs.RandRange(0, FabList.Num() - 1)];
			// young plants in a pack (saplings, banana shoots) keep about their own size: stretched to a tree they would look wrong
			const float OwnH = FabTreeH[C]->GetStaticMesh()->GetBounds().BoxExtent.Z * 2.f * CM2M;
			if (((Kinds && HMax <= 0.f) || OwnH < 9.f) && OwnH > 0.05f) T.H = OwnH * Rs.FRandRange(0.85f, 1.2f);
			if (!Kinds && T.H >= 6.f)
			{
				const int32 Shade = Rs.RandRange(0, 2) + (T.bConifer ? 3 : 0);
				T.FarComp = Shade; T.FarIdx = FarT[Shade].Num();
				// tall enough to reach the ground: a crown with no trunk would seem to float
				const float CrownW = T.H * (T.bConifer ? 0.5f : 0.82f);
				FarT[Shade].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Z + T.H * 0.46f) * M2CM, FVector(CrownW, CrownW, T.H)));
			}
			float Base = 0.f;
			const float Sc = FRWFab::HeightScale(FabTreeH[C]->GetStaticMesh(), T.H, &Base);
			T.FabComp = C; T.FabIdx = FabT[C].Num();
			T.FabT = FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Z) * M2CM - FVector(0, 0, Base * Sc), FVector(Sc));
			FabT[C].Add(T.FabT);
			const int32 FGX = FMath::Clamp(FMath::FloorToInt((X + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1), FGY = FMath::Clamp(FMath::FloorToInt((Y + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1);
			TreeGrid[FGY * TreeGridN + FGX].Add(Trees.Num());
			Trees.Add(T);
			return true;
		}
		const float TrunkD = 0.22f + T.H * 0.02f;
		TT.Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Z + T.H * 0.3f) * M2CM, FVector(TrunkD, TrunkD, T.H * 0.62f)));
		if (T.bConifer)
		{
			// three overlapping tiers of foliage, widest at the bottom
			T.Crown = TC.Num();
			const float W = T.H * Rs.FRandRange(0.30f, 0.38f);
			for (int32 k = 0; k < 3; ++k)
			{
				const float Wk = W * (1.f - k * 0.27f), Hk = T.H * (0.46f - k * 0.08f);
				TC.Add(FTransform(FRotator(Rs.FRandRange(-3.f, 3.f), Rs.FRand() * 360.f, Rs.FRandRange(-3.f, 3.f)), FVector(X, Y, Z + T.H * (0.38f + k * 0.2f) + Hk * 0.5f - Hk * 0.3f) * M2CM, FVector(Wk, Wk * Rs.FRandRange(0.9f, 1.1f), Hk)));
				T.CrownT[k] = TC.Last();
			}
		}
		else
		{
			// clustered lobes for a broadleaf crown
			T.Crown = TB.Num();
			const float W = T.H * Rs.FRandRange(0.36f, 0.48f);
			for (int32 k = 0; k < 3; ++k)
			{
				const float A = Rs.FRand() * 2 * PI;
				const FVector Off = k == 0 ? FVector(0, 0, T.H * 0.74f) : FVector(FMath::Cos(A) * W * 0.32f, FMath::Sin(A) * W * 0.32f, T.H * Rs.FRandRange(0.6f, 0.68f));
				const float Sk = W * (k == 0 ? 1.f : Rs.FRandRange(0.6f, 0.8f));
				TB.Add(FTransform(FRotator(Rs.FRand() * 20.f, Rs.FRand() * 360.f, 0), (FVector(X, Y, Z) + Off) * M2CM, FVector(Sk, Sk * Rs.FRandRange(0.8f, 1.1f), Sk * 0.75f)));
				T.CrownT[k] = TB.Last();
			}
		}
		T.TrunkT = TT.Last();
		const int32 GX = FMath::Clamp(FMath::FloorToInt((X + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1), GY = FMath::Clamp(FMath::FloorToInt((Y + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1);
		TreeGrid[GY * TreeGridN + GX].Add(Trees.Num());
		Trees.Add(T);
		return true;
	};
	// the level's own trees and plants when it has them (exported from the game, placed and edited in the Unreal Editor):
	// every model exactly where it stands there
	for (int32 C : FabConifer) FabTreeComps.Add(C);
	for (int32 C : FabBroad) FabTreeComps.Add(C);
	for (int32 C : FabPalm) FabTreeComps.Add(C);
	for (int32 C : FabBanana) FabTreeComps.Add(C);
	for (int32 C : FabBamboo) FabTreeComps.Add(C);
	bool bLevelPlants = false;
	if (Layout->LevelPlants.Num())
	{
		TMap<FString, int32> CompOf;
		for (int32 C = 0; C < FabTreeH.Num(); ++C) if (FabTreeH[C] && FabTreeH[C]->GetStaticMesh()) CompOf.Add(FabTreeH[C]->GetStaticMesh()->GetPathName(), C);
		int32 Placed = 0, Missing = 0;
		for (const FRWLayout::FLevelPlants& Lp : Layout->LevelPlants)
		{
			const int32* Cp = CompOf.Find(Lp.Mesh);
			if (!Cp) { Missing += Lp.Instances.Num(); continue; }
			const int32 C = *Cp;
			const float OwnH = FabTreeH[C]->GetStaticMesh()->GetBounds().BoxExtent.Z * 2.f * CM2M;
			for (const FTransform& X : Lp.Instances)
			{
				++Placed;
				if (!Lp.bTree) { FabT[C].Add(X); continue; }
				const FVector L = X.GetLocation() * CM2M;
				if (!Terrain->InBounds(L.X, L.Y)) continue;
				FRWTree T; T.P = FVector2D(L.X, L.Y); T.Z = Terrain->HeightAt(L.X, L.Y); T.bAlive = true; T.Trunk = 0; T.Crown = 0;
				T.bConifer = FabConifer.Contains(C);
				T.H = FMath::Max(OwnH * X.GetScale3D().Z, 1.f);
				if (T.H >= 6.f)
				{
					const int32 Shade = Rs.RandRange(0, 2) + (T.bConifer ? 3 : 0);
					T.FarComp = Shade; T.FarIdx = FarT[Shade].Num();
					const float CrownW = T.H * (T.bConifer ? 0.5f : 0.82f);
					FarT[Shade].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(L.X, L.Y, T.Z + T.H * 0.46f) * M2CM, FVector(CrownW, CrownW, T.H)));
				}
				T.FabComp = C; T.FabIdx = FabT[C].Num(); T.FabT = X;
				FabT[C].Add(X);
				const int32 GX = FMath::Clamp(FMath::FloorToInt((L.X + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1), GY = FMath::Clamp(FMath::FloorToInt((L.Y + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1);
				TreeGrid[GY * TreeGridN + GX].Add(Trees.Num());
				Trees.Add(T);
			}
		}
		RWLog(FString::Printf(TEXT("World: %d trees and plants from the level (%d of models not in this game)"), Placed, Missing));
		bLevelPlants = Placed > 0;
	}
	if (!bLevelPlants)
	{
	if (Forest)
		for (int32 k = 0; k < 2600; ++k)
			TryTree(Forest->C.X + Rs.FRandRange(-Forest->HalfExt.X, Forest->HalfExt.X), Forest->C.Y + Rs.FRandRange(-Forest->HalfExt.Y, Forest->HalfExt.Y));
	for (int32 k = 0; k < 900; ++k) TryTree(Rs.FRandRange(-250.f, 250.f), Rs.FRandRange(-250.f, 250.f));
	// trees along the access road corridor (the road job has to clear these)
	for (int32 k = 0; k < 40; ++k) TryTree(Rs.FRandRange(-20.f, 40.f), Rs.FRandRange(0.f, 45.f));
	// the forest beyond the plain: it thickens up the hillsides towards the map's edge, with clearings
	{
		const float Lim = ARWTerrain::Half - 4.f;
		// the level's forest when the map has one: each tree where it stands in the editor
		for (const FVector& Lt : Layout->LevelTrees) TryTree(Lt.X, Lt.Y);
		for (int32 k = 0; k < (Layout->LevelTrees.Num() ? 0 : 340000); ++k)
		{
			const float X = Rs.FRandRange(-Lim, Lim), Y = Rs.FRandRange(-Lim, Lim);
			const float Edge = FMath::Max(FMath::Abs(X), FMath::Abs(Y));
			if (Edge < 255.f && Y < 120.f) continue;
			if (RWNoise2(X / 95.f, Y / 95.f, 19) < -0.3f) continue;
			if (Rs.FRand() > FMath::Clamp((Edge - 200.f) / 180.f + 0.25f, 0.f, 1.f)) continue;
			TryTree(X, Y);
		}
	}
	// the look of the Thai countryside: palms along the roads and field edges, bananas by the houses, bamboo on the banks
	if (FabPalm.Num())
	{
		auto NearRoad = [&](float MinD, float MaxD)
		{
			const FRWRoad& R = Layout->Roads[Rs.RandRange(0, Layout->Roads.Num() - 1)];
			const int32 i = Rs.RandRange(0, R.Pts.Num() - 1);
			const float A = Rs.FRand() * 2.f * PI, D = Rs.FRandRange(MinD, MaxD);
			const FVector2D Near = R.Pts[i] + FVector2D(FMath::Cos(A), FMath::Sin(A)) * D;
			// (palms and bananas only down in the middle of the valley: out of bounds elsewhere, so that the tree is not planted)
			return FMath::Max(FMath::Abs(Near.X), FMath::Abs(Near.Y)) < 420.f ? Near : FVector2D(1e7f, 1e7f);
		};
		// fallen fruit and rotting leaves lie around a banana plant
		auto TryBanana = [&](float X, float Y)
		{
			if (!TryTree(X, Y, &FabBanana, 0.f, 0.f) || FabProp.Num() == 0 || Rs.FRand() > 0.6f) return;
			const float A = Rs.FRand() * 2.f * PI, D = Rs.FRandRange(0.4f, 1.8f);
			const float Px = X + FMath::Cos(A) * D, Py = Y + FMath::Sin(A) * D;
			if (!Terrain->InBounds(Px, Py)) return;
			const int32 C = FabProp[Rs.RandRange(0, FabProp.Num() - 1)];
			FabT[C].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(Px, Py, Terrain->HeightAt(Px, Py)) * M2CM));
		};
		for (int32 k = 0; k < 1500; ++k) { const FVector2D P = NearRoad(10.f, 26.f); TryTree(P.X, P.Y, &FabPalm, 10.f, 17.f); }
		for (int32 k = 0; k < 1500; ++k) { const FVector2D P = NearRoad(9.f, 30.f); TryBanana(P.X, P.Y); }
		for (const FRWZone& Z : Layout->Zones)
		{
			if (Z.Type != ERWZone::Paddy && Z.Type != ERWZone::Village) continue;
			// just outside the fields and the houses
			const int32 Count = Z.Type == ERWZone::Paddy ? 120 : 90;
			for (int32 k = 0; k < Count; ++k)
			{
				const float A = Rs.FRand() * 2.f * PI;
				const FVector2D P = Z.C + FVector2D(FMath::Cos(A) * (Z.HalfExt.X + 10.f), FMath::Sin(A) * (Z.HalfExt.Y + 10.f)) * Rs.FRandRange(1.f, 1.22f);
				if (k % 3 == 2) TryBanana(P.X, P.Y);
				else TryTree(P.X, P.Y, &FabPalm, 10.f, 17.f);
			}
		}
		for (const FRWStream& S : Layout->Streams)
			for (int32 k = 0; k < S.Pts.Num() / 3; ++k)
			{
				const int32 i = Rs.RandRange(0, S.Pts.Num() - 1);
				const float A = Rs.FRand() * 2.f * PI, D = Rs.FRandRange(7.f, 15.f);
				TryTree(S.Pts[i].X + FMath::Cos(A) * D, S.Pts[i].Y + FMath::Sin(A) * D, &FabBamboo, 8.f, 13.f);
			}
		for (int32 k = 0; k < 900; ++k)
		{
			const float X = Rs.FRandRange(-400.f, 400.f);
			TryTree(X, Layout->RiverY(X) + (Rs.FRand() > 0.5f ? 1.f : -1.f) * Rs.FRandRange(12.f, 26.f), k % 3 == 0 ? &FabPalm : &FabBamboo, 9.f, 15.f);
		}
	}
	// the forest floor and the banks: the low tropical plants of the pack, each at its own size
	if (FabUnder.Num())
	{
		const float Lim = ARWTerrain::Half - 8.f;
		for (int32 k = 0; k < 140000; ++k)
		{
			const float X = Rs.FRandRange(-Lim, Lim), Y = Rs.FRandRange(-Lim, Lim);
			const int32 i = Terrain->IndexAt(X, Y);
			if (Terrain->Grass[i] < 90 || Terrain->Height[i] < Terrain->WaterZ + 0.3f || Layout->StreamDist(X, Y) < 4.f || Terrain->NormalAt(X, Y).Z < 0.8f || Layout->LakeShoreDist(X, Y) < 3.f) continue;
			float RZ; if (Layout->RoadInfluence(X, Y, RZ) > 0.05f) continue;
			bool bBlocked = false;
			for (const FRWZone& Z : Layout->Zones) if (Z.Type != ERWZone::Forest && Z.Type != ERWZone::Knoll && FRWLayout::InZone(Z, X, Y, 3.f)) { bBlocked = true; break; }
			if (bBlocked) continue;
			const int32 C = FabUnder[Rs.RandRange(0, FabUnder.Num() - 1)];
			const float Sc = Rs.FRandRange(0.8f, 1.25f);
			FabT[C].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Terrain->Height[i]) * M2CM, FVector(Sc)));
		}
	}
	// rotting leaves scattered under the trees
	if (FabProp.Num())
		for (int32 k = 0; k < 24000; ++k)
		{
			const FVector2D P(Rs.FRandRange(-ARWTerrain::Half + 14.f, ARWTerrain::Half - 14.f), Rs.FRandRange(-ARWTerrain::Half + 14.f, ARWTerrain::Half - 14.f));
			if (Layout->RiverDist(P.X, P.Y) < 12.f || Terrain->Height[Terrain->IndexAt(P.X, P.Y)] < Terrain->WaterZ + 0.3f) continue;
			float RZ; if (Layout->RoadInfluence(P.X, P.Y, RZ) > 0.05f) continue;
			bool bBlocked = false;
			for (const FRWZone& Z : Layout->Zones) if (Z.Type != ERWZone::Forest && FRWLayout::InZone(Z, P.X, P.Y, 2.f)) { bBlocked = true; break; }
			if (bBlocked) continue;
			const int32 C = FabProp[FabProp.Num() - 1 - Rs.RandRange(0, 1)]; // the last two in the list are the leaves
			FabT[C].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(P.X, P.Y, Terrain->HeightAt(P.X, P.Y)) * M2CM));
		}
	auto PutFabBush = [&](float X, float Y, float HeightM)
	{
		const int32 C = FabBush[Rs.RandRange(0, FabBush.Num() - 1)];
		float Base = 0.f;
		const float Sc = FRWFab::HeightScale(FabTreeH[C]->GetStaticMesh(), HeightM, &Base);
		FabT[C].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Terrain->HeightAt(X, Y)) * M2CM - FVector(0, 0, Base * Sc), FVector(Sc)));
	};
	// river bank bushes
	for (int32 k = 0; k < 8000; ++k)
	{
		const float X = Rs.FRandRange(-ARWTerrain::Half + 14.f, ARWTerrain::Half - 14.f);
		const float Y = Layout->RiverY(X) + (Rs.FRand() > 0.5f ? 1.f : -1.f) * Rs.FRandRange(9.f, 20.f);
		if (!Terrain->InBounds(X, Y)) continue;
		float RZ; if (Layout->RoadInfluence(X, Y, RZ) > 0.05f) continue;
		const float S = Rs.FRandRange(0.8f, 2.2f);
		if (FabBush.Num()) PutFabBush(X, Y, S);
		else TBu.Add(FTransform(FRotator::ZeroRotator, FVector(X, Y, Terrain->HeightAt(X, Y) + S * 0.3f) * M2CM, FVector(S, S, S * 0.7f)));
	}
	// real shrubs are worth seeing: scatter them over the open land and along the forest edge too, clear of roads and work zones
	if (FabBush.Num())
		for (int32 k = 0; k < 90000; ++k)
		{
			const float X = Rs.FRandRange(-ARWTerrain::Half + 9.f, ARWTerrain::Half - 9.f), Y = Rs.FRandRange(-ARWTerrain::Half + 9.f, ARWTerrain::Half - 9.f);
			if (!Terrain->InBounds(X, Y) || Layout->RiverDist(X, Y) < 9.f || Layout->StreamDist(X, Y) < 5.f || Terrain->NormalAt(X, Y).Z < 0.82f) continue;
			if (Layout->LakeShoreDist(X, Y) < 6.f) continue;
			float RZ; if (Layout->RoadInfluence(X, Y, RZ) > 0.05f) continue;
			bool bBlocked = false;
			for (const FRWZone& Z : Layout->Zones) if (Z.Type != ERWZone::Forest && Z.Type != ERWZone::Knoll && FRWLayout::InZone(Z, X, Y, 4.f)) bBlocked = true;
			if (!bBlocked) PutFabBush(X, Y, Rs.FRandRange(0.7f, 1.9f));
		}
	} // (the generated trees and plants, when the level has none)
	// the forests on the mountains outside the map: closed canopy up the slopes, thinner where the rock shows
	{
		const float RMin = ARWTerrain::Half - 2.f, RMax = 7500.f;
		for (int32 k = 0; k < 120000; ++k)
		{
			const float A = Rs.FRand() * 2 * PI, D = FMath::Lerp(RMin, RMax, FMath::Pow(Rs.FRand(), 1.4f)); // thicker near the map, thinner where haze hides it
			const float X = FMath::Cos(A) * D, Y = FMath::Sin(A) * D;
			if (FMath::Abs(X) < RMin && FMath::Abs(Y) < RMin) continue;
			const float Z = Layout->Landscape(X, Y, false) - 0.35f;
			if (Z < Layout->WaterZ + 1.f || RWNoise2(X / 150.f, Y / 150.f, 9) < -0.5f) continue;
			// the tree line: the forest thins out and stops below the bare rock and snow
			if (Rs.FRand() < FMath::Clamp((Z - (Layout->Params.TreeLine - 90.f)) / 180.f, 0.f, 1.f)) continue;
			const float Dzx = Layout->Landscape(X + 12.f, Y, false) - 0.35f - Z, Dzy = Layout->Landscape(X, Y + 12.f, false) - 0.35f - Z;
			if (FMath::Sqrt(Dzx * Dzx + Dzy * Dzy) / 12.f > 1.1f) continue; // a limestone face: bare rock
			const float H = Rs.FRandRange(16.f, 28.f) * (1.f + 2.f * D / 7500.f);
			FarT[3 + Rs.RandRange(0, 2)].Add(FTransform(FRotator(0, Rs.FRand() * 360.f, 0), FVector(X, Y, Z + H * 0.45f) * M2CM, FVector(H * 0.55f, H * 0.55f, H)));
		}
	}
	for (int32 c = 0; c < FarCrowns.Num(); ++c) FarCrowns[c]->AddInstances(FarT[c], false);
	for (int32 C = 0; C < FabTreeH.Num(); ++C) if (FabT[C].Num()) FabTreeH[C]->AddInstances(FabT[C], false);
	Trunks->AddInstances(TT, false);
	Conifers->AddInstances(TC, false);
	Broadleaf->AddInstances(TB, false);
	FarTrees->AddInstances(TF, false);
	Bushes->AddInstances(TBu, false);
	int32 NPlants = 0; for (const TArray<FTransform>& L : FabT) NPlants += L.Num();
	RWLog(FString::Printf(TEXT("World: %d trees, %d plants placed in %d model lists, %d far crowns, %d obstacles"), Trees.Num(), NPlants, FabTreeH.Num(), FarT[0].Num() + FarT[1].Num() + FarT[2].Num() + FarT[3].Num() + FarT[4].Num() + FarT[5].Num(), Obstacles.Num()));
}

void ARWWorld::StreamsAndPaddies(UMaterialInterface* WaterSurface)
{
	auto Water3D = [&](UStaticMesh* M, const FVector& AtM, float YawDeg, const FVector& Scale, UMaterialInterface* Override = nullptr)
	{
		if (!M) return;
		UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(this);
		if (!CurObj.IsNone()) CompObj.Add(C, CurObj);
		C->SetStaticMesh(M);
		if (Override) C->SetMaterial(0, Override);
		C->SetupAttachment(RootComponent);
		C->SetMobility(EComponentMobility::Movable);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->SetWorldLocationAndRotation(AtM * M2CM, FRotator(0.f, YawDeg, 0.f));
		C->SetWorldScale3D(Scale);
		C->RegisterComponent();
	};
	auto Pack = [](const TCHAR* Path) { return LoadObject<UStaticMesh>(nullptr, Path); };
	UStaticMesh* Plane0 = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));
	// the reservoirs: their own calm water and an island of sand
	// (their water and island belong to the lake: in the level they are part of the lake's own actor, RW_Lake)
	ON_SCOPE_EXIT { CurObj = NAME_None; };
	for (const FRWLayout::FRWLake& L : Layout->Lakes)
	{
		CurObj = FName(*FString::Printf(TEXT("Lake_%d"), &L - Layout->Lakes.GetData()));
		ON_SCOPE_EXIT { CurObj = NAME_None; };
		if (FRWFab::Lake) Water3D(Plane0, FVector(L.C.X, L.C.Y, L.Z - 0.1f), 0.f, FVector(2.f * L.R + 40.f, 2.f * L.R + 40.f, 1.f), FRWFab::Lake);
		Water3D(Pack(TEXT("/Game/WaterMaterials/Meshes/SM_Island.SM_Island")), FVector(L.C.X, L.C.Y, L.Z - 0.5f), 30.f, FVector(0.7f));
		// (the pack's Shore, LakeBank and Riverbank are square slabs that stand out against a round shore: they are in the map editor's list instead)
	}
	// waterfalls: every stream that starts high up comes over a rock cliff; rapids where the fall is steepest
	UStaticMesh* CliffM = Pack(TEXT("/Game/WaterMaterials/Meshes/SM_Cliff.SM_Cliff"));
	UStaticMesh* FallArc = Pack(TEXT("/Game/WaterMaterials/Meshes/SM_Waterfall_Arc.SM_Waterfall_Arc"));
	UStaticMesh* FallBase = Pack(TEXT("/Game/WaterMaterials/Meshes/SM_Waterfall_Base.SM_Waterfall_Base"));
	UStaticMesh* RapidsM = Pack(TEXT("/Game/WaterMaterials/Meshes/SM_Rapids.SM_Rapids"));
	UStaticMesh* RapidsB = Pack(TEXT("/Game/WaterMaterials/Meshes/SM_RapidsBank.SM_RapidsBank"));
	UParticleSystem* FoamFx = LoadObject<UParticleSystem>(nullptr, TEXT("/Game/WaterMaterials/Particles/P_Waterfall_Foam.P_Waterfall_Foam"));
	for (const FRWStream& St : Layout->Streams)
	{
		if (St.Pts.Num() < 30 || St.Bed[0] < 12.f) continue;
		const FVector2D Head = St.Pts[0], Down = (St.Pts[6] - St.Pts[0]).GetSafeNormal();
		const float DownYaw = FMath::RadiansToDegrees(FMath::Atan2(Down.Y, Down.X));
		const FVector Foot(Head.X, Head.Y, St.Bed[0] + 0.3f);
		// these meshes face and flow along their +Y, with the foot of the fall at y = 0 and the rock going back behind it
		Water3D(CliffM, Foot - FVector(Down.X, Down.Y, 0.f) * 0.6f, DownYaw - 90.f, FVector(0.8f));
		Water3D(FallArc, Foot, DownYaw - 90.f, FVector(0.8f));
		Water3D(FallBase, Foot, DownYaw - 90.f, FVector(0.8f));
		if (FoamFx) UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), FoamFx, FTransform(FRotator(0.f, DownYaw, 0.f), Foot * M2CM));
		// the steepest stretch of this stream
		int32 Best = 12; float Fall = -1.f;
		for (int32 i = 12; i + 16 < St.Pts.Num(); ++i) { const float F = St.Bed[i] - St.Bed[i + 15]; if (F > Fall) { Fall = F; Best = i; } }
		// the rapids mesh runs 45 m along its +Y from y = -37.5 (3.97 m high) to y = 7.5 (0.12 m), 15 m wide: fit it to this stretch
		const FVector2D RapTop = St.Pts[Best], Along = (St.Pts[Best + 15] - St.Pts[Best]).GetSafeNormal();
		const float AlongYaw = FMath::RadiansToDegrees(FMath::Atan2(Along.Y, Along.X)) - 90.f;
		const float RapZ = FMath::Max(Fall, 0.5f) / 3.85f, RapW = (2.f * St.HalfW + 2.f) / 15.f;
		const FVector2D RapPivot = RapTop + Along * 37.5f;
		const FVector RapAt(RapPivot.X, RapPivot.Y, St.Bed[Best] + 0.45f - 3.97f * RapZ);
		Water3D(RapidsM, RapAt, AlongYaw, FVector(RapW, 1.f, RapZ));
		Water3D(RapidsB, RapAt - FVector(0, 0, 0.1f), AlongYaw, FVector(RapW * 1.3f, 1.f, RapZ));
	}
	// the stream water: a ribbon following each stream's bed down to the river
	StreamWater = NewObject<UProceduralMeshComponent>(this, TEXT("StreamWater"));
	StreamWater->SetupAttachment(RootComponent);
	StreamWater->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	StreamWater->SetCastShadow(false);
	StreamWater->RegisterComponent();
	for (int32 s = 0; s < Layout->Streams.Num(); ++s)
	{
		const FRWStream& St = Layout->Streams[s];
		const int32 Np = St.Pts.Num();
		TArray<FVector> V, Nrm; TArray<FVector2D> UV; TArray<int32> Tri;
		float Run = 0.f;
		for (int32 i = 0; i < Np; ++i)
		{
			const FVector2D Dir = (St.Pts[FMath::Min(i + 1, Np - 1)] - St.Pts[FMath::Max(i - 1, 0)]).GetSafeNormal();
			const FVector2D Lat(-Dir.Y, Dir.X);
			if (i > 0) Run += FVector2D::Distance(St.Pts[i], St.Pts[i - 1]);
			const float W = St.HalfW + 1.6f, Z = St.Bed[i] + 0.34f;
			for (int32 c = -1; c <= 1; ++c)
			{
				const FVector2D P = St.Pts[i] + Lat * (c * W);
				V.Add(FVector(P.X, P.Y, Z) * M2CM);
				Nrm.Add(FVector::UpVector);
				UV.Add(FVector2D(Run, c * W) / 14.f);
			}
			if (i + 1 < Np)
				for (int32 c = 0; c < 2; ++c)
				{
					const int32 A = i * 3 + c, B = A + 1, D = A + 3, E = A + 4;
					// Unreal's front face: (C-A) x (B-A) must point up
					const bool bUp = FVector::CrossProduct(FVector(Dir.X, Dir.Y, 0.f), FVector(Lat.X, Lat.Y, 0.f)).Z > 0.f;
					if (bUp) Tri.Append({A, B, D, B, E, D}); else Tri.Append({A, D, B, B, D, E});
				}
		}
		TArray<FProcMeshTangent> Tan; Tan.Init(FProcMeshTangent(FVector(1, 0, 0), false), V.Num());
		StreamWater->CreateMeshSection_LinearColor(s, V, Tri, Nrm, UV, TArray<FLinearColor>(), Tan, false);
		StreamWater->SetMaterial(s, WaterSurface);
	}
	// standing water in the rice fields
	UStaticMesh* PlaneMesh = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Plane.Plane"));
	int32 Fields = 0;
	for (const FRWZone& Z : Layout->Zones)
	{
		if (Z.Type != ERWZone::Paddy) continue;
		const int32 Nx = FMath::FloorToInt(2.f * Z.HalfExt.X / FRWLayout::PaddyFieldX), Ny = FMath::FloorToInt(2.f * Z.HalfExt.Y / FRWLayout::PaddyFieldY);
		for (int32 iy = 0; iy < Ny; ++iy)
			for (int32 ix = 0; ix < Nx; ++ix)
			{
				const float X = Z.C.X - Z.HalfExt.X + (ix + 0.5f) * FRWLayout::PaddyFieldX, Y = Z.C.Y - Z.HalfExt.Y + (iy + 0.5f) * FRWLayout::PaddyFieldY;
				if (Terrain->SurfaceMat(Terrain->IndexAt(X, Y)) != ESoil::Mud) continue; // a lane runs through here
				float Level, Bund;
				FRWLayout::PaddyField(Z, X, Y, Level, Bund);
				UStaticMeshComponent* W = NewObject<UStaticMeshComponent>(this);
				W->SetStaticMesh(PlaneMesh);
				W->SetMaterial(0, WaterSurface);
				W->SetupAttachment(RootComponent);
				W->SetMobility(EComponentMobility::Movable);
				W->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				W->SetCastShadow(false);
				W->SetWorldLocation(FVector(X, Y, Level + 0.14f) * M2CM);
				W->SetWorldScale3D(FVector(FRWLayout::PaddyFieldX - 1.f, FRWLayout::PaddyFieldY - 1.f, 1.f));
				W->RegisterComponent();
				++Fields;
			}
	}
	RWLog(FString::Printf(TEXT("World: %d streams, %d rice fields, %d limestone hills"), Layout->Streams.Num(), Fields, Layout->Towers.Num()));
}

void ARWWorld::SetTreeAlive(int32 i, bool bAlive)
{
	if (!Trees.IsValidIndex(i)) return;
	FRWTree& T = Trees[i];
	T.bAlive = bAlive;
	const FVector S0 = FVector::ZeroVector;
	if (T.FarComp >= 0 && FarCrowns.IsValidIndex(T.FarComp))
		FarCrowns[T.FarComp]->UpdateInstanceTransform(T.FarIdx, FTransform(FQuat::Identity, FVector(T.P.X, T.P.Y, T.Z + T.H * 0.46f) * M2CM, bAlive ? FVector(T.H * (T.bConifer ? 0.5f : 0.82f), T.H * (T.bConifer ? 0.5f : 0.82f), T.H) : S0), true, true, true);
	if (T.FabComp >= 0)
	{
		// a whole-tree model: one instance to hide or bring back
		FabTreeH[T.FabComp]->UpdateInstanceTransform(T.FabIdx, bAlive ? T.FabT : FTransform(FQuat::Identity, FVector(T.P.X, T.P.Y, T.Z - 50.f) * M2CM, S0), true, true, true);
		return;
	}
	if (!bAlive)
	{
		Trunks->UpdateInstanceTransform(T.Trunk, FTransform(FQuat::Identity, FVector(T.P.X, T.P.Y, T.Z - 50.f) * M2CM, S0), true, true, true);
		for (int32 k = 0; k < 3; ++k)
			(T.bConifer ? Conifers : Broadleaf)->UpdateInstanceTransform(T.Crown + k, FTransform(FQuat::Identity, FVector(T.P.X, T.P.Y, T.Z - 50.f) * M2CM, S0), true, true, true);
	}
	else
	{
		Trunks->UpdateInstanceTransform(T.Trunk, T.TrunkT, true, true, true);
		for (int32 k = 0; k < 3; ++k)
			(T.bConifer ? Conifers : Broadleaf)->UpdateInstanceTransform(T.Crown + k, T.CrownT[k], true, true, true);
	}
}

int32 ARWWorld::ExportPlants(const FString& File) const
{
	// per instance list: the model's asset path, tree or not, the placements (location cm, rotation, scale)
	TArray<uint8> Out;
	FMemoryWriter W(Out);
	int32 Magic = 0x52575031, Lists = 0, Total = 0;
	W << Magic << Lists;
	for (int32 C = 0; C < FabTreeH.Num(); ++C)
	{
		UHierarchicalInstancedStaticMeshComponent* H = FabTreeH[C];
		if (!H || !H->GetStaticMesh() || H->GetInstanceCount() == 0) continue;
		if (UserTreeComps.Contains(C)) continue; // (trees placed in the level by hand: the level has them already)
		FString Path = H->GetStaticMesh()->GetPathName();
		if (!Path.StartsWith(TEXT("/Game/"))) continue; // (models built while the game runs are not assets the editor can place)
		uint8 bTree = FabTreeComps.Contains(C) ? 1 : 0;
		int32 N = H->GetInstanceCount();
		W << Path << bTree << N;
		for (int32 i = 0; i < N; ++i)
		{
			FTransform X; H->GetInstanceTransform(i, X, true);
			FVector L = X.GetLocation(), S = X.GetScale3D(); FQuat Q = X.GetRotation();
			W << L << Q << S;
		}
		++Lists; Total += N;
	}
	// the number of lists goes at the front
	FMemory::Memcpy(Out.GetData() + 4, &Lists, 4);
	IFileManager::Get().MakeDirectory(*FPaths::GetPath(File), true);
	const bool bOk = FFileHelper::SaveArrayToFile(Out, *File);
	RWLog(FString::Printf(TEXT("Plants exported: %d instances in %d lists -> %s (%s)"), Total, Lists, *File, bOk ? TEXT("ok") : TEXT("FAILED")));
	return bOk ? Total : -1;
}

int32 ARWWorld::HitTrees(const FVector& P, float R, const FVector& Dir, float HalfH)
{
	// fallen trunks and rocks in the way are shoved along (Dir carries the machine's speed) where the tool meets them
	{
		const float Ds = GetWorld() ? GetWorld()->GetDeltaSeconds() : 0.f, Dt = Ds > 0.f ? FMath::Min(Ds, 0.05f) : 1.f / 60.f;
		for (const TWeakObjectPtr<ARWProp>& Wp : ARWProp::All) if (ARWProp* Pp = Wp.Get()) Pp->Push(P, R, Dir, Dt, HalfH);
	}
	const int32 GX = FMath::Clamp(FMath::FloorToInt((P.X + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1), GY = FMath::Clamp(FMath::FloorToInt((P.Y + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1);
	int32 Count = 0;
	for (int32 dy = -1; dy <= 1; ++dy)
		for (int32 dx = -1; dx <= 1; ++dx)
		{
			const int32 X = GX + dx, Y = GY + dy;
			if (X < 0 || Y < 0 || X >= TreeGridN || Y >= TreeGridN) continue;
			for (int32 Ti : TreeGrid[Y * TreeGridN + X])
			{
				FRWTree& T = Trees[Ti];
				if (!T.bAlive) continue;
				if (FVector2D::Distance(T.P, FVector2D(P.X, P.Y)) > R + 0.4f) continue;
				if (P.Z < T.Z - 1.f || P.Z > T.Z + FMath::Min(T.H * 0.8f, 10.f)) continue;
				UStaticMesh* FabMesh = T.FabComp >= 0 && FabTreeH.IsValidIndex(T.FabComp) ? FabTreeH[T.FabComp]->GetStaticMesh() : nullptr;
				SetTreeAlive(Ti, false);
				if (UWorld* W = GetWorld())
				{
					ARWProp* Log = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
					Log->Init(0, Terrain, FVector(T.P.X, T.P.Y, T.Z), FMath::RadiansToDegrees(FMath::Atan2(Dir.Y, Dir.X)));
					Log->FallAngle = 0.f;
					Log->RemoveAfter = ARWProp::FelledTreeLife; // cleared away 15 s after it is down
					Log->SetActorRotation(FRotator(0, Log->FallYaw, 0));
					if (FabMesh)
					{
						// the tree itself goes over, at its own size, standing on its base
						// (a tree placed in the level may be stretched: its own scale on each axis)
						const FVector Sc = T.FabT.GetScale3D();
						float Base = 0.f;
						FRWFab::HeightScale(FabMesh, 1.f, &Base);
						Log->Mesh->SetStaticMesh(FabMesh);
						Log->Mesh->EmptyOverrideMaterials();
						// the palms and bamboo built in the game, and trees placed in the level with materials of their own
						if (FabTreeH[T.FabComp]->OverrideMaterials.Num() > 0)
							for (int32 s = 0; s < FabTreeH[T.FabComp]->GetNumMaterials(); ++s) Log->Mesh->SetMaterial(s, FabTreeH[T.FabComp]->GetMaterial(s));
						Log->Mesh->SetRelativeScale3D(Sc);
						Log->Mesh->SetRelativeLocation(FVector(0.f, 0.f, -Base * Sc.Z));
						Log->Mesh->SetCastShadow(true);
					}
					else
					{
						Log->Mesh->SetRelativeScale3D(FVector(0.22f + T.H * 0.02f, 0.22f + T.H * 0.02f, T.H * 0.8f));
						Log->Mesh->SetRelativeLocation(FVector(0, 0, T.H * 0.4f * M2CM));
					}
					if (Fx) Fx->SpawnDust(FVector(T.P.X, T.P.Y, T.Z + 0.3f), 0.8f, FVector(0.f, 0.f, 0.3f));
				}
				Terrain->ClearGrass(Terrain->IndexAt(T.P.X, T.P.Y), 1.f);
				++Count;
			}
		}
	if (Count) RWLog(FString::Printf(TEXT("%d tree(s) pushed over at %.0f,%.0f"), Count, P.X, P.Y));
	return Count;
}

int32 ARWWorld::LowCellKey(float X, float Y) const
{
	const int32 Side = FMath::CeilToInt(2.f * ARWTerrain::Half / LowCell) + 1;
	const int32 GX = FMath::Clamp(FMath::FloorToInt((X + ARWTerrain::Half) / LowCell), 0, Side - 1);
	const int32 GY = FMath::Clamp(FMath::FloorToInt((Y + ARWTerrain::Half) / LowCell), 0, Side - 1);
	return GY * Side + GX;
}

void ARWWorld::IndexLowPlants()
{
	LowPlants.Reset(); LowComps.Reset(); LowPlantCells.Reset(); LowPending.Reset();
	TArray<UHierarchicalInstancedStaticMeshComponent*> Lists;
	for (int32 C = 0; C < FabTreeH.Num(); ++C) if (FabTreeH[C] && !FabTreeComps.Contains(C)) Lists.Add(FabTreeH[C]);
	if (Bushes) Lists.Add(Bushes);
	for (UHierarchicalInstancedStaticMeshComponent* H : Lists)
	{
		if (!H || H->GetInstanceCount() == 0 || !H->GetStaticMesh()) continue;
		const int32 Ci = LowComps.Add(H);
		const FVector Ext = H->GetStaticMesh()->GetBounds().BoxExtent * CM2M;
		for (int32 i = 0; i < H->GetInstanceCount(); ++i)
		{
			FTransform X;
			if (!H->GetInstanceTransform(i, X, true)) continue;
			FLowPlant P;
			P.Comp = Ci; P.Idx = i; P.X = X;
			const FVector L = X.GetLocation() * CM2M;
			P.P = FVector2f(L.X, L.Y);
			// how far it spreads over the ground (a grass clump a few decimetres, a bush a metre or two)
			P.R = FMath::Clamp((float)FMath::Max(Ext.X * FMath::Abs(X.GetScale3D().X), Ext.Y * FMath::Abs(X.GetScale3D().Y)), 0.1f, 2.f);
			const int32 k = LowPlants.Add(P);
			LowPlantCells.FindOrAdd(LowCellKey(L.X, L.Y)).Add(k);
		}
	}
	RWLog(FString::Printf(TEXT("World: %d low plants in %d lists go when their ground is worked"), LowPlants.Num(), LowComps.Num()));
}

void ARWWorld::SetLowPlantGone(int32 k, bool bGone)
{
	FLowPlant& P = LowPlants[k];
	if (P.bGone == bGone) return;
	P.bGone = bGone;
	LowPending.FindOrAdd(P.Comp).Add(k);
}

void ARWWorld::DisturbAt(int32 i)
{
	if (LowPlants.Num() == 0 || !Terrain) return;
	const FVector2f At(Terrain->PX(i % ARWTerrain::N), Terrain->PX(i / ARWTerrain::N));
	// the worked point is half a metre across; a plant goes when it is under it (a bush's spread counts in part)
	const float Reach = 2.5f;
	for (const float Oy : {-Reach, 0.f, Reach})
		for (const float Ox : {-Reach, 0.f, Reach})
		{
			const TArray<int32>* Cell = LowPlantCells.Find(LowCellKey(At.X + Ox, At.Y + Oy));
			if (!Cell) continue;
			for (const int32 k : *Cell)
			{
				const FLowPlant& P = LowPlants[k];
				if (!P.bGone && FVector2f::Distance(P.P, At) < 0.35f + 0.6f * P.R) SetLowPlantGone(k, true);
			}
		}
}

void ARWWorld::RefreshLowPlants()
{
	if (!Terrain) return;
	int32 Gone = 0;
	for (int32 k = 0; k < LowPlants.Num(); ++k)
	{
		const FLowPlant& P = LowPlants[k];
		const bool bWorked = Terrain->InBounds(P.P.X, P.P.Y) && Terrain->IsWorked(Terrain->IndexAt(P.P.X, P.P.Y));
		SetLowPlantGone(k, bWorked);
		Gone += bWorked ? 1 : 0;
	}
	FlushLowPlants();
	if (LowPlants.Num()) RWLog(FString::Printf(TEXT("World: %d of %d low plants stand on worked ground and are gone"), Gone, LowPlants.Num()));
}

void ARWWorld::FlushLowPlants()
{
	for (TPair<int32, TArray<int32>>& E : LowPending)
	{
		UHierarchicalInstancedStaticMeshComponent* H = LowComps.IsValidIndex(E.Key) ? LowComps[E.Key] : nullptr;
		if (!H || E.Value.Num() == 0) continue;
		for (const int32 k : E.Value)
		{
			const FLowPlant& P = LowPlants[k];
			// gone: shrunk to nothing where it stood (the list keeps its order, so saves and the rest still match)
			FTransform X = P.X;
			if (P.bGone) X.SetScale3D(FVector(0.001f));
			H->UpdateInstanceTransform(P.Idx, X, true, false, true);
		}
		H->MarkRenderStateDirty();
	}
	LowPending.Reset();
}

void ARWWorld::SetMarkers(const TArray<FTransform>& T)
{
	if (!Markers) return;
	Markers->ClearInstances();
	if (T.Num()) Markers->AddInstances(T, false, true);
}

int32 ARWWorld::AliveTreesIn(const FVector2D& C, const FVector2D& Half) const
{
	int32 N = 0;
	for (const FRWTree& T : Trees) if (T.bAlive && FMath::Abs(T.P.X - C.X) <= Half.X && FMath::Abs(T.P.Y - C.Y) <= Half.Y) ++N;
	return N;
}

void ARWWorld::SpawnProps()
{
	UWorld* W = GetWorld();
	// a stack of drain pipes at the construction site, ready to be laid
	for (int32 k = 0; k < 8; ++k)
	{
		ARWProp* Pp = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		const float PX = 36.f + (k % 4) * 1.15f, PY = -44.f + (k / 4) * 3.4f;
		Pp->Init(3, Terrain, FVector(PX, PY, Terrain->HeightAt(PX, PY)), 90.f);
	}
	for (int32 k = 0; k < 6; ++k)
	{
		ARWProp* P = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		const float X = -160.f + k * 2.6f, Y = -186.f;
		P->Init(2, Terrain, FVector(X, Y, Terrain->HeightAt(X, Y)), 90.f);
		ARWProp* Q = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		const float X2 = -160.f + k * 2.8f, Y2 = -180.f;
		Q->Init(3, Terrain, FVector(X2, Y2, Terrain->HeightAt(X2, Y2)), 90.f);
	}
	for (int32 k = 0; k < 8; ++k)
	{
		ARWProp* P = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
		const float X = 150.f + k * 5.f, Y = 162.f + (k % 3) * 4.f;
		P->Init(1, Terrain, FVector(X, Y, Terrain->HeightAt(X, Y)), k * 40.f);
	}
	// loose rocks a bucket can pick up: at the quarry face and at the construction site
	{
		FRandomStream Rr(777);
		for (int32 k = 0; k < 36; ++k)
		{
			const bool bSite = k % 3 == 0;
			const float X = bSite ? Rr.FRandRange(20.f, 70.f) : Rr.FRandRange(140.f, 200.f);
			const float Y = bSite ? Rr.FRandRange(-80.f, -60.f) : Rr.FRandRange(150.f, 185.f);
			ARWProp* P = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
			P->Init(1, Terrain, FVector(X, Y, Terrain->HeightAt(X, Y)), Rr.FRand() * 360.f);
			P->SetRockSize(Rr.FRandRange(0.3f, 0.75f));
		}
	}
}

int32 ARWWorld::AdoptPlaced()
{
	UWorld* W = GetWorld();
	if (!W || !Terrain) return 0;
	// what a model is, by its name and folder: 1 a tree, 2 a rock, 0 neither (it stays scenery)
	auto KindOf = [](const UStaticMesh* M) -> int32
	{
		const FString Name = M->GetName(), Path = FPackageName::GetLongPackagePath(M->GetOutermost()->GetName());
		const FString C = FRWFab::Classify(Name, Path);
		if (C == TEXT("conifer") || C == TEXT("broadleaf")) return 1;
		if (C == TEXT("rock")) return 2;
		const FString S = (Path + TEXT("/") + Name).ToLower();
		for (const TCHAR* Wd : {TEXT("palm"), TEXT("coconut"), TEXT("bamboo"), TEXT("banana")}) if (S.Contains(Wd) && !S.Contains(TEXT("leaf")) && !S.Contains(TEXT("leaves"))) return 1;
		return 0;
	};
	int32 NTrees = 0, NRocks = 0, NBig = 0;
	for (TActorIterator<AActor> It(W); It; ++It)
	{
		AActor* A = *It;
		if (!A || A->IsActorBeingDestroyed() || AdoptSeen.Contains(A)) continue;
		AdoptSeen.Add(A);
		// the game's own actors and the level's parts the game reads itself (RW_ tags) are not hand-placed things
		if (A->GetClass()->GetOutermost()->GetName() == TEXT("/Script/RoadWorks") || A->IsA<ALandscapeProxy>() || A->Tags.Contains(TEXT("RWStatic"))) continue;
		bool bGameTag = false;
		for (const FName& Tg : A->Tags) if (Tg.ToString().StartsWith(TEXT("RW_"))) { bGameTag = true; break; }
		if (bGameTag) continue;
		const bool bTreeTag = A->Tags.Contains(TEXT("RWTree")), bRockTag = A->Tags.Contains(TEXT("RWRock"));
		const FString Key = A->GetPathName();
		const bool bAgain = AdoptedKeys.Contains(Key); // streamed out and in again: the game has it already
		bool bTook = false;
		TArray<UStaticMeshComponent*> Comps;
		A->GetComponents(Comps);
		for (UStaticMeshComponent* C : Comps)
		{
			UStaticMesh* M = C ? C->GetStaticMesh() : nullptr;
			if (!M || !C->IsVisible() || C->bHiddenInGame) continue;
			UInstancedStaticMeshComponent* I = Cast<UInstancedStaticMeshComponent>(C);
			if (I && I->GetInstanceCount() == 0) continue;
			const int32 Kind = bTreeTag ? 1 : bRockTag ? 2 : KindOf(M);
			if (Kind == 0) continue;
			TArray<FTransform> Xs;
			if (I) { for (int32 i = 0; i < I->GetInstanceCount(); ++i) { FTransform X; if (I->GetInstanceTransform(i, X, true)) Xs.Add(X); } }
			else Xs.Add(C->GetComponentTransform());
			TArray<UMaterialInterface*> Mats;
			for (int32 s = 0; s < C->GetNumMaterials(); ++s) Mats.Add(C->GetMaterial(s));
			// which ones the game takes over (the rest stay as they are in the level)
			TArray<int32> Taken;
			for (int32 i = 0; i < Xs.Num(); ++i)
			{
				const FTransform& X = Xs[i];
				const FVector L = X.GetLocation() * CM2M;
				if (!Terrain->InBounds(L.X, L.Y)) continue;
				if (Kind == 2)
				{
					// a rock bigger than about a house is part of the land (an outcrop, a cliff): it stays where it is
					const FVector Sz = M->GetBoundingBox().TransformBy(FTransform(X.GetRotation(), FVector::ZeroVector, X.GetScale3D())).GetSize() * CM2M;
					if (FMath::Max(Sz.X, Sz.Y) > 8.f) { ++NBig; continue; }
				}
				Taken.Add(i);
				if (bAgain) continue;
				if (Kind == 2)
				{
					ARWProp* P = W->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
					P->Init(1, Terrain, FVector(L.X, L.Y, Terrain->HeightAt(L.X, L.Y)), 0.f);
					P->SetRockModel(M, Mats, X);
					++NRocks;
					continue;
				}
				// a tree: an instance list of its own for this model (and its materials), a tree of the forest
				FString ListKey = M->GetPathName();
				for (UMaterialInterface* Mi : Mats) ListKey += TEXT("|") + (Mi ? Mi->GetPathName() : FString());
				int32 Ci;
				if (const int32* F = UserTreeCompOf.Find(ListKey)) Ci = *F;
				else
				{
					UHierarchicalInstancedStaticMeshComponent* H = NewObject<UHierarchicalInstancedStaticMeshComponent>(this);
					H->SetStaticMesh(M);
					for (int32 s = 0; s < Mats.Num(); ++s) if (Mats[s]) H->SetMaterial(s, Mats[s]);
					H->SetupAttachment(RootComponent);
					H->SetMobility(EComponentMobility::Movable);
					H->SetCollisionEnabled(ECollisionEnabled::NoCollision);
					H->SetCastShadow(C->CastShadow);
					if (I) H->SetCullDistances(I->InstanceStartCullDistance, I->InstanceEndCullDistance); // (as painted with the Foliage tool)
					H->RegisterComponent();
					Ci = FabTreeH.Add(H);
					FabTreeComps.Add(Ci);
					UserTreeComps.Add(Ci);
					UserTreeCompOf.Add(ListKey, Ci);
				}
				UHierarchicalInstancedStaticMeshComponent* H = FabTreeH[Ci];
				FRWTree T; T.P = FVector2D(L.X, L.Y); T.Z = Terrain->HeightAt(L.X, L.Y); T.bAlive = true; T.Trunk = 0; T.Crown = 0;
				T.bConifer = FRWFab::Classify(M->GetName(), FPackageName::GetLongPackagePath(M->GetOutermost()->GetName())) == TEXT("conifer");
				T.H = FMath::Max((float)(M->GetBounds().BoxExtent.Z * 2.f * CM2M * X.GetScale3D().Z), 1.f);
				T.FabComp = Ci; T.FabIdx = H->GetInstanceCount(); T.FabT = X;
				H->AddInstance(X, true);
				const int32 GX = FMath::Clamp(FMath::FloorToInt((L.X + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1), GY = FMath::Clamp(FMath::FloorToInt((L.Y + ARWTerrain::Half) / 16.f), 0, TreeGridN - 1);
				if (TreeGrid.Num() == TreeGridN * TreeGridN) TreeGrid[GY * TreeGridN + GX].Add(Trees.Num());
				Trees.Add(T);
				++NTrees;
			}
			if (Taken.Num() == 0) continue;
			bTook = true;
			// the level's own copy goes (the game draws it now)
			if (I)
			{
				if (Taken.Num() == Xs.Num()) I->ClearInstances();
				else { Taken.Sort([](int32 X, int32 Y) { return X > Y; }); for (const int32 i : Taken) I->RemoveInstance(i); }
			}
			else
			{
				C->SetVisibility(false);
				C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			}
		}
		if (bTook) AdoptedKeys.Add(Key);
	}
	UserTreesAdopted += NTrees; UserRocksAdopted += NRocks; UserRocksTooBig += NBig;
	if (NTrees || NRocks || NBig)
		RWLog(FString::Printf(TEXT("World: from the level's hand-placed models: %d trees and %d rocks taken over (machines push, flick and scoop them); %d rocks over 8 m stay as part of the land"), NTrees, NRocks, NBig));
	return NTrees + NRocks;
}

bool ARWWorld::Resolve(ARWMachine* M, FVector& Push) const
{
	Push = FVector::ZeroVector;
	const FVector2D P(M->PosM.X, M->PosM.Y);
	const float R = M->Radius2D * 0.8f;
	bool bHit = false;
	for (const FRWObstacle& O : Obstacles)
	{
		if (FMath::Abs(O.C.X - P.X) > O.Half.GetMax() + R + 2.f || FMath::Abs(O.C.Y - P.Y) > O.Half.GetMax() + R + 2.f) continue;
		const float C = FMath::Cos(FMath::DegreesToRadians(-O.Yaw)), S = FMath::Sin(FMath::DegreesToRadians(-O.Yaw));
		const FVector2D D = P - O.C;
		const FVector2D L(D.X * C - D.Y * S, D.X * S + D.Y * C);
		const FVector2D Cl(FMath::Clamp(L.X, -O.Half.X, O.Half.X), FMath::Clamp(L.Y, -O.Half.Y, O.Half.Y));
		const FVector2D Delta = L - Cl;
		const float Dist = Delta.Size();
		if (Dist < R)
		{
			FVector2D N = Dist > 1e-3f ? Delta / Dist : FVector2D(1, 0);
			const float C2 = FMath::Cos(FMath::DegreesToRadians(O.Yaw)), S2 = FMath::Sin(FMath::DegreesToRadians(O.Yaw));
			N = FVector2D(N.X * C2 - N.Y * S2, N.X * S2 + N.Y * C2);
			Push += FVector(N.X, N.Y, 0) * (R - Dist);
			bHit = true;
		}
	}
	for (const TWeakObjectPtr<ARWMachine>& O : Machines)
	{
		if (!O.IsValid() || O.Get() == M) continue;
		const FVector2D D = P - FVector2D(O->PosM.X, O->PosM.Y);
		const float Min = (R + O->Radius2D * 0.8f) * 0.85f;
		const float Dist = D.Size();
		if (Dist < Min && Dist > 1e-3f)
		{
			Push += FVector(D.X / Dist, D.Y / Dist, 0) * (Min - Dist);
			bHit = true;
		}
	}
	return bHit;
}

void ARWWorld::SetWeather(int32 W)
{
	Weather = FMath::Clamp(W, 0, 3);
	NextWeatherChange = FMath::FRandRange(4.f, 10.f);
	RWLog(FString::Printf(TEXT("Weather -> %s"), *WeatherName()));
}

FString ARWWorld::WeatherName() const
{
	static const TCHAR* N[4] = {TEXT("Clear"), TEXT("Cloudy"), TEXT("Rain"), TEXT("Thunderstorm")};
	return N[Weather];
}

FString ARWWorld::ClockText() const
{
	const int32 H = FMath::FloorToInt(TimeOfDay), M = FMath::FloorToInt((TimeOfDay - H) * 60.f);
	return FString::Printf(TEXT("Day %d  %02d:%02d"), Day, H, M);
}

void ARWWorld::UpdateSky(float Dt)
{
	// Sun path: rises 6:00 in the east, sets 18:30 in the west, ~68 deg max elevation.
	const float T = (TimeOfDay - 6.f) / 12.5f;
	const float Elev = FMath::Sin(T * PI) * 68.f - (T < 0 || T > 1 ? 15.f : 0.f);
	const float Az = -90.f + T * 180.f + 20.f;
	Sun->SetWorldRotation(FRotator(-Elev, Az, 0));
	const float Day01 = FMath::Clamp((Elev + 4.f) / 12.f, 0.f, 1.f);
	const float Cover = Overcast;
	Sun->SetIntensity(FMath::Lerp(0.f, 10.f, Day01) * FMath::Lerp(1.f, 0.25f, Cover));
	Sun->SetLightColor(FMath::Lerp(FLinearColor(1.f, 0.55f, 0.3f), FLinearColor(1.f, 0.96f, 0.9f), FMath::Clamp(Elev / 25.f, 0.f, 1.f)));
	Moon->SetWorldRotation(FRotator(-35.f, Az + 180.f, 0));
	Moon->SetIntensity((1.f - Day01) * 0.08f + Flash * 6.f);
	Moon->SetLightColor(Flash > 0.01f ? FLinearColor(0.8f, 0.85f, 1.f) : FLinearColor(0.55f, 0.65f, 1.f));
	SkyLight->SetIntensity(FMath::Lerp(1.f, 1.6f, Cover));
	Fog->SetFogDensity(FMath::Lerp(0.006f, 0.035f, Cover) + Rain * 0.03f);
	Fog->SetVolumetricFogExtinctionScale(1.f + Rain * 2.f);
	if (Ambient)
	{
		Ambient->Rain.store(Rain);
		Ambient->Wind.store(0.25f + Cover * 0.4f + (Weather == 3 ? 0.4f : 0.f));
		Ambient->Birds.store((1.f - Cover) * Day01 * (1.f - Rain));
	}
}

void ARWWorld::Tick(float Dt)
{
	Super::Tick(Dt);
	const double PerfT0 = FPlatformTime::Seconds();
	ON_SCOPE_EXIT { PerfTickSec += FPlatformTime::Seconds() - PerfT0; };
	Dt = FMath::Min(Dt, 0.1f);
	// plants taken by worked ground: redrawn a few times a second, not for every point a blade passes
	LowFlushT += Dt;
	if (LowPending.Num() && LowFlushT > 0.15f) { LowFlushT = 0.f; FlushLowPlants(); }
	// hand-placed trees and rocks in parts of the level that streamed in since the last look
	AdoptTimer += Dt;
	if (AdoptTimer > 3.f) { AdoptTimer = 0.f; AdoptPlaced(); }
	const float GameHours = Dt * ARWMachine::TimeScale * TimeMul / 3600.f;
	TimeOfDay += GameHours;
	if (TimeOfDay >= 24.f) { TimeOfDay -= 24.f; ++Day; }
	if (bAutoWeather)
	{
		NextWeatherChange -= GameHours;
		if (NextWeatherChange <= 0.f)
		{
			const float R = FMath::FRand();
			SetWeather(R < 0.45f ? 0 : R < 0.75f ? 1 : R < 0.93f ? 2 : 3);
		}
	}
	const float TargetCover = Weather == 0 ? 0.1f : Weather == 1 ? 0.6f : 0.9f;
	const float TargetRain = Weather == 2 ? 0.6f : Weather == 3 ? 1.f : 0.f;
	Overcast = FMath::FInterpConstantTo(Overcast, TargetCover, Dt, 0.03f);
	Rain = FMath::FInterpConstantTo(Rain, TargetRain * FMath::Clamp((Overcast - 0.5f) * 2.5f, 0.f, 1.f), Dt, 0.03f);
	// lightning & thunder
	Flash = FMath::Max(0.f, Flash - Dt * 6.f);
	if (Weather == 3)
	{
		LightningTimer -= Dt;
		if (LightningTimer <= 0.f) { Flash = 1.f; ThunderDelay = FMath::FRandRange(0.5f, 3.f); LightningTimer = FMath::FRandRange(6.f, 20.f); }
	}
	if (ThunderDelay > 0.f) { ThunderDelay -= Dt; if (ThunderDelay <= 0.f && Ambient) Ambient->ThunderCount.fetch_add(1); }
	UpdateSky(Dt);
	if (Fx) Fx->RainIntensity = Rain;
	// ground gets wet in rain and dries in sun & wind
	const float Sunny = FMath::Clamp(Sun->Intensity / 10.f, 0.f, 1.f);
	Terrain->UpdateMoisture(Dt, Rain * 0.015f * TimeMul, (0.0008f + 0.004f * Sunny) * (1.f - Rain) * TimeMul);
}
