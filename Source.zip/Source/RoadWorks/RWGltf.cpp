#include "RWGltf.h"
#include "RWMeshGen.h"
#include "RWTypes.h"
#include "Engine/StaticMesh.h"
#include "Engine/Texture2D.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/Base64.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Modules/ModuleManager.h"

UMaterialInterface* FRWGltfModel::TexturedMat = nullptr;
UMaterialInterface* FRWGltfModel::PlainMat = nullptr;
UMaterialInterface* FRWGltfModel::GlassMat = nullptr;
static TMap<FString, TSharedPtr<FRWGltfModel>> GModels;

// glTF is right-handed Y-up in metres; Unreal is left-handed Z-up in centimetres.
static FORCEINLINE FVector ConvP(double X, double Y, double Z) { return FVector(X, Z, Y); }

namespace
{
	struct FDoc
	{
		TSharedPtr<FJsonObject> J;
		TArray<TArray<uint8>> Buffers;
		FString Dir;
		const TArray<TSharedPtr<FJsonValue>>& Arr(const TCHAR* K) const
		{
			static const TArray<TSharedPtr<FJsonValue>> Empty;
			const TArray<TSharedPtr<FJsonValue>>* A;
			return J->TryGetArrayField(K, A) ? *A : Empty;
		}
		TSharedPtr<FJsonObject> Obj(const TCHAR* K, int32 i) const
		{
			const TArray<TSharedPtr<FJsonValue>>& A = Arr(K);
			return A.IsValidIndex(i) ? A[i]->AsObject() : nullptr;
		}
		// Returns pointer + stride for a buffer view slice.
		const uint8* View(int32 ViewIdx, int32 ExtraOffset, int32& OutStride, int32& OutLen) const
		{
			TSharedPtr<FJsonObject> V = Obj(TEXT("bufferViews"), ViewIdx);
			if (!V) return nullptr;
			const int32 B = V->GetIntegerField(TEXT("buffer"));
			int32 Off = 0; V->TryGetNumberField(TEXT("byteOffset"), Off);
			OutLen = V->GetIntegerField(TEXT("byteLength"));
			OutStride = 0; V->TryGetNumberField(TEXT("byteStride"), OutStride);
			if (!Buffers.IsValidIndex(B) || Off + ExtraOffset > Buffers[B].Num()) return nullptr;
			return Buffers[B].GetData() + Off + ExtraOffset;
		}
		// Reads an accessor as floats (Comp components per element).
		bool Read(int32 AccIdx, TArray<float>& Out, int32& Comp) const
		{
			TSharedPtr<FJsonObject> A = Obj(TEXT("accessors"), AccIdx);
			if (!A) return false;
			const FString Type = A->GetStringField(TEXT("type"));
			Comp = Type == TEXT("SCALAR") ? 1 : Type == TEXT("VEC2") ? 2 : Type == TEXT("VEC3") ? 3 : Type == TEXT("VEC4") ? 4 : 16;
			const int32 CT = A->GetIntegerField(TEXT("componentType"));
			const int32 Count = A->GetIntegerField(TEXT("count"));
			bool bNorm = false; A->TryGetBoolField(TEXT("normalized"), bNorm);
			int32 AOff = 0; A->TryGetNumberField(TEXT("byteOffset"), AOff);
			int32 ViewIdx = -1;
			Out.SetNumZeroed(Count * Comp);
			if (!A->TryGetNumberField(TEXT("bufferView"), ViewIdx)) return true; // all zeros (sparse not supported)
			int32 Stride, Len;
			const uint8* P = View(ViewIdx, AOff, Stride, Len);
			if (!P) return false;
			const int32 CSize = (CT == 5126 || CT == 5125) ? 4 : (CT == 5123 || CT == 5122) ? 2 : 1;
			if (Stride == 0) Stride = CSize * Comp;
			for (int32 e = 0; e < Count; ++e)
				for (int32 c = 0; c < Comp; ++c)
				{
					const uint8* Q = P + e * Stride + c * CSize;
					float V = 0;
					switch (CT)
					{
					case 5126: FMemory::Memcpy(&V, Q, 4); break;
					case 5125: { uint32 U; FMemory::Memcpy(&U, Q, 4); V = (float)U; break; }
					case 5123: { uint16 U; FMemory::Memcpy(&U, Q, 2); V = bNorm ? U / 65535.f : (float)U; break; }
					case 5122: { int16 S; FMemory::Memcpy(&S, Q, 2); V = bNorm ? FMath::Max(S / 32767.f, -1.f) : (float)S; break; }
					case 5121: V = bNorm ? *Q / 255.f : (float)*Q; break;
					case 5120: V = bNorm ? FMath::Max(*(const int8*)Q / 127.f, -1.f) : (float)*(const int8*)Q; break;
					}
					Out[e * Comp + c] = V;
				}
			return true;
		}
	};
}

static UTexture2D* DecodeImage(const TArray<uint8>& Bytes)
{
	IImageWrapperModule& IW = FModuleManager::LoadModuleChecked<IImageWrapperModule>(TEXT("ImageWrapper"));
	const EImageFormat Fmt = IW.DetectImageFormat(Bytes.GetData(), Bytes.Num());
	if (Fmt == EImageFormat::Invalid) return nullptr;
	TSharedPtr<IImageWrapper> W = IW.CreateImageWrapper(Fmt);
	TArray<uint8> Raw;
	if (!W.IsValid() || !W->SetCompressed(Bytes.GetData(), Bytes.Num()) || !W->GetRaw(ERGBFormat::BGRA, 8, Raw)) return nullptr;
	UTexture2D* T = UTexture2D::CreateTransient(W->GetWidth(), W->GetHeight(), PF_B8G8R8A8);
	if (!T) return nullptr;
	T->SRGB = true;
	void* Data = T->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
	FMemory::Memcpy(Data, Raw.GetData(), Raw.Num());
	T->GetPlatformData()->Mips[0].BulkData.Unlock();
	T->UpdateResource();
	T->AddToRoot();
	if (FRWMeshGen::bKeepGeometry) FRWMeshGen::KeptImages.Add(T, Bytes); // (-RWExportScenery writes it for the editor)
	return T;
}

static FTransform NodeLocal(const TSharedPtr<FJsonObject>& N, float Scale)
{
	FVector T = FVector::ZeroVector, S = FVector::OneVector;
	FQuat R = FQuat::Identity;
	const TArray<TSharedPtr<FJsonValue>>* M;
	if (N->TryGetArrayField(TEXT("matrix"), M) && M->Num() == 16)
	{
		// column-major 4x4 -> row-vector FMatrix (element i*4+j)
		FMatrix Mx;
		for (int32 i = 0; i < 4; ++i) for (int32 j = 0; j < 4; ++j) Mx.M[i][j] = (*M)[i * 4 + j]->AsNumber();
		const FTransform G(Mx);
		T = G.GetTranslation(); R = G.GetRotation(); S = G.GetScale3D();
	}
	else
	{
		const TArray<TSharedPtr<FJsonValue>>* A;
		if (N->TryGetArrayField(TEXT("translation"), A) && A->Num() == 3) T = FVector((*A)[0]->AsNumber(), (*A)[1]->AsNumber(), (*A)[2]->AsNumber());
		if (N->TryGetArrayField(TEXT("rotation"), A) && A->Num() == 4) R = FQuat((*A)[0]->AsNumber(), (*A)[1]->AsNumber(), (*A)[2]->AsNumber(), (*A)[3]->AsNumber());
		if (N->TryGetArrayField(TEXT("scale"), A) && A->Num() == 3) S = FVector((*A)[0]->AsNumber(), (*A)[1]->AsNumber(), (*A)[2]->AsNumber());
	}
	// change of basis (swap Y/Z = mirror): vectors (x,z,y), rotations (-x,-z,-y,w)
	return FTransform(FQuat(-R.X, -R.Z, -R.Y, R.W), ConvP(T.X, T.Y, T.Z) * 100.f * Scale, FVector(S.X, S.Z, S.Y));
}

bool FRWGltfModel::Load(const FString& InPath, float Scale, float YawOffsetDeg)
{
	Path = InPath;
	TArray<uint8> File;
	if (!FFileHelper::LoadFileToArray(File, *Path)) { Error = TEXT("file not found"); return false; }
	FDoc D; D.Dir = FPaths::GetPath(Path);
	FString JsonText;
	if (File.Num() >= 20 && File[0] == 'g' && File[1] == 'l' && File[2] == 'T' && File[3] == 'F')
	{
		int32 Off = 12;
		while (Off + 8 <= File.Num())
		{
			uint32 Len, Type; FMemory::Memcpy(&Len, &File[Off], 4); FMemory::Memcpy(&Type, &File[Off + 4], 4);
			if (Off + 8 + (int32)Len > File.Num()) break;
			if (Type == 0x4E4F534A) { FUTF8ToTCHAR Conv((const ANSICHAR*)&File[Off + 8], Len); JsonText = FString(Conv.Length(), Conv.Get()); }
			else if (Type == 0x004E4942) { TArray<uint8> B; B.Append(&File[Off + 8], Len); D.Buffers.Add(MoveTemp(B)); }
			Off += 8 + Len;
		}
	}
	else
	{
		FFileHelper::BufferToString(JsonText, File.GetData(), File.Num());
	}
	if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(JsonText), D.J) || !D.J.IsValid()) { Error = TEXT("not a valid glTF file"); return false; }
	// external / embedded buffers (.gltf)
	const TArray<TSharedPtr<FJsonValue>>& Bufs = D.Arr(TEXT("buffers"));
	for (int32 b = D.Buffers.Num(); b < Bufs.Num(); ++b)
	{
		FString Uri; Bufs[b]->AsObject()->TryGetStringField(TEXT("uri"), Uri);
		TArray<uint8> B;
		if (Uri.StartsWith(TEXT("data:"))) { FString Enc; Uri.Split(TEXT(","), nullptr, &Enc); FBase64::Decode(Enc, B); }
		else FFileHelper::LoadFileToArray(B, *(D.Dir / Uri));
		D.Buffers.Add(MoveTemp(B));
	}
	// textures
	TArray<UTexture2D*> Images;
	for (const TSharedPtr<FJsonValue>& V : D.Arr(TEXT("images")))
	{
		TSharedPtr<FJsonObject> I = V->AsObject();
		TArray<uint8> Bytes;
		int32 BV = -1; FString Uri;
		if (I->TryGetNumberField(TEXT("bufferView"), BV)) { int32 Stride, Len; if (const uint8* P = D.View(BV, 0, Stride, Len)) Bytes.Append(P, Len); }
		else if (I->TryGetStringField(TEXT("uri"), Uri))
		{
			if (Uri.StartsWith(TEXT("data:"))) { FString Enc; Uri.Split(TEXT(","), nullptr, &Enc); FBase64::Decode(Enc, Bytes); }
			else FFileHelper::LoadFileToArray(Bytes, *(D.Dir / Uri.Replace(TEXT("%20"), TEXT(" "))));
		}
		Images.Add(Bytes.Num() ? DecodeImage(Bytes) : nullptr);
	}
	// materials
	TArray<UMaterialInterface*> Mats;
	for (const TSharedPtr<FJsonValue>& V : D.Arr(TEXT("materials")))
	{
		TSharedPtr<FJsonObject> M = V->AsObject();
		FLinearColor Col = FLinearColor::White; float Metal = 0.f, Rough = 0.6f; UTexture2D* Tex = nullptr;
		const TSharedPtr<FJsonObject>* Pbr;
		if (M->TryGetObjectField(TEXT("pbrMetallicRoughness"), Pbr))
		{
			const TArray<TSharedPtr<FJsonValue>>* C;
			if ((*Pbr)->TryGetArrayField(TEXT("baseColorFactor"), C) && C->Num() == 4) Col = FLinearColor((*C)[0]->AsNumber(), (*C)[1]->AsNumber(), (*C)[2]->AsNumber(), (*C)[3]->AsNumber());
			double Mv = 1.0, Rv = 1.0; (*Pbr)->TryGetNumberField(TEXT("metallicFactor"), Mv); (*Pbr)->TryGetNumberField(TEXT("roughnessFactor"), Rv);
			Metal = Mv; Rough = Rv;
			const TSharedPtr<FJsonObject>* BT;
			if ((*Pbr)->TryGetObjectField(TEXT("baseColorTexture"), BT))
			{
				TSharedPtr<FJsonObject> TO = D.Obj(TEXT("textures"), (*BT)->GetIntegerField(TEXT("index")));
				int32 Src = -1; if (TO && TO->TryGetNumberField(TEXT("source"), Src) && Images.IsValidIndex(Src)) Tex = Images[Src];
			}
		}
		FString AlphaMode; M->TryGetStringField(TEXT("alphaMode"), AlphaMode);
		const bool bGlass = AlphaMode == TEXT("BLEND") || Col.A < 0.95f || M->GetStringField(TEXT("name")).Contains(TEXT("glass"));
		UMaterialInterface* Base = bGlass && GlassMat ? GlassMat : (Tex && TexturedMat ? TexturedMat : PlainMat);
		UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(Base ? Base : PlainMat, GetTransientPackage());
		MID->AddToRoot();
		if (!bGlass)
		{
			MID->SetVectorParameterValue(TEXT("Color"), FLinearColor(Col.R, Col.G, Col.B, 1.f));
			// worked machinery has no mirror-smooth surfaces, whatever a model file says
			MID->SetScalarParameterValue(TEXT("Metallic"), FMath::Min(Metal, 0.3f));
			MID->SetScalarParameterValue(TEXT("Roughness"), FMath::Clamp(Rough, 0.6f, 1.f));
			if (Tex) MID->SetTextureParameterValue(TEXT("BaseTex"), Tex);
		}
		Mats.Add(MID);
		if (!bGlass) MatByName.Add(M->GetStringField(TEXT("name")), MID);
	}
	// skins: which meshes a skeleton bends, its bones and their inverse bind matrices
	struct FSkinData { TArray<int32> Joints; TArray<float> Ibm; };
	struct FSkinPart { int32 JointNode = -1; FMeshBuild B; UMaterialInterface* Mat = nullptr; FBox Bounds = FBox(ForceInit); TArray<FVector3f> Points; TArray<int32> Tris; FString Key; };
	TArray<FSkinData> Skins;
	for (const TSharedPtr<FJsonValue>& V : D.Arr(TEXT("skins")))
	{
		FSkinData S;
		const TArray<TSharedPtr<FJsonValue>>* Js;
		if (V->AsObject()->TryGetArrayField(TEXT("joints"), Js)) for (const TSharedPtr<FJsonValue>& J : *Js) S.Joints.Add((int32)J->AsNumber());
		int32 IbmA = -1, Cm = 0;
		if (V->AsObject()->TryGetNumberField(TEXT("inverseBindMatrices"), IbmA)) D.Read(IbmA, S.Ibm, Cm);
		Skins.Add(MoveTemp(S));
	}
	TMap<int32, int32> SkinOfMesh; // mesh -> skin
	TArray<int32> SkinnedNodes;
	{
		const TArray<TSharedPtr<FJsonValue>>& JN0 = D.Arr(TEXT("nodes"));
		for (int32 n = 0; n < JN0.Num(); ++n)
		{
			int32 Sk = -1, Me = -1;
			if (JN0[n]->AsObject()->TryGetNumberField(TEXT("skin"), Sk) && JN0[n]->AsObject()->TryGetNumberField(TEXT("mesh"), Me) && Skins.IsValidIndex(Sk))
			{
				SkinOfMesh.Add(Me, Sk);
				SkinnedNodes.Add(n);
			}
		}
	}
	TArray<FSkinPart> SkinParts;
	// meshes (one runtime static mesh per primitive)
	const TArray<TSharedPtr<FJsonValue>>& Meshes = D.Arr(TEXT("meshes"));
	MeshPrims.SetNum(Meshes.Num()); MeshMats.SetNum(Meshes.Num()); MeshBounds.SetNum(Meshes.Num()); MeshPoints.SetNum(Meshes.Num()); MeshTris.SetNum(Meshes.Num()); MeshBuilds.SetNum(Meshes.Num());
	for (int32 m = 0; m < Meshes.Num(); ++m)
	{
		FBox Bounds(ForceInit);
		const TArray<TSharedPtr<FJsonValue>>* Prims;
		if (!Meshes[m]->AsObject()->TryGetArrayField(TEXT("primitives"), Prims)) continue;
		for (int32 p = 0; p < Prims->Num(); ++p)
		{
			TSharedPtr<FJsonObject> Pr = (*Prims)[p]->AsObject();
			int32 Mode = 4; Pr->TryGetNumberField(TEXT("mode"), Mode);
			if (Mode != 4) continue;
			const TSharedPtr<FJsonObject>* Attr;
			if (!Pr->TryGetObjectField(TEXT("attributes"), Attr)) continue;
			int32 PosA = -1, NrmA = -1, UvA = -1, IdxA = -1, MatI = -1;
			(*Attr)->TryGetNumberField(TEXT("POSITION"), PosA);
			(*Attr)->TryGetNumberField(TEXT("NORMAL"), NrmA);
			(*Attr)->TryGetNumberField(TEXT("TEXCOORD_0"), UvA);
			Pr->TryGetNumberField(TEXT("indices"), IdxA);
			Pr->TryGetNumberField(TEXT("material"), MatI);
			TArray<float> Pos, Nrm, Uv, Idx; int32 C1 = 0, C2 = 0, C3 = 0, C4 = 0;
			if (PosA < 0 || !D.Read(PosA, Pos, C1) || C1 != 3) continue;
			if (NrmA >= 0) D.Read(NrmA, Nrm, C2);
			if (UvA >= 0) D.Read(UvA, Uv, C3);
			const int32 NV = Pos.Num() / 3;
			if (IdxA >= 0) D.Read(IdxA, Idx, C4); else { Idx.SetNum(NV); for (int32 i = 0; i < NV; ++i) Idx[i] = i; }
			// A mesh bent by a skeleton (skinned): each triangle goes with the bone that moves it most, as its own rigid part under
			// that bone, so that the parts move with the bones like any other model part (boom, arm, blade...).
			if (const int32* SkinI = SkinOfMesh.Find(m))
			{
				int32 JA = -1, WA = -1, CJ = 0, CW = 0;
				(*Attr)->TryGetNumberField(TEXT("JOINTS_0"), JA);
				(*Attr)->TryGetNumberField(TEXT("WEIGHTS_0"), WA);
				TArray<float> Jt, Wt;
				const FSkinData& Sk = Skins[*SkinI];
				if (JA >= 0 && WA >= 0 && D.Read(JA, Jt, CJ) && D.Read(WA, Wt, CW) && CJ == 4 && CW == 4 && Jt.Num() == NV * 4)
				{
					TArray<int32> Dom; Dom.SetNumUninitialized(NV);
					for (int32 v = 0; v < NV; ++v)
					{
						int32 Best = 0;
						for (int32 k = 1; k < 4; ++k) if (Wt[v * 4 + k] > Wt[v * 4 + Best]) Best = k;
						Dom[v] = (int32)Jt[v * 4 + Best];
					}
					TMap<int32, TArray<int32>> TrisOf; // joint (index in the skin) -> triangle corner list
					for (int32 t = 0; t + 2 < Idx.Num(); t += 3)
					{
						const int32 a = (int32)Idx[t], b = (int32)Idx[t + 1], c = (int32)Idx[t + 2];
						if (a >= NV || b >= NV || c >= NV) continue;
						const int32 J = (Dom[b] == Dom[c]) ? Dom[b] : Dom[a];
						TArray<int32>& L = TrisOf.FindOrAdd(J);
						L.Add(a); L.Add(b); L.Add(c);
					}
					for (const TPair<int32, TArray<int32>>& G : TrisOf)
					{
						if (!Sk.Joints.IsValidIndex(G.Key)) continue;
						const float* Mx = Sk.Ibm.Num() >= (G.Key + 1) * 16 ? &Sk.Ibm[G.Key * 16] : nullptr;
						// bind-pose vertex in the bone's own space: inverse bind matrix (column-major) times the vertex
						auto Xf = [&](float X, float Y, float Z, float W) -> FVector
						{
							if (!Mx) return FVector(X, Y, Z);
							return FVector(Mx[0] * X + Mx[4] * Y + Mx[8] * Z + Mx[12] * W, Mx[1] * X + Mx[5] * Y + Mx[9] * Z + Mx[13] * W, Mx[2] * X + Mx[6] * Y + Mx[10] * Z + Mx[14] * W);
						};
						FSkinPart Part; Part.JointNode = Sk.Joints[G.Key]; Part.Mat = Mats.IsValidIndex(MatI) ? Mats[MatI] : PlainMat;
						TMap<int32, int32> Remap;
						for (const int32 v : G.Value)
						{
							int32* Have = Remap.Find(v);
							if (!Have)
							{
								const FVector Q = Xf(Pos[v * 3], Pos[v * 3 + 1], Pos[v * 3 + 2], 1.f);
								const FVector P = ConvP(Q.X, Q.Y, Q.Z) * Scale;
								FVector Nn = FVector::UpVector;
								if (Nrm.Num() == Pos.Num()) { const FVector Rn = Xf(Nrm[v * 3], Nrm[v * 3 + 1], Nrm[v * 3 + 2], 0.f); Nn = ConvP(Rn.X, Rn.Y, Rn.Z).GetSafeNormal(); }
								const FVector2D U = Uv.Num() >= (v + 1) * 2 ? FVector2D(Uv[v * 2], Uv[v * 2 + 1]) : FVector2D::ZeroVector;
								Have = &Remap.Add(v, Part.B.P.Num());
								Part.B.P.Add(FVector3f(P)); Part.B.N.Add(FVector3f(Nn)); Part.B.UV.Add(FVector2f(U));
								Part.Bounds += P * 100.f;
								Part.Points.Add(FVector3f(P * 100.f));
							}
							Part.B.T.Add(*Have);
						}
						Part.Tris = Part.B.T;
						Part.Key = FString::Printf(TEXT("gltf_%08x_%d_%d_%d_j%d"), GetTypeHash(Path), FMath::RoundToInt(Scale * 1000.f), m, p, G.Key);
						SkinParts.Add(MoveTemp(Part));
					}
					continue;
				}
			}
			FMeshBuild B;
			const int32 PointBase = MeshPoints[m].Num();
			for (int32 v = 0; v < NV; ++v)
			{
				const FVector P = ConvP(Pos[v * 3], Pos[v * 3 + 1], Pos[v * 3 + 2]) * Scale; // metres
				const FVector N = Nrm.Num() == Pos.Num() ? ConvP(Nrm[v * 3], Nrm[v * 3 + 1], Nrm[v * 3 + 2]) : FVector::UpVector;
				const FVector2D U = Uv.Num() >= (v + 1) * 2 ? FVector2D(Uv[v * 2], Uv[v * 2 + 1]) : FVector2D::ZeroVector;
				B.P.Add(FVector3f(P)); B.N.Add(FVector3f(N.GetSafeNormal())); B.UV.Add(FVector2f(U));
				Bounds += P * 100.f;
				MeshPoints[m].Add(FVector3f(P * 100.f));
			}
			// glTF's counter-clockwise front faces in a right-handed space stay front faces after the
			// Y/Z swap into Unreal's left-handed space (the mirror and the handedness flip cancel)
			for (int32 t = 0; t + 2 < Idx.Num(); t += 3)
			{
				const int32 a = (int32)Idx[t], b = (int32)Idx[t + 1], c = (int32)Idx[t + 2];
				if (a >= NV || b >= NV || c >= NV) continue;
				B.T.Add(a); B.T.Add(b); B.T.Add(c);
				MeshTris[m].Add(PointBase + a); MeshTris[m].Add(PointBase + b); MeshTris[m].Add(PointBase + c);
			}
			if (Nrm.Num() != Pos.Num())
			{
				// flat-ish normals from faces
				TArray<FVector3f> Acc; Acc.Init(FVector3f::ZeroVector, NV);
				for (int32 t = 0; t + 2 < B.T.Num(); t += 3)
				{
					const FVector3f Fn = FVector3f::CrossProduct(B.P[B.T[t + 2]] - B.P[B.T[t]], B.P[B.T[t + 1]] - B.P[B.T[t]]); // Unreal front-face normal
					Acc[B.T[t]] += Fn; Acc[B.T[t + 1]] += Fn; Acc[B.T[t + 2]] += Fn;
				}
				for (int32 v = 0; v < NV; ++v) B.N[v] = Acc[v].GetSafeNormal();
			}
			const FString Key = FString::Printf(TEXT("gltf_%08x_%d_%d_%d"), GetTypeHash(Path), FMath::RoundToInt(Scale * 1000.f), m, p);
			if (UStaticMesh* SM = FRWMeshGen::Build(Key, B))
			{
				MeshPrims[m].Add(SM);
				MeshMats[m].Add(Mats.IsValidIndex(MatI) ? Mats[MatI] : PlainMat);
				MeshBuilds[m].Add(MoveTemp(B));
			}
		}
		MeshBounds[m] = Bounds;
	}
	// lights placed in Blender (exported with "Punctual Lights")
	{
		const TSharedPtr<FJsonObject>* Ext;
		const TSharedPtr<FJsonObject>* KL;
		const TArray<TSharedPtr<FJsonValue>>* LA;
		if (D.J->TryGetObjectField(TEXT("extensions"), Ext) && (*Ext)->TryGetObjectField(TEXT("KHR_lights_punctual"), KL) && (*KL)->TryGetArrayField(TEXT("lights"), LA))
			for (const TSharedPtr<FJsonValue>& V : *LA)
			{
				FRWGltfLight Lt;
				const TSharedPtr<FJsonObject> O = V->AsObject();
				if (!O) { Lights.Add(Lt); continue; }
				O->TryGetStringField(TEXT("type"), Lt.Type);
				double Num = 0.0;
				if (O->TryGetNumberField(TEXT("intensity"), Num)) Lt.Intensity = (float)Num;
				if (O->TryGetNumberField(TEXT("range"), Num)) Lt.Range = (float)Num;
				const TArray<TSharedPtr<FJsonValue>>* C;
				if (O->TryGetArrayField(TEXT("color"), C) && C->Num() == 3) Lt.Color = FLinearColor((*C)[0]->AsNumber(), (*C)[1]->AsNumber(), (*C)[2]->AsNumber());
				const TSharedPtr<FJsonObject>* Sp;
				if (O->TryGetObjectField(TEXT("spot"), Sp))
				{
					if ((*Sp)->TryGetNumberField(TEXT("outerConeAngle"), Num)) Lt.OuterCone = (float)Num;
					if ((*Sp)->TryGetNumberField(TEXT("innerConeAngle"), Num)) Lt.InnerCone = (float)Num;
				}
				Lights.Add(Lt);
			}
	}
	// nodes
	const TArray<TSharedPtr<FJsonValue>>& JN = D.Arr(TEXT("nodes"));
	Nodes.SetNum(JN.Num());
	for (int32 n = 0; n < JN.Num(); ++n)
	{
		TSharedPtr<FJsonObject> N = JN[n]->AsObject();
		FRWGltfNode& Nd = Nodes[n];
		N->TryGetStringField(TEXT("name"), Nd.Name);
		if (Nd.Name.IsEmpty()) Nd.Name = FString::Printf(TEXT("node%d"), n);
		N->TryGetNumberField(TEXT("mesh"), Nd.Mesh);
		Nd.Local = NodeLocal(N, Scale);
		// a light placed in Blender, and the object's custom properties (the RoadWorks add-on writes rw_part, rw_lumens...)
		const TSharedPtr<FJsonObject>* Ext;
		const TSharedPtr<FJsonObject>* KL;
		if (N->TryGetObjectField(TEXT("extensions"), Ext) && (*Ext)->TryGetObjectField(TEXT("KHR_lights_punctual"), KL)) (*KL)->TryGetNumberField(TEXT("light"), Nd.Light);
		const TSharedPtr<FJsonObject>* Ex;
		if (N->TryGetObjectField(TEXT("extras"), Ex))
			for (const TPair<FString, TSharedPtr<FJsonValue>>& E : (*Ex)->Values)
			{
				FString S;
				if (E.Value.IsValid() && E.Value->TryGetString(S)) Nd.Extras.Add(E.Key, S);
				else if (E.Value.IsValid() && E.Value->Type == EJson::Number) Nd.Extras.Add(E.Key, FString::SanitizeFloat(E.Value->AsNumber()));
				else if (E.Value.IsValid() && E.Value->Type == EJson::Boolean) Nd.Extras.Add(E.Key, E.Value->AsBool() ? TEXT("1") : TEXT("0"));
			}
		const TArray<TSharedPtr<FJsonValue>>* Ch;
		if (N->TryGetArrayField(TEXT("children"), Ch)) for (const TSharedPtr<FJsonValue>& C : *Ch) Nd.Children.Add((int32)C->AsNumber());
	}
	for (int32 n = 0; n < Nodes.Num(); ++n) for (int32 c : Nodes[n].Children) if (Nodes.IsValidIndex(c)) Nodes[c].Parent = n;
	// the skinned parts: a mesh of their own each, hanging under their bone (named "<bone>#skin")
	for (const int32 n : SkinnedNodes) if (Nodes.IsValidIndex(n)) Nodes[n].Mesh = -1;
	for (FSkinPart& Pt : SkinParts)
	{
		if (!Nodes.IsValidIndex(Pt.JointNode) || Pt.B.T.Num() == 0) continue;
		UStaticMesh* SM = FRWMeshGen::Build(Pt.Key, Pt.B);
		if (!SM) continue;
		const int32 Mi = MeshPrims.Num();
		MeshPrims.AddDefaulted(); MeshMats.AddDefaulted(); MeshBounds.Add(Pt.Bounds); MeshPoints.Add(MoveTemp(Pt.Points)); MeshTris.Add(MoveTemp(Pt.Tris)); MeshBuilds.AddDefaulted();
		MeshPrims[Mi].Add(SM); MeshMats[Mi].Add(Pt.Mat); MeshBuilds[Mi].Add(MoveTemp(Pt.B));
		FRWGltfNode Nd; Nd.Name = Nodes[Pt.JointNode].Name + TEXT("#skin"); Nd.Parent = Pt.JointNode; Nd.Mesh = Mi; Nd.Local = FTransform::Identity;
		const int32 Ni = Nodes.Add(Nd);
		Nodes[Pt.JointNode].Children.Add(Ni);
	}
	const FTransform Yaw(FRotator(0, YawOffsetDeg, 0));
	TFunction<void(int32, const FTransform&)> Walk = [&](int32 n, const FTransform& PW)
	{
		Nodes[n].World = Nodes[n].Local * PW;
		for (int32 c : Nodes[n].Children) if (Nodes.IsValidIndex(c)) Walk(c, Nodes[n].World);
	};
	for (int32 r : Roots()) Walk(r, Yaw);
	RWLog(FString::Printf(TEXT("Model loaded: %s (%d nodes, %d meshes, %d textures)"), *FPaths::GetCleanFilename(Path), Nodes.Num(), Meshes.Num(), Images.Num()));
	return true;
}

TArray<FRWGltfModel::FLampPoint> FRWGltfModel::LampPoints() const
{
	TArray<FLampPoint> Out;
	for (int32 n = 0; n < Nodes.Num(); ++n)
	{
		const FRWGltfNode& Nd = Nodes[n];
		const bool bNamed = Nd.Name.StartsWith(TEXT("lamp"), ESearchCase::IgnoreCase) || Nd.Name.StartsWith(TEXT("RW_Lamp"), ESearchCase::IgnoreCase) || Nd.Extras.Contains(TEXT("rw_lamp"));
		const bool bLight = Lights.IsValidIndex(Nd.Light) && Lights[Nd.Light].Type != TEXT("directional");
		// (a lamp's own glass or housing named "lamp..." is a mesh, not the light itself)
		if (!bLight && (!bNamed || Nd.Mesh >= 0)) continue;
		// (Blender may write a light as an object node with the light itself on a child turned to glTF's axes: one lamp)
		bool bChildLight = false;
		for (int32 c : Nd.Children) bChildLight |= Nodes.IsValidIndex(c) && Lights.IsValidIndex(Nodes[c].Light);
		if (!bLight && bChildLight) continue;
		const TMap<FString, FString>& Ex = Nd.Extras.Num() == 0 && Nodes.IsValidIndex(Nd.Parent) ? Nodes[Nd.Parent].Extras : Nd.Extras;
		FLampPoint L;
		L.Node = n;
		L.Pos = Nd.World.GetLocation();
		// glTF lights shine down their local -Z: that axis in Unreal's swapped basis is -Y
		L.Dir = Nd.World.TransformVectorNoScale(FVector(0.f, -1.f, 0.f)).GetSafeNormal();
		if (bLight)
		{
			const FRWGltfLight& Lt = Lights[Nd.Light];
			L.Color = Lt.Color;
			// the file's candela as lumens over half a sphere, kept within a working lamp's range (the add-on's rw_lumens is exact)
			if (Lt.Intensity > 0.f) L.Lumens = FMath::Clamp(Lt.Intensity * 4.f * PI * 0.5f, 800.f, 60000.f);
			if (Lt.Type == TEXT("spot")) L.OuterDeg = FMath::Clamp(FMath::RadiansToDegrees(Lt.OuterCone), 5.f, 80.f);
			else L.OuterDeg = 80.f;
			if (Lt.Range > 0.f) L.RangeM = FMath::Clamp(Lt.Range, 5.f, 200.f);
		}
		// the add-on's own settings win
		if (const FString* V = Ex.Find(TEXT("rw_lumens"))) L.Lumens = FMath::Clamp(FCString::Atof(**V), 100.f, 100000.f);
		if (const FString* V = Ex.Find(TEXT("rw_cone"))) L.OuterDeg = FMath::Clamp(FCString::Atof(**V), 5.f, 80.f);
		if (const FString* V = Ex.Find(TEXT("rw_range"))) L.RangeM = FMath::Clamp(FCString::Atof(**V), 5.f, 200.f);
		if (const FString* V = Ex.Find(TEXT("rw_work"))) L.bWork = *V == TEXT("1") || V->ToLower() == TEXT("true");
		// which moving part it is on ("rw_lamp_on" from the add-on; "rw_part" also understood)
		if (const FString* V = Ex.Find(TEXT("rw_lamp_on"))) L.Part = *V;
		else if (const FString* V2 = Ex.Find(TEXT("rw_part"))) L.Part = *V2;
		Out.Add(L);
	}
	return Out;
}

void FRWGltfModel::ApplyMaterialOverrides(const FJsonObject& Section)
{
	// (a name ending in * stands for every material whose name starts that way)
	static UTexture2D* White = LoadObject<UTexture2D>(nullptr, TEXT("/Engine/EngineResources/WhiteSquareTexture.WhiteSquareTexture"));
	for (const TPair<FString, TSharedPtr<FJsonValue>>& E : Section.Values)
	{
		const TSharedPtr<FJsonObject> O = E.Value.IsValid() ? E.Value->AsObject() : nullptr;
		TArray<UMaterialInstanceDynamic*> Hit;
		if (E.Key.EndsWith(TEXT("*"))) { const FString Pre = E.Key.LeftChop(1); for (const TPair<FString, UMaterialInstanceDynamic*>& Mm : MatByName) if (Mm.Key.StartsWith(Pre, ESearchCase::IgnoreCase)) Hit.Add(Mm.Value); }
		else if (UMaterialInstanceDynamic** Found = MatByName.Find(E.Key)) Hit.Add(*Found);
		if (Hit.Num() == 0 || !O.IsValid())
		{
			RWLog(FString::Printf(TEXT("Model materials: \"%s\" is not a material of %s"), *E.Key, *FPaths::GetCleanFilename(Path)));
			continue;
		}
		for (UMaterialInstanceDynamic* Mi : Hit)
		{
			const TArray<TSharedPtr<FJsonValue>>* C;
			if (O->TryGetArrayField(TEXT("color"), C) && C->Num() >= 3) Mi->SetVectorParameterValue(TEXT("Color"), FLinearColor((*C)[0]->AsNumber(), (*C)[1]->AsNumber(), (*C)[2]->AsNumber(), 1.f));
			double V;
			if (O->TryGetNumberField(TEXT("metallic"), V)) Mi->SetScalarParameterValue(TEXT("Metallic"), (float)V);
			if (O->TryGetNumberField(TEXT("roughness"), V)) Mi->SetScalarParameterValue(TEXT("Roughness"), (float)V);
			// a file whose "colour" pictures are really other maps (specular, masks): drop the picture, keep the colour
			bool bTex = true;
			if (O->TryGetBoolField(TEXT("texture"), bTex) && !bTex && White) Mi->SetTextureParameterValue(TEXT("BaseTex"), White);
		}
	}
}

TArray<int32> FRWGltfModel::Roots() const
{
	TArray<int32> R;
	for (int32 n = 0; n < Nodes.Num(); ++n) if (Nodes[n].Parent < 0) R.Add(n);
	return R;
}

int32 FRWGltfModel::Find(const FString& Name) const
{
	for (int32 n = 0; n < Nodes.Num(); ++n) if (Nodes[n].Name.Equals(Name, ESearchCase::IgnoreCase)) return n;
	return INDEX_NONE;
}

FBox FRWGltfModel::SubtreeBounds(int32 Node, const TSet<int32>& Exclude) const
{
	FBox B(ForceInit);
	if (!Nodes.IsValidIndex(Node)) return B;
	const FTransform Inv = Nodes[Node].World.Inverse();
	TFunction<void(int32)> Rec = [&](int32 n)
	{
		const FRWGltfNode& Nd = Nodes[n];
		if (MeshBounds.IsValidIndex(Nd.Mesh) && MeshBounds[Nd.Mesh].IsValid) B += MeshBounds[Nd.Mesh].TransformBy(Nd.World * Inv);
		for (int32 c : Nd.Children) if (Nodes.IsValidIndex(c) && !Exclude.Contains(c)) Rec(c);
	};
	Rec(Node);
	return B;
}

void FRWGltfModel::Spawn(AActor* Owner, USceneComponent* Parent, int32 Node, const FTransform& ParentWorldRest, const TSet<int32>& Exclude, TArray<UStaticMeshComponent*>* Out) const
{
	if (!Nodes.IsValidIndex(Node) || !Owner || !Parent) return;
	const FTransform InvP = ParentWorldRest.Inverse();
	// many parts moving together (a body, a blade...): one mesh per material, so the renderer draws a few objects instead of hundreds
	{
		struct FItem { int32 M; int32 P; FTransform Rel; };
		TArray<FItem> Items;
		TFunction<void(int32)> Gather = [&](int32 n)
		{
			const FRWGltfNode& Nd = Nodes[n];
			if (MeshPrims.IsValidIndex(Nd.Mesh)) for (int32 p = 0; p < MeshPrims[Nd.Mesh].Num(); ++p) Items.Add({Nd.Mesh, p, Nd.World * InvP});
			for (int32 c : Nd.Children) if (Nodes.IsValidIndex(c) && !Exclude.Contains(c)) Gather(c);
		};
		Gather(Node);
		bool bCanMerge = Items.Num() > 6;
		for (const FItem& It : Items) if (!MeshBuilds.IsValidIndex(It.M) || !MeshBuilds[It.M].IsValidIndex(It.P)) bCanMerge = false;
		if (bCanMerge)
		{
			TMap<UMaterialInterface*, FMeshBuild> Groups;
			for (const FItem& It : Items)
			{
				FTransform Xm = It.Rel; Xm.SetTranslation(Xm.GetTranslation() * 0.01f); // the parts are in metres
				Groups.FindOrAdd(MeshMats[It.M][It.P]).Append(MeshBuilds[It.M][It.P], Xm);
			}
			int32 Gi = 0;
			for (TPair<UMaterialInterface*, FMeshBuild>& G : Groups)
			{
				const FVector Tl = ParentWorldRest.GetTranslation();
				const FString Key = FString::Printf(TEXT("merge_%08x_%d_%d_%d_%d_%d_%d"), GetTypeHash(Path), Node, Exclude.Num(), Gi++, FMath::RoundToInt(Tl.X), FMath::RoundToInt(Tl.Y), FMath::RoundToInt(Tl.Z));
				UStaticMesh* SM = FRWMeshGen::Find(Key);
				if (!SM) SM = FRWMeshGen::Build(Key, G.Value);
				if (!SM) continue;
				UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(Owner);
				C->SetStaticMesh(SM);
				C->SetMaterial(0, G.Key);
				C->SetupAttachment(Parent);
				C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				C->RegisterComponent();
				if (Out) Out->Add(C);
			}
			return;
		}
	}
	TFunction<void(int32)> Rec = [&](int32 n)
	{
		const FRWGltfNode& Nd = Nodes[n];
		if (MeshPrims.IsValidIndex(Nd.Mesh))
		{
			const FTransform Rel = Nd.World * InvP;
			for (int32 p = 0; p < MeshPrims[Nd.Mesh].Num(); ++p)
			{
				UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(Owner);
				C->SetStaticMesh(MeshPrims[Nd.Mesh][p]);
				C->SetMaterial(0, MeshMats[Nd.Mesh][p]);
				C->SetupAttachment(Parent);
				C->SetRelativeTransform(Rel);
				C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				C->RegisterComponent();
				if (Out) Out->Add(C);
			}
		}
		for (int32 c : Nd.Children) if (Nodes.IsValidIndex(c) && !Exclude.Contains(c)) Rec(c);
	};
	Rec(Node);
}

void FRWGltfModel::SpawnAll(AActor* Owner, USceneComponent* Parent, TArray<UStaticMeshComponent*>* Out) const
{
	for (int32 r : Roots()) Spawn(Owner, Parent, r, FTransform::Identity, TSet<int32>(), Out);
}

TSharedPtr<FRWGltfModel> FRWGltfModel::Get(const FString& P, float Scale, float Yaw)
{
	const FString Key = FString::Printf(TEXT("%s|%.3f|%.1f"), *P, Scale, Yaw);
	if (TSharedPtr<FRWGltfModel>* F = GModels.Find(Key)) return *F;
	TSharedPtr<FRWGltfModel> M = MakeShared<FRWGltfModel>();
	if (!M->Load(P, Scale, Yaw)) { RWLog(FString::Printf(TEXT("Model %s could not be loaded: %s"), *P, *M->Error)); M.Reset(); }
	GModels.Add(Key, M);
	return M;
}
