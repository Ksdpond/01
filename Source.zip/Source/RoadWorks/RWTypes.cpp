﻿#include "RWTypes.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"

DEFINE_LOG_CATEGORY(LogRW);

// Linear-space albedo colours. Values tuned to look like real ground under physical sky lighting.
static const FSoilProps GSoil[SOIL_COUNT] = {
	//Name             Dens  Swell Hard  Fric  WetF  Rep  WRep Bear  Abs   Drain RollR  Color                                   WetColor                               Dig   Comp
	{TEXT("Dry soil"),   1.60f, 0.25f, 0.30f, 0.75f, 0.55f, 35, 28, 180, 0.80f, 0.60f, 0.06f, FLinearColor(0.135f,0.088f,0.052f), FLinearColor(0.070f,0.046f,0.028f), true,  true},
	{TEXT("Wet soil"),   1.85f, 0.22f, 0.25f, 0.60f, 0.60f, 30, 24, 120, 0.80f, 0.50f, 0.09f, FLinearColor(0.110f,0.075f,0.045f), FLinearColor(0.065f,0.042f,0.026f), true,  true},
	{TEXT("Mud"),        1.90f, 0.10f, 0.10f, 0.35f, 0.70f, 14,  9,  45, 0.90f, 0.20f, 0.20f, FLinearColor(0.075f,0.055f,0.035f), FLinearColor(0.045f,0.034f,0.022f), true,  false},
	{TEXT("Sand"),       1.70f, 0.12f, 0.15f, 0.55f, 1.15f, 33, 42, 150, 1.00f, 1.00f, 0.12f, FLinearColor(0.300f,0.235f,0.150f), FLinearColor(0.170f,0.130f,0.080f), true,  true},
	{TEXT("Gravel"),     1.90f, 0.15f, 0.40f, 0.70f, 0.90f, 38, 36, 400, 0.50f, 1.20f, 0.04f, FLinearColor(0.240f,0.225f,0.205f), FLinearColor(0.130f,0.120f,0.110f), true,  true},
	{TEXT("Small rock"), 2.00f, 0.35f, 0.65f, 0.70f, 0.90f, 40, 38, 600, 0.20f, 1.50f, 0.05f, FLinearColor(0.200f,0.190f,0.180f), FLinearColor(0.110f,0.105f,0.100f), true,  true},
	{TEXT("Large rock"), 2.60f, 0.55f, 0.97f, 0.65f, 0.85f, 70, 70,2000, 0.05f, 2.00f, 0.03f, FLinearColor(0.160f,0.155f,0.150f), FLinearColor(0.085f,0.082f,0.080f), false, false},
	{TEXT("Clay"),       1.75f, 0.30f, 0.55f, 0.70f, 0.40f, 45, 18, 220, 0.30f, 0.30f, 0.07f, FLinearColor(0.260f,0.130f,0.075f), FLinearColor(0.150f,0.070f,0.040f), true,  true},
	{TEXT("Laterite"),   1.95f, 0.25f, 0.45f, 0.75f, 0.60f, 40, 30, 300, 0.50f, 0.70f, 0.05f, FLinearColor(0.380f,0.140f,0.060f), FLinearColor(0.200f,0.070f,0.032f), true,  true},
	{TEXT("Compacted"),  1.95f, 0.30f, 0.60f, 0.80f, 0.65f, 60, 45, 500, 0.30f, 0.80f, 0.03f, FLinearColor(0.200f,0.150f,0.100f), FLinearColor(0.110f,0.080f,0.055f), true,  true},
	{TEXT("Asphalt"),    2.30f, 0.20f, 0.70f, 0.85f, 0.75f, 50, 50, 900, 0.05f, 2.00f, 0.015f,FLinearColor(0.045f,0.045f,0.048f), FLinearColor(0.022f,0.022f,0.024f), true,  true},
};

const FSoilProps& SoilProps(ESoil M)
{
	return GSoil[FMath::Clamp((int32)M, 0, SOIL_COUNT - 1)];
}

FString SoilName(ESoil M, float Moisture)
{
	if (M == ESoil::DrySoil)
	{
		if (Moisture > 0.72f) return TEXT("Mud");
		if (Moisture > 0.38f) return TEXT("Wet soil");
	}
	if (M == ESoil::Clay && Moisture > 0.6f) return TEXT("Wet clay");
	if (M == ESoil::Sand && Moisture > 0.5f) return TEXT("Wet sand");
	return SoilProps(M).Name;
}

FSoilState EvalSoil(ESoil M, float Moist, float Comp)
{
	const FSoilProps& P = SoilProps(M);
	FSoilState S;
	Moist = FMath::Clamp(Moist, 0.f, 1.f);
	Comp = FMath::Clamp(Comp, 0.f, 1.f);
	// Friction: wet clay & soil become slippery; sand gets firmer when damp then loses grip when saturated.
	float WetF = FMath::Lerp(1.f, P.WetFriction, Moist);
	if (M == ESoil::Sand) WetF = Moist < 0.5f ? FMath::Lerp(1.f, P.WetFriction, Moist * 2.f) : FMath::Lerp(P.WetFriction, 0.8f, (Moist - 0.5f) * 2.f);
	S.Friction = P.Friction * WetF * FMath::Lerp(0.95f, 1.05f, Comp);
	// Bearing capacity rises strongly with compaction, drops with water.
	const float WetBear = (M == ESoil::Clay || M == ESoil::DrySoil || M == ESoil::WetSoil || M == ESoil::Mud) ? FMath::Lerp(1.f, 0.30f, Moist) : FMath::Lerp(1.f, 0.75f, Moist);
	S.Bearing = P.Bearing * WetBear * FMath::Lerp(0.55f, 2.2f, Comp);
	S.Hardness = FMath::Clamp(P.Hardness * FMath::Lerp(0.75f, 1.35f, Comp) * (M == ESoil::Clay ? FMath::Lerp(1.f, 0.6f, Moist) : 1.f), 0.f, 1.f);
	// Repose: cohesion of compacted / natural ground lets cut faces stand steeper.
	S.Repose = FMath::Lerp((float)P.Repose, (float)P.WetRepose, Moist) + Comp * (M == ESoil::Sand ? 8.f : 25.f);
	S.Repose = FMath::Min(S.Repose, 80.f);
	S.RollRes = P.RollRes * FMath::Lerp(1.4f, 0.7f, Comp) * FMath::Lerp(1.f, 1.8f, Moist);
	return S;
}

float FPayload::MassKg() const
{
	float Kg = 0;
	for (int32 i = 0; i < SOIL_COUNT; ++i)
	{
		const FSoilProps& P = SoilProps((ESoil)i);
		Kg += Vol[i] * (P.Density * 1000.f / (1.f + P.Swell));
	}
	return Kg * (1.f + Moist * 0.12f);
}

ESoil FPayload::Dominant() const
{
	int32 Best = 0;
	for (int32 i = 1; i < SOIL_COUNT; ++i) if (Vol[i] > Vol[Best]) Best = i;
	return (ESoil)Best;
}

void FPayload::Add(ESoil M, float V, float Moisture)
{
	if (V <= 0) return;
	const float T = Total();
	if (Moisture >= 0.f) Moist = (Moist * T + Moisture * V) / FMath::Max(T + V, 1e-6f);
	Vol[(int32)M] += V;
}

void FPayload::AddPayload(const FPayload& O)
{
	const float T = Total(), OT = O.Total();
	if (OT <= 0) return;
	Moist = (Moist * T + O.Moist * OT) / FMath::Max(T + OT, 1e-6f);
	for (int32 i = 0; i < SOIL_COUNT; ++i) Vol[i] += O.Vol[i];
}

FPayload FPayload::Take(float V)
{
	FPayload Out;
	const float T = Total();
	if (T <= 1e-7f || V <= 0) return Out;
	const float F = FMath::Min(1.f, V / T);
	for (int32 i = 0; i < SOIL_COUNT; ++i)
	{
		Out.Vol[i] = Vol[i] * F;
		Vol[i] -= Out.Vol[i];
	}
	Out.Moist = Moist;
	return Out;
}

static void AppendLine(const FString& File, const FString& Msg)
{
	const FString Path = FPaths::ProjectSavedDir() / TEXT("Logs") / File;
	const FString Line = FString::Printf(TEXT("[%s] %s\n"), *FDateTime::Now().ToString(TEXT("%Y-%m-%d %H:%M:%S")), *Msg);
	FFileHelper::SaveStringToFile(Line, *Path, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_Append);
}

// ---- the problems of this run, on their own (Saved/Logs/RoadWorks_Problems.log): what went wrong, without the thousands of
// ordinary lines around it. Started afresh each time the game starts; the game's own error lines and the engine's errors and
// warnings (except a few harmless ones) go into it.
static FCriticalSection GProblemLock;
static int32 GProblems = 0;

int32 RWProblemCount() { return GProblems; }
FString RWProblemFile() { return FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir() / TEXT("Logs") / TEXT("RoadWorks_Problems.log")); }

void RWProblem(const FString& Where, const FString& Msg)
{
	FScopeLock Lock(&GProblemLock);
	++GProblems;
	AppendLine(TEXT("RoadWorks_Problems.log"), FString::Printf(TEXT("%s: %s"), *Where, *Msg));
}

static void RWProblemsStart()
{
	FScopeLock Lock(&GProblemLock);
	GProblems = 0;
	const FString Head = FString::Printf(TEXT("RoadWorks - problems found in this run (started %s)\n")
		TEXT("Each line: when, where it came from, what went wrong. The whole story is in RoadWorks_Game.log and RoadWorks.log.\n\n"),
		*FDateTime::Now().ToString(TEXT("%Y-%m-%d %H:%M:%S")));
	FFileHelper::SaveStringToFile(Head, *RWProblemFile(), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

// the game's own lines that say something went wrong
static bool IsProblemLine(const FString& M)
{
	static const TCHAR* Words[] = {TEXT("ERROR"), TEXT("not found"), TEXT("could not"), TEXT("failed"), TEXT("FAILED"), TEXT("missing"), TEXT("are required"),
		TEXT("is not a material"), TEXT("not compatible"), TEXT("damaged"), TEXT("timed out"), TEXT("unknown base")};
	for (const TCHAR* W : Words) if (M.Contains(W, ESearchCase::CaseSensitive)) return true;
	return false;
}

// the engine's errors and warnings, as they are written
class FRWProblemDevice : public FOutputDevice
{
public:
	virtual void Serialize(const TCHAR* V, ELogVerbosity::Type Verbosity, const FName& Category) override
	{
		const ELogVerbosity::Type Lv = (ELogVerbosity::Type)(Verbosity & ELogVerbosity::VerbosityMask);
		if (Lv > ELogVerbosity::Warning || Category == TEXT("LogRW")) return;
		const FString S(V);
		// (harmless: the scalability settings giving way to the project's own, and the optional profiler DLLs)
		if (S.Contains(TEXT("was ignored as it is lower priority")) || S.Contains(TEXT("blocking wait for shader preload")) || S.Contains(TEXT("Failed to load '"))) return;
		RWProblem(FString::Printf(TEXT("engine %s %s"), *Category.ToString(), Lv <= ELogVerbosity::Error ? TEXT("error") : TEXT("warning")), S);
	}
	virtual bool CanBeUsedOnAnyThread() const override { return true; }
};

void RWProblemsBegin()
{
	RWProblemsStart();
	static FRWProblemDevice* Device = nullptr;
	if (!Device && GLog) { Device = new FRWProblemDevice(); GLog->AddOutputDevice(Device); }
}

void RWLog(const FString& Msg)
{
	UE_LOG(LogRW, Log, TEXT("%s"), *Msg);
	AppendLine(TEXT("RoadWorks_Game.log"), Msg);
	if (IsProblemLine(Msg)) RWProblem(TEXT("game"), Msg);
}

void RWTestLog(const FString& Msg)
{
	UE_LOG(LogRW, Display, TEXT("[TEST] %s"), *Msg);
	AppendLine(TEXT("RoadWorks_Tests.log"), Msg);
}

static FORCEINLINE uint32 Hash2(int32 X, int32 Y, int32 S)
{
	uint32 H = (uint32)X * 374761393u + (uint32)Y * 668265263u + (uint32)S * 2246822519u;
	H = (H ^ (H >> 13)) * 1274126177u;
	return H ^ (H >> 16);
}

float RWNoise2(float X, float Y, int32 Seed)
{
	const int32 X0 = FMath::FloorToInt(X), Y0 = FMath::FloorToInt(Y);
	const float FX = X - X0, FY = Y - Y0;
	const float SX = FX * FX * (3 - 2 * FX), SY = FY * FY * (3 - 2 * FY);
	auto V = [&](int32 IX, int32 IY) { return (Hash2(IX, IY, Seed) & 0xFFFFFF) / float(0xFFFFFF) * 2.f - 1.f; };
	const float A = FMath::Lerp(V(X0, Y0), V(X0 + 1, Y0), SX);
	const float B = FMath::Lerp(V(X0, Y0 + 1), V(X0 + 1, Y0 + 1), SX);
	return FMath::Lerp(A, B, SY);
}

float RWFbm(float X, float Y, int32 Octaves, int32 Seed)
{
	float Sum = 0, Amp = 1, Norm = 0;
	for (int32 i = 0; i < Octaves; ++i)
	{
		Sum += RWNoise2(X, Y, Seed + i * 101) * Amp;
		Norm += Amp;
		Amp *= 0.5f;
		X = X * 2.03f + 17.1f;
		Y = Y * 2.03f - 9.7f;
	}
	return Sum / Norm;
}
