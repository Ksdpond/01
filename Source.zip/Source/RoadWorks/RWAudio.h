// Procedural audio: diesel engine, turbo, hydraulics, tracks, ground contact and weather.
// Synthesised in real time so every sound follows the simulation state (RPM, load, flow...).
#pragma once

#include "CoreMinimal.h"
#include "Components/SynthComponent.h"
#include <atomic>
#include "RWAudio.generated.h"

// A recorded sound, decoded to mono (-1..1) at its own sample rate.
struct FRWClip
{
	TArray<float> S;
	float Rate = 0.f;
	FString File;
	bool IsValid() const { return S.Num() > 1 && Rate > 0.f; }
	float Seconds() const { return Rate > 0.f ? S.Num() / Rate : 0.f; }
	// the sample at a (fractional) position, between two recorded ones
	float At(double Pos) const { const int32 i = (int32)Pos; const float F = (float)(Pos - i); return i + 1 < S.Num() ? S[i] + (S[i + 1] - S[i]) * F : (i < S.Num() ? S[i] : 0.f); }
};

// The game's sound files: the folder "souds" next to the game (or next to the project's Mods folder given with -RWMods),
// Ogg Vorbis or WAV. By name: "chenille" / "track" = the tracks running (a loop), "start" = the engine starting,
// "stop" = the engine stopping. Read once, before the first machine makes a sound; the audio threads only read them.
struct ROADWORKS_API FRWSoundFiles
{
	static FRWClip Track;
	static FRWClip Start;
	static FRWClip Stop;
	static FString Folder;
	static bool bLoaded;
	static void Load();
	static bool Decode(const FString& Path, FRWClip& Out);
};

UCLASS(ClassGroup = Synth)
class ROADWORKS_API URWEngineSynth : public USynthComponent
{
	GENERATED_BODY()
public:
	URWEngineSynth(const FObjectInitializer& OI);

	// Parameters written by the game thread.
	std::atomic<float> Rpm{0.f};       // 0 = engine off
	std::atomic<float> Load{0.f};      // 0..1 engine load
	std::atomic<float> Hyd{0.f};       // hydraulic flow*pressure 0..1 (>1 relief valve)
	std::atomic<float> TrackSpeed{0.f};// m/s (tracked machines)
	std::atomic<float> Gravel{0.f};    // tyre/ground crunch 0..1
	std::atomic<float> Scrape{0.f};    // bucket/blade scraping 0..1
	std::atomic<float> Rock{0.f};      // rock clatter 0..1
	std::atomic<float> Pour{0.f};      // material sliding out 0..1
	std::atomic<float> Hammer{0.f};    // breaker hammer 0..1
	std::atomic<float> Master{1.f};
	// counted up by the game when the engine is started (the key turned) / switched off: the recorded start / stop plays once
	std::atomic<int32> StartCount{0};
	std::atomic<int32> StopCount{0};
	int32 Cylinders = 6;
	float Pitch = 1.f;                 // per machine character

protected:
	virtual bool Init(int32& SampleRate) override;
	virtual int32 OnGenerateAudio(float* OutAudio, int32 NumSamples) override;

private:
	float SR = 48000.f;
	// the recorded sounds: where each one is playing (-1: not playing), how loud the tracks are now
	int32 SeenStart = 0, SeenStop = 0;
	double StartPos = -1.0, StopPos = -1.0, TrackPos = 0.0;
	float TrackGain = 0.f, Duck = 0.f;
	double Phase = 0, PumpPhase = 0, TurboPhase = 0, TrackPhase = 0, HammerPhase = 0;
	float Boost = 0, LP1 = 0, LP2 = 0, LP3 = 0, LP4 = 0, HP1 = 0, HPPrev = 0, Ping = 0, PingPhase = 0, RockEnv = 0, SmRpm = 0, SmLoad = 0;
	uint32 Rng = 12345;
	float Rand() { Rng = Rng * 1664525u + 1013904223u; return (Rng >> 8) / float(1 << 24) * 2.f - 1.f; }
};

UCLASS(ClassGroup = Synth)
class ROADWORKS_API URWAmbientSynth : public USynthComponent
{
	GENERATED_BODY()
public:
	URWAmbientSynth(const FObjectInitializer& OI);
	std::atomic<float> Rain{0.f};
	std::atomic<float> Wind{0.3f};
	std::atomic<float> Birds{0.5f};
	std::atomic<int32> ThunderCount{0};
	std::atomic<float> Water{0.f};

protected:
	virtual bool Init(int32& SampleRate) override;
	virtual int32 OnGenerateAudio(float* OutAudio, int32 NumSamples) override;

private:
	float SR = 48000.f;
	float LP1 = 0, LP2 = 0, LP3 = 0, HPPrev = 0, HP = 0, WindMod = 0, Thunder = 0, ThunderLP = 0, ThunderLP2 = 0;
	int32 SeenThunder = 0;
	float BirdT = 0, BirdEnv = 0, BirdF = 3000, BirdPh = 0, BirdNext = 1.f;
	uint32 Rng = 777;
	float Rand() { Rng = Rng * 1664525u + 1013904223u; return (Rng >> 8) / float(1 << 24) * 2.f - 1.f; }
};
