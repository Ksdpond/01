// Textured look of loose soil (buckets, truck beds, hoppers, heaps, flying clods): picks the soil
// PBR texture set (Content/Textures/Soil, imported by Tools/make_soil.py) that matches the load.
#pragma once

#include "CoreMinimal.h"
#include "RWTypes.h"

class UMaterialInterface;
class UMaterialInstanceDynamic;
class UTexture2D;

class ROADWORKS_API FRWSoilLook
{
public:
	static UMaterialInterface* LooseMat; // M_SoilLoose (null -> plain painted fallback)
	static void Init();
	// a material instance for loose soil; falls back to the plain paint material if the textures are missing
	static UMaterialInstanceDynamic* Make(UObject* Outer, ESoil M, float Moist);
	// switch an instance made by Make() to another soil / wetness (cheap when nothing changed)
	static void Apply(UMaterialInstanceDynamic* MID, ESoil M, float Moist);
	static FString SetFor(ESoil M, float Moist); // texture set name, e.g. "LateriteRed"
	static bool IsTextured(UMaterialInstanceDynamic* MID);
	static UTexture2D* Tex(const FString& Set, const TCHAR* Kind); // (also for the editor's heaps in the level)
private:
	static TMap<FString, UTexture2D*> Cache;
	static TMap<TWeakObjectPtr<UMaterialInstanceDynamic>, int32> Last;
};
