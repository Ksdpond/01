// Environment: sun/moon/sky/clouds/fog, day-night & weather, river water, trees, buildings and obstacles.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RWTypes.h"
#include "RWWorld.generated.h"

class ARWTerrain;
class ARWEffects;
class ARWMachine;
class FRWLayout;
class UDirectionalLightComponent;
class USkyAtmosphereComponent;
class USkyLightComponent;
class UExponentialHeightFogComponent;
class UVolumetricCloudComponent;
class UPostProcessComponent;
class UHierarchicalInstancedStaticMeshComponent;
class URWAmbientSynth;
class UProceduralMeshComponent;
class UMaterialInstanceDynamic;

struct FRWObstacle { FVector2D C; FVector2D Half; float Yaw; FName Obj; }; // Obj: the building it belongs to (moves with it when edited in the level)
struct FRWTree { FVector2D P; float Z; float H; bool bAlive; int32 Trunk; int32 Crown; bool bConifer; FTransform TrunkT; FTransform CrownT[3];
	int32 FabComp = -1, FabIdx = -1; FTransform FabT; // a whole-tree model from Fab drawn instead of trunk + crowns
	int32 FarComp = -1, FarIdx = -1; }; // the simple crown that stands for this tree beyond the distance where the model is drawn

UCLASS()
class ROADWORKS_API ARWWorld : public AActor
{
	GENERATED_BODY()
public:
	ARWWorld();
	double PerfTickSec = 0.0; // time spent in Tick since the last Perf log line
	void Build(const FRWLayout* InLayout, ARWTerrain* InTerrain, ARWEffects* InFx, UMaterialInterface* Paint, UMaterialInterface* Water, UMaterialInterface* Cloud);
	virtual void Tick(float Dt) override;

	// ---- time & weather ----
	float TimeOfDay = 8.5f; // hours
	int32 Day = 1;
	float TimeMul = 1.f;    // extra speed-up (T key)
	int32 Weather = 0;      // 0 clear, 1 cloudy, 2 rain, 3 storm
	float Rain = 0.f, Overcast = 0.1f;
	bool bAutoWeather = true;
	float NextWeatherChange = 6.f; // game hours
	float Flash = 0.f;
	void SetWeather(int32 W);
	FString WeatherName() const;
	FString ClockText() const;
	bool IsNight() const { return TimeOfDay < 6.f || TimeOfDay > 19.f; }

	// ---- interaction ----
	int32 HitTrees(const FVector& P, float R, const FVector& Dir, float HalfH = 0.6f);
	// writes every tree and plant (model and placement) for the editor's import (Tools/make_map.py); the number of instances
	int32 ExportPlants(const FString& File) const;
	int32 AliveTreesIn(const FVector2D& C, const FVector2D& Half) const;
	bool Resolve(ARWMachine* M, FVector& Push) const;
	TArray<TWeakObjectPtr<ARWMachine>> Machines;
	TArray<FRWObstacle> Obstacles;
	TArray<FRWTree> Trees;
	void SetTreeAlive(int32 i, bool bAlive);
	void SpawnProps();
	// Trees and rocks put in the level by hand in the Unreal Editor (dragged in, or painted with the Foliage tool) are taken
	// over by the game: a tree joins the forest (a machine pushes it over; the trunk is then pushed, flicked and scooped), a rock
	// becomes a loose rock with its own model (pushed, flicked, and scooped when it fits in the bucket). The level's own copy
	// is hidden. What they are comes from the model's name (tree, pine, palm..., rock, stone, boulder...) or the actor's tag:
	// RWTree / RWRock, or RWStatic to leave it as scenery. A rock over 8 m across is part of the land and stays put.
	// Runs at the start and again every few seconds for parts of the level that stream in later; returns how many it took.
	int32 AdoptPlaced();
	int32 UserTreesAdopted = 0, UserRocksAdopted = 0, UserRocksTooBig = 0;
	// low plants (bushes, ground plants and grass models from the level / Fab) by where they stand: ground that is dug,
	// filled, bladed or driven over loses its plants (DisturbAt, from the terrain); RefreshLowPlants goes over all of them
	// again from the ground as it is now (at the start and after loading a game)
	void IndexLowPlants();
	void DisturbAt(int32 TerrainIndex);
	void RefreshLowPlants();
	int32 LowPlantCount() const { return LowPlants.Num(); }
	int32 LowPlantsGone() const { int32 N = 0; for (const FLowPlant& P : LowPlants) N += P.bGone ? 1 : 0; return N; }
	bool IsLowPlantGone(int32 k) const { return LowPlants.IsValidIndex(k) && LowPlants[k].bGone; }
	FVector2D LowPlantAt(int32 k) const { return LowPlants.IsValidIndex(k) ? FVector2D(LowPlants[k].P) : FVector2D::ZeroVector; }
	// which building / object each part belongs to (House_3, Yard, ...), for the level's editable scenery; Lake_ parts go with the lakes
	FName CurObj;
	TMap<const UPrimitiveComponent*, FName> CompObj;
	// the soil heaps and the excavation the world started with (x, y, ground z / yaw), as written for the level
	struct FPileDef { FVector P; float R, H; ESoil M; };
	TArray<FPileDef> PileDefs;
	TArray<FVector> DigDefs;

	UPROPERTY() UDirectionalLightComponent* Sun = nullptr;
	UPROPERTY() UDirectionalLightComponent* Moon = nullptr;
	UPROPERTY() USkyAtmosphereComponent* Atmos = nullptr;
	UPROPERTY() USkyLightComponent* SkyLight = nullptr;
	UPROPERTY() UExponentialHeightFogComponent* Fog = nullptr;
	UPROPERTY() UVolumetricCloudComponent* Clouds = nullptr;
	UPROPERTY() UPostProcessComponent* Post = nullptr;
	UPROPERTY() UStaticMeshComponent* WaterPlane = nullptr;
	UPROPERTY() URWAmbientSynth* Ambient = nullptr;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* Trunks = nullptr;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* Conifers = nullptr;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* Broadleaf = nullptr;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* FarTrees = nullptr;
	UPROPERTY() TArray<UHierarchicalInstancedStaticMeshComponent*> FarCrowns; // tropical forest canopy seen from afar, a few shades of green
	UPROPERTY() UProceduralMeshComponent* StreamWater = nullptr;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* Bushes = nullptr;
	UPROPERTY() UInstancedStaticMeshComponent* Markers = nullptr;
	void SetMarkers(const TArray<FTransform>& T);
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() ARWEffects* Fx = nullptr;
	const FRWLayout* Layout = nullptr;
	FVector CamM = FVector::ZeroVector;

private:
	UPROPERTY() UMaterialInterface* PaintMat = nullptr;
	TMap<FLinearColor, UMaterialInstanceDynamic*> MatCache;
	TArray<TArray<int32>> TreeGrid;
	static constexpr int32 TreeGridN = 282; // 16 m cells over the whole map
	float ThunderDelay = -1.f, LightningTimer = 5.f;
	UMaterialInstanceDynamic* Mat(const FLinearColor& C, float Rough = 0.6f, float Metal = 0.f);
public:
	// places a (rounded) box, a cylinder or any static mesh in the world; also used by mods
	UStaticMeshComponent* Box(const FVector& C, const FVector& Size, float Yaw, const FLinearColor& Col, bool bObstacle, float Rough = 0.6f, float Metal = 0.f, UStaticMesh* Mesh = nullptr, const FRotator& Extra = FRotator::ZeroRotator);
	void UpdateGrass(const FVector& Cam);
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* GrassHISM = nullptr;
	UPROPERTY() TArray<UHierarchicalInstancedStaticMeshComponent*> FabTreeH;  // whole Fab trees, one per model variant
	UPROPERTY() TArray<UHierarchicalInstancedStaticMeshComponent*> FabGrassH; // extra Fab grass variants (GrassHISM holds the first)
	TArray<float> FabGrassScale; // per grass component: scale to natural size
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* RiceHISM = nullptr;
	TArray<TArray<FTransform>> GrassSplit; // the tufts per model, waiting to be handed over
	int32 GrassApplyNext = 0;
	UPROPERTY() UHierarchicalInstancedStaticMeshComponent* RockHISM = nullptr;
	UPROPERTY() UInstancedStaticMeshComponent* LineWhite = nullptr;
	UPROPERTY() UInstancedStaticMeshComponent* LineYellow = nullptr;
	UPROPERTY() UMaterialInterface* FoliageMat = nullptr;
	FVector LastGrassCam = FVector(1e9);
private:
	void RoadMarkings();
	void ScatterRocks();
	void Buildings();
	void PlantTrees();
	TSet<int32> FabTreeComps; // the instance lists that hold trees (the rest are low plants and things on the ground)
	// AdoptPlaced: the instance lists made for hand-placed trees (one per model and materials; the level has these trees
	// itself, so they are not written out for it), the actors already looked at, and the ones taken over (by path: an actor
	// that streams out and back in again is not taken twice)
	TSet<int32> UserTreeComps;
	TMap<FString, int32> UserTreeCompOf;
	TSet<TWeakObjectPtr<AActor>> AdoptSeen;
	TSet<FString> AdoptedKeys;
	float AdoptTimer = 0.f;
	void StreamsAndPaddies(UMaterialInterface* WaterSurface);
	void Stockpile(float X, float Y, float R, float H, ESoil M);
	void Excavation(float X, float Y, float Yaw); // the pit dug by the previous shift, its spoil in two heaps beside it
	struct FLowPlant { int32 Comp = 0; int32 Idx = 0; FVector2f P = FVector2f::ZeroVector; float R = 0.5f; FTransform X; bool bGone = false; };
	TArray<FLowPlant> LowPlants;
	UPROPERTY() TArray<UHierarchicalInstancedStaticMeshComponent*> LowComps;
	TMap<int32, TArray<int32>> LowPlantCells; // 4 m squares of the map -> LowPlants
	TMap<int32, TArray<int32>> LowPending;    // per LowComps entry: plants whose instance waits for the next redraw
	float LowFlushT = 0.f;
	static constexpr float LowCell = 4.f;
	int32 LowCellKey(float X, float Y) const;
	void SetLowPlantGone(int32 k, bool bGone);
	void FlushLowPlants();
	int32 HouseN = 0;
	void House(float X, float Y, float Yaw, const FLinearColor& Wall, const FLinearColor& Roof);
	void UpdateSky(float Dt);
};
