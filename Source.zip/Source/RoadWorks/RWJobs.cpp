#include "RWJobs.h"
#include "RWTerrain.h"
#include "RWWorld.h"
#include "RWLayout.h"
#include "RWLoc.h"

void FRWEconomy::Add(double Amount, const FString& What)
{
	Money += Amount;
	Ledger.Insert(FString::Printf(TEXT("%s%s  %s"), Amount >= 0 ? TEXT("+") : TEXT("-"), *FString::Printf(TEXT("$%.0f"), FMath::Abs(Amount)), *What), 0);
	if (Ledger.Num() > 10) Ledger.SetNum(10);
	RWLog(FString::Printf(TEXT("Money %+.0f (%s) -> %.0f"), Amount, *What, Money));
}

float FRWEconomy::MaterialPrice(ESoil M)
{
	switch (M)
	{
	case ESoil::Gravel: return 22.f;
	case ESoil::Sand: return 15.f;
	case ESoil::Laterite: return 12.f;
	case ESoil::Asphalt: return 110.f;
	case ESoil::SmallRock: return 18.f;
	default: return 8.f;
	}
}

float FRWJob::EstimatedPay() const
{
	return BasePay + RatePerUnit * FMath::Max(TargetVol, (float)Count);
}

FString FRWJobs::TypeName(EJob T)
{
	switch (T)
	{
	case EJob::Pond: return TEXT("Excavation");
	case EJob::LevelPad: return TEXT("Site levelling");
	case EJob::Ditch: return TEXT("Drainage ditch");
	case EJob::HaulOut: return TEXT("Haul away");
	case EJob::Fill: return TEXT("Fill & compact");
	case EJob::Road: return TEXT("Road construction");
	case EJob::Repair: return TEXT("Road repair");
	case EJob::Quarry: return TEXT("Quarry production");
	case EJob::Deliver: return TEXT("Material delivery");
	case EJob::CutHill: return TEXT("Hill cut");
	case EJob::Clear: return TEXT("Land clearing");
	default: return TEXT("Crane lift");
	}
}

void FRWJobs::Init(const FRWLayout* L, ARWTerrain* T, ARWWorld* W)
{
	Layout = L; Terrain = T; World = W;
	Jobs.Reset();
	auto Add = [&](EJob Ty, const TCHAR* Title, const TCHAR* Client, const TCHAR* Desc, FVector2D C, FVector2D H) -> FRWJob&
	{
		FRWJob J; J.Id = NextId++; J.Type = Ty; J.Title = Title; J.Client = Client; J.Desc = Desc; J.C = C; J.Half = H;
		Jobs.Add(J);
		return Jobs.Last();
	};
	{
		FRWJob& J = Add(EJob::Pond, TEXT("Detention pond"), TEXT("District Water Office"), TEXT("Excavate the pond to 2.5 m below original ground. Haul or stockpile the spoil outside the pond."), FVector2D(62, -36), FVector2D(8, 6));
		J.Depth = 2.5f; J.BasePay = 9000; J.RatePerUnit = 25; J.TargetVol = 16 * 12 * 2.5f;
	}
	{
		FRWJob& J = Add(EJob::LevelPad, TEXT("Warehouse building pad"), TEXT("Northline Logistics"), TEXT("Level the pad to the design elevation (+/-5 cm) and compact it to at least 85%."), FVector2D(15, -75), FVector2D(12, 9));
		float S = 0; int32 N = 0;
		for (float X = J.C.X - J.Half.X; X <= J.C.X + J.Half.X; X += 2.f) for (float Y = J.C.Y - J.Half.Y; Y <= J.C.Y + J.Half.Y; Y += 2.f) { S += T->HeightAt(X, Y); ++N; }
		J.TargetZ = FMath::RoundToFloat(S / FMath::Max(N, 1) * 10.f) / 10.f;
		J.BasePay = 16000;
	}
	{
		FRWJob& J = Add(EJob::Ditch, TEXT("Site drainage ditch"), TEXT("Construction Site"), TEXT("Dig a 1.0 m deep drainage ditch along the staked line."), FVector2D(20, -27), FVector2D(28, 8));
		J.Path = {FVector2D(-6, -31), FVector2D(18, -28), FVector2D(34, -26), FVector2D(46, -16)};
		J.Depth = 1.0f; J.HalfW = 0.8f; J.BasePay = 8500;
	}
	{
		FRWJob& J = Add(EJob::HaulOut, TEXT("Remove spoil heaps"), TEXT("Construction Site"), TEXT("Load the pond spoil heaps into trucks and haul them away (e.g. to the Spoil Dump)."), FVector2D(66, -45), FVector2D(9, 4.5f));
		J.TargetVol = 35.f; J.BasePay = 2500; J.RatePerUnit = 40;
	}
	{
		const FRWZone* D = L->Find(ERWZone::DumpSite);
		FRWJob& J = Add(EJob::Fill, TEXT("Raise the spoil dump platform"), TEXT("River Authority"), TEXT("Fill the platform up to the design level and compact the fill."), D ? D->C : FVector2D(118, 28), FVector2D(9, 7));
		J.TargetZ = T->HeightAt(J.C.X, J.C.Y) + 1.0f; J.BasePay = 14000;
	}
	{
		FRWJob& J = Add(EJob::Road, TEXT("North access road"), TEXT("Provincial Highways Dept."), TEXT("Build a 6 m asphalt road: clear trees, cut through the knoll, 20 cm laterite subbase, 15 cm crushed gravel base, 5 cm asphalt. Compact every layer."), FVector2D(12, 15), FVector2D(32, 32));
		J.Path = {FVector2D(40, -12), FVector2D(28, 8), FVector2D(12, 28), FVector2D(-12, 42)};
		J.HalfW = 3.f; J.BasePay = 95000;
	}
	{
		FRWJob& J = Add(EJob::Repair, TEXT("Pothole repair, Highway 7"), TEXT("Provincial Highways Dept."), TEXT("Patch the potholes: clean out, fill with base, pave and roll flush with the road."), (L->PotholeA + L->PotholeB) * 0.5f, FVector2D(17, 5));
		J.Path = {L->PotholeA, L->PotholeB}; J.HalfW = 4.f; J.BasePay = 26000;
	}
	{
		const FRWZone* P = L->Find(ERWZone::Plant);
		FRWJob& J = Add(EJob::Quarry, TEXT("Supply crusher feed"), TEXT("Material Plant"), TEXT("Break and load quarry rock, haul it and tip it inside the Material Plant yard."), P ? P->C : FVector2D(-60, -200), P ? P->HalfExt : FVector2D(30, 25));
		J.TargetVol = 60.f; J.RatePerUnit = 48; J.BasePay = 1500;
	}
	{
		const FRWZone* S = L->Find(ERWZone::Site);
		FRWJob& J = Add(EJob::Deliver, TEXT("Gravel for the site"), TEXT("Construction Site"), TEXT("Buy crushed gravel at the plant and tip it inside the construction site."), S ? S->C : FVector2D(40, -60), S ? S->HalfExt : FVector2D(55, 45));
		J.Mat = ESoil::Gravel; J.TargetVol = 40.f; J.RatePerUnit = 38; J.BasePay = 2000;
	}
	{
		const FRWZone* K = L->Find(ERWZone::Knoll);
		FRWJob& J = Add(EJob::CutHill, TEXT("Lower the knoll"), TEXT("Provincial Highways Dept."), TEXT("Cut the hill down to the design level (stakes) for the new road alignment."), K ? K->C : FVector2D(30, 30), FVector2D(12, 12));
		J.TargetZ = (K ? K->Z : T->HeightAt(30, 30)) + 1.2f; J.BasePay = 24000;
	}
	{
		FRWJob& J = Add(EJob::Clear, TEXT("Clear forest edge"), TEXT("Forestry Office"), TEXT("Push over and clear all trees in the marked area (dozer or excavator)."), FVector2D(-48, 104), FVector2D(12, 10));
		J.RatePerUnit = 450; J.BasePay = 1000;
	}
	{
		FRWJob& J = Add(EJob::Lift, TEXT("Place concrete barriers"), TEXT("Construction Site"), TEXT("Use the mobile crane (or excavator grapple) to set 4 barriers from the yard inside the marked area."), FVector2D(30, -100), FVector2D(8, 4));
		J.Count = 4; J.BasePay = 7000;
	}
	{
		// a road over the foothills: the route is planned to climb no steeper than 8 %, and the design line lies half way
		// between the ground's highs and lows, so that what is cut out of the hill is about what the low stretches need
		const TArray<FVector2D> Route = L->PlanRoute(FVector2D(-40.f, 290.f), FVector2D(-120.f, 700.f), 0.08f);
		FBox2D Bx(ForceInit);
		for (const FVector2D& Pt : Route) Bx += Pt;
		FRWJob& J = Add(EJob::Road, TEXT("Mountain road: cut and fill"), TEXT("Provincial Highways Dept."), TEXT("Build the road up the hillside to the staked line: cut the high stretches, use that soil to fill the low ones, shape the side slopes, compact, then lay the layers. Grade no steeper than 8%."), Bx.GetCenter(), Bx.GetExtent());
		J.Path = Route;
		J.HalfW = 3.5f; J.BasePay = 240000;
	}
	for (FRWJob& J : Jobs)
	{
		if (J.Type == EJob::Clear && World) J.InitialTrees = World->AliveTreesIn(J.C, J.Half);
	}
	// Player-designed road (empty until stakes are placed)
	FRWJob P; P.Id = NextId++; P.Type = EJob::Road; P.bPlayer = true; P.Title = TEXT("Your surveyed road"); P.Client = TEXT("Own company (sold to the province on completion)");
	P.Desc = TEXT("Place survey stakes (K) to design your own road. Publish it from the job board to start building.");
	P.HalfW = 3.f;
	Jobs.Add(P);
}

void FRWJobs::Snapshot(FRWJob& J)
{
	FVector2D Mn = J.C - J.Half, Mx = J.C + J.Half;
	if (J.Path.Num())
	{
		Mn = FVector2D(1e9, 1e9); Mx = FVector2D(-1e9, -1e9);
		for (const FVector2D& P : J.Path) { Mn = FVector2D(FMath::Min(Mn.X, P.X), FMath::Min(Mn.Y, P.Y)); Mx = FVector2D(FMath::Max(Mx.X, P.X), FMath::Max(Mx.Y, P.Y)); }
		Mn -= FVector2D(J.HalfW + 4.f); Mx += FVector2D(J.HalfW + 4.f);
	}
	J.SX0 = FMath::Clamp(Terrain->ToGrid(Mn.X), 0, ARWTerrain::N - 1); J.SY0 = FMath::Clamp(Terrain->ToGrid(Mn.Y), 0, ARWTerrain::N - 1);
	const int32 X1 = FMath::Clamp(Terrain->ToGrid(Mx.X), 0, ARWTerrain::N - 1), Y1 = FMath::Clamp(Terrain->ToGrid(Mx.Y), 0, ARWTerrain::N - 1);
	J.SW = X1 - J.SX0 + 1; J.SH = Y1 - J.SY0 + 1;
	J.Snap.SetNum(J.SW * J.SH);
	// Excavation jobs are measured from the original ground; the others from the state at acceptance.
	const bool bOriginal = J.Type == EJob::Pond || J.Type == EJob::Ditch;
	for (int32 y = 0; y < J.SH; ++y) for (int32 x = 0; x < J.SW; ++x)
	{
		const int32 i = Terrain->Idx(J.SX0 + x, J.SY0 + y);
		J.Snap[y * J.SW + x] = bOriginal ? Terrain->Natural[i] + Terrain->Layers[i].Total() * 0.f : Terrain->Height[i];
	}
}

void FRWJobs::BuildRoadProfile(FRWJob& J, bool bFromSnapshot)
{
	TArray<FVector2D> D;
	for (int32 i = 0; i + 1 < J.Path.Num(); ++i)
	{
		const int32 Steps = FMath::Max(1, FMath::CeilToInt(FVector2D::Distance(J.Path[i], J.Path[i + 1])));
		for (int32 s = 0; s < Steps; ++s) D.Add(FMath::Lerp(J.Path[i], J.Path[i + 1], s / float(Steps)));
	}
	if (J.Path.Num()) D.Add(J.Path.Last());
	TArray<float> Raw;
	for (const FVector2D& P : D) Raw.Add(Terrain->HeightAt(P.X, P.Y));
	J.PathZ.SetNum(Raw.Num());
	for (int32 i = 0; i < Raw.Num(); ++i)
	{
		float S = 0, W = 0;
		for (int32 k = -20; k <= 20; ++k) { const int32 j = FMath::Clamp(i + k, 0, Raw.Num() - 1); const float Wk = 21.f - FMath::Abs(k); S += Raw[j] * Wk; W += Wk; }
		float Off = 0;
		if (J.Offsets.Num() && J.Stakes.Num() > 1)
		{
			const float T = i / float(FMath::Max(1, Raw.Num() - 1)) * (J.Stakes.Num() - 1);
			const int32 a = FMath::Clamp(FMath::FloorToInt(T), 0, J.Stakes.Num() - 2);
			Off = FMath::Lerp(J.Offsets[a], J.Offsets[a + 1], T - a);
		}
		J.PathZ[i] = S / W + Off + 0.15f;
	}
	// limit grade to 8%, with as much to cut as to fill
	FRWLayout::LimitGrade(J.PathZ, D, 0.08f);
	// settle the whole line so that the earth from its cuts just about fills its low stretches (the ends stay on the ground they join)
	if (!J.bPlayer && J.PathZ.Num() > 80)
	{
		double Diff = 0.0;
		for (int32 i = 0; i < J.PathZ.Num(); ++i) Diff += Raw[i] - J.PathZ[i];
		const float Shift = (float)(Diff / J.PathZ.Num());
		for (int32 i = 0; i < J.PathZ.Num(); ++i)
			J.PathZ[i] += Shift * FMath::Min(1.f, FMath::Min(i, J.PathZ.Num() - 1 - i) / 40.f);
		FRWLayout::LimitGrade(J.PathZ, D, 0.08f);
	}
	J.Path = D;
	J.PlanCut = J.PlanFill = 0.f;
	for (int32 i = 0; i + 1 < D.Num(); ++i)
	{
		const float Ds = FVector2D::Distance(D[i], D[i + 1]), Dz = Raw[i] - J.PathZ[i];
		(Dz > 0.f ? J.PlanCut : J.PlanFill) += FMath::Abs(Dz) * Ds * 2.f * J.HalfW;
	}
	RWLog(FString::Printf(TEXT("Road job %s: %d m, about %.0f m3 to cut and %.0f m3 to fill"), *J.Title, D.Num(), J.PlanCut, J.PlanFill));
}

void FRWJobs::Accept(int32 i)
{
	if (!Jobs.IsValidIndex(i)) return;
	FRWJob& J = Jobs[i];
	if (J.bAccepted || J.bDone) return;
	if (J.bPlayer && J.Stakes.Num() < 2) return;
	if (J.Type == EJob::Road && !J.bPlayer) BuildRoadProfile(J, true);
	Snapshot(J);
	if (J.Type == EJob::Clear && World) J.InitialTrees = World->AliveTreesIn(J.C, J.Half);
	J.bAccepted = true;
	J.Delivered = 0;
	Tracked = i;
	Evaluate(J);
	RWLog(FString::Printf(TEXT("Job accepted: %s"), *J.Title));
}

void FRWJobs::Abandon(int32 i)
{
	if (!Jobs.IsValidIndex(i)) return;
	Jobs[i].bAccepted = false;
	if (Tracked == i) Tracked = -1;
}

bool FRWJobs::DesignSurface(const FRWJob& J, const FVector2D& P, float& Z, float& Lat) const
{
	float Best = 1e9f;
	bool bHit = false;
	for (int32 s = 0; s + 1 < J.Path.Num() && s + 1 < J.PathZ.Num(); ++s)
	{
		const FVector2D A = J.Path[s], B = J.Path[s + 1], AB = B - A;
		const float L2 = FMath::Max(AB.SizeSquared(), 1e-4f);
		const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / L2, 0.f, 1.f);
		const float D = FVector2D::Distance(P, A + AB * T);
		if (D < Best) { Best = D; Z = FMath::Lerp(J.PathZ[s], J.PathZ[s + 1], T); bHit = true; }
	}
	Lat = Best;
	if (bHit) Z -= J.CrossSlope * FMath::Min(Best, J.HalfW);
	return bHit;
}

bool FRWJobs::DesignGrade(const FVector& P, float& Z) const
{
	auto TryJob = [&](const FRWJob& J) -> bool
	{
		if (!J.bAccepted || J.bDone) return false;
		const FVector2D Q(P.X, P.Y);
		switch (J.Type)
		{
		case EJob::Road:
		{
			float S, Lat;
			if (!DesignSurface(J, Q, S, Lat) || Lat > J.HalfW + 0.6f) return false;
			const int32 i = Terrain->IndexAt(P.X, P.Y);
			const ESoil Top = Terrain->SurfaceMat(i);
			const bool bLayer = Terrain->Layers[i].Count > 0;
			if (Top == ESoil::Asphalt) Z = S;
			else if (bLayer && Top == ESoil::Gravel) Z = S - J.AsphaltT;
			else if (bLayer && Top == ESoil::Laterite) Z = S - J.AsphaltT - J.BaseT;
			else Z = S - J.AsphaltT - J.BaseT - J.SubbaseT;
			return true;
		}
		case EJob::LevelPad: case EJob::Fill: case EJob::CutHill:
			if (!FRWLayout::InZone(FRWZone{TEXT(""), ERWZone::Site, J.C, J.Half}, P.X, P.Y)) return false;
			Z = J.TargetZ; return true;
		case EJob::Pond:
		{
			if (!FRWLayout::InZone(FRWZone{TEXT(""), ERWZone::Site, J.C, J.Half}, P.X, P.Y) || J.Snap.Num() == 0) return false;
			const int32 x = Terrain->ToGrid(P.X) - J.SX0, y = Terrain->ToGrid(P.Y) - J.SY0;
			if (x < 0 || y < 0 || x >= J.SW || y >= J.SH) return false;
			Z = J.Snap[y * J.SW + x] - J.Depth; return true;
		}
		case EJob::Ditch:
		{
			float S, Lat;
			if (J.Snap.Num() == 0 || !DesignSurface(J, Q, S, Lat) || Lat > J.HalfW + 0.5f) return false;
			const int32 x = Terrain->ToGrid(P.X) - J.SX0, y = Terrain->ToGrid(P.Y) - J.SY0;
			if (x < 0 || y < 0 || x >= J.SW || y >= J.SH) return false;
			Z = J.Snap[y * J.SW + x] - J.Depth; return true;
		}
		default: return false;
		}
	};
	if (Jobs.IsValidIndex(Tracked) && TryJob(Jobs[Tracked])) return true;
	for (const FRWJob& J : Jobs) if (TryJob(J)) return true;
	return false;
}

void FRWJobs::OnDeposit(int32 Idx, ESoil M, float Vol)
{
	const float X = Terrain->PX(Idx % ARWTerrain::N), Y = Terrain->PX(Idx / ARWTerrain::N);
	for (FRWJob& J : Jobs)
	{
		if (!J.bAccepted || J.bDone) continue;
		if (J.Type == EJob::Quarry && (M == ESoil::SmallRock || M == ESoil::LargeRock) && FMath::Abs(X - J.C.X) <= J.Half.X && FMath::Abs(Y - J.C.Y) <= J.Half.Y) J.Delivered += Vol;
		if (J.Type == EJob::Deliver && M == J.Mat && FMath::Abs(X - J.C.X) <= J.Half.X && FMath::Abs(Y - J.C.Y) <= J.Half.Y) J.Delivered += Vol;
	}
}

void FRWJobs::OnRemove(int32 Idx, ESoil M, float Vol)
{
	// material re-handled inside the zone (slumping, pushing) does not count twice
	const float X = Terrain->PX(Idx % ARWTerrain::N), Y = Terrain->PX(Idx / ARWTerrain::N);
	for (FRWJob& J : Jobs)
	{
		if (!J.bAccepted || J.bDone) continue;
		if ((J.Type == EJob::Quarry && (M == ESoil::SmallRock || M == ESoil::LargeRock)) || (J.Type == EJob::Deliver && M == J.Mat))
			if (FMath::Abs(X - J.C.X) <= J.Half.X && FMath::Abs(Y - J.C.Y) <= J.Half.Y) J.Delivered = FMath::Max(0.f, J.Delivered - Vol);
	}
}

void FRWJobs::EvalRoad(FRWJob& J)
{
	if (J.Path.Num() < 2 || J.PathZ.Num() < 2) { J.Progress = 0; J.Status = TEXT("No design"); return; }
	int32 N = 0; float StageSum = 0; int32 Final = 0;
	for (float& F : J.StageFrac) F = 0;
	float Dev2 = 0; int32 DevN = 0;
	int32 TreesLeft = 0;
	if (World)
		for (const FRWTree& T : World->Trees)
		{
			if (!T.bAlive) continue;
			float Z, Lat;
			if (DesignSurface(J, T.P, Z, Lat) && Lat < J.HalfW + 1.5f) ++TreesLeft;
		}
	for (int32 i = 0; i < J.Path.Num(); i += 2)
	{
		const FVector2D A = J.Path[i];
		const FVector2D Dir = (J.Path[FMath::Min(i + 1, J.Path.Num() - 1)] - J.Path[FMath::Max(i - 1, 0)]).GetSafeNormal();
		const FVector2D Nrm(-Dir.Y, Dir.X);
		for (int32 l = -1; l <= 1; ++l)
		{
			const FVector2D P = A + Nrm * (l * J.HalfW * 0.7f);
			if (!Terrain->InBounds(P.X, P.Y)) continue;
			const int32 Idx = Terrain->IndexAt(P.X, P.Y);
			float S, Lat; DesignSurface(J, P, S, Lat);
			const FLayers& L = Terrain->Layers[Idx];
			const float H = Terrain->Height[Idx];
			const float Sub = S - J.AsphaltT - J.BaseT - J.SubbaseT;
			int32 Stage = TreesLeft == 0 && Terrain->Grass[Idx] < 60 ? 1 : 0;
			// find road layers on top of the stack
			float TAs = 0, TBa = 0, TSb = 0; float CAs = 0, CBa = 0, CSb = 0;
			int32 k = L.Count - 1;
			if (k >= 0 && L.Mat[k] == (uint8)ESoil::Asphalt) { TAs = L.T[k]; CAs = L.Comp[k] / 255.f; --k; }
			if (k >= 0 && L.Mat[k] == (uint8)ESoil::Gravel) { TBa = L.T[k]; CBa = L.Comp[k] / 255.f; --k; }
			if (k >= 0 && L.Mat[k] == (uint8)ESoil::Laterite) { TSb = L.T[k]; CSb = L.Comp[k] / 255.f; --k; }
			const float Below = H - TAs - TBa - TSb;
			if (Stage >= 1 && FMath::Abs(Below - Sub) < 0.1f && Terrain->SurfaceComp(Idx) >= 0.0f) Stage = 2;
			if (Stage >= 2 && TSb >= J.SubbaseT * 0.6f && CSb >= 0.8f) Stage = 3;
			if (Stage >= 3 && TBa >= J.BaseT * 0.6f && CBa >= 0.8f) Stage = 4;
			if (Stage >= 4 && TAs >= J.AsphaltT * 0.6f) Stage = 5;
			if (Stage >= 5 && CAs >= 0.9f && FMath::Abs(H - S) <= 0.04f) Stage = 6;
			J.StageFrac[Stage] += 1.f;
			StageSum += Stage; ++N;
			if (Stage == 6) ++Final;
			if (Stage >= 5) { Dev2 += FMath::Square(H - S); ++DevN; }
		}
	}
	for (float& F : J.StageFrac) F /= FMath::Max(N, 1);
	J.Progress = StageSum / FMath::Max(N * 6.f, 1.f);
	const float Rms = DevN ? FMath::Sqrt(Dev2 / DevN) : 0.1f;
	J.Quality = FMath::Clamp(1.f - Rms / 0.06f, 0.f, 1.f) * 0.5f + 0.5f * (Final / FMath::Max(1.f, (float)N));
	J.Status = TRF(TEXT("Trees left {0} | cleared {1}% subgrade {2}% subbase {3}% base {4}% paved {5}% finished {6}% | surface RMS {7} cm"),
		FString::FromInt(TreesLeft), RWNum(100.f * (1 - J.StageFrac[0])), RWNum(100.f * (J.StageFrac[2] + J.StageFrac[3] + J.StageFrac[4] + J.StageFrac[5] + J.StageFrac[6])),
		RWNum(100.f * (J.StageFrac[3] + J.StageFrac[4] + J.StageFrac[5] + J.StageFrac[6])), RWNum(100.f * (J.StageFrac[4] + J.StageFrac[5] + J.StageFrac[6])),
		RWNum(100.f * (J.StageFrac[5] + J.StageFrac[6])), RWNum(100.f * J.StageFrac[6]), RWNum(Rms * 100.f, 1));
}

void FRWJobs::Evaluate(FRWJob& J)
{
	if (!J.bAccepted) return;
	const float A = ARWTerrain::CellArea;
	auto ForZone = [&](TFunctionRef<void(int32 Idx, float Snap)> F)
	{
		const int32 X0 = Terrain->ToGrid(J.C.X - J.Half.X), X1 = Terrain->ToGrid(J.C.X + J.Half.X);
		const int32 Y0 = Terrain->ToGrid(J.C.Y - J.Half.Y), Y1 = Terrain->ToGrid(J.C.Y + J.Half.Y);
		for (int32 y = Y0; y <= Y1; ++y)
			for (int32 x = X0; x <= X1; ++x)
			{
				if (!Terrain->Valid(x, y)) continue;
				const int32 sx = x - J.SX0, sy = y - J.SY0;
				const float S = (sx >= 0 && sy >= 0 && sx < J.SW && sy < J.SH) ? J.Snap[sy * J.SW + sx] : Terrain->Height[Terrain->Idx(x, y)];
				F(Terrain->Idx(x, y), S);
			}
	};
	switch (J.Type)
	{
	case EJob::Pond:
	{
		float Removed = 0; int32 Ok = 0, N = 0;
		ForZone([&](int32 i, float S) { const float D = S - Terrain->Height[i]; Removed += FMath::Max(0.f, D) * A; if (FMath::Abs(D - J.Depth) < 0.25f) ++Ok; ++N; });
		J.Delivered = Removed;
		J.Progress = FMath::Clamp(Removed / FMath::Max(J.TargetVol, 1.f), 0.f, 1.f) * 0.5f + 0.5f * Ok / FMath::Max(N, 1);
		J.Quality = Ok / FMath::Max(1.f, (float)N);
		J.Status = TRF(TEXT("Excavated {0} m3 of {1}   at design depth {2}%"), RWNum(Removed), RWNum(J.TargetVol), RWNum(100.f * J.Quality));
		break;
	}
	case EJob::LevelPad: case EJob::Fill: case EJob::CutHill:
	{
		int32 Ok = 0, N = 0; float Dev2 = 0, Comp = 0;
		ForZone([&](int32 i, float S)
		{
			const float D = Terrain->Height[i] - J.TargetZ;
			Dev2 += D * D; Comp += Terrain->SurfaceComp(i); ++N;
			const bool bGood = J.Type == EJob::CutHill ? (D <= 0.1f) : (FMath::Abs(D) <= 0.05f || (J.Type == EJob::Fill && D > 0.f && D < 0.15f));
			if (bGood) ++Ok;
		});
		const float Frac = Ok / FMath::Max(1.f, (float)N);
		const float Rms = FMath::Sqrt(Dev2 / FMath::Max(N, 1));
		const float AvgC = Comp / FMath::Max(N, 1);
		J.Progress = Frac;
		const bool bNeedComp = J.Type != EJob::CutHill;
		J.Quality = FMath::Clamp(1.f - Rms / 0.25f, 0.f, 1.f) * (bNeedComp ? FMath::Clamp(AvgC / 0.85f, 0.f, 1.f) : 1.f);
		if (bNeedComp && AvgC < 0.85f) J.Progress = FMath::Min(J.Progress, 0.95f);
		J.Status = TRF(TEXT("Within tolerance {0}%   RMS {1} cm   compaction {2}%   design {3} m"), RWNum(Frac * 100.f), RWNum(Rms * 100.f, 1), RWNum(AvgC * 100.f), RWNum(J.TargetZ, 2));
		break;
	}
	case EJob::Ditch:
	{
		int32 Ok = 0, N = 0;
		for (int32 s = 0; s + 1 < J.Path.Num(); ++s)
		{
			const float Len = FVector2D::Distance(J.Path[s], J.Path[s + 1]);
			for (float d = 0; d < Len; d += 1.f)
			{
				const FVector2D P = FMath::Lerp(J.Path[s], J.Path[s + 1], d / Len);
				const int32 x = Terrain->ToGrid(P.X) - J.SX0, y = Terrain->ToGrid(P.Y) - J.SY0;
				if (x < 0 || y < 0 || x >= J.SW || y >= J.SH) continue;
				const float Dd = J.Snap[y * J.SW + x] - Terrain->HeightAt(P.X, P.Y);
				if (Dd >= J.Depth * 0.9f) ++Ok;
				++N;
			}
		}
		J.Progress = Ok / FMath::Max(1.f, (float)N);
		J.Quality = J.Progress;
		J.Status = TRF(TEXT("Ditch at depth: {0}% of {1} m"), RWNum(J.Progress * 100.f), FString::FromInt(N));
		break;
	}
	case EJob::HaulOut:
	{
		float Net = 0;
		ForZone([&](int32 i, float S) { Net += (S - Terrain->Height[i]) * A; });
		J.Delivered = FMath::Max(0.f, Net);
		J.Progress = FMath::Clamp(J.Delivered / J.TargetVol, 0.f, 1.f);
		J.Quality = 1.f;
		J.Status = TRF(TEXT("Removed {0} of {1} m3"), RWNum(J.Delivered, 1), RWNum(J.TargetVol));
		break;
	}
	case EJob::Road: EvalRoad(J); break;
	case EJob::Repair:
	{
		int32 Ok = 0, N = 0;
		const FVector2D A0 = J.Path[0], B0 = J.Path.Last();
		for (float t = 0; t <= 1.f; t += 0.02f)
			for (int32 l = -3; l <= 3; ++l)
			{
				const FVector2D P = FMath::Lerp(A0, B0, t) + FVector2D(0, l * 0.9f);
				float RZ, Lat;
				if (!Layout->RoadAt(P.X, P.Y, RZ, Lat)) continue;
				const int32 i = Terrain->IndexAt(P.X, P.Y);
				const float Design = RZ - 0.025f * FMath::Min(Lat, 4.f);
				const bool bGood = Terrain->SurfaceMat(i) == ESoil::Asphalt && Terrain->SurfaceComp(i) >= 0.85f && FMath::Abs(Terrain->Height[i] - Design) <= 0.03f;
				if (bGood) ++Ok;
				++N;
			}
		J.Progress = Ok / FMath::Max(1.f, (float)N);
		J.Quality = J.Progress;
		J.Status = TRF(TEXT("Sound, flush asphalt: {0}% of the stretch"), RWNum(J.Progress * 100.f));
		break;
	}
	case EJob::Quarry: case EJob::Deliver:
		J.Progress = FMath::Clamp(J.Delivered / J.TargetVol, 0.f, 1.f);
		J.Quality = 1.f;
		J.Status = TRF(TEXT("Delivered {0} of {1} m3 ({2})"), RWNum(J.Delivered, 1), RWNum(J.TargetVol), J.Type == EJob::Quarry ? TR(TEXT("rock")) : TR(SoilProps(J.Mat).Name));
		break;
	case EJob::Clear:
	{
		const int32 Left = World ? World->AliveTreesIn(J.C, J.Half) : 0;
		J.Progress = J.InitialTrees > 0 ? 1.f - Left / float(J.InitialTrees) : 1.f;
		J.Quality = 1.f;
		J.Delivered = (float)(J.InitialTrees - Left);
		J.Status = TRF(TEXT("Trees remaining {0} of {1}"), FString::FromInt(Left), FString::FromInt(J.InitialTrees));
		break;
	}
	case EJob::Lift:
	{
		extern int32 RWCountPropsIn(int32 Type, const FVector2D& C, const FVector2D& H);
		const int32 In = RWCountPropsIn(2, J.C, J.Half);
		J.Progress = FMath::Clamp(In / float(FMath::Max(J.Count, 1)), 0.f, 1.f);
		J.Quality = 1.f;
		J.Status = TRF(TEXT("Barriers placed {0} / {1}"), FString::FromInt(In), FString::FromInt(J.Count));
		break;
	}
	}
}

void FRWJobs::Tick(float Dt)
{
	EvalTimer -= Dt;
	if (EvalTimer > 0) return;
	EvalTimer = 1.f;
	for (FRWJob& J : Jobs) if (J.bAccepted && !J.bDone) Evaluate(J);
}

FRWJob* FRWJobs::PlayerRoad()
{
	for (FRWJob& J : Jobs) if (J.bPlayer) return &J;
	return nullptr;
}

void FRWJobs::AddStake(const FVector2D& P)
{
	FRWJob* J = PlayerRoad();
	if (!J || J->bAccepted) return;
	J->Stakes.Add(P);
	J->Offsets.Add(0.f);
	RebuildPlayerRoad();
}

void FRWJobs::RemoveStake()
{
	FRWJob* J = PlayerRoad();
	if (!J || J->bAccepted || J->Stakes.Num() == 0) return;
	J->Stakes.Pop(); J->Offsets.Pop();
	RebuildPlayerRoad();
}

void FRWJobs::RebuildPlayerRoad()
{
	FRWJob* J = PlayerRoad();
	if (!J) return;
	J->Path = J->Stakes;
	if (J->Path.Num() >= 2) BuildRoadProfile(*J, false); else J->PathZ.Reset();
	float Len = 0; for (int32 i = 0; i + 1 < J->Stakes.Num(); ++i) Len += FVector2D::Distance(J->Stakes[i], J->Stakes[i + 1]);
	J->BasePay = Len * (2.f * J->HalfW) * 95.f;
	FVector2D Mn(1e9, 1e9), Mx(-1e9, -1e9);
	for (const FVector2D& P : J->Stakes) { Mn = FVector2D(FMath::Min(Mn.X, P.X), FMath::Min(Mn.Y, P.Y)); Mx = FVector2D(FMath::Max(Mx.X, P.X), FMath::Max(Mx.Y, P.Y)); }
	if (J->Stakes.Num()) { J->C = (Mn + Mx) * 0.5f; J->Half = (Mx - Mn) * 0.5f + FVector2D(J->HalfW + 2.f); }
}

void FRWJobs::PublishPlayerRoad()
{
	for (int32 i = 0; i < Jobs.Num(); ++i) if (Jobs[i].bPlayer) { RebuildPlayerRoad(); Accept(i); }
}

void FRWJobs::Serialize(FArchive& Ar)
{
	int32 Num = Jobs.Num();
	Ar << Num << Tracked;
	for (int32 i = 0; i < FMath::Min(Num, Jobs.Num()); ++i)
	{
		FRWJob& J = Jobs[i];
		Ar << J.bAccepted << J.bDone << J.Progress << J.Quality << J.Delivered << J.Paid << J.InitialTrees;
		Ar << J.Snap << J.SX0 << J.SY0 << J.SW << J.SH << J.Path << J.PathZ << J.Stakes << J.Offsets << J.HalfW << J.TargetZ << J.BasePay;
	}
}
