// The bridge between the Unreal Editor and the game's map. The level L_RoadWorks_Main holds a real Landscape built from the same
// generator as the game's ground. Sculpting it in the editor is written to Content/MapData as a change on top of the generated
// ground, and the game (play in editor or the packaged game) adds that to its own deformable terrain.
// Called from Tools/make_map.py and from the RoadWorks menu (Content/Python/init_unreal.py).
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "RWMapTools.generated.h"

class UMaterialInterface;
class UStaticMesh;
class UWorld;

UCLASS()
class ROADWORKS_API URWMapTools : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
public:
	// Builds the Landscape and the level's other generated actors from the seed and parameters ([RoadWorks.Map] in DefaultGame.ini),
	// removing what an earlier run made: nothing is duplicated. Seed < 0 keeps the present seed. A new seed drops earlier sculpting.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool BuildMap(int32 Seed, UMaterialInterface* LandscapeMaterial, UMaterialInterface* LakeMaterial, UStaticMesh* TreeMesh, int32 TreeCount);

	// Every tree and plant the game placed (written by the game with -RWExportPlants=<file>) as real instances of their models
	// in the level, replacing earlier ones: what is seen and edited here is what the game plants. Returns the instance count.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static int32 ImportPlants(const FString& File);

	// The game's whole scenery (written by the game with -RWExportScenery=<file>): buildings, rocks, road lines, bridges, water,
	// pipes... as real mesh and material assets and actors in the level, replacing earlier ones (editor only: the game builds its own).
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static int32 ImportScenery(const FString& File);

	// The ground's soils as the game has them (soil, sand, laterite, mud, gravel, rock, clay, packed ground, roads, grass,
	// wetness) baked into three textures for the Landscape's material (T_RWSurfA/B/C in /Game/Maps).
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool BakeSurface(int32 Size);

	// Gives the Landscape a material (the one with the game's soil textures).
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool SetLandscapeMaterial(UMaterialInterface* Material);

	// After saving the level: removes the files of the actors BuildMap replaced, or they would come back the next time the level opens.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static int32 FinishRebuild();

	// Writes what was sculpted in the loaded parts of the Landscape for the game to use. Returns the number of points changed (-1: no Landscape).
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static int32 BakeSculpt();

	// Forgets all sculpting: the game goes back to the plain generated ground.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool ClearSculpt();

	// Loads every part of the Landscape for editing (World Partition starts with none of it loaded). Done by itself when this map is opened.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool LoadWholeMap();

	// Raises (or with a negative height, lowers) a smooth hill on the Landscape's edit layer, the way the sculpt brush does. For scripts and checks.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static bool SculptHill(float X, float Y, float Radius, float Height);

	// What the renderer has of the Landscape, for checking; bRefresh asks for all its edit layers to be merged again.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static FString GroundReport(bool bRefresh);

	// One line for checking: Landscape size in metres, its actors, generated actors, seed.
	UFUNCTION(BlueprintCallable, Category = "RoadWorks|Map")
	static FString MapReport();

	// The Landscape is only the editor's copy: in play the game draws its own deformable terrain in its place.
	static void HideEditorGround(UWorld* World);
	// The lakes, road lines and forest placed in the level (RW_Lake, RW_Road, RW_Forest): the game builds its world from these.
	static void ReadLevelLayout(UWorld* World, class FRWLayout& Layout);
};

// the editor's hooks (bake before Play); nothing in a packaged game
void RWMapTools_RegisterEditorHooks();
