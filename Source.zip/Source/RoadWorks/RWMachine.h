// Base class for every drivable machine: engine + gearbox/hydrostatic drive, multi-point suspension,
// tyre/track traction against the soil model, sinkage & ruts, lights, doors, cameras, sound, fuel & wear.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "RWTypes.h"
#include "RWVehicleXml.h"
#include "RWMachine.generated.h"
class ARWTerrain;
class ARWEffects;
class URWEngineSynth;
class USpringArmComponent;
class UCameraComponent;
class USpotLightComponent;
class UPointLightComponent;
class UMaterialInstanceDynamic;
class UInstancedStaticMeshComponent;
class ARWProp;
struct FRWModMachine;

enum class EMachineKind : uint8
{
	Excavator, DumpTruck, Bulldozer, WheelLoader, Grader, Roller, Paver, WaterTruck, Crane, Count
};

enum class EDrive : uint8 { Wheeled, Articulated, Tracked };
enum class EShape : uint8 { Cube, Cylinder, Sphere, Cone };

struct FRWWheel
{
	FVector2D Local = FVector2D::ZeroVector; // metres; X forward, Y right
	float Radius = 0.55f;
	float Width = 0.45f;
	bool bSteer = false;
	bool bDriven = true;
	bool bFront = true;     // front frame for articulated machines
	bool bTrack = false;    // track road wheel (no mesh spin)
	bool bDual = false;     // rear dual tyre arrangement: separate inner/outer contact patches
	float Comp = 0, CompVel = 0, Load = 0, Spin = 0, Slip = 0, Ground = 0, Sink = 0;
	FVector2D LastImprint = FVector2D(1e9, 1e9);
	float RutSpinTimer = 0.f; // stationary spin only deforms soil at fixed intervals
	USceneComponent* Pivot = nullptr;   // steer pivot
	USceneComponent* Spinner = nullptr; // spinning hub
};

struct FHydCyl
{
	USceneComponent* A = nullptr; FVector ALocal;
	USceneComponent* B = nullptr; FVector BLocal;
	UStaticMeshComponent* Barrel = nullptr;
	UStaticMeshComponent* Rod = nullptr;
	float BarrelLen = 1.f;
	void Update();
};

struct FMachineSpec
{
	EMachineKind Kind; int32 Size; const TCHAR* Name; float Price; float RentPerDay; FLinearColor Color;
};
ROADWORKS_API const TArray<FMachineSpec>& MachineCatalog();

UCLASS(Abstract)
class ROADWORKS_API ARWMachine : public APawn
{
	GENERATED_BODY()
public:
	ARWMachine();
	virtual void BeginPlay() override;
	virtual void Tick(float Dt) override;
	// XML is strictly opt-in per machine (mod.json: "control_source": "xml").
	// mod.json remains a discovery/metadata file; its rig is replaced by XML at load.
	TUniquePtr<FRWVehicleXml> VehicleXml;
	// Only independently spawned GLB pivots are registered here; merged geometry cannot be animated.
	TMap<FString, TWeakObjectPtr<USceneComponent>> XmlGltfNodes;
	// the same parts' vertices (cm, in their own pivot's space): the XML hydraulics find a cylinder's pin ends from them
	TMap<FString, TArray<FVector>> XmlGltfNodePoints;
	FString ModFolder;
	bool bXmlControlRequested = false;
	bool bXmlControlValid = false;
	bool bVehicleXmlChecked = false;

	void Setup(ARWTerrain* InTerrain, ARWEffects* InFx, int32 InSize, const FVector& PosMetres, float YawDeg);
	void SimStep(float Dt); // full simulation step (Tick calls this; tests call it directly)

	// ---------- identity / economy ----------
	EMachineKind Kind = EMachineKind::Excavator;
	int32 Size = 1;
	int32 Id = 0;
	FString Model;
	float Price = 100000, RentPerDay = 800;
	bool bOwned = false, bRented = false;
	int32 UpEngine = 0, UpHyd = 0, UpTraction = 0, UpTool = 0;
	float Fuel = 200, FuelCap = 300, FuelRate = 20; // L, L, L/h at full load
	float Condition = 1.f, Hours = 0.f, Odometer = 0.f;
	float WearCostAccum = 0.f; // $ of parts consumed since last repair
	bool CanOperate() const { return bOwned || bRented; }

	// ---------- engine & drive ----------
	float IdleRpm = 750, MaxRpm = 2100, Rpm = 0, PowerKW = 120, EngineLoad = 0;
	float ThrottleDial = 0.85f; // hand throttle for work machines
	bool bEngineOn = false; float Cranking = 0.f;
	bool bHandThrottle = true;
	int32 Gear = 1, NumGears = 1; TArray<float> Ratios; float FinalDrive = 1.f; float ShiftTimer = 0.f;
	EDrive Drive = EDrive::Wheeled;
	float MaxSpeedF = 10.f, MaxSpeedR = 4.f, MaxSteer = 35.f, Wheelbase = 4.f, TrackGauge = 2.2f, TrackLength = 3.5f, TrackWidth = 0.6f;
	float BrakeDecel = 6.f; // design braking capacity (m/s2 at empty mass)
	float SteerAngle = 0.f; float Artic = 0.f;

	// ---------- body state (metres / degrees) ----------
	FVector PosM = FVector::ZeroVector;
	float Yaw = 0, Speed = 0, LatSpeed = 0, YawRate = 0;
	float BodyZ = 0, BodyVz = 0, Pitch = 0, PitchRate = 0, Roll = 0, RollRate = 0; // sprung body relative to wheel plane
	float GroundPitch = 0, GroundRoll = 0;
	float EmptyMass = 20000, CgHeight = 1.2f, RideHeight = 1.0f, SpringSag = 0.06f;
	float VibrationLevel = 0.f;
	TArray<FRWWheel> Wheels;
	float TrackSpeedL = 0, TrackSpeedR = 0, TrackTravelL = 0, TrackTravelR = 0;
	float Radius2D = 3.f;

	// ---------- inputs ----------
	float InThrottle = 0, InSteer = 0, InBrake = 0;
	float InA1 = 0, InA2 = 0, InA3 = 0, InA4 = 0; // R/F, T/G, Y/H, Q/E
	bool bParkBrake = true;

	// ---------- readouts ----------
	float Traction = 0.7f, WheelSlip = 0.f, Sinkage = 0.f, HydLoad = 0.f, WorkResist = 0.f, DrawbarLoad = 0.f;
	bool bStuck = false; float StuckTime = 0.f;
	ESoil GroundMat = ESoil::DrySoil; float GroundMoist = 0.f, GroundComp = 0.f;
	FString Warning;

	// ---------- lights / cab ----------
	bool bLights = false, bDoorOpen = false, bHoodOpen = false, bWipers = false, bBeacon = true;
	float DoorAngle = 0, HoodAngle = 0, WiperPhase = 0;

	// ---------- components ----------
	UPROPERTY(VisibleAnywhere) USceneComponent* Root = nullptr;
	UPROPERTY(VisibleAnywhere) USceneComponent* Body = nullptr;  // sprung mass (pitch / roll / heave)
	UPROPERTY(VisibleAnywhere) USpringArmComponent* Arm = nullptr;
	UPROPERTY(VisibleAnywhere) UCameraComponent* ThirdCam = nullptr;
	UPROPERTY(VisibleAnywhere) UCameraComponent* CabCam = nullptr;
	UPROPERTY() URWEngineSynth* Synth = nullptr;
	bool bSoundRunning = false; // the engine running (or being started) as the sound last knew it: starts and stops play once
	UPROPERTY() TArray<USpotLightComponent*> Lamps;
	UPROPERTY() TArray<UMaterialInstanceDynamic*> LampMIDs;
	UPROPERTY() UPointLightComponent* BeaconLight = nullptr;
	UPROPERTY() USceneComponent* DoorPivot = nullptr;
	UPROPERTY() USceneComponent* HoodPivot = nullptr;
	UPROPERTY() USceneComponent* WiperPivot = nullptr;
	UPROPERTY() USceneComponent* CabRoot = nullptr;
	// track shoes: one holder per side with a separate component per shoe (never culled as a batch)
	UPROPERTY() USceneComponent* ShoesL = nullptr;
	UPROPERTY() USceneComponent* ShoesR = nullptr;
	UPROPERTY() TArray<UStaticMeshComponent*> ShoeCompsL;
	UPROPERTY() TArray<UStaticMeshComponent*> ShoeCompsR;
	// track loop shape: wheel centres at CX +- Half, height Zc, wrap radius TrackRadOverride (0 = derive from size)
	float TrackLoopCX = 0.f, TrackLoopZc = 0.f, TrackLoopHalf = 0.f;
	float LastShoeTravelL = 1e9f, LastShoeTravelR = 1e9f;
	FVector2D LastPrint[2] = {FVector2D(1e9f), FVector2D(1e9f)}; // where each track last pressed its grouser pattern
	bool bRigidFrame = false;
	// propped on the bucket: the whole machine tilts about the far edge of its tracks (degrees, towards PropDir)
	float PropAngle = 0.f;
	FVector2D PropDir = FVector2D(1, 0);
	float PropPivot = 2.f; // metres from the machine centre to the edge it tips about
	// ---- stability: the machine's mass in parts (where each is now), the soil's force on its tool; from them the centre of
	// mass, where the weight and the forces meet the ground against the tracks' support, the load on each corner - and only
	// when they really carry it over an edge, the whole machine tipping about that edge (crawlers; wheeled machines keep
	// their sprung body). It turns the machine through ApplyTransform, like the old prop-lift did: nothing else places it.
	struct FMassPart { FString Name; float Kg = 0.f; FVector At = FVector::ZeroVector; FString Source; }; // At: world, m
	virtual void MassParts(TArray<FMassPart>& Out) const;
	// the soil's force on the working tool (world, N) and where it acts (world, m); zero when nothing pushes on it
	virtual FVector ToolForceN(FVector& AtWorld) const { AtWorld = PosM; return FVector::ZeroVector; }
	void StabilityStep(float Dt);
	FVector TestToolForceN = FVector::ZeroVector, TestToolAt = FVector::ZeroVector; // (tests: a force put on the tool instead)
	FVector ComLocal = FVector::ZeroVector;      // centre of mass (machine frame, m)
	float TotalMassKg = 0.f;
	FVector2D WeightAt = FVector2D::ZeroVector;  // where the resultant of weight and tool force meets the ground (machine frame, m)
	float StabilityMargin = 0.f;                 // m inside the support's nearest edge; negative = past it
	float CornerLoad[4] = {0.f, 0.f, 0.f, 0.f};  // N on the front left, front right, rear left, rear right of the support
	float TipAngle = 0.f, TipRate = 0.f;         // the whole machine tipped about an edge (deg, deg/s)
	FVector2D TipDir = FVector2D(1.f, 0.f);      // that edge's outward direction (machine frame)
	float TipPivot = 2.f;                        // its distance from the machine centre (m)
	bool bStabilityLogged = false;
	TMap<FString, float> XmlMassKg;              // vehicle.xml <mass><part name="..." kg="..."/></mass>, by lower-case name
	UPROPERTY() UMaterialInterface* TrackShoeMat = nullptr;
	UPROPERTY() UStaticMesh* TrackShoeMesh[2] = {nullptr, nullptr}; // the shoe taken from a model's own chain, per side (none = the game's generated shoe)
	float TrackShoePitch = 0.19f; // length of one link of the chain (m)
	int32 ModelTrackLinkCount[2] = {0, 0}; // exact count per side if source GLB supplies a complete ordered loop
	void BuildTrackShoes(float Width);
	void TrackLoop(float& Rad, float& Half, float& CX, float& Zc) const;
	UPROPERTY() UMaterialInstanceDynamic* PaintMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* DarkMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* SteelMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* ChromeMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* RubberMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* GlassMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* SeatMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* GaugeMID = nullptr;
	UPROPERTY() UMaterialInstanceDynamic* BeaconMID = nullptr;
	UPROPERTY() ARWTerrain* Terrain = nullptr;
	UPROPERTY() ARWEffects* Fx = nullptr;
	float Dirt = 0.f, Wear = 0.f;
	float MaterialUpdateAccumulator = 0.f;
	float CamYaw = 0.f, CamPitch = -15.f, CamDist = 14.f;
	float CabYaw = 0.f, CabPitch = -8.f;
	FVector SeatPos = FVector(0, 0, 2);
	bool bCabView = false;
	float HornTime = 0.f;

	// ---------- behaviour hooks for each machine type ----------
	virtual void Build() {}
	virtual void WorkTick(float Dt) {}
	virtual void VisualTick(float Dt) {}
	virtual FString HelpText() const;
	virtual FString ToolText() const { return FString(); }
	virtual bool TryReceive(const FVector& P, ESoil M, float Vol, float Moist) { return false; }
	virtual float PayloadKg() const { return 0.f; }
	virtual void ToolCycle() {}
	virtual void WorkToggle() {}
	virtual void Interact() {}
	// Point used by the machine-control (GPS) grade display: world metres.
	virtual bool GradePoint(FVector& Out) const { return false; }
	virtual void SerializeState(FArchive& Ar);
	virtual float WorkPowerKW() const { return 0.f; }

	// ---------- helpers ----------
	float Mass() const { return EmptyMass + PayloadKg(); }
	FVector Fwd2() const { return FVector(FMath::Cos(FMath::DegreesToRadians(Yaw)), FMath::Sin(FMath::DegreesToRadians(Yaw)), 0); }
	FVector Right2() const { return FVector(-FMath::Sin(FMath::DegreesToRadians(Yaw)), FMath::Cos(FMath::DegreesToRadians(Yaw)), 0); }
	FVector LocalToWorldM(const FVector& L) const; // root (yaw only) frame
	FVector BodyToWorldM(const FVector& L) const;  // sprung body frame
	FVector WorldToBodyM(const FVector& W) const;
	float HydSpeedScale() const;
	float RpmFrac() const { return bEngineOn ? FMath::Clamp((Rpm - IdleRpm * 0.6f) / (MaxRpm - IdleRpm * 0.6f), 0.f, 1.f) : 0.f; }
	void ToggleEngine();
	UStaticMeshComponent* Part(USceneComponent* Parent, EShape Shape, const FVector& LocM, const FVector& SizeM, const FRotator& Rot, UMaterialInterface* Mat, bool bUnit = false);
	UStaticMeshComponent* MeshPart(USceneComponent* Parent, UStaticMesh* Mesh, const FVector& LocM, const FRotator& Rot, UMaterialInterface* Mat, const FVector& Scale = FVector::OneVector);
	int32 TyreStyle = 0;
	USceneComponent* Pivot(USceneComponent* Parent, const FVector& LocM, const FRotator& Rot = FRotator::ZeroRotator);
	void AddWheel(const FVector2D& Local, float R, float W, bool bSteer, bool bDriven, bool bFrontFrame, bool bDual = false);
	FString ModId; // set when the machine comes from a mod definition
	float ModScale = 1.f;
	// Where the operator climbs in (ground beside the cab door) and where they sit (world metres).
	virtual FVector EntryWorld() const;
	virtual FVector SeatWorld() const;
	float LastServiceHours = 0.f;
	static const FRWModMachine* PendingMod;
	void AddTracks(float Length, float Gauge, float Width, float Height, int32 RoadWheels);
	void AddCab(USceneComponent* Parent, const FVector& LocM, const FVector& SizeM, bool bRops = false);
	void AddLamp(USceneComponent* Parent, const FVector& LocM, const FRotator& Dir, float Intensity, bool bWork);
	// a lamp where a model says (no housing of the game's: the model has its own); lumens, cone half angle (deg), reach (m)
	void AddLampAt(USceneComponent* Parent, const FVector& LocM, const FRotator& Dir, float Lumens, float OuterDeg, float RangeM, const FLinearColor& Color, bool bWork);
	FHydCyl MakeCyl(USceneComponent* A, const FVector& ALocalM, USceneComponent* B, const FVector& BLocalM, float Radius, float BarrelLen);
	void SetPaint(const FLinearColor& C);
	void ApplyDirt();
	float GroundAt(float X, float Y) const;

	TArray<FHydCyl> Cyls;
	static UStaticMesh* MeshFor(EShape S);
	static UMaterialInterface* GPaint;
	static UMaterialInterface* GGlass;
	static UMaterialInterface* GEmissive;
	static UStaticMesh* GCube;
	static UStaticMesh* GCyl;
	static UStaticMesh* GSphere;
	static UStaticMesh* GCone;
	static float TimeScale; // game-clock seconds per real second (fuel, wear, hours, rent)
	float RootZ = 0.f;
	float RootVz = 0.f, PitchVel = 0.f, RollVel = 0.f, PrevSpeed = 0.f, SmoothAcc = 0.f;
	bool bFrameInit = false;
	float TrackRadOverride = 0.f, TrackShoeZ = 0.02f; // track loop shape when a model supplies the undercarriage
	struct FSpinner { USceneComponent* P = nullptr; float Radius = 0.3f; bool bLeft = true; FQuat Rest = FQuat::Identity; };
	TArray<FSpinner> TrackSpinners;
	// closed shoe path per side (x,z metres, clockwise: bottom run front->rear), wrapped around the model's wheels
	// flexible hydraulic hose across a moving joint: fixed length, hangs/loops with a smooth curve
	struct FHose
	{
		USceneComponent* A = nullptr; FVector OffA = FVector::ZeroVector; // metres, in A's frame
		USceneComponent* B = nullptr; FVector OffB = FVector::ZeroVector;
		float Length = 1.f, Radius = 0.03f, MinBend = 0.15f;
		FVector LoopDir = FVector(0, 0, 1); // in A's frame: which way the slack loops (keeps it clear of the steel)
		TArray<UStaticMeshComponent*> Segs;
		float CurveLen = 0.f, Sag = 0.f, MinRadius = 1e9f; bool bTaut = false; // last solved shape (tests / debugging)
		float Spread = 0.5f; // how far the loop opens sideways (chosen each frame for the gentlest bend)
		FVector LastP0 = FVector(1e9f), LastP1 = FVector(1e9f); // re-solve only when an end moved
	};
	TArray<FHose> Hoses;
	static bool bNoHoses; // -rwnohoses (performance comparison)
	int32 AddHose(USceneComponent* A, const FVector& OffA, USceneComponent* B, const FVector& OffB, float Radius, float Length, const FVector& LoopDir);
	// longest end-to-end distance while the joint swings through [Lo, Hi] (pitch, degrees): hose length must cover it
	float HoseReach(USceneComponent* Joint, float Lo, float Hi, USceneComponent* A, const FVector& OffA, USceneComponent* B, const FVector& OffB) const;
	void UpdateHoses();
	static void HoseCurve(const FHose& H, float Sag, TArray<FVector>& Out);
	struct FTrackPath { TArray<FVector2D> P; TArray<float> S; float Y = 0.f; float Len = 0.f; };
	FTrackPath TrackPaths[2];
	void SetTrackPath(int32 Side, const TArray<FVector2D>& Pts, float Y);
	void SetOrderedTrackPath(int32 Side, const TArray<FVector2D>& Pts, float Y);
	float StepRes = 0.f;
	float DrivePowerKW = 0.f;
	static TFunction<float(float, float, float)> GroundOverride; // bridges/structures (unused if null)
	static TFunction<bool(ARWMachine*, FVector&)> CollisionResolver; // world obstacles & other machines
	// knocks over trees and pushes fallen trunks and rocks at a world point (m): reach R, speed, half the height of the tool
	static TFunction<int32(const FVector&, float, const FVector&, float)> TreeHitter;
	static TFunction<bool(const FVector&, float&)> DesignGrade; // active road / job design height at a point

	void TestDriveStep(float Dt) { DriveStep(Dt); } // (the self tests drive on a slope they set themselves)
private:
	void EngineStep(float Dt, float Demand, float LoadTorqueFrac);
	void DriveStep(float Dt);
	void SuspensionStep(float Dt);
	void GroundEffects(float Dt);
	void UpdateWheelVisuals(float Dt);
	void UpdateTrackVisuals();
	void ApplyTransform();
	float LastDust = 0.f;
};
