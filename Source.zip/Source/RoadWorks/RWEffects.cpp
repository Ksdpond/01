#include "RWEffects.h"
#include "RWTerrain.h"
#include "RWMachine.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "RWMeshGen.h"
#include "RWSoilLook.h"

ARWEffects::ARWEffects()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

static UInstancedStaticMeshComponent* MakeISM(AActor* Owner, const TCHAR* Name, UStaticMesh* Mesh, UMaterialInterface* Mat, int32 Pool, bool bShadow)
{
	UInstancedStaticMeshComponent* I = NewObject<UInstancedStaticMeshComponent>(Owner, Name);
	I->SetupAttachment(Owner->GetRootComponent());
	I->SetStaticMesh(Mesh);
	I->SetMaterial(0, Mat);
	I->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	I->SetCastShadow(bShadow);
	I->SetMobility(EComponentMobility::Movable);
	I->RegisterComponent();
	TArray<FTransform> T; T.Init(FTransform(FQuat::Identity, FVector(0, 0, -100000), FVector::ZeroVector), Pool);
	I->AddInstances(T, false, true);
	return I;
}

void ARWEffects::Init(ARWTerrain* InTerrain, UStaticMesh* Sphere, UStaticMesh* Cube, UMaterialInterface* Paint, UMaterialInterface* DustMat, UMaterialInterface* RainMat)
{
	Terrain = InTerrain;
	for (int32 m = 0; m < SOIL_COUNT; ++m)
	{
		// flying clods: lumpy rock-like meshes with the soil's own texture set
		UMaterialInstanceDynamic* MID = FRWSoilLook::Make(this, (ESoil)m, 0.3f);
		const FSoilProps& P = SoilProps((ESoil)m);
		SoilISM.Add(MakeISM(this, *FString::Printf(TEXT("SoilISM%d"), m), FRWMeshGen::Rock(1.f, 20 + m), MID, SoilPool, true));
		(void)Sphere; (void)Cube;
		// track imprints: pressed soil is darker and slightly smoother than the ground around it
		UMaterialInstanceDynamic* PM = UMaterialInstanceDynamic::Create(Paint, this);
		PM->SetVectorParameterValue(TEXT("Color"), FMath::Lerp(P.Color, P.WetColor, 0.7f) * 0.72f);
		PM->SetScalarParameterValue(TEXT("Roughness"), 0.8f);
		PM->SetScalarParameterValue(TEXT("Metallic"), 0.f);
		UInstancedStaticMeshComponent* PrI = MakeISM(this, *FString::Printf(TEXT("PrintISM%d"), m), FRWMeshGen::TrackPrint(), PM, PrintPool, false);
		PrintISM.Add(PrI);
		Prints[m].SetNum(PrintPool);
	}
	UMaterialInstanceDynamic* WM = UMaterialInstanceDynamic::Create(RainMat, this);
	WaterISM = MakeISM(this, TEXT("WaterISM"), Sphere, WM, WaterPool, false);
	DustISM = MakeISM(this, TEXT("DustISM"), Sphere, DustMat, MaxDust, false);
	RainISM = MakeISM(this, TEXT("RainISM"), Cube, RainMat, RainPool, false);
	RainPos.SetNum(RainPool);
	for (FVector& P : RainPos) P = FVector(FMath::FRandRange(-30.f, 30.f), FMath::FRandRange(-30.f, 30.f), FMath::FRandRange(-5.f, 25.f));
}

void ARWEffects::SpawnSoil(const FVector& P, const FVector& V, const FPayload& Load, float Spread)
{
	for (int32 m = 0; m < SOIL_COUNT; ++m)
	{
		float Vol = Load.Vol[m];
		if (Vol <= 1e-6f) continue;
		// Split into clods of ~0.03-0.08 m3; if the pool is full, merge into existing volume.
		// pouring soil breaks into many fist- to football-sized lumps (rock stays in bigger pieces)
		// (a pour is a stream of many small crumbs and a few lumps, not a shower of footballs)
		const float Clod = (m == (int32)ESoil::LargeRock) ? 0.12f : 0.005f;
		int32 Count = FMath::Clamp(FMath::CeilToInt(Vol / Clod), 1, 24);
		const int32 Live = Soil.Num();
		if (Live + Count > SoilPool * 3) Count = 1;
		for (int32 k = 0; k < Count; ++k)
		{
			FClod C;
			C.P = P + FVector(FMath::FRandRange(-Spread, Spread), FMath::FRandRange(-Spread, Spread), FMath::FRandRange(-0.1f, 0.1f));
			C.V = V + FVector(FMath::FRandRange(-0.4f, 0.4f), FMath::FRandRange(-0.4f, 0.4f), FMath::FRandRange(-0.2f, 0.3f));
			C.Vol = Vol / Count; C.Moist = Load.Moist; C.Mat = (uint8)m; C.Life = 0;
			Soil.Add(C);
		}
	}
}

void ARWEffects::SpawnWater(const FVector& P, const FVector& V, float Amount)
{
	if (Water.Num() >= WaterPool) return;
	FDrop D; D.P = P; D.V = V + FVector(FMath::FRandRange(-0.6f, 0.6f), FMath::FRandRange(-0.6f, 0.6f), FMath::FRandRange(-0.3f, 0.3f)); D.Amount = Amount; D.Life = 0;
	Water.Add(D);
}

void ARWEffects::SpawnDust(const FVector& P, float Size, const FVector& V, FLinearColor)
{
	if (Dust.Num() >= MaxDust) return;
	FPuff D; D.P = P; D.V = V + FVector(FMath::FRandRange(-0.4f, 0.4f), FMath::FRandRange(-0.4f, 0.4f), FMath::FRandRange(0.1f, 0.6f));
	D.Size = Size; D.Life = 0; D.MaxLife = FMath::FRandRange(1.8f, 3.5f);
	Dust.Add(D);
}

void ARWEffects::SpawnChunks(const FVector& P, const FVector& V, ESoil M, float Moist, int32 Count, float Size)
{
	int32 Live = 0; for (const FClod& C : Soil) Live += C.bVisual ? 1 : 0;
	for (int32 k = 0; k < Count && Live < SoilPool * 3 / 4; ++k, ++Live)
	{
		FClod C;
		C.P = P + FVector(FMath::FRandRange(-0.25f, 0.25f), FMath::FRandRange(-0.25f, 0.25f), FMath::FRandRange(0.f, 0.1f));
		C.V = V + FVector(FMath::FRandRange(-0.5f, 0.5f), FMath::FRandRange(-0.5f, 0.5f), FMath::FRandRange(0.f, 0.6f));
		C.Vol = Size * FMath::FRandRange(0.6f, 1.3f); // visual chunks keep their size here, not a volume
		C.Moist = Moist; C.Mat = (uint8)M; C.Life = 0; C.bVisual = true;
		Soil.Add(C);
	}
}

void ARWEffects::AddTrackPrint(const FVector& P, float YawDeg, const FVector& Normal, float Width, ESoil Ground, float Press)
{
	const int32 m = FMath::Clamp((int32)Ground, 0, SOIL_COUNT - 1);
	if (PrintISM.Num() != SOIL_COUNT) return;
	FPrint& Pr = Prints[m][PrintNext[m]];
	PrintNext[m] = (PrintNext[m] + 1) % PrintPool; // oldest imprint makes room
	const FQuat Tilt = FQuat::FindBetweenNormals(FVector::UpVector, Normal.GetSafeNormal());
	Pr.P = P; Pr.Q = Tilt * FRotator(0, YawDeg, 0).Quaternion(); Pr.Width = Width; Pr.Press = Press; Pr.bOn = true;
	bPrintsDirty[m] = true;
}

int32 ARWEffects::TrackPrintCount() const
{
	int32 N = 0;
	for (int32 m = 0; m < SOIL_COUNT; ++m) for (const FPrint& Pr : Prints[m]) N += Pr.bOn ? 1 : 0;
	return N;
}

double ARWEffects::InFlightVolume() const
{
	double S = 0; for (const FClod& C : Soil) if (!C.bVisual) S += C.Vol; return S;
}

void ARWEffects::Land(const FClod& C)
{
	if (C.bVisual) return;
	for (const TWeakObjectPtr<ARWMachine>& R : Receivers)
		if (R.IsValid() && R->TryReceive(C.P, (ESoil)C.Mat, C.Vol, C.Moist)) return;
	FPayload P; P.Add((ESoil)C.Mat, C.Vol, C.Moist);
	Terrain->DepositDisc(C.P.X, C.P.Y, 0.55f, P);
	Terrain->SettleAround(C.P.X, C.P.Y, 1.f, 2, [](int32) { return false; }); // (a fast pour settles as it lands)
}

void ARWEffects::SettleAll()
{
	for (const FClod& C : Soil)
	{
		if (C.bVisual) continue;
		FClod L = C; L.P.Z = Terrain->HeightAt(C.P.X, C.P.Y);
		Land(L);
	}
	Soil.Reset();
	Water.Reset();
}

void ARWEffects::UpdatePool(UInstancedStaticMeshComponent* ISM, int32 Pool, TFunctionRef<bool(int32, FTransform&)> Get)
{
	TArray<FTransform> T; T.SetNumUninitialized(Pool);
	for (int32 k = 0; k < Pool; ++k)
	{
		if (!Get(k, T[k])) T[k] = FTransform(FQuat::Identity, FVector(0, 0, -100000), FVector::ZeroVector);
	}
	ISM->BatchUpdateInstancesTransforms(0, T, true, true, true);
}

void ARWEffects::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Terrain || !bEnabled) return;
	Dt = FMath::Min(Dt, 0.05f);
	// --- soil clods ---
	for (int32 k = Soil.Num() - 1; k >= 0; --k)
	{
		FClod& C = Soil[k];
		C.V.Z -= GRAV * Dt;
		C.V *= 1.f - 0.15f * Dt;
		const FVector Prev = C.P;
		C.P += C.V * Dt;
		C.Life += Dt;
		bool bDone = false;
		if (C.bVisual)
		{
			// breakout lump: lands, rolls a little and crumbles into the ground within a second
			const float G = Terrain->HeightAt(C.P.X, C.P.Y) + C.Vol * 0.3f;
			if (C.P.Z <= G || C.Rest > 0.f)
			{
				C.P.Z = FMath::Max(C.P.Z, G);
				C.V = FVector(C.V.X * 0.3f, C.V.Y * 0.3f, 0.f);
				C.Rest += Dt;
			}
			if (C.Rest > 0.9f || C.Life > 5.f) Soil.RemoveAtSwap(k, 1, EAllowShrinking::No);
			continue;
		}
		// receivers first: a clod passing through a truck bed is caught
		for (const TWeakObjectPtr<ARWMachine>& R : Receivers)
		{
			if (R.IsValid() && C.V.Z < 0 && R->TryReceive(C.P, (ESoil)C.Mat, C.Vol, C.Moist)) { bDone = true; break; }
		}
		if (!bDone)
		{
			const float G = Terrain->HeightAt(C.P.X, C.P.Y);
			if (C.P.Z <= G || C.Life > 6.f)
			{
				C.P.Z = G;
				FPayload P; P.Add((ESoil)C.Mat, C.Vol, C.Moist);
				Terrain->DepositDisc(C.P.X, C.P.Y, 0.55f, P);
				// a pour (a loader or a bucket emptied in one place) settles as it lands, instead of standing up in a column
				// while the slow settling queue catches up
				Terrain->SettleAround(C.P.X, C.P.Y, 1.f, 2, [](int32) { return false; });
				if (C.Moist < 0.4f && Dust.Num() < MaxDust && FMath::FRand() < 0.25f) SpawnDust(C.P, 0.6f, FVector::ZeroVector);
				bDone = true;
			}
		}
		(void)Prev;
		if (bDone) Soil.RemoveAtSwap(k, 1, EAllowShrinking::No);
	}
	// --- water spray ---
	for (int32 k = Water.Num() - 1; k >= 0; --k)
	{
		FDrop& D = Water[k];
		D.V.Z -= GRAV * Dt;
		D.P += D.V * Dt;
		D.Life += Dt;
		const float G = Terrain->HeightAt(D.P.X, D.P.Y);
		if (D.P.Z <= G || D.Life > 4.f)
		{
			const int32 CX = Terrain->ToGrid(D.P.X), CY = Terrain->ToGrid(D.P.Y);
			for (int32 dy = -2; dy <= 2; ++dy)
				for (int32 dx = -2; dx <= 2; ++dx)
					if (Terrain->Valid(CX + dx, CY + dy)) Terrain->AddMoisture(Terrain->Idx(CX + dx, CY + dy), D.Amount);
			Water.RemoveAtSwap(k, 1, EAllowShrinking::No);
		}
	}
	// --- dust ---
	for (int32 k = Dust.Num() - 1; k >= 0; --k)
	{
		FPuff& D = Dust[k];
		D.Life += Dt;
		D.P += D.V * Dt;
		D.V *= 1.f - 0.8f * Dt;
		D.V.Z += 0.15f * Dt;
		if (D.Life > D.MaxLife) Dust.RemoveAtSwap(k, 1, EAllowShrinking::No);
	}

	// --- render ---
	TArray<int32> Counts; Counts.Init(0, SOIL_COUNT);
	TArray<TArray<FTransform>> PerMat; PerMat.SetNum(SOIL_COUNT);
	for (const FClod& C : Soil)
	{
		if (PerMat[C.Mat].Num() >= SoilPool) continue;
		if (C.bVisual)
		{
			const float Sh = 1.f - FMath::Clamp(C.Rest / 0.9f, 0.f, 1.f); // crumbles as it settles
			const float Spin = C.Rest > 0.f ? 0.f : C.Life;
			PerMat[C.Mat].Add(FTransform(FRotator(Spin * 260.f + C.Vol * 900.f, Spin * 170.f, C.Vol * 400.f).Quaternion(), C.P * M2CM, FVector(C.Vol, C.Vol * 0.8f, C.Vol * 0.65f) * FMath::Max(Sh, 0.05f)));
			continue;
		}
		const float R = FMath::Clamp(FMath::Pow(C.Vol, 1.f / 3.f) * 0.6f, 0.035f, 0.4f);
		PerMat[C.Mat].Add(FTransform(FRotator(C.Life * 200.f, C.Life * 130.f, 0).Quaternion(), C.P * M2CM, FVector(R * 2.f)));
	}
	for (int32 m = 0; m < SOIL_COUNT; ++m)
	{
		static TArray<int32> LastCount; if (LastCount.Num() != SOIL_COUNT) LastCount.Init(SoilPool, SOIL_COUNT);
		if (PerMat[m].Num() == 0 && LastCount[m] == 0) continue;
		LastCount[m] = PerMat[m].Num();
		UpdatePool(SoilISM[m], SoilPool, [&](int32 k, FTransform& T) { if (k < PerMat[m].Num()) { T = PerMat[m][k]; return true; } return false; });
	}
	{
		static int32 LastW = WaterPool;
		if (Water.Num() > 0 || LastW > 0)
		{
			LastW = Water.Num();
			UpdatePool(WaterISM, WaterPool, [&](int32 k, FTransform& T) { if (k < Water.Num()) { T = FTransform(FQuat::Identity, Water[k].P * M2CM, FVector(0.09f)); return true; } return false; });
		}
	}
	{
		static int32 LastD = 1;
		if (Dust.Num() > 0 || LastD > 0)
		{
			LastD = Dust.Num();
			UpdatePool(DustISM, MaxDust, [&](int32 k, FTransform& T)
			{
				if (k >= Dust.Num()) return false;
				const FPuff& D = Dust[k];
				const float A = D.Life / D.MaxLife;
				const float S = D.Size * (0.4f + 2.2f * A) * (1.f - A * A);
				T = FTransform(FQuat::Identity, D.P * M2CM, FVector(FMath::Max(S, 0.01f)));
				return true;
			});
		}
	}
	// --- track imprints: a few are re-checked each frame; dug, filled or pushed ground wipes them out ---
	if (PrintISM.Num() == SOIL_COUNT)
	{
		for (int32 n = 0; n < 48; ++n)
		{
			PrintCheck = (PrintCheck + 1) % (PrintPool * SOIL_COUNT);
			const int32 m = PrintCheck / PrintPool, k = PrintCheck % PrintPool;
			FPrint& Pr = Prints[m][k];
			if (Pr.bOn && FMath::Abs(Terrain->HeightAt(Pr.P.X, Pr.P.Y) - Pr.P.Z) > 0.12f) { Pr.bOn = false; bPrintsDirty[m] = true; }
		}
		for (int32 m = 0; m < SOIL_COUNT; ++m)
		{
			if (!bPrintsDirty[m]) continue;
			bPrintsDirty[m] = false;
			UpdatePool(PrintISM[m], PrintPool, [&](int32 k, FTransform& T)
			{
				const FPrint& Pr = Prints[m][k];
				if (!Pr.bOn) return false;
				T = FTransform(Pr.Q, Pr.P * M2CM, FVector(1.f, Pr.Width, Pr.Press));
				return true;
			});
		}
	}
	// --- rain streaks around the camera ---
	{
		static bool bWasRaining = true;
		const int32 Visible = FMath::RoundToInt(RainPool * FMath::Clamp(RainIntensity, 0.f, 1.f));
		if (Visible > 0 || bWasRaining)
		{
			bWasRaining = Visible > 0;
			const FVector Wind(1.2f, 0.6f, -9.f);
			for (int32 k = 0; k < Visible; ++k)
			{
				FVector& P = RainPos[k];
				P += Wind * Dt;
				if (P.Z < -6.f) P = FVector(FMath::FRandRange(-30.f, 30.f), FMath::FRandRange(-30.f, 30.f), FMath::FRandRange(14.f, 24.f));
			}
			const FQuat Q = FRotationMatrix::MakeFromZ(-Wind.GetSafeNormal()).ToQuat();
			UpdatePool(RainISM, RainPool, [&](int32 k, FTransform& T)
			{
				if (k >= Visible) return false;
				T = FTransform(Q, (CamM + RainPos[k]) * M2CM, FVector(0.006f, 0.006f, 0.55f));
				return true;
			});
		}
	}
}
