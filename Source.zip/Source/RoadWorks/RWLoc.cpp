#include "RWLoc.h"
#include "RWTypes.h"
#include "Engine/Font.h"
#include "Engine/Engine.h"
#include "Fonts/CompositeFont.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"

int32 GRWLang = 1;
static TMap<FString, FString> GThai;
static UFont* GFontN = nullptr;
static UFont* GFontB = nullptr;

static FString SettingsFile() { return FPaths::ProjectSavedDir() / TEXT("Config") / TEXT("RoadWorksSettings.txt"); }

void RWLocAdd(const FString& En, const FString& Th)
{
	if (!En.IsEmpty() && !Th.IsEmpty()) GThai.Add(En, Th);
}

void RWLocSaveSetting()
{
	FFileHelper::SaveStringToFile(FString::Printf(TEXT("Lang=%s\n"), GRWLang == 1 ? TEXT("th") : TEXT("en")), *SettingsFile());
}

static UFont* MakeFont(const FString& Latin, const FString& Thai, int32 Size)
{
	UFont* F = NewObject<UFont>(GetTransientPackage(), NAME_None, RF_Transient);
	F->AddToRoot();
	F->FontCacheType = EFontCacheType::Runtime;
	F->LegacyFontSize = Size;
	F->CompositeFont.DefaultTypeface.Fonts.Add(FTypefaceEntry(TEXT("Regular"), Latin, EFontHinting::Default, EFontLoadingPolicy::LazyLoad));
	FCompositeSubFont Sub;
	Sub.Typeface.Fonts.Add(FTypefaceEntry(TEXT("Regular"), Thai, EFontHinting::Default, EFontLoadingPolicy::LazyLoad));
	Sub.CharacterRanges.Add(FInt32Range(0x0E00, 0x0E80));
	F->CompositeFont.SubTypefaces.Add(Sub);
	return F;
}

void RWLocInit()
{
	// language setting
	FString S;
	if (FFileHelper::LoadFileToString(S, *SettingsFile())) GRWLang = S.Contains(TEXT("Lang=en")) ? 0 : 1;
	if (FParse::Param(FCommandLine::Get(), TEXT("english"))) GRWLang = 0;
	// built-in Thai table
	TArray<FString> Lines;
	const FString File = FPaths::ProjectContentDir() / TEXT("Lang") / TEXT("th.txt");
	if (FFileHelper::LoadFileToStringArray(Lines, *File))
	{
		for (const FString& L : Lines)
		{
			if (L.StartsWith(TEXT("#"))) continue;
			FString En, Th;
			if (L.Split(TEXT(" => "), &En, &Th)) RWLocAdd(En.Replace(TEXT("\\n"), TEXT("\n")), Th.TrimEnd().Replace(TEXT("\\n"), TEXT("\n")));
		}
		RWLog(FString::Printf(TEXT("Thai translation: %d strings"), GThai.Num()));
	}
	else RWLog(FString::Printf(TEXT("Thai translation file missing: %s"), *File));
	// fonts (Roboto + Noto Sans Thai, both open licences, shipped as loose files in Content/Fonts)
	const FString Dir = FPaths::ProjectContentDir() / TEXT("Fonts");
	if (IFileManager::Get().FileExists(*(Dir / TEXT("NotoSansThai-Regular.ttf"))))
	{
		GFontN = MakeFont(Dir / TEXT("Roboto-Regular.ttf"), Dir / TEXT("NotoSansThai-Regular.ttf"), 15);
		GFontB = MakeFont(Dir / TEXT("Roboto-Bold.ttf"), Dir / TEXT("NotoSansThai-Regular.ttf"), 20);
	}
	else RWLog(TEXT("Thai font missing - falling back to engine font"));
}

FString TR(const FString& En)
{
	if (GRWLang == 1)
		if (const FString* T = GThai.Find(En)) return *T;
	return En;
}

UFont* RWFont(bool bBig)
{
	if (bBig && GFontB) return GFontB;
	if (!bBig && GFontN) return GFontN;
	return bBig ? GEngine->GetLargeFont() : GEngine->GetMediumFont();
}

FString RWNum(double V, int32 D)
{
	if (D <= 0) return FText::AsNumber((int64)FMath::RoundToDouble(V)).ToString();
	return FString::Printf(TEXT("%.*f"), D, V);
}
