#include "RWVehicleXml.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "XmlFile.h"
#include "Components/SceneComponent.h"
#include "Misc/Paths.h"

namespace
{
FString Attr(const FXmlNode* N, const TCHAR* K, const TCHAR* Default=TEXT(""))
{
 const FString V=N->GetAttribute(K); return V.IsEmpty()?FString(Default):V;
}
float Num(const FXmlNode* N, const TCHAR* K, float Default)
{
 const FString V=N->GetAttribute(K); if(V.IsEmpty()) return Default;
 float Parsed=Default;
 return LexTryParseString(Parsed,*V) && FMath::IsFinite(Parsed) ? Parsed : Default;
}
USceneComponent* Find(ARWMachine* Owner, const FString& Name)
{
 if(Name.IsEmpty()) return nullptr;
 // GLB mesh nodes are not UE components by default. These registered nodes were
 // explicitly split from the merged mesh by RWModelRig.cpp.
 if(const TWeakObjectPtr<USceneComponent>* Match=Owner->XmlGltfNodes.Find(Name.ToLower()))
  if(Match->IsValid()) return Match->Get();
 TArray<USceneComponent*> Components;
 Owner->GetComponents<USceneComponent>(Components);
 for(USceneComponent* C:Components)
  if(C && C->GetName().Equals(Name,ESearchCase::IgnoreCase)) return C;
 return nullptr;
}
float InputValue(const ARWMachine* M,const FString& Name)
{
 if(Name.Equals(TEXT("A1"),ESearchCase::IgnoreCase)) return M->InA1;
 if(Name.Equals(TEXT("A2"),ESearchCase::IgnoreCase)) return M->InA2;
 if(Name.Equals(TEXT("A3"),ESearchCase::IgnoreCase)) return M->InA3;
 if(Name.Equals(TEXT("A4"),ESearchCase::IgnoreCase)) return M->InA4;
 return 0.f;
}
// pins="auto": a cylinder's two pin ends found from the shape of its parts. The line from the barrel's middle to the rod's
// middle is the cylinder's axis; the barrel's base pin is its far end along that line (the end away from the rod), the rod's
// eye pin is the rod's far end (away from the barrel). Both in world space (cm).
bool AutoPins(ARWMachine* Owner,const FString& BarrelName,const FString& RodName,USceneComponent* Barrel,USceneComponent* Rod,FVector& BasePin,FVector& EndPin)
{
 const TArray<FVector>* BP=Owner->XmlGltfNodePoints.Find(BarrelName.ToLower());
 const TArray<FVector>* RP=Owner->XmlGltfNodePoints.Find(RodName.ToLower());
 if(!BP || !RP || BP->Num()<4 || RP->Num()<4) return false;
 const FTransform BT=Barrel->GetComponentTransform(), RT=Rod->GetComponentTransform();
 FBox BB(ForceInit), RB(ForceInit);
 for(const FVector& P:*BP) BB+=BT.TransformPosition(P);
 for(const FVector& P:*RP) RB+=RT.TransformPosition(P);
 const FVector Cb=BB.GetCenter(), Cr=RB.GetCenter();
 const FVector Axis=(Cr-Cb).GetSafeNormal();
 if(Axis.IsNearlyZero()) return false;
 float SMin=TNumericLimits<float>::Max(), SMax=-TNumericLimits<float>::Max();
 for(const FVector& P:*BP) SMin=FMath::Min(SMin,(float)FVector::DotProduct(BT.TransformPosition(P)-Cb,Axis));
 for(const FVector& P:*RP) SMax=FMath::Max(SMax,(float)FVector::DotProduct(RT.TransformPosition(P)-Cr,Axis));
 BasePin=Cb+Axis*SMin;
 EndPin=Cr+Axis*SMax;
 return FVector::Dist(BasePin,EndPin)>10.f;
}
}

bool FRWVehicleXml::HydraulicLength(int32 Index,float& Now,float& Min,float& Max) const
{
 if(!Hydraulics.IsValidIndex(Index)) return false;
 const FHydraulic& H=Hydraulics[Index];
 const USceneComponent* Start=H.Start.Get(); const USceneComponent* End=H.End.Get();
 if(!Start || !End) return false;
 Now=FVector::Distance(Start->GetComponentLocation(),End->GetComponentLocation());
 Min=H.MinLen; Max=H.MaxLen;
 return true;
}

// <mass total="kg"><part name="boom" kg="1650"/>...</mass>: the machine's masses for its stability (the parts a machine
// knows: excavator boom / stick / bucket / undercarriage / house; any machine: total). Not given here = estimated, and the
// game log says so. A mass that is no number, not finite, zero or less, or over 1000 t is rejected.
int32 FRWVehicleXml::ReadMass(const FXmlNode* Root,ARWMachine* Owner,int32& Rejected)
{
 int32 MassBound = 0;
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("mass")))
 {
  const float Tot=Num(Group,TEXT("total"),-1.f);
  if(Tot>0.f && Tot<1e6f) { Owner->XmlMassKg.Add(TEXT("total"),Tot); ++MassBound; }
  else if(!Group->GetAttribute(TEXT("total")).IsEmpty()) { UE_LOG(LogTemp,Error,TEXT("RWXML: mass total '%s' is not a mass in kg"),*Group->GetAttribute(TEXT("total"))); ++Rejected; }
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("part")) { ++Rejected; continue; }
   const FString Name=Attr(N,TEXT("name")).ToLower();
   const float Kg=Num(N,TEXT("kg"),-1.f);
   if(Name.IsEmpty() || !(Kg>0.f) || Kg>1e6f) { UE_LOG(LogTemp,Error,TEXT("RWXML: mass part '%s' kg '%s' rejected"),*Name,*N->GetAttribute(TEXT("kg"))); ++Rejected; continue; }
   Owner->XmlMassKg.Add(Name,Kg); ++MassBound;
  }
  UE_LOG(LogTemp,Log,TEXT("RWXML: vehicle=%s mass entries=%d"),*Owner->ModId,MassBound);
 }
 return MassBound;
}

bool FRWVehicleXml::LoadMassOnly(const FString& Path,ARWMachine* Owner)
{
 if(!Owner) return false;
 Owner->XmlMassKg.Reset();
 if(!FPaths::FileExists(Path)) return false;
 FXmlFile Xml(Path,EConstructMethod::ConstructFromFile);
 if(!Xml.IsValid() || !Xml.GetRootNode() || Xml.GetRootNode()->GetTag()!=TEXT("vehicle"))
 {
  UE_LOG(LogTemp,Error,TEXT("RWXML: mass only: not a <vehicle> XML: %s"),*Path); return false;
 }
 int32 Rejected = 0;
 const int32 Bound = ReadMass(Xml.GetRootNode(), Owner, Rejected);
 const bool bOk = Rejected==0 && Bound>0;
 if(!bOk) Owner->XmlMassKg.Reset(); // (a rejected mass section gives no masses: the estimates stay)
 UE_LOG(LogTemp,Log,TEXT("RWXML: vehicle=%s mass only (controls stay the machine's own): entries=%d rejected=%d status=%s path=%s"),
   *Owner->ModId,Bound,Rejected,bOk?TEXT("BOUND"):(Bound+Rejected==0?TEXT("NONE"):TEXT("REJECTED")),*Path);
 return bOk;
}

bool FRWVehicleXml::Load(const FString& Path,ARWMachine* Owner)
{
 Tools.Reset(); Hydraulics.Reset(); Anchors.Reset(); bLoaded=false;
 if(!Owner || !FPaths::FileExists(Path))
 {
  UE_LOG(LogTemp,Error,TEXT("RWXML: missing XML or owner: %s"),*Path);
  return false;
 }
 Owner->XmlMassKg.Reset(); // (loaded again: the masses of the file as it is now, none left over from before)
 FXmlFile Xml(Path,EConstructMethod::ConstructFromFile);
 if(!Xml.IsValid() || !Xml.GetRootNode())
 {
  UE_LOG(LogTemp,Error,TEXT("RWVehicleXml: invalid XML: %s"),*Path); return false;
 }
 const FXmlNode* Root=Xml.GetRootNode();
 if(Root->GetTag()!=TEXT("vehicle"))
 {
  UE_LOG(LogTemp,Error,TEXT("RWVehicleXml: root must be <vehicle>")); return false;
 }
 // (Phase 5.1) Fail closed: GIANTS Cylindered XML is a separate schema, not a synonym for
 // RoadWorks' flat <movingTools>/<movingParts>. Until node path resolution,
 // reference-frame orientation, translatingPart and dependentPart scheduling
 // are implemented and tested, never silently ignore this section.
 if(Root->FindChildNode(TEXT("cylindered")))
 {
  UE_LOG(LogTemp, Error, TEXT("RWXML: unsupported <cylindered> FS25 schema. FS25 I3D node paths and movingParts are not yet bound to GLB. Refusing XML control instead of silently running legacy behavior. File=%s"), *Path);
  return false;
 }
 // Fail closed for malformed or unsupported control channels: never claim XML
 // ownership while running default/legacy actuation silently.
 int32 Rejected = 0;
 int32 NativeBound = 0;
 int32 WorkBound = 0;
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("nativeControls")))
 {
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("control")) { ++Rejected; continue; }
   const FString Function=Attr(N,TEXT("function"));
   const FString Input=Attr(N,TEXT("input"));
   ARWDozer* Dozer=Cast<ARWDozer>(Owner);
   if(!Dozer || (!Function.Equals(TEXT("DOZER_BLADE_LIFT"),ESearchCase::IgnoreCase) &&
                 !Function.Equals(TEXT("DOZER_BLADE_TILT"),ESearchCase::IgnoreCase)))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: unsupported native control '%s' for vehicle '%s'"),*Function,*Owner->ModId);
    ++Rejected; continue;
   }
   const bool bLift=Function.Equals(TEXT("DOZER_BLADE_LIFT"),ESearchCase::IgnoreCase);
   const FString ExpectedInput=bLift?TEXT("A1"):TEXT("A2");
   const float DefaultMin=bLift?-0.45f:-8.f;
   const float DefaultMax=bLift?1.2f:8.f;
   const float DefaultSpeed=bLift?0.45f:6.f;
   const float Min=Num(N,TEXT("min"),DefaultMin);
   const float Max=Num(N,TEXT("max"),DefaultMax);
   const float Speed=Num(N,TEXT("speed"),DefaultSpeed);
   if(!Input.Equals(ExpectedInput,ESearchCase::IgnoreCase) || !(Min<Max) ||
      !FMath::IsFinite(Speed) || Speed<0.f || Speed>20.f || Min < -30.f || Max>30.f ||
      (bLift?Dozer->bRWXmlLiftBound:Dozer->bRWXmlTiltBound))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: invalid/duplicate native '%s' input '%s' limits [%.2f,%.2f] speed %.2f"),
     *Function,*Input,Min,Max,Speed);
    ++Rejected; continue;
   }
   if(bLift)
   {
    Dozer->RWBladeLiftMin=Min; Dozer->RWBladeLiftMax=Max;
    Dozer->RWBladeLiftSpeed=Speed; Dozer->bRWXmlLiftBound=true;
   }
   else
   {
    Dozer->RWBladeTiltMin=Min; Dozer->RWBladeTiltMax=Max;
    Dozer->RWBladeTiltSpeed=Speed; Dozer->bRWXmlTiltBound=true;
   }
   ++NativeBound;
   UE_LOG(LogTemp,Log,TEXT("RWXML: native bound vehicle=%s function=%s input=%s min=%.3f max=%.3f speed=%.3f"),
     *Owner->ModId,*Function,*Input,Min,Max,Speed);
  }
 }
 const int32 MassBound = ReadMass(Root, Owner, Rejected); // (<mass>: see ReadMass)
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("movingTools")))
 {
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("movingTool")) continue;
   FTool T; T.Id=Attr(N,TEXT("id")); T.Node=Attr(N,TEXT("node")); T.Input=Attr(N,TEXT("input"));
   // The same generic joint works for excavators, loaders, dump beds, crane
   // telescoping sections, outriggers, graders and dozer blades.
   const FString Action=Attr(N,TEXT("action"),TEXT("rotate"));
   if(Action.Equals(TEXT("rotate"),ESearchCase::IgnoreCase)) T.bTranslate=false;
   else if(Action.Equals(TEXT("translate"),ESearchCase::IgnoreCase)) T.bTranslate=true;
   else
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: unsupported joint action '%s' id=%s"),*Action,*T.Id);
    ++Rejected; continue;
   }
   USceneComponent* C=Find(Owner,T.Node);
   if(!C)
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: movingTool SceneComponent not found: %s (GLB node names do not necessarily match Components)"),*T.Node);
    ++Rejected; continue;
   }
   if(ARWDozer* Dozer=Cast<ARWDozer>(Owner))
   {
    if(C==Dozer->CFrameP && (Dozer->bRWXmlLiftBound || Dozer->bRWXmlTiltBound))
    {
     UE_LOG(LogTemp,Error,TEXT("RWXML: component '%s' controlled by native dozer channel and movingTool; duplicate ownership refused"),*T.Node);
     ++Rejected; continue;
    }
   }
   T.Component=C; T.Base=C->GetRelativeTransform().GetRotation();
   T.BaseLocation=C->GetRelativeLocation();
   const FString Axis=Attr(N,TEXT("axis"),*Attr(N,TEXT("rotationAxis"),TEXT("X")));
   T.Axis=Axis.Equals(TEXT("Y"),ESearchCase::IgnoreCase)?FVector::YAxisVector:
          Axis.Equals(TEXT("Z"),ESearchCase::IgnoreCase)?FVector::ZAxisVector:FVector::XAxisVector;
   // Rotation uses degrees and degrees/sec. Translation uses centimeters
   // and centimeters/sec, matching Unreal Engine component units.
   T.Min=Num(N,TEXT("min"),Num(N,TEXT("rotMin"),T.bTranslate?0.f:-45.f));
   T.Max=Num(N,TEXT("max"),Num(N,TEXT("rotMax"),T.bTranslate?100.f:45.f));
   T.Speed=Num(N,TEXT("speed"),30.f);
   if(!(T.Min<T.Max) || !FMath::IsFinite(T.Speed) || T.Speed<0.f || T.Speed>10000.f ||
      FMath::Abs(T.Min)>100000.f || FMath::Abs(T.Max)>100000.f)
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: invalid joint range/speed node=%s"),*T.Node);
    ++Rejected; continue;
   }
   T.Angle=FMath::Clamp(Num(N,TEXT("initial"),Num(N,TEXT("initialAngle"),0)),T.Min,T.Max);
   T.bInvert=Attr(N,TEXT("invert"),TEXT("false")).Equals(TEXT("true"),ESearchCase::IgnoreCase);
   if(!T.Input.Equals(TEXT("A1"),ESearchCase::IgnoreCase) &&
      !T.Input.Equals(TEXT("A2"),ESearchCase::IgnoreCase) &&
      !T.Input.Equals(TEXT("A3"),ESearchCase::IgnoreCase) &&
      !T.Input.Equals(TEXT("A4"),ESearchCase::IgnoreCase))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: unsupported input '%s' for '%s'"),*T.Input,*T.Node);
    ++Rejected; continue;
   }
   if(Tools.ContainsByPredicate([&T](const FTool& Other){ return Other.Component.Get() == T.Component.Get(); }))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: duplicate movingTool target node=%s"),*T.Node);
    ++Rejected; continue;
   }
   UE_LOG(LogTemp,Log,TEXT("RWXML: joint bound id=%s node=%s action=%s input=%s axis=%s min=%.1f max=%.1f speed=%.1f"),
    *T.Id,*T.Node,*Action,*T.Input,*Axis,T.Min,T.Max,T.Speed);
   Tools.Add(MoveTemp(T));
  }
 }
 // Named attachment markers: sources are real GLB nodes, but their future movement
 // follows their designated parent (body or blade_frame), not the source mesh.
 // Optional offsetX/Y/Z values are in centimetres in the source node's local axes.
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("anchors")))
 {
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("anchor")) { ++Rejected; continue; }
   const FString Name=Attr(N,TEXT("name"));
   const FString SourceName=Attr(N,TEXT("source"));
   const FString Follow=Attr(N,TEXT("follow"),TEXT("body"));
   USceneComponent* Source=Find(Owner,SourceName);
   // 'follow' may name ANY registered component, or one of the legacy aliases.
   // Do not use nested unbraced 'if' here: the legacy code accidentally bound
   // its 'else if' to the inner Cast<ARWDozer> condition.
   USceneComponent* Parent=nullptr;
   if(Follow.Equals(TEXT("body"),ESearchCase::IgnoreCase))
   {
    Parent=Owner->Body;
   }
   else if(Follow.Equals(TEXT("blade_frame"),ESearchCase::IgnoreCase))
   {
    if(ARWDozer* Dozer=Cast<ARWDozer>(Owner)) Parent=Dozer->CFrameP;
   }
   else if(Follow.Equals(TEXT("blade_angle"),ESearchCase::IgnoreCase))
   {
    Parent=Find(Owner,TEXT("blade_angle_pivot"));
   }
   else if(Follow.Equals(TEXT("blade_pitch"),ESearchCase::IgnoreCase))
   {
    Parent=Find(Owner,TEXT("blade_pitch_pivot"));
   }
   else
   {
    Parent=Find(Owner,Follow);
   }
   if(Name.IsEmpty() || SourceName.IsEmpty() || !Source || !Parent || Find(Owner,Name))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: anchor rejected name=%s source=%s follow=%s"),*Name,*SourceName,*Follow);
    ++Rejected; continue;
   }
   const FVector Offset(Num(N,TEXT("offsetX"),0.f),Num(N,TEXT("offsetY"),0.f),Num(N,TEXT("offsetZ"),0.f));
   USceneComponent* Marker=NewObject<USceneComponent>(Owner,FName(*Name));
   Marker->SetupAttachment(Parent);
   Marker->RegisterComponent();
   Marker->SetWorldLocation(Source->GetComponentTransform().TransformPosition(Offset));
   Anchors.Add(Marker);
   UE_LOG(LogTemp,Log,TEXT("RWXML: anchor bound name=%s follow=%s source=%s"),*Name,*Follow,*SourceName);
  }
 }
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("movingParts")))
 {
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("hydraulic")) continue;
   FHydraulic H; H.Name=Attr(N,TEXT("name"));
   H.Start=Find(Owner,Attr(N,TEXT("start")));
   H.End=Find(Owner,Attr(N,TEXT("end")));
   H.Barrel=Find(Owner,Attr(N,TEXT("barrel")));
   H.Rod=Find(Owner,Attr(N,TEXT("rod")));
   if(!H.Start.IsValid() || !H.End.IsValid() || !H.Barrel.IsValid() || !H.Rod.IsValid())
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s' has missing SceneComponent(s)"),*H.Name);
    ++Rejected; continue;
   }
   if(H.Barrel==H.Rod || H.Start==H.End)
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s' duplicate components/anchors"),*H.Name);
    ++Rejected; continue;
   }
   // pins="anchors" (the default): the start / end anchors are the pins, where they were put.
   // pins="auto": the pins are found from the barrel's and rod's shape and the two anchors are moved there; the anchors
   // still say what each end follows (start: the body, end: the tool).
   const FString Pins=Attr(N,TEXT("pins"),TEXT("anchors"));
   if(Pins.Equals(TEXT("auto"),ESearchCase::IgnoreCase))
   {
    FVector BasePin, EndPin;
    if(!AutoPins(Owner,Attr(N,TEXT("barrel")),Attr(N,TEXT("rod")),H.Barrel.Get(),H.Rod.Get(),BasePin,EndPin))
    {
     UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s' pins=auto: the barrel's and rod's shapes are not known (list both in <modelRig><group name=\"hydraulic_parts\">)"),*H.Name);
     ++Rejected; continue;
    }
    H.Start->SetWorldLocation(BasePin);
    H.End->SetWorldLocation(EndPin);
   }
   else if(!Pins.Equals(TEXT("anchors"),ESearchCase::IgnoreCase))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s' pins='%s' (use \"anchors\" or \"auto\")"),*H.Name,*Pins);
    ++Rejected; continue;
   }
   // the rest pose in the body's frame, so that the machine driving, turning or tipping does not move the cylinder
   USceneComponent* Space=Owner->Body;
   if(!Space)
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s': the machine has no body"),*H.Name);
    ++Rejected; continue;
   }
   const FTransform ST=Space->GetComponentTransform();
   H.Space=Space;
   H.RestA=ST.InverseTransformPosition(H.Start->GetComponentLocation());
   H.RestB=ST.InverseTransformPosition(H.End->GetComponentLocation());
   if(FVector::DistSquared(H.RestA,H.RestB)<1.f)
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: hydraulic '%s' anchors coincide"),*H.Name);
    ++Rejected; continue;
   }
   H.BarrelRest=H.Barrel->GetComponentTransform().GetRelativeTransform(ST);
   H.RodRest=H.Rod->GetComponentTransform().GetRelativeTransform(ST);
   H.MinLen=H.MaxLen=FVector::Distance(H.RestA,H.RestB);
   H.bInitialized=true;
   Hydraulics.Add(MoveTemp(H));
   UE_LOG(LogTemp,Log,TEXT("RWXML: hydraulic bound name=%s pins=%s rest=%.1fcm"),*N->GetAttribute(TEXT("name")),*Pins.ToLower(),
    FVector::Distance(Hydraulics.Last().RestA,Hydraulics.Last().RestB));
  }
 }
 // Work binding: reuse RoadWorks' existing dozer/excavator terrain mechanics.
 // No new terrain algorithm is created by this XML section.
 if(const FXmlNode* Group=Root->FindChildNode(TEXT("workTools")))
 {
  for(const FXmlNode* N:Group->GetChildrenNodes())
  {
   if(N->GetTag()!=TEXT("workTool")) continue;
   const FString Type=Attr(N,TEXT("type"));
   const FString Node=Attr(N,TEXT("node"));
   if(!Node.IsEmpty() && !Find(Owner,Node))
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: workTool '%s' node '%s' is not a SceneComponent"),*Type,*Node);
    ++Rejected; continue;
   }
   if(Type.Equals(TEXT("DOZER_BLADE"),ESearchCase::IgnoreCase))
   {
    ARWDozer* Dozer=Cast<ARWDozer>(Owner);
    if(!Dozer)
    {
     UE_LOG(LogTemp,Error,TEXT("RWXML: DOZER_BLADE requires ARWDozer"));
     ++Rejected; continue;
    }
    // Dimensions in metres, exactly as ARWDozer::WorkTick already uses them.
    const float Width=Num(N,TEXT("width"),Dozer->BladeW);
    const float Forward=Num(N,TEXT("forwardOffset"),Dozer->BladeX);
    if(Width<=0.1f || Width>15.f || FMath::Abs(Forward)>30.f)
    {
     UE_LOG(LogTemp,Error,TEXT("RWXML: invalid dozer blade dimensions"));
     ++Rejected; continue;
    }
    Dozer->BladeW=Width;
    Dozer->BladeX=Forward;
    ++WorkBound;
    UE_LOG(LogTemp,Log,TEXT("RWXML: work tool=DOZER_BLADE physics=ARWDozer::WorkTick width=%.2fm offset=%.2fm"),Width,Forward);
   }
   else if(Type.Equals(TEXT("EXCAVATOR_BUCKET"),ESearchCase::IgnoreCase))
   {
    if(!Cast<ARWExcavator>(Owner))
    {
     UE_LOG(LogTemp,Error,TEXT("RWXML: EXCAVATOR_BUCKET requires ARWExcavator"));
     ++Rejected; continue;
    }
    // The existing ARWExcavator::WorkTick remains the sole owner of digging.
    ++WorkBound;
    UE_LOG(LogTemp,Log,TEXT("RWXML: work tool=EXCAVATOR_BUCKET physics=ARWExcavator::WorkTick (geometry unchanged)"));
   }
   else
   {
    UE_LOG(LogTemp,Error,TEXT("RWXML: unsupported workTool type '%s'"),*Type);
    ++Rejected;
   }
  }
 }
 bLoaded=(Rejected==0) && (NativeBound>0 || Tools.Num()>0 || Hydraulics.Num()>0 || WorkBound>0 || MassBound>0);
 if(!bLoaded) Owner->XmlMassKg.Reset(); // (a rejected file gives no masses either)
 UE_LOG(LogTemp,Log,TEXT("RWXML: vehicle=%s native=%d moving=%d hydraulics=%d work=%d rejected=%d status=%s path=%s"),
   *Owner->ModId,NativeBound,Tools.Num(),Hydraulics.Num(),WorkBound,Rejected,bLoaded?TEXT("BOUND"):TEXT("REJECTED"),*Path);
 if(!bLoaded)
 {
  // Input for native channels is suppressed by ARWDozer::WorkTick when XML is rejected.
  Tools.Reset(); Hydraulics.Reset();
 }
 return bLoaded;
}

void FRWVehicleXml::Update(ARWMachine* Owner,float Dt)
{
 if(!bLoaded || !Owner || !FMath::IsFinite(Dt)) return;
 Dt=FMath::Clamp(Dt,0.f,0.1f);
 for(FTool& T:Tools)
 {
  USceneComponent* C=T.Component.Get(); if(!C) continue;
  float V=FMath::Clamp(InputValue(Owner,T.Input),-1.f,1.f);
  if(T.bInvert) V=-V;
  T.Angle=FMath::Clamp(T.Angle+V*T.Speed*Dt,T.Min,T.Max);
  if(T.bTranslate)
  {
   // Translation is along a local parent-space axis; no mesh scaling.
   C->SetRelativeLocation(T.BaseLocation+T.Axis*T.Angle);
  }
  else
  {
   C->SetRelativeRotation((T.Base*FQuat(T.Axis,FMath::DegreesToRadians(T.Angle))).Rotator());
  }
 }
 // Anchor-based hydraulic visualization. Barrel/rod components must be authored
 // with local +X along the cylinder axis; this does NOT simulate hydraulic forces.
 for(FHydraulic& H:Hydraulics)
 {
  USceneComponent* Start=H.Start.Get(); USceneComponent* End=H.End.Get();
  USceneComponent* Barrel=H.Barrel.Get(); USceneComponent* Rod=H.Rod.Get();
  USceneComponent* Space=H.Space.Get();
  if(!Start || !End || !Barrel || !Rod || !Space) continue;
  // everything in the body's frame (the rest pose was taken in it)
  const FTransform ST=Space->GetComponentTransform();
  const FVector A=ST.InverseTransformPosition(Start->GetComponentLocation()), B=ST.InverseTransformPosition(End->GetComponentLocation());
  const FVector RestD=H.RestB-H.RestA, D=B-A;
  if(RestD.SizeSquared()<1.f || D.SizeSquared()<1.f) continue;
  H.MinLen=FMath::Min(H.MinLen,(float)D.Size()); H.MaxLen=FMath::Max(H.MaxLen,(float)D.Size());
  // Rotate both meshes by the same delta from the authored Blender rest pose,
  // with the barrel fixed to the chassis anchor and rod fixed to tool anchor.
  // Do not scale the rod mesh: telescoping comes from the moving endpoint.
  const FQuat Delta=FQuat::FindBetweenNormals(RestD.GetSafeNormal(),D.GetSafeNormal());
  const FVector BarrelPosition=A+Delta.RotateVector(H.BarrelRest.GetLocation()-H.RestA);
  const FVector RodPosition=B+Delta.RotateVector(H.RodRest.GetLocation()-H.RestB);
  Barrel->SetWorldLocationAndRotation(ST.TransformPosition(BarrelPosition),ST.TransformRotation(Delta*H.BarrelRest.GetRotation()));
  Rod->SetWorldLocationAndRotation(ST.TransformPosition(RodPosition),ST.TransformRotation(Delta*H.RodRest.GetRotation()));
 }
}
