#include "RWMods.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "RWGame.h"
#include "RWTerrain.h"
#include "RWLoc.h"
#include "RWMeshGen.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/CommandLine.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformFileManager.h"
#include "IPlatformFilePak.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "RWWorld.h"
#include "RWPlatform.h"
#include "RWEditor.h"
#include "XmlFile.h"
#include "Dom/JsonValue.h"

TArray<FRWModInfo> FRWMods::Mods;
TArray<FRWModMachine> FRWMods::Machines;
TArray<FRWModProp> FRWMods::Props;
TMap<FString, FString> FRWMods::Replacements;
TArray<TSharedPtr<FJsonObject>> FRWMods::Attachments;

static FString DisabledFile() { return FPaths::ProjectSavedDir() / TEXT("Config") / TEXT("RoadWorksDisabledMods.txt"); }

TArray<FString> FRWMods::DisabledList()
{
	TArray<FString> L;
	FFileHelper::LoadFileToStringArray(L, *DisabledFile());
	for (FString& S : L) S.TrimStartAndEndInline();
	L.RemoveAll([](const FString& S) { return S.IsEmpty(); });
	return L;
}

void FRWMods::SetEnabled(int32 Index, bool bOn)
{
	if (!Mods.IsValidIndex(Index)) return;
	Mods[Index].bEnabled = bOn;
	TArray<FString> Off;
	for (const FRWModInfo& M : Mods) if (!M.bEnabled) Off.Add(FPaths::GetCleanFilename(M.Folder));
	FFileHelper::SaveStringArrayToFile(Off, *DisabledFile());
	RWLog(FString::Printf(TEXT("Mod %s %s (applies after restart)"), *Mods[Index].Name, bOn ? TEXT("enabled") : TEXT("disabled")));
}

UStaticMesh* FRWMods::ReplacementMesh(const FString& Key)
{
	const FString* P = Replacements.Find(Key);
	if (!P) return nullptr;
	UStaticMesh* M = LoadObject<UStaticMesh>(nullptr, **P);
	if (!M) RWLog(FString::Printf(TEXT("Mod replacement %s: mesh %s not found"), *Key, **P));
	return M;
}

UMaterialInterface* FRWMods::ReplacementMaterial(const FString& Key)
{
	const FString* P = Replacements.Find(Key);
	if (!P) return nullptr;
	UMaterialInterface* M = LoadObject<UMaterialInterface>(nullptr, **P);
	if (!M) RWLog(FString::Printf(TEXT("Mod replacement %s: material %s not found"), *Key, **P));
	return M;
}

TArray<FString> FRWMods::SearchDirs()
{
	TArray<FString> D;
	FString Cmd;
	if (FParse::Value(FCommandLine::Get(), TEXT("RWMods="), Cmd)) D.Add(Cmd);
	D.Add(FPaths::ProjectDir() / TEXT("Mods"));
	D.Add(FPaths::LaunchDir() / TEXT("Mods"));
	TArray<FString> Out;
	for (FString& S : D)
	{
		S = FPaths::ConvertRelativePathToFull(S);
		FPaths::NormalizeDirectoryName(S);
		if (IFileManager::Get().DirectoryExists(*S) && !Out.Contains(S)) Out.Add(S);
	}
	return Out;
}

static FVector JVec(const TSharedPtr<FJsonObject>& O, const TCHAR* Key, const FVector& Def)
{
	const TArray<TSharedPtr<FJsonValue>>* A;
	if (!O->TryGetArrayField(Key, A) || A->Num() < 3) return Def;
	return FVector((*A)[0]->AsNumber(), (*A)[1]->AsNumber(), (*A)[2]->AsNumber());
}

static float JNum(const TSharedPtr<FJsonObject>& O, const TCHAR* Key, float Def)
{
	double V; return O->TryGetNumberField(Key, V) ? (float)V : Def;
}

// The existing model builders consume a JSON-shaped rig description.  In XML mode,
// translate <modelRig> to that in-memory shape BEFORE BuildFromModel(); the old
// mod.json rig is deliberately replaced, not merged or used as fallback.
static bool RWImportXmlModelRig(const FString& Path, const TSharedPtr<FJsonObject>& Machine, FString& Error)
{
	FXmlFile Xml(Path, EConstructMethod::ConstructFromFile);
	if (!Xml.IsValid() || !Xml.GetRootNode() || Xml.GetRootNode()->GetTag() != TEXT("vehicle"))
	{
		Error = TEXT("invalid vehicle.xml or missing <vehicle> root"); return false;
	}
	const FXmlNode* ModelRig = Xml.GetRootNode()->FindChildNode(TEXT("modelRig"));
	if (!ModelRig) { Error = TEXT("XML mode requires <modelRig> (legacy mod.json rig is NOT a fallback)"); return false; }
	TSharedPtr<FJsonObject> Rig = MakeShared<FJsonObject>();
	int32 Added = 0;
	for (const FXmlNode* Group : ModelRig->GetChildrenNodes())
	{
		if (Group->GetTag() == TEXT("group"))
		{
			const FString Key = Group->GetAttribute(TEXT("name"));
			if (Key.IsEmpty()) { Error = TEXT("modelRig/group missing name"); return false; }
			TArray<TSharedPtr<FJsonValue>> Patterns;
			for (const FXmlNode* Node : Group->GetChildrenNodes())
			{
				if (Node->GetTag() != TEXT("node")) continue;
				const FString Pattern = Node->GetAttribute(TEXT("pattern"));
				if (Pattern.IsEmpty()) { Error = TEXT("modelRig/group/node missing pattern"); return false; }
				Patterns.Add(MakeShared<FJsonValueString>(Pattern));
			}
			if (Patterns.IsEmpty()) { Error = FString::Printf(TEXT("group '%s' has no nodes"), *Key); return false; }
			Rig->SetArrayField(Key, Patterns); ++Added;
		}
		else if (Group->GetTag() == TEXT("reference") || Group->GetTag() == TEXT("pivot"))
		{
			const FString Key = Group->GetAttribute(TEXT("name"));
			const FString Node = Group->GetAttribute(TEXT("node"));
			if (Key.IsEmpty() || Node.IsEmpty()) { Error = TEXT("modelRig reference/pivot requires name and node"); return false; }
			if (Group->GetTag() == TEXT("reference")) Rig->SetStringField(Key, Node);
			else
			{
				const TSharedPtr<FJsonObject>* Existing = nullptr;
				TSharedPtr<FJsonObject> Pivots;
				if (Rig->TryGetObjectField(TEXT("pivots"), Existing)) Pivots = *Existing;
				else { Pivots = MakeShared<FJsonObject>(); Rig->SetObjectField(TEXT("pivots"), Pivots); }
				Pivots->SetStringField(Key, Node);
			}
			++Added;
		}
		else { Error = FString::Printf(TEXT("unsupported modelRig element '%s'"), *Group->GetTag()); return false; }
	}
	if (Added == 0) { Error = TEXT("modelRig is empty"); return false; }
	Machine->SetObjectField(TEXT("rig"), Rig);
	return true;
}

void FRWMods::LoadAll()
{
	Mods.Reset(); Machines.Reset(); Props.Reset(); Replacements.Reset(); FRWEditor::PendingModItems.Reset(); Attachments.Reset();
	const TArray<FString> Disabled = DisabledList();
	TArray<FString> Dirs = SearchDirs();
	for (const FString& W : FRWPlatform::ExtraModDirs()) Dirs.AddUnique(W); // e.g. subscribed Steam Workshop items
	for (const FString& Dir : Dirs)
	{
		TArray<FString> Sub;
		IFileManager::Get().FindFiles(Sub, *(Dir / TEXT("*")), false, true);
		Sub.Sort();
		for (const FString& S : Sub)
		{
			const FString Folder = Dir / S;
			const FString File = Folder / TEXT("mod.json");
			if (!IFileManager::Get().FileExists(*File)) continue;
			FRWModInfo Info; Info.Folder = Folder; Info.Name = S;
			FString Text;
			TSharedPtr<FJsonObject> Root;
			if (!FFileHelper::LoadFileToString(Text, *File) || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Root) || !Root.IsValid())
			{
				Info.Error = TEXT("mod.json is not valid JSON");
				RWLog(FString::Printf(TEXT("MOD ERROR %s: %s"), *S, *Info.Error));
				Mods.Add(Info);
				continue;
			}
			Root->TryGetStringField(TEXT("name"), Info.Name);
			Root->TryGetStringField(TEXT("author"), Info.Author);
			Root->TryGetStringField(TEXT("version"), Info.Version);
			Root->TryGetStringField(TEXT("id"), Info.Id);
			Root->TryGetStringField(TEXT("workshop_id"), Info.WorkshopId);
			Root->TryGetStringField(TEXT("sdk_version"), Info.SdkVersion);
			// the same mod in two of the folders (the game's own Mods and the one given with -RWMods): the first one found is
			// used - two copies would put two of its machines on the map
			if (!Info.Id.IsEmpty())
				if (const FRWModInfo* Same = Mods.FindByPredicate([&](const FRWModInfo& O) { return O.Id == Info.Id; }))
				{
					RWLog(FString::Printf(TEXT("Mod %s (%s) in %s is also in %s: that copy is used, this one is left out"), *Info.Name, *Info.Id, *Folder, *Same->Folder));
					continue;
				}
			if (Disabled.Contains(S))
			{
				Info.bEnabled = false;
				RWLog(FString::Printf(TEXT("Mod disabled by player: %s"), *Info.Name));
				Mods.Add(Info);
				continue;
			}
			// environment replacements: trees, rocks, houses, terrain material ...
			const TSharedPtr<FJsonObject>* Rep;
			if (Root->TryGetObjectField(TEXT("replace"), Rep))
				for (const auto& KV : (*Rep)->Values) { Replacements.Add(FString(*KV.Key), KV.Value->AsString()); Info.Replacements++; }
			// placed props: buildings, houses, industrial structures, rocks ...
			const TArray<TSharedPtr<FJsonValue>>* Pr;
			if (Root->TryGetArrayField(TEXT("props"), Pr))
				for (const TSharedPtr<FJsonValue>& V : *Pr) if (V->AsObject().IsValid()) { Props.Add({Info.Name, V->AsObject(), Folder}); Info.Props++; }
			// objects placed with the map editor and shared as a mod
			const TArray<TSharedPtr<FJsonValue>>* MI;
			if (Root->TryGetArrayField(TEXT("map_items"), MI)) { FRWEditor::PendingModItems.Append(*MI); Info.Props += MI->Num(); }
			// attachments (buckets for now) with their real dimensions
			const TArray<TSharedPtr<FJsonValue>>* At;
			if (Root->TryGetArrayField(TEXT("attachments"), At))
				for (const TSharedPtr<FJsonValue>& V : *At)
				{
					const TSharedPtr<FJsonObject> O = V->AsObject();
					FString Kind; if (!O.IsValid() || !O->TryGetStringField(TEXT("kind"), Kind)) continue;
					if (Kind != TEXT("excavator_bucket")) { RWLog(FString::Printf(TEXT("Mod %s: attachment kind '%s' is not supported yet"), *Info.Name, *Kind)); continue; }
					if (JNum(O, TEXT("width_m"), 0.f) <= 0.f || JNum(O, TEXT("capacity_m3"), 0.f) <= 0.f) { RWLog(FString::Printf(TEXT("MOD ERROR %s: bucket needs width_m and capacity_m3"), *Info.Name)); continue; }
					FString Nm, NmTh; O->TryGetStringField(TEXT("name"), Nm); O->TryGetStringField(TEXT("name_th"), NmTh);
					if (!Nm.IsEmpty() && !NmTh.IsEmpty()) RWLocAdd(Nm, NmTh);
					Attachments.Add(O);
				}
			// custom cooked content (meshes made in the Unreal editor) ships as .pak files next to mod.json
			TArray<FString> Paks;
			IFileManager::Get().FindFiles(Paks, *(Folder / TEXT("*.pak")), true, false);
			for (const FString& P : Paks)
			{
				FPakPlatformFile* Pak = (FPakPlatformFile*)FPlatformFileManager::Get().FindPlatformFile(TEXT("PakFile"));
				if (Pak && Pak->Mount(*(Folder / P), 1000, *(FPaths::ProjectContentDir()))) RWLog(FString::Printf(TEXT("Mod %s: mounted %s"), *Info.Name, *P));
				else RWLog(FString::Printf(TEXT("Mod %s: could not mount %s (pak files load in the packaged game only)"), *Info.Name, *P));
			}
			// translations bundled with the mod
			const TSharedPtr<FJsonObject>* Lang;
			if (Root->TryGetObjectField(TEXT("language"), Lang))
			{
				const TSharedPtr<FJsonObject>* Th;
				if ((*Lang)->TryGetObjectField(TEXT("th"), Th))
					for (const auto& KV : (*Th)->Values) RWLocAdd(FString(*KV.Key), KV.Value->AsString());
			}
			const TArray<TSharedPtr<FJsonValue>>* Ms;
			if (Root->TryGetArrayField(TEXT("machines"), Ms))
			{
				for (const TSharedPtr<FJsonValue>& V : *Ms)
				{
					const TSharedPtr<FJsonObject> O = V->AsObject();
					if (!O.IsValid()) continue;
					FRWModMachine D;
					D.ModName = Info.Name; D.Def = O; D.Folder = Folder;
					O->TryGetStringField(TEXT("id"), D.Id);
					O->TryGetStringField(TEXT("base"), D.Base);
					O->TryGetStringField(TEXT("name"), D.Name);
					O->TryGetStringField(TEXT("name_th"), D.NameTh);
					D.Size = (int32)JNum(O, TEXT("size"), 1.f);
					FString ControlSource;
					O->TryGetStringField(TEXT("control_source"), ControlSource);
					if (!ControlSource.IsEmpty() && !ControlSource.Equals(TEXT("legacy"), ESearchCase::IgnoreCase) &&
					    !ControlSource.Equals(TEXT("xml"), ESearchCase::IgnoreCase))
					{
						RWLog(FString::Printf(TEXT("MOD ERROR %s/%s: unknown control_source '%s'"), *Info.Name, *D.Id, *ControlSource));
						continue;
					}
					if (ControlSource.Equals(TEXT("xml"), ESearchCase::IgnoreCase))
					{
						FString RigError;
						const FString XmlPath = FPaths::Combine(Folder, TEXT("vehicle.xml"));
						if (!RWImportXmlModelRig(XmlPath, O, RigError))
						{
							RWLog(FString::Printf(TEXT("MOD ERROR %s/%s: XML rig rejected: %s (%s)"), *Info.Name, *D.Id, *RigError, *XmlPath));
							continue; // do not spawn or silently use the old JSON rig
						}
						RWLog(FString::Printf(TEXT("RWXML: modelRig=XML, mod=%s machine=%s, source=%s"), *Info.Name, *D.Id, *XmlPath));
					}
					if (!BaseClass(D.Base)) { Info.Error = FString::Printf(TEXT("unknown base '%s'"), *D.Base); RWLog(FString::Printf(TEXT("MOD ERROR %s: %s"), *Info.Name, *Info.Error)); continue; }
					if (D.Name.IsEmpty()) D.Name = D.Id;
					if (!D.NameTh.IsEmpty()) RWLocAdd(D.Name, D.NameTh);
					Machines.Add(D);
					Info.Machines++;
				}
			}
			RWLog(FString::Printf(TEXT("Mod loaded: %s %s by %s (%d machines, %d props, %d replacements)"), *Info.Name, *Info.Version, *Info.Author, Info.Machines, Info.Props, Info.Replacements));
			Mods.Add(Info);
		}
	}
}

FBucketSpec FRWMods::BucketFromJson(const TSharedPtr<FJsonObject>& O, const FBucketSpec& Def)
{
	FBucketSpec B = Def;
	if (!O.IsValid()) return B;
	O->TryGetStringField(TEXT("id"), B.Id);
	O->TryGetStringField(TEXT("name"), B.Name);
	O->TryGetStringField(TEXT("type"), B.Type);
	B.Width = FMath::Clamp(JNum(O, TEXT("width_m"), B.Width), 0.2f, 3.5f);
	B.Capacity = FMath::Clamp(JNum(O, TEXT("capacity_m3"), B.Capacity), 0.02f, 8.f);
	B.Depth = FMath::Clamp(JNum(O, TEXT("depth_m"), B.Depth), 0.1f, 2.f);
	B.MassKg = FMath::Clamp(JNum(O, TEXT("mass_kg"), B.MassKg), 10.f, 8000.f);
	B.Hardness = FMath::Clamp(JNum(O, TEXT("cut_effort"), B.Hardness), 0.4f, 2.f);
	return B;
}

void FRWMods::AddBucketAttachments(TArray<FBucketSpec>& Out, int32 MachineSize)
{
	if (Out.Num() == 0) return;
	for (const TSharedPtr<FJsonObject>& O : Attachments)
	{
		// "fits_sizes": [0,1,2] (0 mini, 1 standard, 2 large); default: every size
		const TArray<TSharedPtr<FJsonValue>>* Fits;
		if (O->TryGetArrayField(TEXT("fits_sizes"), Fits))
		{
			bool bFit = false;
			for (const TSharedPtr<FJsonValue>& V : *Fits) bFit |= (int32)V->AsNumber() == MachineSize;
			if (!bFit) continue;
		}
		Out.Add(BucketFromJson(O, Out[0]));
	}
}

UClass* FRWMods::BaseClass(const FString& B)
{
	const FString L = B.ToLower();
	if (L == TEXT("excavator")) return ARWExcavator::StaticClass();
	if (L == TEXT("dumptruck") || L == TEXT("truck")) return ARWDumpTruck::StaticClass();
	if (L == TEXT("bulldozer") || L == TEXT("dozer")) return ARWDozer::StaticClass();
	if (L == TEXT("wheelloader") || L == TEXT("loader")) return ARWLoader::StaticClass();
	if (L == TEXT("grader")) return ARWGrader::StaticClass();
	if (L == TEXT("roller")) return ARWRoller::StaticClass();
	if (L == TEXT("paver")) return ARWPaver::StaticClass();
	if (L == TEXT("watertruck")) return ARWWaterTruck::StaticClass();
	if (L == TEXT("crane")) return ARWCrane::StaticClass();
	return nullptr;
}

void FRWMods::PreBuild(ARWMachine* M, const FRWModMachine& D)
{
	M->ModScale = FMath::Clamp(JNum(D.Def, TEXT("scale"), 1.f), 0.4f, 2.f);
	M->ModId = D.Id;
	M->ModFolder = D.Folder; // full path; machine ID is NOT the mod folder name
	FString ControlSource;
	D.Def->TryGetStringField(TEXT("control_source"), ControlSource);
	M->bXmlControlRequested = ControlSource.Equals(TEXT("xml"), ESearchCase::IgnoreCase);
}

static USceneComponent* Socket(ARWMachine* M, const FString& S)
{
	const FString L = S.ToLower();
	if (L == TEXT("root")) return M->Root;
	if (L == TEXT("cab") && M->CabRoot) return M->CabRoot;
	if (ARWExcavator* E = Cast<ARWExcavator>(M))
	{
		if (L == TEXT("house")) return E->House;
		if (L == TEXT("boom")) return E->BoomP;
		if (L == TEXT("arm")) return E->ArmP;
		if (L == TEXT("bucket")) return E->BucketP;
	}
	if (ARWDumpTruck* T = Cast<ARWDumpTruck>(M)) if (L == TEXT("bed")) return T->BedP;
	if (ARWDozer* Dz = Cast<ARWDozer>(M)) if (L == TEXT("blade")) return Dz->BladeP;
	if (ARWGrader* G = Cast<ARWGrader>(M)) if (L == TEXT("blade")) return G->BladeP;
	if (ARWLoader* Lo = Cast<ARWLoader>(M)) { if (L == TEXT("front")) return Lo->FrontP; if (L == TEXT("bucket")) return Lo->BucketP; if (L == TEXT("arm")) return Lo->LiftP; }
	if (ARWCrane* C = Cast<ARWCrane>(M)) { if (L == TEXT("upper")) return C->Upper; if (L == TEXT("boom")) return C->BoomP; }
	return M->Body;
}

void FRWMods::PostBuild(ARWMachine* M, const FRWModMachine& D)
{
	const TSharedPtr<FJsonObject>& O = D.Def;
	M->Model = D.Name;
	M->Price = JNum(O, TEXT("price"), M->Price);
	M->RentPerDay = JNum(O, TEXT("rent"), M->RentPerDay);
	M->PowerKW = JNum(O, TEXT("power_kw"), M->PowerKW);
	M->EmptyMass = JNum(O, TEXT("mass_kg"), M->EmptyMass);
	M->FuelCap = JNum(O, TEXT("fuel_l"), M->FuelCap);
	M->FuelRate = JNum(O, TEXT("fuel_lph"), M->FuelRate);
	M->MaxSpeedF = JNum(O, TEXT("max_speed"), M->MaxSpeedF);
	bool bOwned = false;
	if (O->TryGetBoolField(TEXT("owned"), bOwned)) M->bOwned = bOwned;
	if (O->HasField(TEXT("color"))) M->SetPaint(FLinearColor(JVec(O, TEXT("color"), FVector(0.4f, 0.25f, 0.01f))));
	const float Cap = JNum(O, TEXT("capacity_m3"), -1.f);
	if (Cap > 0)
	{
		if (ARWExcavator* E = Cast<ARWExcavator>(M)) { E->Bucket.Capacity = Cap; if (E->BucketSpecs.Num()) E->BucketSpecs[0].Capacity = Cap; }
		if (ARWLoader* L = Cast<ARWLoader>(M)) L->Bucket.Capacity = Cap;
		if (ARWDumpTruck* T = Cast<ARWDumpTruck>(M)) T->Capacity = Cap;
		if (ARWPaver* P = Cast<ARWPaver>(M)) P->HopperCap = Cap;
	}
	// the machine's own bucket: "bucket": { "width_m", "capacity_m3", "depth_m", "mass_kg", "type", "cut_effort" }
	if (ARWExcavator* E = Cast<ARWExcavator>(M))
	{
		if (E->BucketSpecs.Num() == 0)
		{
			// a model rig: its bucket comes from the 3D model (width measured from the model)
			FBucketSpec B; B.Id = TEXT("model"); B.Name = TEXT("Digging bucket"); B.Width = E->Bucket.Width; B.Capacity = E->Bucket.Capacity;
			B.Depth = E->Bucket.Depth > 0.05f ? E->Bucket.Depth : 0.45f * E->Lk; // measured from the model when rigged B.MassKg = E->EmptyMass * 0.04f;
			E->BucketSpecs.Add(B);
			E->BaseEmptyMass = E->EmptyMass;
		}
		const TSharedPtr<FJsonObject>* BO;
		if (O->TryGetObjectField(TEXT("bucket"), BO)) E->BucketSpecs[0] = BucketFromJson(*BO, E->BucketSpecs[0]);
		E->BaseEmptyMass = E->EmptyMass;
		E->ApplyBucket(0);
	}
	// flexible hydraulic hoses: "hoses": [{ "from": "boom", "from_pos": [x,y,z], "to": "arm", "to_pos": [x,y,z],
	//   "radius": 0.016, "length": 1.4 (optional: measured over the joint's range + 4%), "loop": [0,0,1] }]
	const TArray<TSharedPtr<FJsonValue>>* HoseA;
	if (O->TryGetArrayField(TEXT("hoses"), HoseA))
		for (const TSharedPtr<FJsonValue>& V : *HoseA)
		{
			const TSharedPtr<FJsonObject> HO = V->AsObject();
			if (!HO.IsValid()) continue;
			FString From, To; HO->TryGetStringField(TEXT("from"), From); HO->TryGetStringField(TEXT("to"), To);
			USceneComponent* A = Socket(M, From); USceneComponent* B = Socket(M, To);
			const FVector PA = JVec(HO, TEXT("from_pos"), FVector::ZeroVector), PB = JVec(HO, TEXT("to_pos"), FVector::ZeroVector);
			float Len = JNum(HO, TEXT("length"), -1.f);
			if (Len <= 0.f)
			{
				float Lo = -30.f, Hi = 30.f; USceneComponent* J = B;
				if (ARWExcavator* E = Cast<ARWExcavator>(M))
				{
					const FString T = To.ToLower();
					if (T == TEXT("boom")) { Lo = E->BoomLo; Hi = E->BoomHi; }
					else if (T == TEXT("arm")) { Lo = E->ArmLo; Hi = E->ArmHi; }
					else if (T == TEXT("bucket")) { Lo = E->BktLo; Hi = E->BktHi; }
				}
				Len = M->HoseReach(J, Lo, Hi, A, PA, B, PB) * 1.04f + 0.05f;
			}
			if (M->AddHose(A, PA, B, PB, JNum(HO, TEXT("radius"), 0.016f), Len, JVec(HO, TEXT("loop"), FVector(0, 0, 1))) == INDEX_NONE)
				RWLog(FString::Printf(TEXT("Mod %s: hose %s -> %s has an unknown end"), *D.ModName, *From, *To));
		}
	// extra visual parts: primitives with real bevelled geometry, or meshes from a mounted mod pak
	const TArray<TSharedPtr<FJsonValue>>* Parts;
	if (O->TryGetArrayField(TEXT("parts"), Parts))
	{
		for (const TSharedPtr<FJsonValue>& V : *Parts)
		{
			const TSharedPtr<FJsonObject> P = V->AsObject();
			if (!P.IsValid()) continue;
			FString Attach = TEXT("body"), Shape = TEXT("box"), MeshPath;
			P->TryGetStringField(TEXT("attach"), Attach);
			P->TryGetStringField(TEXT("shape"), Shape);
			P->TryGetStringField(TEXT("mesh"), MeshPath);
			const FVector Pos = JVec(P, TEXT("pos"), FVector::ZeroVector);
			const FVector Sz = JVec(P, TEXT("size"), FVector(0.5f));
			const FVector R = JVec(P, TEXT("rot"), FVector::ZeroVector);
			UMaterialInstanceDynamic* Mat = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, M);
			Mat->SetVectorParameterValue(TEXT("Color"), FLinearColor(JVec(P, TEXT("color"), FVector(0.4f, 0.25f, 0.01f))));
			Mat->SetScalarParameterValue(TEXT("Metallic"), JNum(P, TEXT("metal"), 0.f));
			Mat->SetScalarParameterValue(TEXT("Roughness"), JNum(P, TEXT("rough"), 0.45f));
			USceneComponent* Parent = Socket(M, Attach);
			const FRotator Rot(R.X, R.Y, R.Z);
			if (!MeshPath.IsEmpty())
			{
				UStaticMesh* SM = LoadObject<UStaticMesh>(nullptr, *MeshPath);
				if (SM) { M->MeshPart(Parent, SM, Pos, Rot, nullptr, Sz); continue; }
				RWLog(FString::Printf(TEXT("Mod %s: mesh %s not found, using a box"), *D.ModName, *MeshPath));
			}
			const EShape Sh = Shape == TEXT("cylinder") ? EShape::Cylinder : Shape == TEXT("sphere") ? EShape::Sphere : Shape == TEXT("cone") ? EShape::Cone : EShape::Cube;
			M->Part(Parent, Sh, Pos, Sz, Rot, Mat);
		}
	}
}

void FRWMods::SpawnProps(ARWWorld* World)
{
	if (!World || !World->Terrain) return;
	for (const FRWModProp& P : Props)
	{
		const TSharedPtr<FJsonObject>& O = P.Def;
		FString MeshPath, Shape = TEXT("box"), ModelFile;
		O->TryGetStringField(TEXT("mesh"), MeshPath);
		O->TryGetStringField(TEXT("shape"), Shape);
		O->TryGetStringField(TEXT("model"), ModelFile);
		const FVector Pos = JVec(O, TEXT("pos"), FVector::ZeroVector);
		if (!ModelFile.IsEmpty())
		{
			// a building / structure / tree exported from Blender as glTF
			FRWPlaceable Pl; Pl.Name = ModelFile; Pl.ModelPath = P.Folder / ModelFile; Pl.Scale = JNum(O, TEXT("scale"), 1.f);
			bool bObs = true; O->TryGetBoolField(TEXT("obstacle"), bObs);
			FRWEditor::Build(World, Pl, Pos, JNum(O, TEXT("yaw"), 0.f), 1.f);
			const FVector Fp = JVec(O, TEXT("footprint"), FVector(4.f, 4.f, 0.f));
			if (bObs) World->Obstacles.Add({FVector2D(Pos.X, Pos.Y), FVector2D(Fp.X, Fp.Y) * 0.5f, JNum(O, TEXT("yaw"), 0.f)});
			continue;
		}
		const FVector Sz = JVec(O, TEXT("size"), FVector(1.f));
		const float Yaw = JNum(O, TEXT("yaw"), 0.f);
		bool bObstacle = true; O->TryGetBoolField(TEXT("obstacle"), bObstacle);
		const FVector Col = JVec(O, TEXT("color"), FVector(0.5f, 0.5f, 0.5f));
		const float G = World->Terrain->HeightAt(Pos.X, Pos.Y);
		UStaticMesh* Mesh = nullptr;
		if (!MeshPath.IsEmpty()) Mesh = LoadObject<UStaticMesh>(nullptr, *MeshPath);
		if (!MeshPath.IsEmpty() && !Mesh) RWLog(FString::Printf(TEXT("Mod %s: prop mesh %s not found, using a box"), *P.ModName, *MeshPath));
		if (!Mesh && Shape == TEXT("cylinder")) Mesh = ARWMachine::GCyl;
		if (!Mesh && Shape == TEXT("rock")) Mesh = FRWMeshGen::Rock(1.f, 11);
		// meshes sit on the ground (pivot at the base); primitives are centred
		const bool bPivotBase = Mesh && Mesh != ARWMachine::GCyl;
		World->Box(FVector(Pos.X, Pos.Y, G + Pos.Z + (bPivotBase ? 0.f : Sz.Z * 0.5f)), Sz, Yaw, FLinearColor(Col), bObstacle, JNum(O, TEXT("rough"), 0.6f), JNum(O, TEXT("metal"), 0.f), Mesh);
	}
	if (Props.Num()) RWLog(FString::Printf(TEXT("Mod props placed: %d"), Props.Num()));
}

void FRWMods::SpawnAll(ARWGameMode* GM)
{
	int32 Slot = 0;
	for (const FRWModMachine& D : Machines)
	{
		UClass* C = BaseClass(D.Base);
		FVector Sp = JVec(D.Def, TEXT("spawn"), FVector(1e9, 0, 0));
		if (Sp.X > 1e8) Sp = FVector(-200.f + Slot * 8.f, -174.f, 90.f); // second row of the machine yard
		++Slot;
		ARWMachine::PendingMod = &D;
		ARWMachine* M = GM->SpawnMachine(C, D.Size, Sp.X, Sp.Y, Sp.Z, false);
		ARWMachine::PendingMod = nullptr;
		if (M) RWLog(FString::Printf(TEXT("Mod machine spawned: %s (%s)"), *D.Name, *D.ModName));
	}
}
