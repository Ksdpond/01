﻿// Deformable soil terrain: a 0.5 m heightfield with per-point layer stacks
// (material, thickness, compaction), moisture, vegetation, granular slope relaxation
// and chunked/LOD procedural mesh rendering.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RWTypes.h"
#include "RWTerrain.generated.h"

class UProceduralMeshComponent;
class UMaterialInterface;
class FRWLayout;

struct FLayers
{
	uint8 Count = 0;
	uint8 Mat[4] = {0, 0, 0, 0};
	uint8 Comp[4] = {0, 0, 0, 0}; // 0..255 compaction
	float T[4] = {0, 0, 0, 0};    // thickness in metres
	float Total() const { float S = 0; for (int32 k = 0; k < Count; ++k) S += T[k]; return S; }
};

UCLASS()
class ROADWORKS_API ARWTerrain : public AActor
{
	GENERATED_BODY()
public:
	ARWTerrain();

	static constexpr int32 N = 9001;          // points per side
	static constexpr float CS = 0.5f;         // spacing (m)
	static constexpr float Half = 2250.f;     // world spans [-Half, Half]: a 4500 x 4500 m map
	static constexpr int32 ChunkCells = 120;
	static constexpr int32 NumChunks = 75;
	static constexpr float CellArea = CS * CS;

	float WaterZ = 0.f;
	const FRWLayout* Layout = nullptr;

	void Generate(const FRWLayout* InLayout, UMaterialInterface* Mat);

	// ---- queries (metres, world space) ----
	FORCEINLINE int32 Idx(int32 X, int32 Y) const { return Y * N + X; }
	FORCEINLINE bool Valid(int32 X, int32 Y) const { return X >= 0 && Y >= 0 && X < N && Y < N; }
	FORCEINLINE float PX(int32 X) const { return -Half + X * CS; }
	FORCEINLINE int32 ToGrid(float W) const { return FMath::RoundToInt((W + Half) / CS); }
	bool InBounds(float X, float Y) const { return X > -Half && X < Half && Y > -Half && Y < Half; }
	int32 IndexAt(float X, float Y) const;
	float HeightAt(float X, float Y) const;
	FVector NormalAt(float X, float Y) const;
	ESoil SurfaceMat(int32 i) const;
	float SurfaceComp(int32 i) const;
	float MoistureAt(int32 i) const { return Moist[i] / 255.f; }
	FSoilState SurfaceState(int32 i) const;
	ESoil MatAtDepth(int32 i, float DepthBelowSurface) const;

	// ---- edits ----
	// Removes up to Dh metres of height at point i, adds loose material to Out. Returns removed height.
	float RemoveAt(int32 i, float Dh, FPayload& Out, bool bAllowRock = false);
	// points where something buried stands in the ground (a pipe): nothing is dug away below this height there
	TMap<int32, float> DigFloor;
	void DepositAt(int32 i, ESoil M, float LooseVol, float Moisture, uint8 Comp = 0);
	void DepositPayloadAt(int32 i, const FPayload& P);
	// Compacts the top layer. Amount = fraction of remaining compaction gained.
	void CompactAt(int32 i, float Amount);
	// Shared, world-space tyre/crawler footprint deformation. Metres, Newtons, normalized slip.
	// All machines use the existing heightfield, soil layers and persistence.
	// Returns total material displaced sideways in loose cubic metres.
	// MaxRutDepth: the deepest a rut gets below the natural ground under this wheel / track (m; 0 = no limit) - a wheel
	// rides on its rim and frame once it has sunk that far
	float ApplyContactRut(const FVector2D& Center, const FVector2D& Forward,
		float ContactLength, float ContactWidth, float NormalLoadN, float Slip,
		float PassFactor, bool bCrawler, float MaxRutDepth = 0.f);
	void AddMoisture(int32 i, float D);
	void ClearGrass(int32 i, float Amt);
	void AddGrass(int32 i, float Amt);
	void BreakRock(int32 i, float Depth); // turns large rock at surface into small rock layer
	void Touch(int32 i, bool bRelax = true);

	// Spread a payload over a disc (falling material).
	void DepositDisc(float X, float Y, float R, const FPayload& P);

	// ---- simulation ----
	void Relax(int32 Budget);
	// the settling the game runs for one frame of Dt seconds (the game and the tests both call this): as much per second at
	// any frame rate (9000 points a frame at 60 fps)
	void RelaxFor(float Dt);
	// Soil just put down somewhere (the pile in front of a dozer's blade...) settles at once to its angle of repose, the same
	// rule Relax follows, but straight away and with the excess shared between all the lower neighbours - instead of waiting
	// in the queue while the machine piles on more (which stood it up in a ridge metres too steep). Wall: points no soil may
	// flow onto (the blade itself). Nothing is lost or made: soil only moves. Returns the volume moved (m3).
	float SettleAround(float X, float Y, float R, int32 Iterations, TFunctionRef<bool(int32)> Wall);
	// Terrain tests: in the box (centre, half sizes, m) the points sticking up more than 8 cm above all eight neighbours, the
	// loose points standing steeper than their angle of repose (+10 deg, + 5 cm) to a neighbour, and the worst spike (m)
	// WorstOver: the most any loose point stands above what its own angle of repose allows to a neighbour (m); Vol: the
	// ground's volume in the box above height 0 (m3), to follow what was added or taken
	void SpikeCount(const FVector2D& C, float HalfX, float HalfY, int32& Peaks, int32& Steep, float& WorstPeak, float* WorstOver = nullptr, double* Vol = nullptr, int32* WorstAt = nullptr) const;
	void UpdateMoisture(float Dt, float RainRate, float DryRate);

	// ---- rendering ----
	void UpdateMeshes(const FVector& CamM, bool bForceAll);
	int32 PendingChunks() const;

	// ---- persistence / testing ----
	void SaveTo(TArray<uint8>& Out) const;
	bool LoadFrom(const TArray<uint8>& In);
	double LooseBook() const; // loose-equivalent material balance used by the conservation tests
	uint32 Checksum() const;

	// Event hooks (jobs listen to these).
	TFunction<void(int32, ESoil, float)> OnDeposit;
	TFunction<void(int32, ESoil, float)> OnRemove;
	TFunction<void(int32)> OnTouch; // any change of height at point i (the water simulation listens)
	// the ground at point i was worked (dug, filled, pressed, driven over): plants on it are gone (the world listens)
	TFunction<void(int32)> OnDisturb;
	// how much grass the point had when the map was made; ground with much less than that has been worked since
	uint8 GenGrass(int32 i) const;
	TArray<uint8> GrassGen; // (the grass of every point as the map was made)
	bool IsWorked(int32 i) const { return Grass.IsValidIndex(i) && Grass[i] + 30 < GenGrass(i); }

	TArray<float> Natural, Base, Height;
	TArray<FLayers> Layers;
	TArray<uint8> BaseComp, Moist, Grass;

	UPROPERTY() TArray<UProceduralMeshComponent*> ChunkComps;
	UPROPERTY() UProceduralMeshComponent* Backdrop = nullptr;
	UPROPERTY() UMaterialInterface* TerrainMat = nullptr;
	// textured soil (M_TerrainPBR): vertices carry soil-type weights instead of a flat colour
	bool bPBR = false;
	void SetPBR(bool bOn, UMaterialInterface* Mat);
	void PBRWeights(int32 i, FLinearColor& Col, FVector2D& UV1, FVector2D& UV2, FVector2D& UV3) const;

private:
	struct FChunk { int32 Lod = -1; bool bDirty = true; int32 Verts = 0; };
	TArray<FChunk> Chunks;
	TArray<int32> ActiveList;
	TBitArray<> ActiveFlag;
	int32 MoistRow = 0;
	uint32 DepositSeq = 0; // varies how each dumped load spreads, so heaps are lumpy rather than perfect cones
	TArray<int32> TriCache[5];
	static int32 LodStep(int32 Lod) { static const int32 S[5] = {1, 2, 4, 8, 24}; return S[Lod]; } // grid points between mesh vertices
	// what was built on the ground at the start (roads, yards), so that a loaded game can put an edited chunk back first
	struct FGenPoint { FLayers L; uint8 BaseC = 175; uint8 G = 0; };
	TMap<int32, FGenPoint> GenPoints;
	// the chunks somebody has changed: only they go into a save, the rest comes back from the map generator
	TBitArray<> ChunkEdited;
	void MarkEdited(int32 i);
	void ResetEditedChunks();

	void Recalc(int32 i) { Height[i] = Base[i] + Layers[i].Total(); }
	void BuildChunk(int32 C, int32 Lod);
	void BuildTriangles(int32 Lod);
	FLinearColor PointColor(int32 i) const;
	void BuildBackdrop();
	double FarDirtyAt = 0.0;
	TArray<uint8> NatSurf; // surface soil of each point of the untouched ground
	void MarkChunk(int32 X, int32 Y);
};
