#include "RWSoilLook.h"
#include "RWMachine.h"
#include "Engine/Texture2D.h"
#include "Materials/MaterialInstanceDynamic.h"

UMaterialInterface* FRWSoilLook::LooseMat = nullptr;
TMap<FString, UTexture2D*> FRWSoilLook::Cache;
TMap<TWeakObjectPtr<UMaterialInstanceDynamic>, int32> FRWSoilLook::Last;

void FRWSoilLook::Init()
{
	LooseMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Materials/M_SoilLoose.M_SoilLoose"));
	if (LooseMat) LooseMat->AddToRoot();
	RWLog(FString::Printf(TEXT("Loose soil look: %s"), LooseMat ? TEXT("textured (M_SoilLoose)") : TEXT("plain colour (M_SoilLoose missing)")));
}

FString FRWSoilLook::SetFor(ESoil M, float Moist)
{
	switch (M)
	{
	case ESoil::DrySoil: return Moist > 0.72f ? TEXT("WetMud") : Moist > 0.4f ? TEXT("Loam") : TEXT("DrySoil");
	case ESoil::WetSoil: return TEXT("Loam");
	case ESoil::Mud: return Moist > 0.85f ? TEXT("PeatSwamp") : TEXT("WetMud");
	case ESoil::Sand: return TEXT("SandySoil");
	case ESoil::Gravel: return TEXT("GravelSoil");
	case ESoil::SmallRock: return TEXT("RockySoil");
	case ESoil::LargeRock: return TEXT("Volcanic");
	case ESoil::Clay: return TEXT("GreyClay");
	case ESoil::Laterite: return TEXT("LateriteRed");
	case ESoil::Compacted: return TEXT("CompactedDirt");
	case ESoil::Asphalt: return TEXT("Volcanic");
	default: return TEXT("DrySoil");
	}
}

UTexture2D* FRWSoilLook::Tex(const FString& Set, const TCHAR* Kind)
{
	const FString Name = FString::Printf(TEXT("T_Soil_%s_%s"), *Set, Kind);
	if (UTexture2D** F = Cache.Find(Name)) return *F;
	UTexture2D* T = LoadObject<UTexture2D>(nullptr, *FString::Printf(TEXT("/Game/Textures/Soil/%s.%s"), *Name, *Name));
	if (T) T->AddToRoot();
	Cache.Add(Name, T);
	return T;
}

bool FRWSoilLook::IsTextured(UMaterialInstanceDynamic* MID) { return MID && LooseMat && MID->Parent == LooseMat; }

UMaterialInstanceDynamic* FRWSoilLook::Make(UObject* Outer, ESoil M, float Moist)
{
	UMaterialInstanceDynamic* MID = UMaterialInstanceDynamic::Create(LooseMat ? LooseMat : ARWMachine::GPaint, Outer);
	if (!LooseMat) { MID->SetScalarParameterValue(TEXT("Roughness"), 0.95f); MID->SetScalarParameterValue(TEXT("Metallic"), 0.f); }
	Apply(MID, M, Moist);
	return MID;
}

void FRWSoilLook::Apply(UMaterialInstanceDynamic* MID, ESoil M, float Moist)
{
	if (!MID) return;
	const int32 Key = (int32)M * 32 + FMath::Clamp(FMath::RoundToInt(Moist * 20.f), 0, 20);
	if (const int32* K = Last.Find(MID)) if (*K == Key) return;
	Last.Add(MID, Key);
	const FSoilProps& P = SoilProps(M);
	if (!IsTextured(MID))
	{
		MID->SetVectorParameterValue(TEXT("Color"), FMath::Lerp(P.Color, P.WetColor, FMath::Clamp(Moist, 0.f, 1.f)));
		return;
	}
	const FString Set = SetFor(M, Moist);
	if (UTexture2D* T = Tex(Set, TEXT("BaseColor"))) MID->SetTextureParameterValue(TEXT("BaseTex"), T);
	if (UTexture2D* T = Tex(Set, TEXT("Normal"))) MID->SetTextureParameterValue(TEXT("NormalTex"), T);
	if (UTexture2D* T = Tex(Set, TEXT("ORM"))) MID->SetTextureParameterValue(TEXT("ORMTex"), T);
	// wet soil darkens with a dull sheen; fully wet it used to shine like glass
	MID->SetScalarParameterValue(TEXT("Wet"), FMath::Clamp(Moist * 1.1f - 0.1f, 0.f, 0.45f));
	// loose, freshly dug soil is a touch lighter and coarser than the same soil packed in the ground
	MID->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.05f, 1.03f, 1.f));
	MID->SetScalarParameterValue(TEXT("Tiling"), M == ESoil::Gravel || M == ESoil::SmallRock || M == ESoil::LargeRock ? 0.45f : 0.6f);
}
