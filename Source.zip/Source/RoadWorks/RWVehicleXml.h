#pragma once
#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"
class ARWMachine;
class USceneComponent;

// RoadWorks-owned FS25-inspired schema, not GIANTS' original XML schema.
class FRWVehicleXml
{
public:
 bool Load(const FString& Path, ARWMachine* Owner);
 // only the <mass> section, for a machine whose controls stay its own (mod.json not set to XML control): no control,
 // joint or hydraulic of the file is bound. True when masses were read and none was rejected.
 static bool LoadMassOnly(const FString& Path, ARWMachine* Owner);
 void Update(ARWMachine* Owner, float Dt);
 bool IsLoaded() const { return bLoaded; }
 // for tests: a hydraulic's present pin-to-pin length and the shortest / longest it has been (cm); false if there is none
 bool HydraulicLength(int32 Index, float& Now, float& Min, float& Max) const;
private:
 // reads <mass> into Owner->XmlMassKg; returns the entries bound, counts the rejected ones into Rejected
 static int32 ReadMass(const class FXmlNode* Root, ARWMachine* Owner, int32& Rejected);
 struct FTool
 {
  FString Node, Input, Id;
  bool bTranslate = false;
  FVector BaseLocation = FVector::ZeroVector;
  TWeakObjectPtr<USceneComponent> Component;
  FQuat Base = FQuat::Identity;
  FVector Axis = FVector::XAxisVector;
  float Min=-45, Max=45, Speed=30, Angle=0;
  bool bInvert=false;
 };
 struct FHydraulic
 {
  FString Name;
  TWeakObjectPtr<USceneComponent> Barrel, Rod, Start, End;
  TWeakObjectPtr<USceneComponent> Space; // the machine's body: rest pose and motion are kept in its frame
  FVector BarrelBaseScale = FVector::OneVector, RodBaseScale = FVector::OneVector;
  FVector RestA = FVector::ZeroVector, RestB = FVector::ZeroVector; // pins at rest, in Space (cm)
  FTransform BarrelRest, RodRest;                                    // the two parts at rest, in Space
  float MinLen = 0.f, MaxLen = 0.f;                                  // pin-to-pin length seen so far (cm)
  bool bInitialized=false;
 };
 TArray<TWeakObjectPtr<USceneComponent>> Anchors;
 TArray<FTool> Tools;
 TArray<FHydraulic> Hydraulics;
 bool bLoaded=false;
};
