// Soil mechanics for digging: our own replacement for a commercial shovel/terrain physics plugin.
// The force on a cutting blade comes from the Fundamental Earthmoving Equation (Reece 1964; McKyes 1985), the same family
// of soil-wedge model used by professional earthmoving simulators:
//     F = (rho g d^2 Ng + c d Nc + ca d Na + q d Nq) W
// d depth of cut, W width, rho soil density, c cohesion, ca adhesion to the steel, q load on the soil ahead. The N factors
// depend on the blade angle, the friction angles and the failure plane, which is the angle needing the least force.
// See Docs/DIG_PHYSICS.md.
#pragma once

#include "CoreMinimal.h"
#include "RWTypes.h"

struct FRWSoilStrength
{
	float PhiDeg = 30.f;   // internal friction angle
	float DeltaDeg = 18.f; // soil-on-steel friction angle
	float Cohesion = 0.f;  // Pa
	float Adhesion = 0.f;  // Pa, soil sticking to the steel
	float Density = 1600.f;// kg/m3
};

struct FRWCutForce
{
	float Total = 0.f;      // N, on the blade
	float Horizontal = 0.f; // N, along the direction of the cut
	float Vertical = 0.f;   // N, across it (lifts the machine when the soil is cut upwards)
	float FailureDeg = 0.f; // angle of the plane the soil breaks along
	float WedgeVol = 0.f;   // m3 of soil in the failing wedge
};

struct ROADWORKS_API FRWSoilMech
{
	// strength of a soil from its type, wetness (0..1) and compaction (0..1)
	static FRWSoilStrength Strength(ESoil M, float Moist, float Comp);
	// RakeDeg: blade angle to the direction of travel. Speed in m/s adds the force of throwing the soil aside.
	// SurchargePa: pressure of soil already piled on the failing ground.
	static FRWCutForce CutForce(const FRWSoilStrength& S, float Depth, float Width, float RakeDeg, float Speed, float SurchargePa = 0.f);
	// hydraulic speed left under a load: full flow up to half the force limit, then the pump's power runs out,
	// and near the limit only a creep is left while the relief valve blows
	static float HydSpeedScale(float ForceFrac) { return FMath::Clamp((1.f - ForceFrac) * 2.f, 0.04f, 1.f); }
};
