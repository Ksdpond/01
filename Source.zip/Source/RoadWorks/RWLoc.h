// Localisation: English source strings, Thai translations loaded from Content/Lang/th.txt
// (UTF-8, "English<TAB>Thai" per line) plus mod translations. Runtime font with Thai glyphs.
#pragma once

#include "CoreMinimal.h"

class UFont;

ROADWORKS_API extern int32 GRWLang; // 0 = English, 1 = Thai
ROADWORKS_API void RWLocInit();
ROADWORKS_API void RWLocAdd(const FString& En, const FString& Th);
ROADWORKS_API void RWLocSaveSetting();
ROADWORKS_API FString TR(const FString& En);
ROADWORKS_API UFont* RWFont(bool bBig);
ROADWORKS_API FString RWNum(double V, int32 Decimals = 0);

// Translated format string with {0} {1} ... placeholders.
template <typename... TArgs>
FString TRF(const TCHAR* Fmt, TArgs&&... Args)
{
	FStringFormatOrderedArguments A;
	(A.Add(FStringFormatArg(Args)), ...);
	return FString::Format(*TR(Fmt), A);
}
