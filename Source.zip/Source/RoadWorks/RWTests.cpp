﻿// Automated self-tests: run the game with -rwtest (add -rwtestexit to quit afterwards).
// Every result is written to Saved/Logs/RoadWorks_Tests.log with PASS/FAIL and the measured numbers.
#include "RWGame.h"
#include "RWTerrain.h"
#include "RWEffects.h"
#include "RWWorld.h"
#include "RWMachine.h"
#include "RWMachines.h"
#include "Misc/CommandLine.h"
#include "RWMods.h"
#include "RWPlatform.h"
#include "RWEditor.h"
#include "RWFab.h"
#include "RWSoilMech.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Materials/Material.h"
#include "Engine/StaticMesh.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "HAL/PlatformMisc.h"
#include "RWWater.h"
#include "RWSoilLook.h"
#include "ProceduralMeshComponent.h"
#include "Misc/FileHelper.h"
#include "HAL/FileManager.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/Texture.h"
#include "Engine/StaticMeshActor.h"
#include "RWAudio.h"
#include "Misc/ScopeExit.h"
#include "Components/StaticMeshComponent.h"
#include "RWVehicleXml.h"

static int32 GPass = 0, GFail = 0;
static void Check(const FString& Name, bool bOk, const FString& Detail)
{
	(bOk ? GPass : GFail)++;
	RWTestLog(FString::Printf(TEXT("%s  %s  -  %s"), bOk ? TEXT("PASS") : TEXT("FAIL"), *Name, *Detail));
}

static double AreaVolume(ARWTerrain* T, float CX, float CY, float R)
{
	double S = 0;
	for (float y = CY - R; y <= CY + R; y += ARWTerrain::CS)
		for (float x = CX - R; x <= CX + R; x += ARWTerrain::CS)
			S += T->Height[T->IndexAt(x, y)] * ARWTerrain::CellArea;
	return S;
}

void ARWGameMode::RunSelfTests()
{
	GPass = GFail = 0;
	RWTestLog(TEXT("================ RoadWorks self tests ================"));
	ARWTerrain* T = Terrain;
	const float Dt = 1.f / 60.f;
	// 1. dig & deposit bookkeeping
	{
		const int32 i = T->IndexAt(30.f, -80.f);
		const float H0 = T->Height[i];
		FPayload P;
		const float Got = T->RemoveAt(i, 0.3f, P);
		const float H1 = T->Height[i];
		const double Loose = P.Total();
		T->DepositPayloadAt(i, P);
		const float H2 = T->Height[i];
		Check(TEXT("Terrain cut"), FMath::IsNearlyEqual(H0 - H1, 0.3f, 0.002f) && FMath::IsNearlyEqual(Got, 0.3f, 0.002f), FString::Printf(TEXT("removed %.3f m, loose %.4f m3 (%s)"), H0 - H1, Loose, *SoilName(P.Dominant(), P.Moist)));
		Check(TEXT("Bulking on re-deposit"), H2 > H0 && H2 - H0 < 0.15f, FString::Printf(TEXT("refilled surface %.3f m above original (loose swell)"), H2 - H0));
	}
	// 2. compaction
	{
		const int32 i = T->IndexAt(31.f, -80.f);
		T->DepositAt(i, ESoil::DrySoil, 0.1f, 0.45f, 0);
		const float H0 = T->Height[i];
		for (int32 k = 0; k < 8; ++k) T->CompactAt(i, 0.35f);
		Check(TEXT("Compaction"), T->SurfaceComp(i) > 0.85f && T->Height[i] < H0, FString::Printf(TEXT("compaction %.0f%%, settlement %.1f cm, material now %s"), T->SurfaceComp(i) * 100.f, (H0 - T->Height[i]) * 100.f, *SoilName(T->SurfaceMat(i), T->MoistureAt(i))));
	}
	// 3. angle of repose relaxation conserves loose volume
	{
		const double B0 = T->LooseBook();
		FPayload P; P.Add(ESoil::Sand, 3.f, 0.2f);
		const int32 i = T->IndexAt(-150.f, -170.f);
		T->DepositPayloadAt(i, P);
		for (int32 k = 0; k < 200; ++k) T->Relax(20000);
		const double B1 = T->LooseBook();
		float MaxSlope = 0;
		for (int32 dy = -6; dy <= 6; ++dy) for (int32 dx = -6; dx <= 6; ++dx)
		{
			const int32 a = i + dy * ARWTerrain::N + dx;
			MaxSlope = FMath::Max(MaxSlope, FMath::Abs(T->Height[a] - T->Height[a + 1]) / ARWTerrain::CS);
		}
		Check(TEXT("Granular slump"), MaxSlope < FMath::Tan(FMath::DegreesToRadians(50.f)) && FMath::Abs(B1 - B0 - 3.0) < 0.35, FString::Printf(TEXT("3 m3 sand column -> max slope %.0f deg, book change %.2f m3"), FMath::RadiansToDegrees(FMath::Atan(MaxSlope)), B1 - B0));
	}
	// 4. excavator digs real soil into the bucket
	ARWExcavator* E = nullptr; ARWDumpTruck* Tr = nullptr; ARWDozer* Dz = nullptr;
	for (ARWMachine* M : Machines) { if (!E) E = Cast<ARWExcavator>(M); if (!Tr) Tr = Cast<ARWDumpTruck>(M); if (!Dz) Dz = Cast<ARWDozer>(M); }
	if (E)
	{
		E->bEngineOn = true; E->ThrottleDial = 1.f; E->Rpm = E->MaxRpm;
		E->BoomA = -12.f; E->ArmA = -70.f; E->BktA = -20.f;
		E->InA4 = 0.f; E->VSwing = 0.f; // no swing left over from before: sweeping would pile up loose soil in the measured area
		for (int32 k = 0; k < 10; ++k) E->SimStep(Dt);
		const FVector Tip = E->TipWorld();
		const double V0 = AreaVolume(T, Tip.X, Tip.Y, 8.f); // wide enough for the whole stroke of the stick
		const FVector DigPos0 = E->PosM; const float DigYaw0 = E->Yaw, DigSwing0 = E->Swing, DigSwept0 = E->Bucket.SweptVol;
		const float Load0 = E->Bucket.Load.Total();
		int32 BranchFrames[4] = {0, 0, 0, 0}; float PeakLoad = 0.f;
		for (int32 k = 0; k < 160; ++k)
		{
			E->InA1 = -0.3f; E->InA2 = -1.f; E->InA3 = -1.f; E->SimStep(Dt); BranchFrames[FMath::Clamp(E->DbgBranch, 0, 3)]++; PeakLoad = FMath::Max(PeakLoad, E->Bucket.Load.Total());
		}
		E->InA1 = E->InA2 = E->InA3 = 0;
		const double V1 = AreaVolume(T, Tip.X, Tip.Y, 8.f);
		const float Load = E->Bucket.Load.Total();
		RWTestLog(FString::Printf(TEXT("   info: %s at %.1f, %.1f (ground %.2f m, machine %.2f m): moved %.3f m, yaw %.2f deg, swing %.2f deg, swept %.3f m3 during the stroke"), *E->Model, E->PosM.X, E->PosM.Y, T->HeightAt(E->PosM.X, E->PosM.Y), E->PosM.Z, FVector::Dist(E->PosM, DigPos0), E->Yaw - DigYaw0, E->Swing - DigSwing0, E->Bucket.SweptVol - DigSwept0));
		Check(TEXT("Excavator digging"), Load > 0.1f && V0 - V1 > 0.05, FString::Printf(TEXT("bucket %.2f -> %.2f m3 loose (%s, %.0f kg), peak %.2f; ground lost %.2f m3 bank; tip starts %.2f m below ground; frames digging %d, grading %d, sweeping %d"), Load0, Load, *SoilName(E->Bucket.Load.Dominant(), E->Bucket.Load.Moist), E->Bucket.Load.MassKg(), PeakLoad, V0 - V1, T->HeightAt(Tip.X, Tip.Y) - Tip.Z, BranchFrames[0], BranchFrames[1], BranchFrames[2]));
		const int32 Chunks = Fx->LiveChunks();
		Check(TEXT("Soil breaks out of the cut face"), Chunks > 0 && E->Bucket.CutDepth > 0.f, FString::Printf(TEXT("%d breakout lumps thrown, last cut in %s at %.2f m below natural ground"), Chunks, *SoilName(E->Bucket.CutMat, E->Bucket.CutMoist), E->Bucket.CutDepth));
	}
	// 4b. the bucket fills only when its mouth meets the cut; dragging the flat bottom ploughs and resists
	{
		auto Drag = [&](float X, const FVector& Mouth, float& ResOut) -> float
		{
			FBucketTool B; B.Width = 1.f; B.Capacity = 1.f;
			const float Y = -88.f;
			FVector Tip(X, Y, T->HeightAt(X, Y) - 0.25f);
			const FVector Vel(0.5f, 0, 0);
			float ResSum = 0.f;
			for (int32 k = 0; k < 30; ++k)
			{
				Tip += Vel * Dt;
				ResSum += B.Dig(T, Tip, Tip + FVector(-0.6f, 0, 0.2f), FVector(0, 1, 0), Vel, Mouth, 1.f, Dt);
			}
			ResOut = ResSum / 30.f;
			return B.Load.Total();
		};
		float RIn = 0, RFlat = 0;
		const float In = Drag(24.f, FVector(1, 0, 0), RIn);
		const float Flat = Drag(27.f, FVector(0, 0, 1), RFlat);
		Check(TEXT("Bucket angle of attack matters"), In > Flat * 1.6f && In > 0.02f && RFlat > RIn,
			FString::Printf(TEXT("mouth into the cut: %.3f m3 (resistance %.2f); flat bottom dragging: %.3f m3 (resistance %.2f)"), In, RIn, Flat, RFlat));
	}
	// 4c. heaped load: weight rises with volume, fast swings shake the heap off the top
	{
		auto Shaken = [&](float Shake) -> float
		{
			FBucketTool B; B.Width = 1.f; B.Capacity = 1.f;
			B.Load.Add(ESoil::DrySoil, 1.2f, 0.2f);
			B.Shake = Shake;
			const FVector At(33.f, -92.f, T->HeightAt(33.f, -92.f) + 2.f);
			for (int32 k = 0; k < 60; ++k) B.Spill(Fx, At, FVector::ZeroVector, FVector(0, 0, 1), Dt);
			return 1.2f - B.Load.Total();
		};
		FPayload One; One.Add(ESoil::DrySoil, 1.f, 0.2f);
		FPayload Heaped; Heaped.Add(ESoil::DrySoil, 1.2f, 0.2f);
		const float Calm = Shaken(0.f), Hard = Shaken(14.f);
		Fx->SettleAll();
		Check(TEXT("Heaped bucket spills when swung hard"), Calm < 0.01f && Hard > 0.05f && Heaped.MassKg() > One.MassKg(),
			FString::Printf(TEXT("1.2 m3 in a 1.0 m3 bucket: calm swing lost %.3f m3, hard swing lost %.3f m3; load %.0f kg vs %.0f kg level-full"), Calm, Hard, Heaped.MassKg(), One.MassKg()));
	}
	// 4d. dumping builds an irregular heap that slumps to its angle of repose
	{
		const float CXm = -130.f, CYm = -176.f;
		for (int32 k = 0; k < 200; ++k) T->Relax(20000); // let the pits of the digging tests above finish slumping first
		const double B0 = T->LooseBook();
		for (int32 k = 0; k < 40; ++k)
		{
			FPayload P; P.Add(ESoil::DrySoil, 0.1f, 0.25f);
			T->DepositDisc(CXm + FMath::Sin(k * 1.7f) * 0.3f, CYm + FMath::Cos(k * 2.3f) * 0.3f, 0.55f, P);
		}
		for (int32 k = 0; k < 200; ++k) T->Relax(20000);
		const double B1 = T->LooseBook();
		const float G0 = T->Natural[T->IndexAt(CXm + 4.f, CYm)];
		TArray<float> Ring;
		float Mean = 0;
		for (int32 a = 0; a < 16; ++a)
		{
			const float A = a / 16.f * 2.f * PI;
			Ring.Add(T->HeightAt(CXm + FMath::Cos(A) * 1.5f, CYm + FMath::Sin(A) * 1.5f));
			Mean += Ring.Last() / 16.f;
		}
		float Var = 0; for (float H : Ring) Var += FMath::Square(H - Mean) / 16.f;
		const float Peak = T->Height[T->IndexAt(CXm, CYm)] - G0;
		Check(TEXT("Dumped soil forms an irregular heap"), FMath::Sqrt(Var) > 0.005f && Peak > 0.2f && FMath::Abs(B1 - B0 - 4.0) < 0.4,
			FString::Printf(TEXT("4 m3 dumped: heap %.2f m high, height around its flank varies +-%.1f cm, book change %.2f m3"), Peak, FMath::Sqrt(Var) * 100.f, B1 - B0));
	}
	// 4e. layered ground: digging deeper meets different strata with different hardness
	{
		TSet<int32> Seen; FString Seq;
		for (int32 p = 0; p < 120 && !(Seen.Num() >= 6 && Seen.Contains((int32)ESoil::Sand)); ++p)
		{
			const float X = -100.f + (p % 12) * 17.f, Y = -20.f + (p / 12) * 13.f;
			const int32 i = T->IndexAt(X, Y);
			ESoil Last = ESoil::Count;
			FString S;
			for (float D = 0.05f; D < 9.f; D += 0.1f)
			{
				const ESoil M = T->MatAtDepth(i, D);
				if (M == Last) continue;
				Last = M; Seen.Add((int32)M);
				S += FString::Printf(TEXT("%s%s @%.1fm"), S.IsEmpty() ? TEXT("") : TEXT(" > "), SoilProps(M).Name, D);
			}
			const bool bSandS = S.Contains(TEXT("Sand")), bSandQ = Seq.Contains(TEXT("Sand"));
			if ((bSandS && !bSandQ) || (bSandS == bSandQ && Seq.Len() < S.Len())) Seq = S;
		}
		Check(TEXT("Ground has layered strata"), Seen.Num() >= 5 && Seen.Contains((int32)ESoil::Sand), FString::Printf(TEXT("%d soil types found down to 9 m, e.g. %s"), Seen.Num(), *Seq));
	}
	// 5. truck bed catches falling material, 6. tipping returns it to the ground
	if (Tr)
	{
		Tr->Load.Clear();
		const FVector Bed = Tr->BedP->GetComponentTransform().TransformPosition(FVector(Tr->BedLen * 50.f, 0, 250.f)) * CM2M;
		FPayload P; P.Add(ESoil::Clay, 1.5f, 0.3f);
		Fx->SpawnSoil(Bed, FVector::ZeroVector, P, 0.4f);
		for (int32 k = 0; k < 120; ++k) Fx->Tick(Dt);
		Check(TEXT("Truck bed receives material"), Tr->Load.Total() > 1.4f, FString::Printf(TEXT("caught %.2f of 1.50 m3, payload %.0f kg"), Tr->Load.Total(), Tr->Load.MassKg()));
		const float M0 = Tr->Mass();
		Tr->Load.Add(ESoil::Gravel, 6.f, 0.1f);
		const float Squat0 = Tr->BodyZ;
		for (int32 k = 0; k < 120; ++k) Tr->SimStep(Dt);
		Check(TEXT("Suspension squats under load"), Tr->BodyZ < Squat0 - 0.005f || Tr->BodyZ < -0.02f, FString::Printf(TEXT("body height %.3f m with %.1f t aboard (mass %.0f -> %.0f kg)"), Tr->BodyZ, Tr->PayloadKg() / 1000.f, M0, Tr->Mass()));
		const float Before = Tr->Load.Total();
		const double B0 = T->LooseBook() + Fx->InFlightVolume();
		Tr->bEngineOn = true; Tr->Rpm = 1500;
		for (int32 k = 0; k < 600; ++k) { Tr->InA1 = 1.f; Tr->SimStep(Dt); Fx->Tick(Dt); }
		Tr->InA1 = 0;
		for (int32 k = 0; k < 200; ++k) Fx->Tick(Dt);
		Fx->SettleAll();
		const double B1 = T->LooseBook();
		Check(TEXT("Tipping body empties onto the ground"), Tr->Load.Total() < Before * 0.1f && FMath::Abs((B1 - B0) - (Before - Tr->Load.Total())) < 0.6, FString::Printf(TEXT("load %.2f -> %.2f m3, ground gained %.2f m3"), Before, Tr->Load.Total(), B1 - B0));
		for (int32 k = 0; k < 600; ++k) { Tr->InA1 = -1.f; Tr->SimStep(Dt); }
		Tr->InA1 = 0;
	}
	// 7. dozer pushes a pile forward
	if (Dz)
	{
		Dz->bEngineOn = true; Dz->ThrottleDial = 1.f; Dz->Rpm = Dz->MaxRpm;
		Dz->BladeH = -0.08f;
		const FVector P0 = Dz->PosM;
		const double B0 = T->LooseBook();
		for (int32 k = 0; k < 360; ++k) { Dz->InThrottle = 1.f; Dz->InA1 = 0; Dz->SimStep(Dt); }
		Dz->InThrottle = 0;
		const double B1 = T->LooseBook();
		Check(TEXT("Dozer cuts and carries soil"), Dz->CutTotal > 0.3f && FVector::Dist2D(P0, Dz->PosM) > 1.f, FString::Printf(TEXT("cut %.2f m3, travelled %.1f m, pile ahead %.2f m3, push force %.0f kN, loose book +%.2f m3"), Dz->CutTotal, FVector::Dist2D(P0, Dz->PosM), Dz->PileVol, Dz->DrawbarLoad / 1000.f, B1 - B0));
		Dz->BladeH = 0.6f;
		// a crawler on a 25 degree slope, nose down: it stays put with the lever in the middle, comes down no faster than
		// the lever asks, and the brakes hold it with the engine off (it used to run away downhill)
		{
			const FVector KeepP = Dz->PosM; const float KeepPitch = Dz->GroundPitch; const bool KeepOn = Dz->bEngineOn;
			auto Run = [&](bool bOn, float Lever, float Secs) -> float
			{
				Dz->bEngineOn = bOn; Dz->Rpm = bOn ? Dz->MaxRpm : 0.f; Dz->ThrottleDial = 1.f;
				Dz->Speed = 0.f; Dz->bParkBrake = false; Dz->InBrake = 0.f; Dz->InSteer = 0.f;
				float Top = 0.f;
				for (int32 k = 0; k < FMath::RoundToInt(Secs / Dt); ++k)
				{
					Dz->GroundPitch = -25.f; Dz->InThrottle = Lever; Dz->TestDriveStep(Dt);
					Top = FMath::Max(Top, FMath::Abs(Dz->Speed));
				}
				return Top;
			};
			const float Hold = Run(true, 0.f, 3.f);
			const float Lever = 0.4f, Down = Run(true, Lever, 4.f);
			const float Asked = Dz->MaxSpeedF * Lever;
			const float Off = Run(false, 0.f, 3.f);
			Dz->InThrottle = 0.f; Dz->Speed = 0.f; Dz->GroundPitch = KeepPitch; Dz->PosM = KeepP; Dz->bEngineOn = KeepOn;
			Check(TEXT("A crawler holds on a downhill slope"), Hold < 0.1f && Down < Asked * 1.15f + 0.05f && Off < 0.1f,
				FString::Printf(TEXT("25 deg down: lever in the middle top speed %.2f m/s; lever at %.0f%% (asks %.2f m/s) top %.2f m/s; engine off %.2f m/s"), Hold, Lever * 100.f, Asked, Down, Off));
		}
	}
	// 7a. the recorded sounds (souds folder): the tracks, the engine starting and stopping; switching the engine off plays the
	// stop once, turning the key the start once
	{
		FRWSoundFiles::Load();
		const FRWClip& Tk = FRWSoundFiles::Track; const FRWClip& St = FRWSoundFiles::Start; const FRWClip& Sp = FRWSoundFiles::Stop;
		auto Peak = [](const FRWClip& C) { float P = 0.f; for (const float V : C.S) P = FMath::Max(P, FMath::Abs(V)); return P; };
		const bool bFiles = Tk.IsValid() && St.IsValid() && Sp.IsValid() && Peak(Tk) > 0.01f && Peak(St) > 0.01f && Peak(Sp) > 0.01f && Peak(Tk) <= 1.01f;
		bool bStop = false, bStart = false;
		if (Dz && Dz->Synth)
		{
			const bool KeepOn = Dz->bEngineOn;
			Dz->bEngineOn = true; Dz->Cranking = 0.f; Dz->SimStep(Dt);
			const int32 P0 = Dz->Synth->StopCount.load(), S0 = Dz->Synth->StartCount.load();
			Dz->bEngineOn = false; Dz->SimStep(Dt); Dz->SimStep(Dt);
			bStop = Dz->Synth->StopCount.load() == P0 + 1 && Dz->Synth->StartCount.load() == S0;
			Dz->ToggleEngine(); Dz->SimStep(Dt); Dz->SimStep(Dt);
			bStart = Dz->Synth->StartCount.load() == S0 + 1;
			for (int32 k = 0; k < 90; ++k) Dz->SimStep(Dt); // (cranking is over: the engine runs)
			Dz->bEngineOn = KeepOn || Dz->bEngineOn; Dz->Cranking = 0.f;
		}
		auto Say = [&Peak](const FRWClip& C) { return C.IsValid() ? FString::Printf(TEXT("%s %.1f s at %.0f Hz (peak %.2f)"), *C.File, C.Seconds(), C.Rate, Peak(C)) : FString(TEXT("missing")); };
		Check(TEXT("The track, engine start and engine stop sounds come from the souds files"), bFiles && bStop && bStart,
			FString::Printf(TEXT("from %s: tracks %s; start %s; stop %s; engine off plays the stop once: %s, key turned plays the start once: %s"),
				FRWSoundFiles::Folder.IsEmpty() ? TEXT("(no folder)") : *FRWSoundFiles::Folder, *Say(Tk), *Say(St), *Say(Sp), bStop ? TEXT("yes") : TEXT("no"), bStart ? TEXT("yes") : TEXT("no")));
	}
	// 7b. a dozer whose vehicle.xml has <hydraulic> cylinders (the D6): lifting and lowering the blade stretches and
	// shortens them, and the barrel stays on its base pin and the rod on the blade's pin
	{
		ARWDozer* XD = nullptr;
		for (ARWMachine* M : Machines) if (ARWDozer* D = Cast<ARWDozer>(M)) if (D->bXmlControlRequested && !XD) XD = D;
		if (XD)
		{
			XD->bEngineOn = true; XD->ThrottleDial = 1.f; XD->Rpm = XD->MaxRpm;
			for (int32 k = 0; k < 5; ++k) { XD->InA1 = 0.f; XD->SimStep(Dt); } // (the XML is read on the first step)
			float L0 = 0.f, Mn = 0.f, Mx = 0.f;
			const bool bHas = XD->bXmlControlValid && XD->VehicleXml && XD->VehicleXml->HydraulicLength(0, L0, Mn, Mx);
			float H0 = XD->BladeH, HUp = H0, HDown = H0, LUp = L0, LDown = L0;
			if (bHas)
			{
				for (int32 k = 0; k < 300; ++k) { XD->InA1 = 1.f; XD->SimStep(Dt); }
				HUp = XD->BladeH; XD->VehicleXml->HydraulicLength(0, LUp, Mn, Mx);
				for (int32 k = 0; k < 600; ++k) { XD->InA1 = -1.f; XD->SimStep(Dt); }
				HDown = XD->BladeH; XD->VehicleXml->HydraulicLength(0, LDown, Mn, Mx);
				for (int32 k = 0; k < 300; ++k) { XD->InA1 = 1.f; XD->SimStep(Dt); if (XD->BladeH >= H0) break; }
			}
			XD->InA1 = 0.f;
			Check(TEXT("XML hydraulic cylinders follow the blade"), bHas && HUp > HDown + 0.5f && FMath::Abs(LUp - LDown) > 10.f,
				FString::Printf(TEXT("%s: blade %.2f m -> up %.2f m: cylinder %.0f cm; down %.2f m: %.0f cm (rest %.0f cm, range %.0f-%.0f cm)"),
					*XD->ModId, H0, HUp, LUp, HDown, LDown, L0, Mn, Mx));
		}
	}
	// 8. driving: empty vs loaded braking
	if (Tr)
	{
		auto BrakeTest = [&](float Payload) -> FVector2D
		{
			Tr->Load.Clear(); if (Payload > 0) Tr->Load.Add(ESoil::Gravel, Payload, 0.1f);
			Tr->PosM = FVector(-248.f, -112.6f, T->HeightAt(-248.f, -112.6f)); Tr->Yaw = -1.8f; Tr->Speed = 0; Tr->Gear = 1; Tr->bParkBrake = false;
			Tr->bEngineOn = true; Tr->Rpm = 900;
			for (int32 k = 0; k < 60; ++k) Tr->SimStep(Dt);
			float T15 = -1;
			for (int32 k = 0; k < 1500 && Tr->Speed < 12.f; ++k) { Tr->InThrottle = 1.f; Tr->SimStep(Dt); T15 = k * Dt; }
			RWTestLog(FString::Printf(TEXT("   info: payload %.1f t  speed %.1f m/s  gear %d  rpm %.0f  slip %.2f  step %.0f N  traction %.2f  pitch %.1f"), Tr->PayloadKg() / 1000.f, Tr->Speed, Tr->Gear, Tr->Rpm, Tr->WheelSlip, Tr->StepRes, Tr->Traction, Tr->GroundPitch));
			const FVector A = Tr->PosM;
			int32 Steps = 0;
			for (; Steps < 3000 && Tr->Speed > 0.05f; ++Steps) { Tr->InThrottle = 0; Tr->InBrake = 1.f; Tr->SimStep(Dt); }
			Tr->InBrake = 0;
			return FVector2D(T15, FVector::Dist2D(A, Tr->PosM));
		};
		const FVector2D Empty = BrakeTest(0.f), Loaded = BrakeTest(9.f);
		Check(TEXT("Truck accelerates on asphalt"), Empty.X > 0 && Empty.X < 20.f, FString::Printf(TEXT("0-43 km/h in %.1f s empty, %.1f s with 9 m3 gravel"), Empty.X, Loaded.X));
		Check(TEXT("Payload lengthens braking"), Loaded.Y > Empty.Y * 1.1f, FString::Printf(TEXT("stopping distance from 43 km/h: empty %.1f m, loaded %.1f m"), Empty.Y, Loaded.Y));
		// 9. mud: ruts and sinkage
		const FRWZone* Mud = Layout.Find(ERWZone::MudFlat);
		if (Mud)
		{
			Tr->Load.Clear(); Tr->Load.Add(ESoil::Gravel, 9.f, 0.1f);
			const float X0 = Mud->C.X - Mud->HalfExt.X - 8.f;
			Tr->PosM = FVector(X0, Mud->C.Y, T->HeightAt(X0, Mud->C.Y)); Tr->Yaw = 0; Tr->Speed = 0; Tr->Gear = 1; Tr->bParkBrake = false;
			float MaxSlip = 0;
			for (int32 k = 0; k < 1500; ++k) { Tr->InThrottle = 1.f; Tr->SimStep(Dt); MaxSlip = FMath::Max(MaxSlip, Tr->WheelSlip); }
			Tr->InThrottle = 0;
			float Rut = 0;
			for (float y = -3.f; y <= 3.f; y += 0.5f)
				for (float x = X0; x < Tr->PosM.X + 4.f; x += 0.5f)
				{
					const int32 i = T->IndexAt(x, Mud->C.Y + y);
					Rut = FMath::Max(Rut, T->Natural[i] + 0.f - T->Height[i]);
				}
			Check(TEXT("Loaded truck ruts soft mud"), Rut > 0.03f, FString::Printf(TEXT("max rut %.0f cm, max wheel slip %.0f%%, stuck=%s, drove %.1f m (%.1f m into the mud)"), Rut * 100.f, MaxSlip * 100.f, Tr->bStuck ? TEXT("yes") : TEXT("no"), Tr->PosM.X - X0, Tr->PosM.X - (Mud->C.X - Mud->HalfExt.X)));
		}
		Tr->Load.Clear();
	}
	// 10. rain wets the ground
	{
		const int32 MoistStride = T->Moist.Num() / 2001; // spread over the whole map
		double M0 = 0; for (int32 k = 0; k < 2000; ++k) M0 += T->Moist[k * MoistStride];
		for (int32 k = 0; k < 300; ++k) T->UpdateMoisture(0.11f, 0.02f, 0.f); // one full sweep of the map, at a long enough step to show
		double M1 = 0; for (int32 k = 0; k < 2000; ++k) M1 += T->Moist[k * MoistStride];
		Check(TEXT("Rain raises soil moisture"), M1 > M0 * 1.1, FString::Printf(TEXT("mean moisture %.0f%% -> %.0f%%"), M0 / 2000.0 / 2.55, M1 / 2000.0 / 2.55));
	}
	// 11. roller compaction
	{
		ARWRoller* R = nullptr; for (ARWMachine* M : Machines) if (!R) R = Cast<ARWRoller>(M);
		if (R)
		{
			R->bRented = true; R->bEngineOn = true; R->bVibe = true;
			R->PosM = FVector(10.f, -80.f, T->HeightAt(10.f, -80.f)); R->Yaw = 0;
			for (int32 x = 0; x < 30; ++x) for (int32 y = -3; y <= 3; ++y) T->DepositAt(T->IndexAt(12.f + x * 0.5f, -80.f + y * 0.5f), ESoil::Laterite, 0.05f, 0.45f, 0);
			for (int32 pass = 0; pass < 6; ++pass)
			{
				for (int32 k = 0; k < 300; ++k) { R->InThrottle = (pass % 2 == 0) ? 1.f : -1.f; R->SimStep(Dt); }
			}
			R->InThrottle = 0;
			const int32 i = T->IndexAt(17.f, -80.f);
			Check(TEXT("Roller compacts laterite"), T->SurfaceComp(i) > 0.7f, FString::Printf(TEXT("compaction %.0f%% after %d drum passes"), T->SurfaceComp(i) * 100.f, R->Passes));
			R->bRented = false; R->bEngineOn = false; R->bVibe = false;
		}
	}
	// 12. save / load round trip restores the reshaped terrain
	{
		Fx->SettleAll();
		const uint32 C0 = T->Checksum();
		SaveGame(TEXT("selftest"));
		FPayload P; for (int32 k = 0; k < 50; ++k) T->RemoveAt(T->IndexAt(-30.f + k * 0.5f, -60.f), 0.5f, P);
		const uint32 C1 = T->Checksum();
		LoadGame(TEXT("selftest"));
		const uint32 C2 = T->Checksum();
		Check(TEXT("Save / load terrain"), C1 != C0 && C2 == C0, FString::Printf(TEXT("crc saved %08x, after edit %08x, after load %08x"), C0, C1, C2));
	}
	// 13. job measurement
	{
		Jobs.Accept(0);
		Jobs.Evaluate(Jobs.Jobs[0]);
		Check(TEXT("Pond job measured from terrain"), Jobs.Jobs[0].Progress > 0.01f, Jobs.Jobs[0].Status);
		float Z = 0.f;
		Check(TEXT("GPS design grade available"), Jobs.DesignGrade(FVector(62.f, -36.f, 0), Z), FString::Printf(TEXT("design %.2f m at pond centre"), Z));
	}
	// 14. walk to the door, climb in, climb out - machine keeps its state
	ARWPlayerController* PC = Cast<ARWPlayerController>(GetWorld()->GetFirstPlayerController());
	if (PC && Walker && E)
	{
		E->Fuel = 211.f; E->Condition = 0.83f; E->bEngineOn = true;
		Walker->PosM = E->PosM + FVector(-6.f, -4.f, 0.f); Walker->PosM.Z = T->HeightAt(Walker->PosM.X, Walker->PosM.Y);
		PC->BeginEnter(E);
		int32 Steps = 0; bool bSawClimb = false;
		while (PC->Trans != ERWTrans::None && Steps < 900) { PC->StepTransition(Dt); bSawClimb |= Walker->PosM.Z > T->HeightAt(Walker->PosM.X, Walker->PosM.Y) + 0.5f; ++Steps; }
		const bool bIn = PC->Driving == E && Walker->IsHidden();
		Check(TEXT("Climb into the excavator through its door"), bIn && bSawClimb, FString::Printf(TEXT("%.1f s animation, climbed=%s, driving=%s"), Steps * Dt, bSawClimb ? TEXT("yes") : TEXT("no"), PC->Driving ? *PC->Driving->Model : TEXT("none")));
		PC->BeginExit();
		Steps = 0;
		while (PC->Trans != ERWTrans::None && Steps < 900) { PC->StepTransition(Dt); ++Steps; }
		const float DoorDist = FVector::Dist2D(Walker->PosM, E->EntryWorld());
		Check(TEXT("Climb out and machine state is kept"), !PC->Driving && !Walker->IsHidden() && DoorDist < 0.6f && FMath::IsNearlyEqual(E->Fuel, 211.f, 0.5f) && FMath::IsNearlyEqual(E->Condition, 0.83f, 0.01f) && E->bEngineOn,
			FString::Printf(TEXT("standing %.2f m from the door, fuel %.0f L, condition %.0f%%, engine %s"), DoorDist, E->Fuel, E->Condition * 100.f, E->bEngineOn ? TEXT("idling") : TEXT("off")));
		// 15. hand shovel digs and throws real soil
		Walker->PosM = FVector(10.f, -70.f, T->HeightAt(10.f, -70.f)); Walker->Yaw = 0.f;
		const FVector F(1, 0, 0);
		const int32 Di = T->IndexAt(10.9f, -70.f), Ti = T->IndexAt(11.7f, -70.f);
		const float D0 = T->Height[Di], T0 = T->Height[Ti];
		FPayload Spade;
		T->RemoveAt(Di, 0.035f, Spade);
		T->DepositPayloadAt(Ti, Spade);
		Check(TEXT("Hand shovel moves soil"), T->Height[Di] < D0 - 0.03f && T->Height[Ti] > T0 + 0.03f, FString::Printf(TEXT("hole %.1f cm, heap +%.1f cm (%.1f litres)"), (D0 - T->Height[Di]) * 100.f, (T->Height[Ti] - T0) * 100.f, Spade.Total() * 1000.f));
		(void)F;
		// 16. field service restores condition
		E->bOwned = true; E->Condition = 0.6f;
		PC->StartService(E, 0);
		for (int32 k = 0; k < 300; ++k) PC->FootActivities(Dt);
		Check(TEXT("Field service on foot"), E->Condition > 0.64f, FString::Printf(TEXT("condition 60%% -> %.0f%%"), E->Condition * 100.f));
		E->Condition = 1.f;
	}
	// 17. mod switches & achievements
	{
		const int32 Before = FRWMods::Mods.Num();
		bool bToggled = false;
		if (Before > 0)
		{
			FRWMods::SetEnabled(0, false);
			bToggled = FRWMods::DisabledList().Num() > 0;
			FRWMods::SetEnabled(0, true);
		}
		Check(TEXT("Mods load and can be switched off/on"), Before > 0 && bToggled && FRWMods::DisabledList().Num() == 0, FString::Printf(TEXT("%d mod(s), %d mod machines, %d props, %d replacements"), Before, FRWMods::Machines.Num(), FRWMods::Props.Num(), FRWMods::Replacements.Num()));
		Check(TEXT("Achievement system"), FRWPlatform::Achievements().Num() >= 8, FString::Printf(TEXT("%d achievements, backend %s, saves in %s"), FRWPlatform::Achievements().Num(), *FRWPlatform::BackendName(), *FRWPlatform::SaveDir()));
	}
	// 18. player's 3D model excavator: joints move the real parts, cylinders stretch
	{
		ARWExcavator* MX = nullptr;
		// prefer a model whose undercarriage lists its rollers (CX250D), so the wheel checks have something to test
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && (!MX || (MX->TrackSpinners.Num() == 0 && X->TrackSpinners.Num() > 0))) MX = X;
		if (MX)
		{
			for (int32 k = 0; k < 5; ++k) MX->SimStep(Dt); // settle at its start position first
			const FVector Tip0 = MX->TipWorld();
			float Span0 = -1.f, Span1 = -1.f;
			if (MX->Aims.Num() >= 2 && MX->Aims[0].P && MX->Aims[0].Target) Span0 = FVector::Dist(MX->Aims[0].P->GetComponentLocation(), MX->Aims[0].Target->GetComponentLocation());
			MX->bEngineOn = true; MX->Rpm = MX->MaxRpm; MX->ThrottleDial = 1.f;
			const float BoomA0 = MX->BoomA;
			for (int32 k = 0; k < 120; ++k) { MX->InA1 = 1.f; MX->SimStep(Dt); }
			MX->InA1 = 0.f;
			RWTestLog(FString::Printf(TEXT("   info: boom angle %.1f -> %.1f, hyd scale %.2f, resist %.2f, tip %s -> %s, bucket pin %s, machine %s"), BoomA0, MX->BoomA, MX->HydSpeedScale(), MX->Bucket.Resist,
				*Tip0.ToCompactString(), *MX->TipWorld().ToCompactString(), *(MX->BucketP->GetComponentLocation() * CM2M).ToCompactString(), *MX->PosM.ToCompactString()));
			if (MX->Aims.Num() >= 2 && MX->Aims[0].P && MX->Aims[0].Target) Span1 = FVector::Dist(MX->Aims[0].P->GetComponentLocation(), MX->Aims[0].Target->GetComponentLocation());
			const FVector Tip1 = MX->TipWorld();
			Check(TEXT("3D model excavator rig works"), Tip1.Z > Tip0.Z + 0.5f && FMath::Abs(Span1 - Span0) > 0.05f,
				FString::Printf(TEXT("%s: boom raised tip %.2f m, boom cylinder %.2f -> %.2f m, %d cylinder halves"), *MX->Model, Tip1.Z - Tip0.Z, Span0 * CM2M, Span1 * CM2M, MX->Aims.Num()));
			// bucket linkage: curling the bucket swings both links, the joint stays on the arm link's circle
			if (MX->Link.bOn)
			{
				const FVector D0 = MX->Link.BktLink->GetRelativeLocation();
				for (int32 k = 0; k < 60; ++k) { MX->InA3 = -1.f; MX->SimStep(Dt); }
				MX->InA3 = 0.f;
				const FVector D1 = MX->Link.BktLink->GetRelativeLocation();
				const float Circle = FVector2D::Distance(FVector2D(D1.X, D1.Z), MX->Link.C) - MX->Link.L1;
				Check(TEXT("Bucket four-bar linkage follows the bucket"), FVector::Dist(D0, D1) > 3.f && FMath::Abs(Circle) < 1.f,
					FString::Printf(TEXT("link joint moved %.0f cm, stays %.1f cm off the arm-link circle (links %.0f / %.0f cm)"), FVector::Dist(D0, D1), Circle, MX->Link.L1, MX->Link.L2));
			}
			else Check(TEXT("Bucket four-bar linkage follows the bucket"), false, TEXT("linkage not set up"));
			// tracks on freshly dumped loose soil: lay a 25 cm loose layer along the path first
			const float Cy = FMath::Cos(FMath::DegreesToRadians(MX->Yaw)), Sy = FMath::Sin(FMath::DegreesToRadians(MX->Yaw));
			auto At = [&](float Fwd, float Side) { return FVector2D(MX->PosM.X + Cy * Fwd - Sy * Side, MX->PosM.Y + Sy * Fwd + Cy * Side); };
			const float HalfG = MX->TrackGauge * 0.5f;
			for (float F = -3.f; F <= 5.f; F += ARWTerrain::CS)
				for (float Sd = -HalfG - 2.5f; Sd <= HalfG + 2.5f; Sd += ARWTerrain::CS)
				{
					const FVector2D Q = At(F, Sd);
					if (T->InBounds(Q.X, Q.Y)) T->DepositAt(T->IndexAt(Q.X, Q.Y), ESoil::DrySoil, 0.25f * ARWTerrain::CellArea, 0.2f, 0);
				}
			const FVector2D RutP = At(0.5f, -HalfG);                    // under the left track, passed by its rollers
			const float Strip = T->HeightAt(RutP.X, RutP.Y);
			const int32 Prints0 = Fx->TrackPrintCount();
			// tracks: driving moves the track shoes and turns the rollers
			const float T0 = MX->TrackTravelL;
			const FQuat R0 = MX->TrackSpinners.Num() ? MX->TrackSpinners[0].P->GetRelativeRotation().Quaternion() : FQuat::Identity;
			for (int32 k = 0; k < 90; ++k) { MX->InThrottle = 1.f; MX->SimStep(Dt); }
			MX->InThrottle = 0.f;
			const float Ang = MX->TrackSpinners.Num() ? FMath::RadiansToDegrees(R0.AngularDistance(MX->TrackSpinners[0].P->GetRelativeRotation().Quaternion())) : 0.f;
			{
				const float Rut = Strip - T->HeightAt(RutP.X, RutP.Y);
				float Berm = -1.f;
				for (float Sd = HalfG + 0.4f; Sd <= HalfG + 1.9f; Sd += 0.25f) { const FVector2D Q = At(0.5f, -Sd); Berm = FMath::Max(Berm, T->HeightAt(Q.X, Q.Y) - Strip); }
				Check(TEXT("Crawler tracks rut loose soil and push it aside"), Rut > 0.02f && Berm > 0.01f && Fx->TrackPrintCount() > Prints0,
					FString::Printf(TEXT("rut %.1f cm under the track, soil heaved %.1f cm beside it, %d grouser imprints left"), Rut * 100.f, Berm * 100.f, Fx->TrackPrintCount() - Prints0));
			}
			const int32 NShoe = MX->ShoeCompsL.Num();
			Check(TEXT("Model tracks and rollers move"), FMath::Abs(MX->TrackTravelL - T0) > 0.5f && MX->TrackSpinners.Num() >= 10 && Ang > 5.f && NShoe > 20 && MX->ShoeCompsL[0]->IsVisible(),
				FString::Printf(TEXT("track travel %.2f m, %d spinning rollers/sprockets (first turned %.0f deg), %d moving track shoes per side"), MX->TrackTravelL - T0, MX->TrackSpinners.Num(), Ang, NShoe));
			// shoes must sit on the model's wheels: no wheel centre outside the chain, chain bottom on the ground, gaps even
			if (NShoe > 0)
			{
				float MinZ = 1e9f, MaxGap = 0.f, MinGap = 1e9f;
				for (int32 k = 0; k < NShoe; ++k)
				{
					const FVector P = MX->ShoeCompsL[k]->GetRelativeLocation();
					MinZ = FMath::Min(MinZ, P.Z);
					float Best = 1e9f;
					for (int32 j = 0; j < NShoe; ++j) if (j != k) Best = FMath::Min(Best, FVector::Dist(P, MX->ShoeCompsL[j]->GetRelativeLocation()));
					MaxGap = FMath::Max(MaxGap, Best); MinGap = FMath::Min(MinGap, Best);
				}
				int32 Outside = 0, Side = 0;
				for (const ARWMachine::FSpinner& Sp : MX->TrackSpinners)
				{
					if (!Sp.bLeft || !Sp.P) continue;
					++Side;
					const FVector C = Sp.P->GetRelativeLocation();
					// a wheel centre must be inside the shoe loop: shoes both above and below it within its length
					bool bBelow = false, bAbove = false;
					for (UStaticMeshComponent* S : MX->ShoeCompsL)
					{
						const FVector P = S->GetRelativeLocation();
						if (FMath::Abs(P.X - C.X) < 15.f) { bBelow |= P.Z < C.Z; bAbove |= P.Z > C.Z; }
					}
					if (!(bBelow && bAbove)) ++Outside;
				}
				const FVector BodyOff = MX->Body->GetRelativeLocation();
				Check(TEXT("Track shoes wrap the model's wheels"), Outside == 0 && MinZ > 2.f && MinZ < 15.f && MaxGap < 30.f && Side > 0,
					FString::Printf(TEXT("%d/%d wheel centres inside the chain, lowest shoe %.1f cm above ground, shoe spacing %.0f-%.0f cm"), Side - Outside, Side, MinZ, MinGap, MaxGap));
				Check(TEXT("Excavator house rides rigidly on its undercarriage"), BodyOff.IsNearlyZero(0.01f) && MX->Body->GetRelativeRotation().IsNearlyZero(0.01f),
					FString::Printf(TEXT("body offset %.2f cm, tilt %.2f / %.2f deg"), BodyOff.Size(), MX->Body->GetRelativeRotation().Pitch, MX->Body->GetRelativeRotation().Roll));
			}
		}
		else Check(TEXT("3D model excavator rig works"), false, TEXT("no model excavator was spawned (Mods/CX250D missing?)"));
	}
	// 20. bucket attachments, backside grading, hydraulic hoses, surface water
	{
		// a flat piece of open ground well above the water table, away from roads and the site
		FVector2D Site(1e9f, 0);
		for (int32 k = 0; k < 400 && Site.X > 1e8f; ++k)
		{
			const float X = -200.f + (k % 20) * 21.f, Y = 40.f + (k / 20) * 17.f;
			if (!T->InBounds(X - 30, Y - 10) || !T->InBounds(X + 30, Y + 70)) continue;
			const float H0 = T->HeightAt(X, Y);
			bool bOk = H0 > T->WaterZ + 3.f;
			for (int32 a = 0; a < 12 && bOk; ++a)
			{
				const FVector2D Q(X + (a % 4) * 8.f, Y + (a / 4) * 25.f);
				const int32 i = T->IndexAt(Q.X, Q.Y);
				const ESoil M = T->SurfaceMat(i);
				bOk = FMath::Abs(T->HeightAt(Q.X, Q.Y) - H0) < 2.5f && T->Layers[i].Count == 0 && M != ESoil::Asphalt && M != ESoil::LargeRock;
			}
			if (bOk) Site = FVector2D(X, Y);
		}
		Check(TEXT("Found open ground for the water and grading tests"), Site.X < 1e8f, FString::Printf(TEXT("test site at %.0f, %.0f"), Site.X, Site.Y));
		if (Site.X < 1e8f)
		{
			// --- backside grading: a wider bucket smooths a wider strip ---
			auto GradeStrip = [&](float OY, float Width, float& Before, float& After) -> float
			{
				const float X0 = Site.X, Y0 = Site.Y + OY;
				for (float x = 0; x <= 6.f; x += ARWTerrain::CS)
					for (float y = -2.f; y <= 2.f; y += ARWTerrain::CS)
					{
						const float Tk = 0.07f + 0.05f * FMath::Sin(x * 3.1f) * FMath::Cos(y * 2.3f + x);
						T->DepositAt(T->IndexAt(X0 + x, Y0 + y), ESoil::DrySoil, Tk * ARWTerrain::CellArea, 0.25f, 0);
					}
				TArray<float> H0; float Mean = 0;
				for (float y = -2.f; y <= 2.f; y += ARWTerrain::CS) for (float x = 1.5f; x <= 4.5f; x += ARWTerrain::CS) H0.Add(T->HeightAt(X0 + x, Y0 + y));
				for (float x = 0.5f; x <= 5.5f; x += ARWTerrain::CS) Mean += T->HeightAt(X0 + x, Y0) / 11.f;
				auto Rough = [&]() { float M = 0, V = 0; int32 Nn = 0; for (float x = 1.f; x <= 5.f; x += ARWTerrain::CS) { M += T->HeightAt(X0 + x, Y0); ++Nn; } M /= Nn; for (float x = 1.f; x <= 5.f; x += ARWTerrain::CS) V += FMath::Square(T->HeightAt(X0 + x, Y0) - M); return FMath::Sqrt(V / Nn); };
				Before = Rough();
				FBucketTool B; B.Width = Width; B.Depth = 0.6f;
				const FVector Vel(-0.5f, 0, 0);
				int32 Graded = 0;
				for (int32 k = 0; k < 600; ++k) // 0.5 m/s for 10 s: the back of the bucket crosses the whole bumpy patch
				{
					const float X = X0 + 6.5f - k * 0.5f * Dt;
					const FVector Tip(X, Y0, Mean + 0.54f), Piv(X - 1.f, Y0, Mean + 0.54f);
					B.Grade(T, Tip, Piv, FVector(0, 1, 0), Vel, FVector(0, 0, 1), Dt);
					Graded += B.bGrading ? 1 : 0;
				}
				After = Rough();
				{
					float M1 = 0.f; for (float x = 1.f; x <= 5.f; x += ARWTerrain::CS) M1 += T->HeightAt(X0 + x, Y0) / 9.f;
					RWLog(FString::Printf(TEXT("TESTDBG backside grading %.1f m bucket: graded %d of 600 frames, line mean %.3f -> %.3f (bucket's back at %.3f), carrying %.3f m3"), Width, Graded, Mean, M1, Mean, B.GradeCarry.Total()));
				}
				// strip width = lateral lines where the bucket changed the ground somewhere along the patch
				int32 Changed = 0, Idx = 0;
				for (float y = -2.f; y <= 2.f; y += ARWTerrain::CS)
				{
					bool bHit = false;
					for (float x = 1.5f; x <= 4.5f; x += ARWTerrain::CS, ++Idx) bHit |= FMath::Abs(T->HeightAt(X0 + x, Y0 + y) - H0[Idx]) > 0.006f;
					Changed += bHit ? 1 : 0;
				}
				return Changed * ARWTerrain::CS;
			};
			float RB1, RA1, RB2, RA2;
			const float WNarrow = GradeStrip(40.f, 0.9f, RB1, RA1), WWide = GradeStrip(52.f, 1.8f, RB2, RA2);
			Check(TEXT("Backside grading smooths a strip as wide as the bucket"), WWide > WNarrow * 1.4f && RA1 < RB1 * 0.75f && RA2 < RB2 * 0.75f,
				FString::Printf(TEXT("0.9 m bucket: %.1f m strip, bumps %.1f -> %.1f cm; 1.8 m bucket: %.1f m strip, bumps %.1f -> %.1f cm"), WNarrow, RB1 * 100.f, RA1 * 100.f, WWide, RB2 * 100.f, RA2 * 100.f));

			// --- Test C: the back of the bucket smooths a bumpy strip on a slope (8 % along, 5 % across) in three passes to an even
			// surface that keeps both slopes, without steps, and leaves the ground beside the strip as it was ---
			{
				const float X0 = Site.X, Y0 = Site.Y + 76.f, Along = 0.08f, Across = 0.05f, Wb = 1.2f;
				const float Base = T->HeightAt(X0, Y0) + 0.3f;
				for (float x = -1.f; x <= 7.5f; x += ARWTerrain::CS)
					for (float y = -2.5f; y <= 2.5f; y += ARWTerrain::CS)
					{
						const int32 i = T->IndexAt(X0 + x, Y0 + y);
						const float Want = Base + Along * x + Across * y + 0.06f * FMath::Sin(x * 2.9f) * FMath::Cos(y * 2.1f + x);
						if (Want > T->Height[i]) T->DepositAt(i, ESoil::DrySoil, (Want - T->Height[i]) * ARWTerrain::CellArea, 0.25f, 0);
					}
				// the strip's surface against the plane that fits it best (least squares z = a + b x + c y): how far off, and the slopes
				auto Fit = [&](float& Rms, float& Bx, float& Cy)
				{
					double S[3][4] = {};
					TArray<FVector> Pt;
					for (float x = 1.5f; x <= 4.5f + 1e-3f; x += 0.25f) for (float y = -0.35f; y <= 0.35f + 1e-3f; y += 0.175f) Pt.Add(FVector(x, y, T->HeightAt(X0 + x, Y0 + y)));
					for (const FVector& P : Pt) { const double R[3] = {1.0, P.X, P.Y}; for (int32 a = 0; a < 3; ++a) { for (int32 b = 0; b < 3; ++b) S[a][b] += R[a] * R[b]; S[a][3] += R[a] * P.Z; } }
					for (int32 c = 0; c < 3; ++c) { for (int32 r = c + 1; r < 3; ++r) { const double F = S[r][c] / S[c][c]; for (int32 k = c; k < 4; ++k) S[r][k] -= F * S[c][k]; } }
					double Z[3];
					for (int32 r = 2; r >= 0; --r) { double V = S[r][3]; for (int32 k = r + 1; k < 3; ++k) V -= S[r][k] * Z[k]; Z[r] = V / S[r][r]; }
					double E = 0.0; for (const FVector& P : Pt) E += FMath::Square(P.Z - (Z[0] + Z[1] * P.X + Z[2] * P.Y));
					Rms = (float)FMath::Sqrt(E / FMath::Max(Pt.Num(), 1)); Bx = (float)Z[1]; Cy = (float)Z[2];
				};
				float Rms0, B0, C0; Fit(Rms0, B0, C0);
				TArray<float> Beside0;
				for (float x = 1.5f; x <= 4.5f + 1e-3f; x += ARWTerrain::CS) for (const float y : {-2.f, -1.5f, 1.5f, 2.f}) Beside0.Add(T->HeightAt(X0 + x, Y0 + y));
				const float A0 = T->HeightAt(X0, Y0); // (the plane through the strip's start: where the bucket's back is held)
				FBucketTool B; B.Width = Wb; B.Depth = 0.6f;
				const FVector Lat = FVector(0.f, 1.f, Across).GetSafeNormal();
				const FVector Vel(-0.5f, 0.f, -0.5f * Along);
				for (int32 Pass = 0; Pass < 3; ++Pass)
					for (int32 k = 0; k < 600; ++k)
					{
						const float X = 6.5f - k * 0.5f * Dt;
						const float Zt = Base + Along * X, Zp = Base + Along * (X - 1.f);
						B.Grade(T, FVector(X0 + X, Y0, Zt + 0.54f), FVector(X0 + X - 1.f, Y0, Zp + 0.54f), Lat, Vel, FVector(-Along, 0.f, 1.f).GetSafeNormal(), Dt);
					}
				(void)A0;
				float Rms1, B1, C1; Fit(Rms1, B1, C1);
				float Beside = 0.f; int32 Bi = 0;
				for (float x = 1.5f; x <= 4.5f + 1e-3f; x += ARWTerrain::CS) for (const float y : {-2.f, -1.5f, 1.5f, 2.f}) Beside = FMath::Max(Beside, FMath::Abs(T->HeightAt(X0 + x, Y0 + y) - Beside0[Bi++]));
				float Step = 0.f, StepX = 0.f, StepY = 0.f;
				for (float x = 1.5f; x < 4.5f; x += ARWTerrain::CS) for (float y = -0.25f; y <= 0.25f + 1e-3f; y += ARWTerrain::CS)
				{
					const float Sv = FMath::Abs(T->HeightAt(X0 + x + ARWTerrain::CS, Y0 + y) - T->HeightAt(X0 + x, Y0 + y) - B1 * ARWTerrain::CS);
					if (Sv > Step) { Step = Sv; StepX = x; StepY = y; }
				}
				{
					// (where it is, and the strip's surface along its middle against the plane through it: what makes the step)
					FString Prof;
					const float Za = T->HeightAt(X0 + 1.5f, Y0);
					for (float x = 0.5f; x <= 5.5f + 1e-3f; x += ARWTerrain::CS) Prof += FString::Printf(TEXT(" %.1f"), (T->HeightAt(X0 + x, Y0) - Za - B1 * (x - 1.5f)) * 100.f);
					RWLog(FString::Printf(TEXT("TESTDBG Test C: largest step %.1f cm between x %.1f and %.1f at y %.2f; middle line off the plane (cm, x 0.5..5.5):%s; carrying %.3f m3"), Step * 100.f, StepX, StepX + ARWTerrain::CS, StepY, *Prof, B.GradeCarry.Total()));
				}
				Check(TEXT("The back of the bucket smooths a slope evenly and keeps it (Test C)"),
					Rms1 < Rms0 * 0.5f && Rms1 < 0.015f && FMath::Abs(B1 - Along) < 0.02f && FMath::Abs(C1 - Across) < 0.02f && Step < 0.02f && Beside < 0.005f,
					FString::Printf(TEXT("3 passes on 8 %% along / 5 %% across: off the best plane %.1f -> %.1f cm; slopes along %.1f -> %.1f %%, across %.1f -> %.1f %%; largest step %.1f cm; ground beside the strip moved %.1f cm"),
						Rms0 * 100.f, Rms1 * 100.f, B0 * 100.f, B1 * 100.f, C0 * 100.f, C1 * 100.f, Step * 100.f, Beside * 100.f));
			}
			// --- the back of the bucket presses the ground once per pass: the same after one pass at 30, 60 and 120 fps; held
			// still it presses no more; driven back over the strip it is a new pass; pass after pass the soil comes nearer to
			// fully packed and never past it ---
			{
				// a level strip of loose dry soil, 0.3 m over the highest point of the ground under it
				auto MakeStrip = [&](float Yo) -> float
				{
					const float X0 = Site.X, Y0 = Site.Y + Yo;
					float Top = -1e9f;
					for (float x = -1.f; x <= 6.f; x += ARWTerrain::CS) for (float y = -1.5f; y <= 1.5f; y += ARWTerrain::CS) Top = FMath::Max(Top, T->HeightAt(X0 + x, Y0 + y));
					const float Z0 = Top + 0.3f;
					for (float x = -1.f; x <= 6.f; x += ARWTerrain::CS)
						for (float y = -1.5f; y <= 1.5f; y += ARWTerrain::CS)
						{
							const int32 i = T->IndexAt(X0 + x, Y0 + y);
							if (Z0 > T->Height[i]) T->DepositAt(i, ESoil::DrySoil, (Z0 - T->Height[i]) * ARWTerrain::CellArea, 0.3f, 0);
						}
					return Z0;
				};
				// (the packing of the soil on top in the strip's middle, 0..1)
				auto Packed = [&](float Yo) -> float
				{
					float S = 0.f; int32 Nn = 0;
					for (float x = 2.f; x <= 4.f + 1e-3f; x += ARWTerrain::CS) for (float y = -0.25f; y <= 0.25f + 1e-3f; y += ARWTerrain::CS)
					{
						const FLayers& L = T->Layers[T->IndexAt(Site.X + x, Site.Y + Yo + y)];
						if (L.Count > 0) { S += L.Comp[L.Count - 1] / 255.f; ++Nn; }
					}
					return Nn ? S / Nn : 0.f;
				};
				// one pass along the strip at 0.5 m/s, the back held at the strip's level, Fps frames a second; Dir -1 = forwards
				auto Pass = [&](FBucketTool& Bk, float Yo, float Z0, float Fps, float Dir)
				{
					const float FDt = 1.f / Fps; const int32 NF = FMath::RoundToInt(5.f / (0.5f * FDt));
					for (int32 k = 0; k < NF; ++k)
					{
						const float X = Dir < 0.f ? 5.5f - k * 0.5f * FDt : 0.5f + k * 0.5f * FDt;
						const float Px = X + (Dir < 0.f ? -1.f : 1.f); // (the pin behind the tip in the way it goes)
						Bk.Grade(T, FVector(Site.X + X, Site.Y + Yo, Z0 + 0.54f), FVector(Site.X + Px, Site.Y + Yo, Z0 + 0.54f), FVector(0.f, 1.f, 0.f), FVector(0.5f * Dir, 0.f, 0.f), FVector(0.f, 0.f, 1.f), FDt);
					}
				};
				FString Rep; bool bOK = true;
				float One[3]; int32 Fi = 0;
				for (const float Fps : {30.f, 60.f, 120.f})
				{
					const float Yo = 90.f + Fi * 6.f;
					const float Z0 = MakeStrip(Yo);
					const float P0 = Packed(Yo);
					FBucketTool Bk; Bk.Width = 1.2f; Bk.Depth = 0.6f;
					Pass(Bk, Yo, Z0, Fps, -1.f);
					One[Fi] = Packed(Yo) - P0;
					Rep += FString::Printf(TEXT("one pass at %.0f fps: packed %.3f -> %.3f; "), Fps, P0, P0 + One[Fi]);
					++Fi;
				}
				const float Spread = FMath::Max3(One[0], One[1], One[2]) - FMath::Min3(One[0], One[1], One[2]);
				if (Spread > 0.2f * FMath::Max3(One[0], One[1], One[2]) + 1e-3f || One[1] <= 0.f) bOK = false;
				// held still on the 60 fps strip for 2 s: no more packing
				{
					const float Yo = 96.f; const float Pb = Packed(Yo);
					FBucketTool Bk; Bk.Width = 1.2f; Bk.Depth = 0.6f;
					const float Z0 = T->HeightAt(Site.X + 3.f, Site.Y + Yo);
					for (int32 k = 0; k < 120; ++k) Bk.Grade(T, FVector(Site.X + 3.5f, Site.Y + Yo, Z0 + 0.54f), FVector(Site.X + 2.5f, Site.Y + Yo, Z0 + 0.54f), FVector(0.f, 1.f, 0.f), FVector::ZeroVector, FVector(0.f, 0.f, 1.f), 1.f / 60.f);
					const float Pa = Packed(Yo);
					Rep += FString::Printf(TEXT("held still 2 s: %.3f -> %.3f; "), Pb, Pa);
					if (Pa - Pb > 1e-4f) bOK = false;
					// back over it the other way: a new pass, and then 8 more, back and forth
					FBucketTool Bk2; Bk2.Width = 1.2f; Bk2.Depth = 0.6f;
					const float Zs = T->HeightAt(Site.X + 3.f, Site.Y + Yo);
					float Prev = Pa, LastGain = 1.f; bool bShrinking = true; FString Seq;
					for (int32 n = 0; n < 9; ++n)
					{
						Pass(Bk2, Yo, Zs, 60.f, n % 2 == 0 ? 1.f : -1.f);
						const float Now = Packed(Yo), Gain = Now - Prev;
						if (n == 0 && Gain <= 0.f) bOK = false; // (the way back is a pass of its own)
						if (Gain < -1e-4f || Now > 1.f + 1e-4f) bOK = false;
						if (n > 1 && Gain > LastGain + 0.01f) bShrinking = false;
						Seq += FString::Printf(TEXT(" %.3f"), Now); LastGain = Gain; Prev = Now;
					}
					Rep += FString::Printf(TEXT("back over it and 8 more passes:%s"), *Seq);
					if (!bShrinking) bOK = false;
				}
				Check(TEXT("The back of the bucket packs the ground once a pass, at any frame rate"), bOK, Rep);
			}

			// --- swinging with the bucket on the ground sweeps it flat and pushes the soil aside ---
			{
				const float X0 = Site.X, Y0 = Site.Y + 64.f;
				for (float x = 0; x <= 6.f; x += ARWTerrain::CS)
					for (float y = -3.f; y <= 3.f; y += ARWTerrain::CS)
					{
						const float Tk = 0.07f + 0.05f * FMath::Sin(x * 2.7f + y) * FMath::Cos(y * 3.1f);
						T->DepositAt(T->IndexAt(X0 + x, Y0 + y), ESoil::DrySoil, Tk * ARWTerrain::CellArea, 0.25f, 0);
					}
				float Mean = 0; int32 Nm = 0;
				for (float y = -2.f; y <= 2.f; y += ARWTerrain::CS) { Mean += T->HeightAt(X0 + 2.9f, Y0 + y); ++Nm; }
				Mean /= Nm;
				// soil sticking up above the bucket's bottom line (the sweep shaves it off; hollows below it stay)
				auto Rough = [&]() { float V = 0; int32 Nn = 0; for (float y = -1.5f; y <= 1.5f; y += ARWTerrain::CS) for (float x = 2.4f; x <= 3.4f; x += ARWTerrain::CS) { V += FMath::Max(0.f, T->HeightAt(X0 + x, Y0 + y) - Mean); ++Nn; } return V / Nn; };
				const float Before = Rough();
				FBucketTool B; B.Width = 1.0f; B.Depth = 0.6f;
				const FVector Vel(0, 0.6f, 0);
				for (int32 k = 0; k < 500; ++k)
				{
					const float Y = Y0 - 2.5f + k * 0.6f * Dt;
					B.Sweep(T, FVector(X0 + 3.6f, Y, Mean + 0.54f), FVector(X0 + 2.2f, Y, Mean + 0.54f), Vel, FVector(0, 0, 1), Dt);
				}
				const float After = Rough();
				Check(TEXT("Swinging the bucket on the ground sweeps it flat"), After < Before * 0.3f && B.SweptVol > 0.05f,
					FString::Printf(TEXT("swept a 5 m arc: soil above the bucket line %.1f -> %.1f cm, %.2f m3 pushed aside into a windrow"), Before * 100.f, After * 100.f, B.SweptVol));
			}

			// --- surface water ---
			if (Water)
			{
				const double A0 = Water->Added, S0 = Water->Soaked, D0 = Water->Drained, V0 = Water->StandingVolume();
				// a 20 m drainage channel, 1.5 m wide, falling 1.5% to a dead end
				const float CX = Site.X, CY = Site.Y + 5.f, Top = T->HeightAt(CX, CY) - 0.5f;
				FPayload Spoil;
				for (float d = 0; d <= 20.f; d += ARWTerrain::CS)
					for (float s = -0.5f; s <= 0.5f; s += ARWTerrain::CS)
					{
						const int32 i = T->IndexAt(CX + d, CY + s);
						const float Bed = Top - 0.015f * d;
						if (T->Height[i] > Bed) T->RemoveAt(i, T->Height[i] - Bed, Spoil, true);
					}
				// a 2.5 x 2.5 m pit, 0.6 m deep, filled past its brim
				const float PX = Site.X + 10.f, PY = Site.Y + 25.f, Rim = T->HeightAt(PX + 3.f, PY);
				for (float x = -1.f; x <= 1.f; x += ARWTerrain::CS)
					for (float y = -1.f; y <= 1.f; y += ARWTerrain::CS)
					{
						const int32 i = T->IndexAt(PX + x, PY + y);
						if (T->Height[i] > Rim - 0.6f) T->RemoveAt(i, T->Height[i] - (Rim - 0.6f), Spoil, true);
					}
				const float PitVol = 25.f * ARWTerrain::CellArea * 0.6f;
				for (int32 k = 0; k < 1600; ++k)
				{
					if (k < 40) { Water->AddWater(CX + 0.2f, CY, 2.f / 40.f, 0.f); Water->AddWater(PX, PY, PitVol * 1.6f / 40.f, 0.f); }
					Water->Step(1.f / 40.f);
				}
				// where did the channel water go?
				float Near = 0, Far = 0, Outside = 0, MaxMud = 0;
				for (float d = 0; d <= 20.f; d += ARWTerrain::CS)
				{
					for (float s = -0.5f; s <= 0.5f; s += ARWTerrain::CS)
					{
						const float Wd = Water->DepthAt(CX + d, CY + s) * ARWTerrain::CellArea;
						(d < 10.f ? Near : Far) += Wd;
						MaxMud = FMath::Max(MaxMud, Water->MudAt(CX + d, CY + s));
					}
					for (const float s : {-2.5f, -2.f, 2.f, 2.5f}) Outside += Water->DepthAt(CX + d, CY + s) * ARWTerrain::CellArea;
				}
				Check(TEXT("Water flows down a dug channel"), Far > Near && Far > 0.3f && Outside < 0.05f * (Near + Far),
					FString::Printf(TEXT("2 m3 poured at the top: %.2f m3 in the upper half, %.2f m3 collected at the low end, %.3f m3 outside the banks"), Near, Far, Outside));
				float PitD = 0, Spill = 0;
				PitD = Water->DepthAt(PX, PY);
				// the ground here is not level: the water leaves where the way out is lowest. Over each direction the way out's
				// highest point decides, and the lowest of those is the real brim.
				const float PitFloor = T->HeightAt(PX, PY);
				float Crest = 1e9f;
				for (float a = 0.f; a < 6.28f; a += 0.1f)
				{
					float Ray = -1e9f;
					for (float r = 1.3f; r <= 7.f; r += 0.25f) Ray = FMath::Max(Ray, T->HeightAt(PX + FMath::Cos(a) * r, PY + FMath::Sin(a) * r));
					Crest = FMath::Min(Crest, Ray);
				}
				const float PitSurface = PitFloor + PitD;
				for (float x = -9.f; x <= 9.f; x += ARWTerrain::CS)
					for (float y = -9.f; y <= 9.f; y += ARWTerrain::CS)
						if (FMath::Abs(x) > 1.2f || FMath::Abs(y) > 1.2f) Spill += Water->DepthAt(PX + x, PY + y) * ARWTerrain::CellArea;
				Check(TEXT("Water fills a pit and overflows its brim"), PitD > 0.5f && FMath::Abs(PitSurface - Crest) < 0.12f && Spill > 0.3f,
					FString::Printf(TEXT("pit holds %.2f m3: water %.2f m deep, surface %.2f m against a brim at %.2f m, %.2f m3 overflowed around it"), PitVol, PitD, PitSurface, Crest, Spill));
				const float MoistBank = T->MoistureAt(T->IndexAt(CX + 19.f, CY));
				Check(TEXT("Water soaks in, wets the soil and runs muddy"), Water->Soaked - S0 > 0.001 && MoistBank > 0.4f && MaxMud > 0.05f,
					FString::Printf(TEXT("%.3f m3 soaked into the ground, channel floor moisture %.0f%%, muddiest water %.0f%%"), Water->Soaked - S0, MoistBank * 100.f, MaxMud * 100.f));
				const double In = Water->Added - A0, Kept = (Water->StandingVolume() - V0) + (Water->Soaked - S0) + (Water->Drained - D0);
				Water->UpdateRender(true);
				Check(TEXT("Water volume is conserved and drawn"), FMath::Abs(In - Kept) < 0.03 * In && Water->VisibleTiles() > 0,
					FString::Printf(TEXT("poured %.2f m3 = standing + soaked + drained %.2f m3; %d active tiles, %d water meshes"), In, Kept, Water->ActiveTiles(), Water->VisibleTiles()));
			}
			else Check(TEXT("Water flows down a dug channel"), false, TEXT("no water simulation"));
			// --- culvert: a pond behind an embankment drains through the pipe into a lower ditch ---
			if (Water)
			{
				const float X0 = Site.X + 14.f, Y0 = Site.Y + 33.f;
				const float G = T->HeightAt(X0 + 5.f, Y0);
				FPayload Spoil;
				auto Pit = [&](float CX, float Floor)
				{
					for (float x = -1.5f; x <= 1.5f; x += ARWTerrain::CS)
						for (float y = -1.5f; y <= 1.5f; y += ARWTerrain::CS)
						{
							const int32 i = T->IndexAt(CX + x, Y0 + y);
							if (T->Height[i] > Floor) T->RemoveAt(i, T->Height[i] - Floor, Spoil, true);
						}
				};
				Pit(X0, G - 0.8f);          // pond on the upstream side
				Pit(X0 + 10.f, G - 1.4f);   // ditch on the downstream side, lower
				ARWWater::FCulvert C;
				C.In = FVector2D(X0 + 1.f, Y0); C.Out = FVector2D(X0 + 9.f, Y0); C.InZ = G - 0.8f; C.OutZ = G - 1.3f; C.Diameter = 0.6f;
				Water->Culverts.Add(C);
				const double Moved0 = Water->PipeMoved;
				auto PoolVol = [&](float CX) { float V = 0; for (float x = -1.5f; x <= 1.5f; x += ARWTerrain::CS) for (float y = -1.5f; y <= 1.5f; y += ARWTerrain::CS) V += Water->DepthAt(CX + x, Y0 + y) * ARWTerrain::CellArea; return V; };
				for (float x = -1.f; x <= 1.f; x += 1.f) for (float y = -1.f; y <= 1.f; y += 1.f) Water->AddWater(X0 + x, Y0 + y, 6.f / 9.f, 0.f);
				const float In0 = PoolVol(X0);
				float PeakQ = 0.f, PeakV = 0.f;
				for (int32 k = 0; k < 1600; ++k) { Water->Step(1.f / 40.f); PeakQ = FMath::Max(PeakQ, Water->Culverts.Last().Q); PeakV = FMath::Max(PeakV, Water->Culverts.Last().Vel); }
				const float In1 = PoolVol(X0), Out1 = PoolVol(X0 + 10.f);
				Water->Culverts.Pop();
				Check(TEXT("Culvert drains a pond through the embankment"), PeakQ > 0.02f && Out1 > 1.f && In1 < In0 * 0.5f && Water->PipeMoved - Moved0 > 1.0,
					FString::Printf(TEXT("pond %.2f -> %.2f m3, ditch below got %.2f m3; peak discharge %.0f L/s at %.1f m/s, %.2f m3 through the 0.6 m pipe"), In0, In1, Out1, PeakQ * 1000.f, PeakV, Water->PipeMoved - Moved0));
				// hydraulics sanity: more head -> more flow; a bigger pipe -> more flow; a drowned outlet -> less flow
				const float Q1 = ARWWater::PipeFlow(0.6f, 0.024f, 8.f, 0.f, -0.08f, 0.3f, -1.f);
				const float Q2 = ARWWater::PipeFlow(0.6f, 0.024f, 8.f, 0.f, -0.08f, 0.9f, -1.f);
				const float Q3 = ARWWater::PipeFlow(0.3f, 0.024f, 8.f, 0.f, -0.08f, 0.9f, -1.f);
				const float Q4 = ARWWater::PipeFlow(0.6f, 0.024f, 8.f, 0.f, -0.08f, 0.9f, 0.85f);
				Check(TEXT("Pipe flow follows the hydraulics"), Q2 > Q1 * 1.5f && Q2 > Q3 * 2.f && Q4 < Q2 * 0.6f && Q1 > 0.f,
					FString::Printf(TEXT("0.6 m pipe: %.0f L/s at 0.3 m head, %.0f L/s at 0.9 m; 0.3 m pipe at 0.9 m: %.0f L/s; drowned outlet: %.0f L/s"), Q1 * 1000.f, Q2 * 1000.f, Q3 * 1000.f, Q4 * 1000.f));
			}
		}
		// --- environment from the Content packs: loaded, instanced, drawn with their own materials ---
		{
			Check(TEXT("Pack names sort into the right plants"),
				FRWFab::Classify(TEXT("SM_Baltic_Pine_A"), TEXT("/Game/X")) == TEXT("conifer") && FRWFab::Classify(TEXT("SM_HP_Tree"), TEXT("/Game/X")) == TEXT("broadleaf")
				&& FRWFab::Classify(TEXT("GV_Shrub_A_full"), TEXT("/Game/X")) == TEXT("bush") && FRWFab::Classify(TEXT("Branch_Pine_01"), TEXT("/Game/X")).IsEmpty()
				&& FRWFab::Classify(TEXT("SM_River_Rock"), TEXT("/Game/X")) == TEXT("rock"), FRWFab::Summary());
			int32 BadMats = 0, MatN = 0; FString BadName;
			TArray<UStaticMesh*> All; All.Append(FRWFab::Conifer); All.Append(FRWFab::Broadleaf); All.Append(FRWFab::Bush); All.Append(FRWFab::Rock);
			for (UStaticMesh* M : All)
				for (const FStaticMaterial& SM : M->GetStaticMaterials())
				{
					++MatN;
					UMaterial* Base = SM.MaterialInterface ? SM.MaterialInterface->GetMaterial() : nullptr;
					if (!Base || Base->IsDefaultMaterial() || !Base->GetUsageByFlag(MATUSAGE_InstancedStaticMeshes)) { ++BadMats; BadName = SM.MaterialInterface ? SM.MaterialInterface->GetName() : TEXT("(none)"); }
				}
			Check(TEXT("Pack models keep their own materials when instanced"), All.Num() > 0 && BadMats == 0,
				FString::Printf(TEXT("%d models, %d material slots, %d would draw grey %s"), All.Num(), MatN, BadMats, *BadName));
			int32 FabTrees = 0, Hidden = -1;
			for (const FRWTree& PackTree : World->Trees) if (PackTree.FabComp >= 0) ++FabTrees;
			for (int32 i = 0; i < World->Trees.Num(); ++i)
				if (World->Trees[i].FabComp >= 0 && World->Trees[i].bAlive)
				{
					// knocking a pack tree down must really hide it, and bringing it back restore it
					World->SetTreeAlive(i, false);
					FTransform X; World->FabTreeH[World->Trees[i].FabComp]->GetInstanceTransform(World->Trees[i].FabIdx, X, true);
					Hidden = X.GetScale3D().IsNearlyZero() ? 1 : 0;
					World->SetTreeAlive(i, true);
					FTransform X2; World->FabTreeH[World->Trees[i].FabComp]->GetInstanceTransform(World->Trees[i].FabIdx, X2, true);
					if (X2.GetScale3D().IsNearlyZero()) Hidden = 0;
					break;
				}
			Check(TEXT("The map's trees are the pack models and can be felled"), FabTrees == World->Trees.Num() && FabTrees > 500 && Hidden == 1,
				FString::Printf(TEXT("%d of %d trees are pack models, felling hides and restores: %s"), FabTrees, World->Trees.Num(), Hidden == 1 ? TEXT("yes") : TEXT("no")));
			Check(TEXT("River uses the pack's water material"), FRWFab::Water != nullptr && World->WaterPlane && World->WaterPlane->GetMaterial(0) == FRWFab::Water, FRWFab::Water ? FRWFab::Water->GetName() : TEXT("none"));
		}
		// --- bucket attachments and hoses on the built-in excavator ---
		ARWExcavator* BE = nullptr;
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (!X->bModelRig && !BE) BE = X;
		if (BE)
		{
			BE->Bucket.Load.Clear();
			const float W0 = BE->Bucket.Width, M0 = BE->EmptyMass;
			BE->ToolCycle(); const float W1 = BE->Bucket.Width; const FString N1 = BE->BucketSpecs[BE->BucketIdx].Name;
			BE->ToolCycle(); const float W2 = BE->Bucket.Width, M2 = BE->EmptyMass;
			BE->ToolCycle(); const float M3 = BE->EmptyMass;
			int32 Guard = 0; while ((BE->Tool != 0 || BE->BucketIdx != 0) && Guard++ < 12) BE->ToolCycle();
			Check(TEXT("Bucket attachments have their own size and weight"), W1 > W0 * 1.4f && W2 < W0 * 0.6f && M2 < M0 && M3 > M0 && BE->BucketSpecs.Num() >= 4 && BE->Bucket.Width == W0,
				FString::Printf(TEXT("%d buckets: standard %.2f m, %s %.2f m, trenching %.2f m; machine %.0f / %.0f / %.0f kg"), BE->BucketSpecs.Num(), W0, *N1, W1, W2, M0, M2, M3));
			float WorstLen = 0.f, WorstBend = 1e9f;
			const float BA = BE->BoomA, AA = BE->ArmA;
			for (int32 k = 0; k <= 12; ++k)
			{
				BE->BoomA = FMath::Lerp(BE->BoomLo, BE->BoomHi, (k % 4) / 3.f);
				BE->ArmA = FMath::Lerp(BE->ArmLo, BE->ArmHi, k / 12.f);
				BE->SimStep(Dt);
				for (const ARWMachine::FHose& H : BE->Hoses)
				{
					WorstLen = FMath::Max(WorstLen, FMath::Abs(H.CurveLen - H.Length) / H.Length);
					WorstBend = FMath::Min(WorstBend, H.MinRadius / H.MinBend);
				}
			}
			BE->BoomA = BA; BE->ArmA = AA; BE->SimStep(Dt);
			// --- pressing the bucket down on firm ground lifts the machine, raising the boom lets it down ---
			{
				BE->bEngineOn = true; BE->Rpm = BE->MaxRpm; BE->ThrottleDial = 1.f; BE->Tool = 0; BE->Bucket.Load.Clear();
				BE->BoomA = 5.f; BE->ArmA = -100.f; BE->BktA = -40.f;
				for (int32 k = 0; k < 5; ++k) BE->SimStep(Dt);
				const FVector Tip0 = BE->TipWorld();
				for (float x = -3.f; x <= 3.f; x += ARWTerrain::CS)
					for (float y = -3.f; y <= 3.f; y += ARWTerrain::CS)
						T->DepositAt(T->IndexAt(Tip0.X + x, Tip0.Y + y), ESoil::LargeRock, 0.15f * ARWTerrain::CellArea, 0.1f, 250); // bedrock pad
				const float Z0 = BE->GetActorLocation().Z;
				float MaxProp = 0.f;
				for (int32 k = 0; k < 360; ++k) { BE->InA1 = -1.f; BE->SimStep(Dt); MaxProp = FMath::Max(MaxProp, BE->PropAngle); }
				const FRotator Lifted = BE->GetActorRotation();
				const float Rise = (BE->GetActorLocation().Z - Z0) * CM2M;
				for (int32 k = 0; k < 420; ++k) { BE->InA1 = 1.f; BE->SimStep(Dt); }
				BE->InA1 = 0.f;
				// lifting the machine on the bucket is switched off for now (player request): pressing must not tilt it
				Check(TEXT("Bucket pressing does not lift the excavator (switched off)"), MaxProp < 0.01f && BE->PropAngle < 0.01f,
					FString::Printf(TEXT("boom pressed the bucket on rock for 6 s: machine tilt %.1f deg (pitch %.1f, roll %.1f, centre %+.2f m)"), MaxProp, Lifted.Pitch, Lifted.Roll, Rise));
				BE->BoomA = BA; BE->ArmA = AA; BE->SimStep(Dt);
			}
			Check(TEXT("Hydraulic hoses keep their length and bend limits"), BE->Hoses.Num() >= 4 && WorstLen < 0.04f && WorstBend >= 0.99f,
				FString::Printf(TEXT("%d hoses across boom foot and arm joint, worst length error %.1f%%, tightest bend %.2f x the allowed radius"), BE->Hoses.Num(), WorstLen * 100.f, WorstBend > 1e8f ? 0.f : WorstBend));
		}
	}
	// 21. textured soil: terrain and loose soil use the imported PBR soil texture sets
	{
		const int32 i = T->IndexAt(-60.f, -100.f);
		T->DepositAt(i, ESoil::Laterite, 0.05f, 0.2f, 200);
		FLinearColor Cw; FVector2D U1, U2, U3;
		T->PBRWeights(i, Cw, U1, U2, U3);
		const FString MatName = T->TerrainMat ? T->TerrainMat->GetName() : TEXT("none");
		Check(TEXT("Ground uses the soil texture sets"), T->bPBR && MatName == TEXT("M_TerrainPBR") && Cw.B > 0.99f && Cw.R < 0.01f,
			FString::Printf(TEXT("terrain material %s (quality preset %d), laterite point weights R %.2f G %.2f B %.2f"), *MatName, Quality, Cw.R, Cw.G, Cw.B));
		bool bTex = false; FString TexName = TEXT("none");
		for (ARWMachine* M : Machines)
			if (ARWExcavator* X = Cast<ARWExcavator>(M))
				if (!X->bModelRig && X->HeapMID && !bTex)
				{
					X->Bucket.Load.Clear(); X->Bucket.Load.Add(ESoil::Laterite, 0.5f, 0.2f);
					X->Tool = 0; X->VisualTick(Dt);
					UTexture* Tx = nullptr;
					if (FRWSoilLook::IsTextured(X->HeapMID) && X->HeapMID->GetTextureParameterValue(FHashedMaterialParameterInfo(FName(TEXT("BaseTex"))), Tx) && Tx) { TexName = Tx->GetName(); bTex = TexName.Contains(TEXT("LateriteRed")); }
					X->Bucket.Load.Clear(); X->VisualTick(Dt);
				}
		Check(TEXT("Soil in the bucket uses the matching soil texture"), bTex, FString::Printf(TEXT("laterite load drawn with %s on a lumpy soil mesh"), *TexName));
	}
	// 22. controls: rebinding never grabs the virtual "Any Key", clashes are reported, binds survive save/load and reset
	if (ARWPlayerController* PCc = Cast<ARWPlayerController>(GetWorld()->GetFirstPlayerController()))
	{
		const FString File = FPaths::ProjectSavedDir() / TEXT("Config") / TEXT("RoadWorksControls.txt");
		FString Keep; const bool bHadFile = FFileHelper::LoadFileToString(Keep, *File); // the player's own settings, restored afterwards
		const TArray<ARWPlayerController::FAction> Before = PCc->Actions;
		int32 Up = INDEX_NONE;
		for (int32 i = 0; i < PCc->Actions.Num(); ++i) if (PCc->Actions[i].Name == FName(TEXT("A1Up"))) Up = i;
		const bool bFilter = !ARWPlayerController::IsBindableKey(EKeys::AnyKey) && !ARWPlayerController::IsBindableKey(EKeys::MouseX) && ARWPlayerController::IsBindableKey(EKeys::K) && ARWPlayerController::IsBindableKey(EKeys::Gamepad_FaceButton_Top);
		// a key another action already uses (whatever the player has bound to "swing left" right now)
		FKey Taken = EKeys::Q;
		for (const ARWPlayerController::FAction& A : PCc->Actions) if (A.Name == FName(TEXT("SwingL")) && A.Key.IsValid()) Taken = A.Key;
		const FString Clash = Up != INDEX_NONE ? PCc->ApplyRebind(Up, 0, Taken) : FString();
		if (Up != INDEX_NONE) PCc->ApplyRebind(Up, 1, EKeys::NumPadEight);
		if (Up != INDEX_NONE) { PCc->Actions[Up].Key = EKeys::Zero; PCc->Actions[Up].Alt = FKey(); }
		PCc->LoadBinds();                                                                           // read back from the file
		const bool bLoaded = Up != INDEX_NONE && PCc->Actions[Up].Key == Taken && PCc->Actions[Up].Alt == EKeys::NumPadEight;
		PCc->ResetBinds();
		const bool bReset = Up != INDEX_NONE && PCc->Actions[Up].Key == EKeys::R && !PCc->Actions[Up].Alt.IsValid();
		// put the player's settings back exactly as they were
		if (bHadFile) FFileHelper::SaveStringToFile(Keep, *File); else IFileManager::Get().Delete(*File);
		PCc->Actions = Before;
		Check(TEXT("Key rebinding works (no 'Any Key')"), bFilter && !Clash.IsEmpty() && bLoaded && bReset,
			FString::Printf(TEXT("Any Key rejected=%s, clash warning \"%s\", saved+reloaded main+second key=%s, reset to defaults=%s"), bFilter ? TEXT("yes") : TEXT("no"), *Clash, bLoaded ? TEXT("yes") : TEXT("no"), bReset ? TEXT("yes") : TEXT("no")));
	}
	// 23. soil in the bucket fills the bucket's own shape and stays level when the bucket tilts
	{
		ARWExcavator* FE = nullptr;
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (!X->bModelRig && !FE) FE = X;
		if (FE)
		{
			// a known pose, clear of the ground, with the opening facing straight up (what earlier tests leave behind is anyone's guess)
			const float Boom0 = FE->BoomA, Arm0 = FE->ArmA, Bkt0 = FE->BktA;
			FE->Tool = 0; FE->InA1 = FE->InA2 = FE->InA3 = FE->InA4 = 0.f;
			FE->BoomA = FE->BoomHi - 5.f; FE->ArmA = FMath::Lerp(FE->ArmLo, FE->ArmHi, 0.5f);
			float BktUp = -70.f, BestUp = -2.f;
			for (float a = FE->BktLo; a <= FE->BktHi; a += 5.f)
			{
				FE->BktA = a; FE->SimStep(Dt);
				if (FE->MouthDir().Z > BestUp) { BestUp = FE->MouthDir().Z; BktUp = a; }
			}
			const float BktTilt = FMath::Clamp(BktUp + 30.f, FE->BktLo, FE->BktHi) == BktUp + 30.f ? BktUp + 30.f : BktUp - 30.f;
			FE->BktA = BktUp;
			for (int32 k = 0; k < 2; ++k) FE->SimStep(Dt);
			auto Measure = [&](float Load, float& MeanZ, float& SpreadZ, bool& bInside, float& MaxUp)
			{
				FE->Bucket.Load.Clear(); FE->Bucket.Load.Add(ESoil::DrySoil, Load, 0.2f);
				FE->FillKey = -1; FE->VisualTick(Dt);
				MeanZ = 0; SpreadZ = 0; bInside = false; MaxUp = 0;
				if (!FE->FillMesh || !FE->FillMesh->IsVisible() || !FE->FillMesh->GetProcMeshSection(0)) return;
				const TArray<FProcMeshVertex>& Vb = FE->FillMesh->GetProcMeshSection(0)->ProcVertexBuffer;
				const FTransform Xf = FE->FillMesh->GetComponentTransform();
				float Lo = 1e9f, Hi = -1e9f; bInside = true;
				const int32 GridT = ARWExcavator::FillNT + 1, GridW = ARWExcavator::FillNW + 1, Grid = GridT * GridW; // surface grid (skirts and loose pieces come after)
				for (int32 k = 0; k < FMath::Min(Vb.Num(), Grid); ++k)
				{
					const FVector P = Vb[k].Position * CM2M;
					bInside &= P.X > -0.05f * FE->Lk && P.X < 1.05f * FE->Lk && FMath::Abs(P.Y) <= FE->Bucket.Width * 0.5f + 0.01f;
					const float Z = Xf.TransformPosition(Vb[k].Position).Z * CM2M;
					MeanZ += Z / Grid;
					// the soil heaps into a mound in the middle on purpose: check the level where it meets the steel
					const int32 Tg = k % GridT, Wg = k / GridT;
					if (Tg == 0 || Tg == GridT - 1 || Wg == 0 || Wg == GridW - 1) { Lo = FMath::Min(Lo, Z); Hi = FMath::Max(Hi, Z); }
					MaxUp = FMath::Max(MaxUp, Z);
				}
				SpreadZ = Hi - Lo;
			};
			float Z30, S30, Z90, S90, ZT, ST, ZH, SH, U30, U90, UT, UH; bool I30, I90, IT, IH;
			const float Cap = FE->Bucket.Capacity;
			Measure(0.3f * Cap, Z30, S30, I30, U30);
			const float Frac30 = FE->FillLevelFrac;
			Measure(0.8f * Cap, Z90, S90, I90, U90);
			FE->BktA = BktTilt; FE->SimStep(Dt);         // tilt the bucket 30 degrees
			Measure(0.3f * Cap, ZT, ST, IT, UT);
			FE->BktA = BktUp; FE->SimStep(Dt);
			Measure(1.3f * Cap, ZH, SH, IH, UH);         // overloaded: heaped above the rim
			FE->Bucket.Load.Clear(); FE->VisualTick(Dt);
			FE->BoomA = Boom0; FE->ArmA = Arm0; FE->BktA = Bkt0; FE->SimStep(Dt);
			const float Lumps = 0.12f * FE->Lk;          // the surface is lumpy by design (+-4.5% of the bucket length)
			Check(TEXT("Soil fills the bucket shape and stays level"), I30 && I90 && IT && S30 < Lumps && ST < Lumps && Z90 > Z30 + 0.05f && UH > U90 && Frac30 > 0.3f && Frac30 < 0.42f,
				FString::Printf(TEXT("30%% load: %.0f%% of the shell, surface level within %.1f cm; 80%%: surface %.2f m higher; tilted 30 deg: still level within %.1f cm; 130%%: heaped %.2f m above the 80%% surface"), Frac30 * 100.f, S30 * 100.f, Z90 - Z30, ST * 100.f, (UH - U90)));
		}
	}
	// 24. grade guide: colours follow the real terrain vs the job design and the cut/fill totals react to digging
	{
		int32 PondJ = INDEX_NONE;
		for (int32 k = 0; k < Jobs.Jobs.Num(); ++k) if (Jobs.Jobs[k].Type == EJob::Pond && Jobs.Jobs[k].bAccepted && !Jobs.Jobs[k].bDone) PondJ = k;
		if (PondJ != INDEX_NONE)
		{
			const int32 KeepTrack = Jobs.Tracked; Jobs.Tracked = PondJ;
			const FVector KeepCam = CamM; CamM = FVector(Jobs.Jobs[PondJ].C.X, Jobs.Jobs[PondJ].C.Y, 0.f);
			UpdateGradeGuide(true);
			const float Cut0 = GuideCut, On0 = GuideOnGrade;
			const int32 Tris = GuideMesh && GuideMesh->GetProcMeshSection(0) ? GuideMesh->GetProcMeshSection(0)->ProcIndexBuffer.Num() / 3 : 0;
			// dig a 4 x 4 m patch of the pond exactly down to the design level
			const FRWJob& J = Jobs.Jobs[PondJ];
			double Removed = 0;
			for (float x = -2.f; x <= 2.f; x += ARWTerrain::CS)
				for (float y = -2.f; y <= 2.f; y += ARWTerrain::CS)
				{
					const FVector Q(J.C.X + x, J.C.Y + y, 0.f);
					float Z;
					const int32 i = Terrain->IndexAt(Q.X, Q.Y);
					if (Jobs.DesignGrade(FVector(Q.X, Q.Y, Terrain->Height[i]), Z) && Terrain->Height[i] > Z) { FPayload Pl; Removed += Terrain->RemoveAt(i, Terrain->Height[i] - Z, Pl, true) * ARWTerrain::CellArea; }
				}
			UpdateGradeGuide(true);
			Check(TEXT("Grade guide shows cut / fill and updates when digging"), Tris > 0 && Cut0 > 1.f && GuideCut < Cut0 - 0.5f * Removed && GuideOnGrade > On0,
				FString::Printf(TEXT("pond guide %d triangles: %.0f m3 to cut, %.0f%% on grade; after digging %.1f m3 to grade: %.0f m3 to cut, %.0f%% on grade"), Tris, Cut0, On0 * 100.f, Removed, GuideCut, GuideOnGrade * 100.f));
			Jobs.Tracked = KeepTrack; CamM = KeepCam;
		}
		else Check(TEXT("Grade guide shows cut / fill and updates when digging"), false, TEXT("no running pond job"));
	}
	// 25. the CX250D model really digs with its controls: soil leaves the ground, appears in the bucket's cavity
	//     (world bounds inside the bucket's own meshes) and pours out again when dumped
	{
		ARWExcavator* CX = nullptr;
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && X->Model.Contains(TEXT("CX250D")) && !CX) CX = X; // (these are the CX250D's own measured checks)
		if (!CX) for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && !CX) CX = X;
		if (CX)
		{
			CX->bEngineOn = true; CX->Rpm = CX->MaxRpm; CX->ThrottleDial = 1.f; CX->Tool = 0; CX->Bucket.Load.Clear();
			// grading with the machine's own controls: the bucket lies on its back and the arm draws it in. Only the back is on the
			// ground, so the machine must grade (not scoop): nothing enters the bucket and only the skin of the ground changes
			{
				CX->Bucket.Load.Clear(); CX->Tool = 0; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				const float KeepBoom = CX->BoomA, KeepArm = CX->ArmA, KeepBkt = CX->BktA;
					for (int32 k = 0; k < 90; ++k) { CX->InA1 = 0.6f; CX->InA2 = 0.5f; CX->SimStep(Dt); } // up and out
				CX->InA1 = CX->InA2 = 0.f;
				float BestZ = -2.f, BestA = CX->BktA;
				for (float Ang = CX->BktLo + 1.f; Ang < CX->BktHi; Ang += 3.f)
				{
					CX->BktA = Ang; CX->SimStep(Dt);
					if (CX->MouthDir().Z > BestZ) { BestZ = CX->MouthDir().Z; BestA = Ang; }
				}
				CX->BktA = BestA; CX->SimStep(Dt);
				auto Gap = [&]() { return CX->DbgBellyGap + 0.005f; }; // the belly just pressing on the ground
				int32 Lower = 0;
				const float GapAir = Gap();
				while (Gap() > 0.02f && Lower++ < 900) { CX->InA1 = FMath::Clamp(-Gap() * 2.f, -1.f, -0.05f); CX->SimStep(Dt); }
				RWTestLog(FString::Printf(TEXT("   info: flat bucket (mouth up %.2f): belly %.2f m over the ground in the air, %.2f m after %d frames lowering; boom %.0f arm %.0f bucket %.0f; belly %.2f m under the teeth"), BestZ, GapAir, Gap(), Lower, CX->BoomA, CX->ArmA, CX->BktA, CX->DbgBelly));
				const FVector Tip0 = CX->TipWorld();
				TArray<float> H0;
				for (float x = -6.f; x <= 6.f; x += ARWTerrain::CS) for (float y = -6.f; y <= 6.f; y += ARWTerrain::CS) H0.Add(T->HeightAt(Tip0.X + x, Tip0.Y + y));
				int32 GradeFrames = 0, DigFrames = 0, Frames = 0, WorkFrames = 0;
				for (int32 k = 0; k < 110; ++k)
				{
					CX->InA2 = -0.35f; CX->InA1 = FMath::Clamp(-Gap() * 8.f, -1.f, 1.f); CX->SimStep(Dt); ++Frames;
					GradeFrames += CX->DbgBranch == 1; DigFrames += CX->DbgBranch == 0; WorkFrames += CX->Bucket.bGrading;
										if (k % 25 == 0) RWTestLog(FString::Printf(TEXT("   info: stroke frame %d: belly gap %.3f, tip speed %.2f, into-mouth %.2f, boom input %.2f, branch %d, resist %.2f"), k, CX->DbgBellyGap, FVector::Dist(CX->TipWorld(), Tip0) / FMath::Max(k * Dt, 0.01f), CX->DbgInto, CX->InA1, CX->DbgBranch, CX->Bucket.Resist));
				}
				CX->InA1 = CX->InA2 = 0.f;
				const float LoadAfter = CX->Bucket.Load.Total();
				float MaxDrop = 0.f, MaxRise = 0.f; int32 Idx = 0;
				for (float x = -6.f; x <= 6.f; x += ARWTerrain::CS) for (float y = -6.f; y <= 6.f; y += ARWTerrain::CS)
				{
					const float DH = T->HeightAt(Tip0.X + x, Tip0.Y + y) - H0[Idx++];
					MaxDrop = FMath::Max(MaxDrop, -DH); MaxRise = FMath::Max(MaxRise, DH);
				}
				Check(TEXT("Grading with the machine: back on the ground, nothing enters the bucket, only the skin changes"), GradeFrames > Frames * 8 / 10 && WorkFrames > Frames / 2 && LoadAfter < 0.005f && MaxDrop < 0.15f,
					FString::Printf(TEXT("%d of %d frames graded (%d with ground contact), %d dug; bucket %.3f m3; ground cut at most %.1f cm, rose at most %.1f cm"), GradeFrames, Frames, WorkFrames, DigFrames, LoadAfter, MaxDrop * 100.f, MaxRise * 100.f));
				CX->BoomA = KeepBoom; CX->ArmA = KeepArm; CX->BktA = KeepBkt; CX->SimStep(Dt);
				CX->InA1 = 0.f;
			}
			const double Book0 = T->LooseBook() + Fx->InFlightVolume();
			int32 Ph = 0; float PT = 0.f; float MaxLoad = 0.f; int32 Steps = 0;
			while (Steps++ < 60 * 30 && !CX->AutoDig(Dt, 0.6f, false, 0.f, Ph, PT))
			{
				CX->SimStep(Dt); Fx->Tick(Dt); MaxLoad = FMath::Max(MaxLoad, CX->Bucket.Load.Total());
				if (Steps % 30 == 0)
				{
					const FVector Tp = CX->TipWorld();
					RWTestLog(FString::Printf(TEXT("   trace t=%.1f phase %d  boom %.0f arm %.0f bkt %.0f | teeth %.2f below ground, into-mouth %.2f, branch %d | bucket %.3f m3, resist %.2f"),
						Steps * Dt, Ph, CX->BoomA, CX->ArmA, CX->BktA, CX->DbgPen, CX->DbgInto, CX->DbgBranch, CX->Bucket.Load.Total(), CX->Bucket.Resist));
				}
			}
			CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
			CX->FillKey = -1; CX->VisualTick(Dt); // force the rebuild: the soil mesh normally updates at most 15 times a second
			const float Load = CX->Bucket.Load.Total();
			Fx->SettleAll();
			const double Book1 = T->LooseBook();
			const double Lost = Book0 - Book1; // loose-equivalent volume that left the ground (and did not land again)
			// where is the soil mesh compared with the bucket's own steel?
			FBox BucketBox(ForceInit);
			TArray<USceneComponent*> Kids; CX->ToolRoots[0]->GetChildrenComponents(true, Kids);
			for (USceneComponent* K : Kids)
				if (UStaticMeshComponent* SM = Cast<UStaticMeshComponent>(K)) if (SM != CX->Heap && !CX->HeapClods.Contains(SM) && SM->IsVisible()) BucketBox += SM->Bounds.GetBox();
			FBox FillBox(ForceInit); int32 NV = 0, Inside = 0;
			const bool bVis = CX->FillMesh && CX->FillMesh->IsVisible() && CX->FillMesh->GetProcMeshSection(0) && CX->FillMesh->GetProcMeshSection(0)->ProcVertexBuffer.Num() > 0;
			if (bVis)
			{
				const FTransform Xf = CX->FillMesh->GetComponentTransform();
				for (const FProcMeshVertex& Vx : CX->FillMesh->GetProcMeshSection(0)->ProcVertexBuffer)
				{
					const FVector Wp = Xf.TransformPosition(Vx.Position);
					FillBox += Wp; ++NV;
					Inside += BucketBox.ExpandBy(5.f).IsInside(Wp) ? 1 : 0;
				}
			}
			const float InFrac = NV ? Inside / float(NV) : 0.f;
			const FVector Mouth = CX->MouthDir();
			// which way the DRAWN side of the soil surface faces in the world (Unreal draws where (C-A)x(B-A) points)
			float FrontUp = -1.f;
			if (bVis)
			{
				const FProcMeshSection* Sec = CX->FillMesh->GetProcMeshSection(0);
				const FTransform Xf = CX->FillMesh->GetComponentTransform();
				FVector Acc(0);
				for (int32 k = 0; k + 2 < Sec->ProcIndexBuffer.Num() && k < ARWExcavator::FillNT * ARWExcavator::FillNW * 6; k += 3)
				{
					const FVector A = Xf.TransformPosition(Sec->ProcVertexBuffer[Sec->ProcIndexBuffer[k]].Position), B = Xf.TransformPosition(Sec->ProcVertexBuffer[Sec->ProcIndexBuffer[k + 1]].Position), C = Xf.TransformPosition(Sec->ProcVertexBuffer[Sec->ProcIndexBuffer[k + 2]].Position);
					Acc += FVector::CrossProduct(C - A, B - A);
				}
				FrontUp = Acc.GetSafeNormal().Z;
			}
			Check(TEXT("Bucket soil surface is drawn facing the sky (not culled)"), FrontUp > 0.5f, FString::Printf(TEXT("drawn side of the soil surface points up %.2f (1 = straight up)"), FrontUp));
			Check(TEXT("CX250D digs: soil goes into its bucket and shows inside the cavity"), Load > 0.3f * CX->Bucket.Capacity && bVis && InFrac > 0.95f,
				FString::Printf(TEXT("bucket %.2f of %.2f m3 (%s), ground lost %.2f m3; soil mesh %s, %.0f%% of its %d points inside the bucket (bucket %s, soil %s); shell side %s, mouth faces up %.2f"),
					Load, CX->Bucket.Capacity, *SoilName(CX->Bucket.Load.Dominant(), CX->Bucket.Load.Moist), Lost, bVis ? TEXT("visible") : TEXT("HIDDEN"), InFrac * 100.f, NV,
					*BucketBox.GetSize().ToCompactString(), *FillBox.GetSize().ToCompactString(), CX->BucketSign > 0 ? TEXT("+Z") : TEXT("-Z"), Mouth.Z));
			// dump it again: the bucket empties and the soil returns to the ground
			Ph = 5; PT = 0.f; Steps = 0;
			while (Steps++ < 60 * 12 && !CX->AutoDig(Dt, 0.6f, true, 0.05f, Ph, PT)) { CX->SimStep(Dt); Fx->Tick(Dt); }
			CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
			Fx->SettleAll();
			const double Book2 = T->LooseBook();
			// (AutoDig was told to stop tipping at 5 % of the bucket's capacity, whatever the load)
			Check(TEXT("CX250D dumps: the bucket empties back onto the ground"), CX->Bucket.Load.Total() < FMath::Max(0.1f * Load, 0.055f * CX->Bucket.Capacity) && FMath::Abs((Book2 - Book1) - (Load - CX->Bucket.Load.Total())) < 0.1 * Load + 0.05,
				FString::Printf(TEXT("bucket %.2f -> %.2f m3, ground gained %.2f m3"), Load, CX->Bucket.Load.Total(), Book2 - Book1));
		}
		else Check(TEXT("CX250D digs: soil goes into its bucket and shows inside the cavity"), false, TEXT("no 3D-model excavator loaded"));
	}
	// 26. at any bucket angle the soil stays inside the steel (it may only rise out of the open mouth when that
	//     faces up) and the soil face across the opening is drawn when the mouth faces the side
	{
		ARWExcavator* CX = nullptr;
		for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && X->Model.Contains(TEXT("CX250D")) && !CX) CX = X; // (these are the CX250D's own measured checks)
		if (!CX) for (ARWMachine* M : Machines) if (ARWExcavator* X = Cast<ARWExcavator>(M)) if (X->bModelRig && !CX) CX = X;
		if (CX)
		{
			int32 Bad = 0, Total = 0, Faces = 0; FString Per;
			const float L = CX->Lk, D = FMath::Max(CX->Bucket.Depth, 0.15f * L) * 0.94f, S = CX->BucketSign;
			for (const float Ang : {CX->BktLo + 1.f, -130.f, -90.f, -50.f, -10.f, 30.f}) // incl. curled fully in
			{
				CX->Tool = 0; CX->BktA = Ang; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				CX->SimStep(Dt);
				CX->Bucket.Load.Clear(); CX->Bucket.Load.Add(ESoil::DrySoil, 0.9f * CX->Bucket.Capacity, 0.2f);
				CX->FillKey = -1; CX->VisualTick(Dt);
				int32 B = 0, NV = 0;
				if (CX->FillMesh && CX->FillMesh->IsVisible() && CX->FillMesh->GetProcMeshSection(0))
				{
					const TArray<FProcMeshVertex>& Vb = CX->FillMesh->GetProcMeshSection(0)->ProcVertexBuffer;
					NV = Vb.Num();
					if (CX->FillBaseVerts > (ARWExcavator::FillNT + 1) * (ARWExcavator::FillNW + 1)) ++Faces;
					for (const FProcMeshVertex& Vx : Vb)
					{
						const FVector P = Vx.Position * CM2M; // bucket frame: x to the teeth, z into the shell (x sign)
						const float Zs = P.Z * S;
						const TArray<FVector2D>& Pr = CX->BucketProfile;
						if (Pr.Num() >= 4)
						{
							// the steel's real outer surface, measured from the model's vertices
							if (P.X < Pr[0].X - 0.05f || P.X > Pr.Last().X + 0.05f) { ++B; continue; }
							int32 k = 0; while (k + 1 < Pr.Num() - 1 && Pr[k + 1].X < P.X) ++k;
							const float A = FMath::Clamp((P.X - Pr[k].X) / FMath::Max(Pr[k + 1].X - Pr[k].X, 1e-3f), 0.f, 1.f);
							const float Outer = FMath::Lerp(Pr[k].Y, Pr[k + 1].Y, A);
							if (Zs > Outer + 0.02f) ++B; // beyond the shell = through the steel
						}
						else
						{
							if (Zs > 0.06f * D)
							{
								const float Ell = FMath::Square((P.X - 0.5f * L) / (0.47f * L)) + FMath::Square((Zs - 0.06f * D) / (0.9f * D));
								if (Ell > 1.1f) ++B; // outside the shell's curve = through the steel
							}
							if (P.X < -0.08f * L || P.X > 1.08f * L) ++B; // past the back plate or the teeth
						}
					}
				}
				Bad += B; Total += NV;
				Per += FString::Printf(TEXT(" %.0f deg: %d/%d out, mouth up %.2f;"), Ang, B, NV, CX->MouthDir().Z);
			}
			CX->Bucket.Load.Clear(); CX->VisualTick(Dt);
			Check(TEXT("Bucket soil never pokes through the steel"), Total > 0 && Bad == 0 && Faces > 0,
				FString::Printf(TEXT("%d soil points checked at 6 bucket angles (incl. fully curled), %d outside the real shell, heap sides closed at %d angles:%s"), Total, Bad, Faces, *Per));
			// soil mechanics: the force follows the earthmoving equation, the hydraulics stall at the machine's limit
			{
				const FRWSoilStrength Soil1 = FRWSoilMech::Strength(ESoil::DrySoil, 0.2f, 0.7f);
				const float F03 = FRWSoilMech::CutForce(Soil1, 0.3f, 1.2f, 50.f, 0.5f).Total, F06 = FRWSoilMech::CutForce(Soil1, 0.6f, 1.2f, 50.f, 0.5f).Total;
				const float FWide = FRWSoilMech::CutForce(Soil1, 0.3f, 2.4f, 50.f, 0.5f).Total;
				const float FSand = FRWSoilMech::CutForce(FRWSoilMech::Strength(ESoil::Sand, 0.0f, 0.3f), 0.3f, 1.2f, 50.f, 0.5f).Total;
				const float FClay = FRWSoilMech::CutForce(FRWSoilMech::Strength(ESoil::Clay, 0.2f, 0.7f), 0.3f, 1.2f, 50.f, 0.5f).Total;
				const float FWetClay = FRWSoilMech::CutForce(FRWSoilMech::Strength(ESoil::Clay, 0.9f, 0.7f), 0.3f, 1.2f, 50.f, 0.5f).Total;
				const float FHard = FRWSoilMech::CutForce(FRWSoilMech::Strength(ESoil::Compacted, 0.1f, 1.f), 0.8f, 1.2f, 50.f, 0.5f).Total;
				const float Limit = CX->EmptyMass * GRAV * 0.7f;
				Check(TEXT("Digging force follows the soil mechanics"), F06 > F03 * 1.9f && FMath::IsNearlyEqual(FWide, F03 * 2.f, F03 * 0.02f) && FClay > FSand * 3.f && FClay > FWetClay * 1.5f && F03 > 4000.f && F03 < 0.5f * Limit && FHard > Limit,
					FString::Printf(TEXT("%.0f kN limit; soil 0.3 m deep: %.1f kN, 0.6 m: %.1f kN, twice as wide: %.1f kN; sand %.1f, clay %.1f, wet clay %.1f kN; 0.8 m of compacted ground %.0f kN"), Limit / 1000.f, F03 / 1000.f, F06 / 1000.f, FWide / 1000.f, FSand / 1000.f, FClay / 1000.f, FWetClay / 1000.f, FHard / 1000.f));
				Check(TEXT("Hydraulics slow down and stall at the force limit"), FRWSoilMech::HydSpeedScale(0.3f) > 0.99f && FMath::IsNearlyEqual(FRWSoilMech::HydSpeedScale(0.75f), 0.5f, 0.01f) && FRWSoilMech::HydSpeedScale(1.2f) < 0.05f && FRWSoilMech::HydSpeedScale(1.2f) > 0.f,
					FString::Printf(TEXT("speed at 30%% / 75%% / 120%% of the force limit: %.2f / %.2f / %.2f"), FRWSoilMech::HydSpeedScale(0.3f), FRWSoilMech::HydSpeedScale(0.75f), FRWSoilMech::HydSpeedScale(1.2f)));
			}
			// pouring: the bucket holds its load until the soil reaches the lip, then it runs out; upside down it empties
			{
				float HoldUp = -1.f, HoldDown = 1e9f, ZUp = -2.f, ZDown = 2.f, AngUp = 0.f, AngDown = 0.f;
				for (float Ang = CX->BktLo + 1.f; Ang < CX->BktHi; Ang += 12.f)
				{
					CX->Tool = 0; CX->BktA = Ang; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
					CX->SimStep(Dt);
					const float Mz = CX->MouthDir().Z, Hd = CX->BucketHoldLoose();
					if (Mz > ZUp) { ZUp = Mz; HoldUp = Hd; AngUp = Ang; }
					if (Mz < ZDown) { ZDown = Mz; HoldDown = Hd; AngDown = Ang; }
				}
				const FVector PourAt = CX->TipWorld() + FVector(0, 0, 2.f);
				auto Poured = [&](float Ang)
				{
					CX->BktA = Ang; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
					CX->SimStep(Dt);
					CX->Bucket.Penetration = 0.f;
					FBucketTool B = CX->Bucket;
					B.Load.Clear(); B.Load.Add(ESoil::DrySoil, 0.9f * B.Capacity, 0.2f);
					B.Shake = 0.f; // held still: only the attitude decides
					const float Before = B.Load.Total(), Hd = CX->BucketHoldLoose();
					for (int32 k = 0; k < 120; ++k) B.Spill(Fx, PourAt, FVector::ZeroVector, CX->MouthDir(), Dt, Hd);
					return Before - B.Load.Total();
				};
				const float LostUp = Poured(AngUp), LostDown = Poured(AngDown);
				Fx->SettleAll();
				CX->Bucket.Load.Clear();
				Check(TEXT("Soil stays in the bucket until it reaches the lip, then pours"), HoldUp >= CX->Bucket.Capacity && HoldDown < 0.35f * CX->Bucket.Capacity && LostUp < 0.001f && LostDown > 0.3f * CX->Bucket.Capacity,
					FString::Printf(TEXT("mouth up (%.2f): holds %.2f m3 and 2 s loses %.3f m3 of a %.2f m3 load; mouth down (%.2f): holds %.2f m3 and 2 s pours %.2f m3"), ZUp, HoldUp, LostUp, 0.9f * CX->Bucket.Capacity, ZDown, HoldDown, LostDown));
			}
			// crawler tracks: the same machine sinks deeper into soft wet soil than into packed ground
			{
				ARWMachine* Cr = nullptr;
				for (ARWMachine* M : Machines) if (M && M != CX && M->Drive == EDrive::Tracked && !Cast<ARWExcavator>(M) && !Cr) Cr = M;
				if (Cr)
				{
					const FVector KeepPos = Cr->PosM; const float KeepYaw = Cr->Yaw;
					auto Run = [&](const FVector2D& At, bool bSoft) -> float
					{
						for (float x = -8.f; x <= 26.f; x += ARWTerrain::CS)
							for (float y = -6.f; y <= 6.f; y += ARWTerrain::CS)
							{
								const int32 i = T->IndexAt(At.X + x, At.Y + y);
								FPayload Sp; T->RemoveAt(i, FMath::Max(0.f, T->Height[i] - (T->Height[T->IndexAt(At.X, At.Y)])), Sp, true);
								T->DepositAt(i, ESoil::DrySoil, 0.5f * ARWTerrain::CellArea, bSoft ? 0.6f : 0.1f, bSoft ? 10 : 245);
								if (!bSoft) T->CompactAt(i, 1.f);
							}
						for (int32 r = 0; r < 8; ++r) T->Relax(4000);
						Cr->PosM = FVector(At.X, At.Y, T->HeightAt(At.X, At.Y) + 0.5f); Cr->Yaw = 0.f; Cr->Speed = 0.f;
						Cr->bEngineOn = true; Cr->Rpm = Cr->MaxRpm;
						for (int32 k = 0; k < 60; ++k) { Cr->InThrottle = 0.f; Cr->SimStep(Dt); }
						const FVector2D Lane(At.X + 8.f, At.Y + Cr->TrackGauge * 0.5f);
						const float Z0 = T->HeightAt(Lane.X, Lane.Y);
						for (int32 k = 0; k < 420; ++k) { Cr->InThrottle = 1.f; Cr->SimStep(Dt); }
						Cr->InThrottle = 0.f;
						return Z0 - T->HeightAt(Lane.X, Lane.Y);
					};
					const float Soft = Run(FVector2D(-20.f, -120.f), true), Hard = Run(FVector2D(-20.f, -140.f), false);
					Cr->PosM = KeepPos; Cr->Yaw = KeepYaw; Cr->Speed = 0.f;
					for (int32 k = 0; k < 30; ++k) Cr->SimStep(Dt);
					Check(TEXT("Crawler tracks sink deeper into soft ground"), Soft > 0.01f && Soft > Hard * 2.f,
						FString::Printf(TEXT("rut in soft wet soil %.1f cm, in packed soil %.1f cm"), Soft * 100.f, Hard * 100.f));
				}
			}
			// pipe laying: sling a pipe under the bucket, set it down, set a second next to it: they join into one run, it
			// stays down when buried, and water runs through
			{
				CX->Bucket.Load.Clear(); CX->Tool = 0; CX->BktA = -70.f; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				CX->SimStep(Dt);
				const FVector PTip = CX->TipWorld();
				const float PY0 = 30.f;
				ARWProp* P1 = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				ARWProp* P2 = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				P1->Init(3, T, FVector(PTip.X, PTip.Y, T->HeightAt(PTip.X, PTip.Y)), PY0);
				const bool bGrabbed = CX->SlingGrab();
				const bool bHeld = bGrabbed && CX->Slung.Get() == P1 && P1->bCarried;
				for (int32 k = 0; k < 30; ++k) CX->SimStep(Dt);
				const float HangZ = P1->PosM().Z - T->HeightAt(P1->PosM().X, P1->PosM().Y);
				// set it down
				CX->SlingRelease();
				for (int32 k = 0; k < 240; ++k) P1->Tick(Dt);
				const bool bLaid1 = P1->bLaid;
				FVector A1, B1; P1->PipeEnds(A1, B1);
				// the second lands a little off line, just beyond its end
				const FVector2D Off = FVector2D(B1 - A1).GetSafeNormal() * (0.5f * ARWProp::PipeLen + 0.7f) + FVector2D(0.2f, -0.2f);
				const FVector2D C2 = FVector2D(B1) + Off;
				P2->Init(3, T, FVector(C2.X, C2.Y, T->HeightAt(C2.X, C2.Y) + 1.f), P1->FallYaw + 12.f);
				P2->bCarried = true; P2->Tick(Dt); P2->bCarried = false;
				for (int32 k = 0; k < 240; ++k) P2->Tick(Dt);
				FVector A2, B2; P2->PipeEnds(A2, B2);
				const float JointGap = FMath::Min(FVector2D::Distance(FVector2D(B1), FVector2D(A2)), FVector2D::Distance(FVector2D(B1), FVector2D(B2)));
				TArray<ARWProp::FPipeRun> Runs; ARWProp::PipeRuns(Runs);
				int32 Longest = 0; for (const ARWProp::FPipeRun& R : Runs) Longest = FMath::Max(Longest, R.Count);
				// buried: soil on top must leave it where it is
				const float Z2 = P2->PosM().Z;
				const int32 Over = T->IndexAt(P2->PosM().X, P2->PosM().Y);
				FPayload Fill; Fill.Add(ESoil::DrySoil, 2.f, 0.2f);
				T->DepositPayloadAt(Over, Fill);
				for (int32 k = 0; k < 30; ++k) P2->Tick(Dt);
				const float Buried = FMath::Abs(P2->PosM().Z - Z2);
				UpdateWaterSources();
				bool bCulvert = false;
				if (Water) for (const ARWWater::FCulvert& C : Water->Culverts) if (FMath::IsNearlyEqual(C.Diameter, ARWProp::PipeDia, 0.01f)) bCulvert = true;
				Check(TEXT("Pipes are slung, laid, joined and carry water"), bHeld && HangZ > 0.1f && bLaid1 && P2->bLaid && JointGap < 0.05f && Longest == 2 && Buried < 0.02f && bCulvert,
					FString::Printf(TEXT("picked up: %s, hanging %.2f m above the ground; laid: %s/%s; joint gap %.2f m, longest run %d pipes; moved %.2f m when buried; water run registered: %s"),
						bHeld ? TEXT("yes") : TEXT("no"), HangZ, bLaid1 ? TEXT("yes") : TEXT("no"), P2->bLaid ? TEXT("yes") : TEXT("no"), JointGap, Longest, Buried, bCulvert ? TEXT("yes") : TEXT("no")));
				// tipped right over the open end: the mouth stays clear and the soil goes aside, none of it lost
				{
					TArray<ARWProp::FPipeRun> Runs2; ARWProp::PipeRuns(Runs2);
					const ARWProp::FPipeRun* Run = nullptr;
					for (const ARWProp::FPipeRun& R : Runs2) if (R.Count == 2) Run = &R;
					UpdateWaterSources();
					KeepPipeMouthsOpen();
					if (Water) for (ARWWater::FCulvert& C : Water->Culverts) C.bKeepMouth = true; // a built culvert keeps its ends open; a laid pipe can be buried (next test)
					const FVector MouthP = Run ? Run->In : A1, OtherP = Run ? Run->Out : B1;
					const FVector2D Mouth(MouthP), Out2 = (FVector2D(MouthP) - FVector2D(OtherP)).GetSafeNormal();
					const double Bk0 = AreaVolume(T, Mouth.X, Mouth.Y, 16.f);
					FPayload Tip1; Tip1.Add(ESoil::DrySoil, 8.f, 0.2f);
					T->DepositDisc(Mouth.X, Mouth.Y, 1.6f, Tip1);
					const double Bk1 = AreaVolume(T, Mouth.X, Mouth.Y, 16.f);
					const FVector2D Front = Mouth + Out2 * 0.25f;
					const float HOver = T->HeightAt(Front.X, Front.Y) - MouthP.Z;
					for (int32 k = 0; k < 40; ++k) { T->Relax(4000); KeepPipeMouthsOpen(); }
					const float HAfter = T->HeightAt(Front.X, Front.Y) - MouthP.Z;
					const double Bk2 = AreaVolume(T, Mouth.X, Mouth.Y, 16.f); // it has only been moved aside, so the area still holds it
					Check(TEXT("Soil never closes the open end of a built culvert"), HOver > 0.3f && HAfter < 0.08f && FMath::Abs(Bk2 - Bk1) < 0.15 * (Bk1 - Bk0),
						FString::Printf(TEXT("8 m3 tipped on the mouth: ground over the pipe floor %.2f m -> %.2f m; volume around it %.2f -> %.2f -> %.2f m3"), HOver, HAfter, Bk0, Bk1, Bk2));
				}
				P1->Destroy(); P2->Destroy();
				// the whole job with bucket pours: trench, pipe on its floor, soil over it, and dug open again
				{
					const FVector2D Sd0(40.f, -104.f);
					const float Floor = T->HeightAt(Sd0.X, Sd0.Y) - 1.5f;
					for (float x = -4.f; x <= 4.f; x += ARWTerrain::CS)
						for (float y = -1.25f; y <= 1.25f; y += ARWTerrain::CS)
						{
							const int32 i = T->IndexAt(Sd0.X + x, Sd0.Y + y);
							FPayload Sp;
							T->RemoveAt(i, T->Height[i] - Floor, Sp, true);
						}
					ARWProp* P3 = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
					P3->Init(3, T, FVector(Sd0.X, Sd0.Y, Floor + 1.f), 0.f);
					P3->bCarried = true; P3->Tick(Dt); P3->bCarried = false;
					for (int32 k = 0; k < 240; ++k) P3->Tick(Dt);
					const float PipeZ = P3->PosM().Z, Open0 = P3->PipeCover();
					const bool bHasFloor = P3->PipeFloorCells.Num() > 0;
					FVector PA, PB; P3->PipeEnds(PA, PB);
					const FVector2D PMid = (FVector2D(PA) + FVector2D(PB)) * 0.5f, PDir = (FVector2D(PB) - FVector2D(PA)).GetSafeNormal();
					// pour bucket loads until it is covered, as a bucket does: soil that falls and lands
					float Poured = 0.f, FirstRise = 0.f; int32 Pours = 0;
					while (P3->PipeCover() < 0.5f && Pours < 60)
					{
						const FVector2D At = PMid + PDir * ((Pours % 3 - 1) * 1.2f);
						const float H0 = T->HeightAt(At.X, At.Y);
						FPayload Pour; Pour.Add(ESoil::DrySoil, 0.8f, 0.2f);
						Fx->SpawnSoil(FVector(At.X, At.Y, H0 + 1.5f), FVector::ZeroVector, Pour, 0.5f);
						Fx->SettleAll();
						for (int32 r = 0; r < 4; ++r) T->Relax(4000);
						if (Pours == 0) FirstRise = T->HeightAt(At.X, At.Y) - H0;
						Poured += 0.8f; ++Pours;
					}
					for (int32 k = 0; k < 40; ++k) { T->Relax(4000); P3->Tick(Dt); }
					const float Covered = P3->PipeCover();
					// measured all over it: ground above the crown everywhere along the pipe, the pipe itself neither moved nor hidden by a switch
					const bool bStill = FMath::Abs(P3->PosM().Z - PipeZ) < 0.01f && !P3->IsHidden() && P3->Mesh->IsVisible();
					Check(TEXT("A laid pipe is buried by pouring soil over it"), Open0 < -0.5f && Covered >= 0.3f && bStill && bHasFloor,
						FString::Printf(TEXT("diameter %.2f m at %.2f m below the old ground; ground over the crown %.2f -> %.2f m after %d pours, %.1f m3 loose (first pour raised the ground %.2f m), pipe stayed put and visible to the renderer: %s"),
							ARWProp::PipeDia, 1.5f, Open0, Covered, Pours, Poured, FirstRise, bStill ? TEXT("yes") : TEXT("no")));
					// open it again with a real bucket: the soil comes off, the pipe stays whole under it
					FBucketTool Bk; Bk.Width = 1.2f; Bk.Capacity = 5.f;
					const FVector2D Lat2(-PDir.Y, PDir.X);
					const float CrownZ = PipeZ + ARWProp::PipeDia;
					for (int32 Pass = 0; Pass < 6; ++Pass)
						for (const float Sd : {0.f, -0.9f, 0.9f})
						{
							FVector Tip(PMid.X - PDir.X * 3.f + Lat2.X * Sd, PMid.Y - PDir.Y * 3.f + Lat2.Y * Sd, CrownZ - 0.2f);
							const FVector VelB(PDir.X * 1.f, PDir.Y * 1.f, 0.f);
							for (int32 k = 0; k < 360; ++k)
							{
								Tip += VelB * Dt;
								Bk.Dig(T, Tip, Tip - FVector(PDir.X, PDir.Y, -0.3f) * 0.6f, FVector(Lat2.X, Lat2.Y, 0.f), VelB, FVector(PDir.X, PDir.Y, 0.f), 1.f, Dt);
								if (Bk.Load.Total() > 4.f) Bk.Load.Clear();
							}
						}
					// and nothing can go through it even when asked to
					FPayload Thru;
					const int32 OverPipe = T->IndexAt(PMid.X, PMid.Y);
					T->RemoveAt(OverPipe, 5.f, Thru, true);
					const float Dug = P3->PipeCover(), OverZ = T->Height[OverPipe];
					const bool bPipeOk = P3->bLaid && FMath::Abs(P3->PosM().Z - PipeZ) < 0.01f && OverZ >= CrownZ;
					Check(TEXT("A buried pipe can be dug open again without digging through it"), Dug < 0.1f && bPipeOk,
						FString::Printf(TEXT("ground over the crown %.2f -> %.2f m; pipe still laid and in place: %s; a 5 m dig on top of it stops %.2f m above the crown"), Covered, Dug, bPipeOk ? TEXT("yes") : TEXT("no"), OverZ - CrownZ));
					P3->Destroy();
					Check(TEXT("Taking a pipe away frees the ground under it"), !T->DigFloor.Contains(OverPipe), FString::Printf(TEXT("%d points still reserved"), T->DigFloor.Num()));
				}
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
				UpdateWaterSources();
			}
			// the mountain road job: cut the high stretches, use that same soil on the low ones
			{
				int32 Mj = INDEX_NONE;
				for (int32 j = 0; j < Jobs.Jobs.Num(); ++j) if (Jobs.Jobs[j].Title == TEXT("Mountain road: cut and fill")) Mj = j;
				if (Mj != INDEX_NONE)
				{
					const int32 KeepTrack = Jobs.Tracked;
					Jobs.Accept(Mj);
					FRWJob& J = Jobs.Jobs[Mj];
					float Steep = 0.f, PathLen = 0.f;
					for (int32 k = 1; k < J.PathZ.Num(); ++k)
					{
						const float Ds = FVector2D::Distance(J.Path[k], J.Path[k - 1]);
						PathLen += Ds;
						Steep = FMath::Max(Steep, FMath::Abs(J.PathZ[k] - J.PathZ[k - 1]) / FMath::Max(Ds, 0.1f));
					}
					// the whole line
					const int32 A0 = 0, A1 = J.Path.Num() - 1;
					TArray<int32> Cells; TSet<int32> Seen;
					for (int32 k = A0; k < A1; ++k)
						for (float Sx = -J.HalfW - 1.f; Sx <= J.HalfW + 1.f; Sx += ARWTerrain::CS)
							for (float Sy = -J.HalfW - 1.f; Sy <= J.HalfW + 1.f; Sy += ARWTerrain::CS)
							{
								const int32 Ci = T->IndexAt(J.Path[k].X + Sx, J.Path[k].Y + Sy);
								if (!Seen.Contains(Ci)) { Seen.Add(Ci); Cells.Add(Ci); }
							}
					auto Design = [&](int32 Ci, float& Zd, float& Lat)
					{
						return Jobs.DesignSurface(J, FVector2D(T->PX(Ci % ARWTerrain::N), T->PX(Ci / ARWTerrain::N)), Zd, Lat) && Lat <= J.HalfW + 0.5f;
					};
					FPayload Cart;
					double Cut = 0.0, Fill = 0.0;
					for (const int32 Ci : Cells)
					{
						float Zd, Lat;
						if (!Design(Ci, Zd, Lat) || T->Height[Ci] <= Zd) continue;
						Cut += T->RemoveAt(Ci, T->Height[Ci] - Zd, Cart, true) * ARWTerrain::CellArea;
					}
					const float CartAfterCut = Cart.Total();
					// and the loose soil from the cut raises the low stretches
					for (const int32 Ci : Cells)
					{
						float Zd, Lat;
						if (!Design(Ci, Zd, Lat) || T->Height[Ci] >= Zd || Cart.Total() <= 0.f) continue;
						const float Before = T->Height[Ci];
						const FPayload Part = Cart.Take(FMath::Min((Zd - Before) * ARWTerrain::CellArea, Cart.Total()));
						T->DepositPayloadAt(Ci, Part);
						Fill += (T->Height[Ci] - Before) * ARWTerrain::CellArea;
						T->CompactAt(Ci, 0.5f);
					}
					double Err = 0.0; int32 ErrN = 0; float Worst = 0.f;
					for (const int32 Ci : Cells)
					{
						float Zd, Lat;
						if (!Design(Ci, Zd, Lat)) continue;
						const float Miss = FMath::Abs(T->Height[Ci] - Zd);
						Err += Miss; ++ErrN; Worst = FMath::Max(Worst, Miss);
					}
					const float MeanErr = ErrN ? Err / ErrN : 1e3f;
					Check(TEXT("A road up the mountain: grade limited, cut soil used for the fill"), PathLen > 300.f && Steep <= 0.081f && Cut > 1.f && CartAfterCut > 0.f && (Fill > 0.0 || J.PlanFill < 1.f) && MeanErr < 0.25f,
						FString::Printf(TEXT("%.0f m long, steepest %.1f %%; planned about %.0f m3 cut, %.0f m3 fill; done: %.0f m3 cut gave %.0f m3 loose, %.0f m3 of that raised the low parts, %.0f m3 left for the side slopes; on the design line to %.0f cm (worst %.0f cm)"),
							PathLen, Steep * 100.f, J.PlanCut, J.PlanFill, Cut, CartAfterCut, Fill, Cart.Total(), MeanErr * 100.f, Worst * 100.f));
					Jobs.Abandon(Mj);
					Jobs.Tracked = KeepTrack;
				}
				else Check(TEXT("A road up the mountain: grade limited, cut soil used for the fill"), false, TEXT("no such job"));
			}
			// machines really drive the mountain roads and along a ridge
			{
				auto DriveAlong = [&](ARWMachine* M, const FRWRoad& R, int32 From, int32 To, float Throttle, float& OutSpeed, float& OutWorst, float& OutClimb) -> bool
				{
					const FVector KeepPos = M->PosM; const float KeepYaw = M->Yaw;
					const FVector2D Dir0 = (R.Pts[FMath::Min(From + 4, R.Pts.Num() - 1)] - R.Pts[From]).GetSafeNormal();
					M->PosM = FVector(R.Pts[From].X, R.Pts[From].Y, T->HeightAt(R.Pts[From].X, R.Pts[From].Y));
					M->Yaw = FMath::RadiansToDegrees(FMath::Atan2(Dir0.Y, Dir0.X));
					M->Speed = 0.f; M->Gear = 1; M->bParkBrake = false; M->bEngineOn = true; M->Rpm = M->MaxRpm; M->InBrake = 0.f;
					int32 At = From;
					float Dist = 0.f, Off = 0.f, Low = 1e9f, High = -1e9f;
					int32 Steps = 0;
					const int32 Limit = 60 * 420;
					FVector Last = M->PosM;
					for (; Steps < Limit && At < To; ++Steps)
					{
						// the nearest stretch ahead, and steer for a point a little beyond it
						for (int32 Look = 0; Look < 30 && At + 1 < R.Pts.Num(); ++Look)
						{
							if (FVector2D::DistSquared(FVector2D(M->PosM), R.Pts[At + 1]) < FVector2D::DistSquared(FVector2D(M->PosM), R.Pts[At])) ++At; else break;
						}
						const FVector2D Aim = R.Pts[FMath::Min(At + 7, R.Pts.Num() - 1)] - FVector2D(M->PosM);
						const float Want = FMath::RadiansToDegrees(FMath::Atan2(Aim.Y, Aim.X));
						M->InSteer = FMath::Clamp(FRotator::NormalizeAxis(Want - M->Yaw) / 14.f, -1.f, 1.f);
						M->InThrottle = FMath::Abs(M->Speed) > 6.f ? 0.f : Throttle;
						M->SimStep(Dt);
						Off = FMath::Max(Off, FVector2D::Distance(FVector2D(M->PosM), R.Pts[At]));
						Dist += FVector::Dist2D(M->PosM, Last); Last = M->PosM;
						Low = FMath::Min(Low, M->PosM.Z); High = FMath::Max(High, M->PosM.Z);
					}
					M->InThrottle = M->InSteer = 0.f;
					OutSpeed = Dist / FMath::Max(Steps * Dt, 0.01f); OutWorst = Off; OutClimb = High - Low;
					M->PosM = KeepPos; M->Yaw = KeepYaw; M->Speed = 0.f;
					for (int32 k = 0; k < 10; ++k) M->SimStep(Dt);
					return At >= To;
				};
				const FRWRoad* Haul = nullptr; const FRWRoad* Ridge = nullptr;
				for (const FRWRoad& R : Layout.Roads) { if (R.Name == TEXT("Mine Haul Road")) Haul = &R; if (R.Name == TEXT("South Ridge Road")) Ridge = &R; }
				ARWMachine* Truck = nullptr; ARWMachine* Crawler = nullptr;
				for (ARWMachine* M : Machines) { if (!Truck && Cast<ARWDumpTruck>(M)) Truck = M; if (!Crawler && Cast<ARWDozer>(M)) Crawler = M; }
				if (Haul && Ridge && Truck && Crawler)
				{
					float V1 = 0.f, O1 = 0.f, C1 = 0.f, V2 = 0.f, O2 = 0.f, C2 = 0.f;
					const bool bHaul = DriveAlong(Truck, *Haul, 40, Haul->Pts.Num() - 40, 0.9f, V1, O1, C1);
					// the highest stretch of the ridge road, 500 m of it
					int32 Top = 0;
					for (int32 k = 0; k < Ridge->Z.Num(); ++k) if (Ridge->Z[k] > Ridge->Z[Top]) Top = k;
					const int32 RFrom = FMath::Max(Top - 125, 0), RTo = FMath::Min(Top + 125, Ridge->Pts.Num() - 1);
					const bool bRidge = DriveAlong(Crawler, *Ridge, RFrom, RTo, 1.f, V2, O2, C2);
					Check(TEXT("A truck drives the mine haul road"), bHaul && O1 < 12.f, FString::Printf(TEXT("%.0f m, %.1f m/s on average, climbed %.0f m, furthest %.1f m off the centre line"), Haul->Pts.Num() * 2.f, V1, C1, O1));
					Check(TEXT("A crawler drives along the ridge road"), bRidge && O2 < 12.f, FString::Printf(TEXT("500 m round the top at %.0f m, %.1f m/s on average, climbed %.0f m, furthest %.1f m off the centre line"), Ridge->Z[Top], V2, C2, O2));
				}
				else Check(TEXT("A truck drives the mine haul road"), false, TEXT("road or machine missing"));
			}
			// the map itself
			{
				float Top = -1e9f; int32 Snowy = 0, Samples = 0;
				for (int32 y = 0; y < ARWTerrain::N; y += 16) for (int32 x = 0; x < ARWTerrain::N; x += 16) { const float H = T->Height[T->Idx(x, y)]; Top = FMath::Max(Top, H); ++Samples; Snowy += H > 430.f; }
				int32 Mountain = 0; float Longest = 0.f;
				for (const FRWRoad& R : Layout.Roads) if (R.MaxGrade > 0.f) { ++Mountain; Longest = FMath::Max(Longest, R.Pts.Num() * 2.f); }
				Check(TEXT("The map is 4500 x 4500 m with mountains, lakes, river, mine and mountain roads"), FMath::IsNearlyEqual(ARWTerrain::Half * 2.f, 4500.f) && ARWTerrain::N == 9001 && Top > 500.f && Layout.Lakes.Num() >= 4 && Layout.Find(ERWZone::Mine) != nullptr && Mountain >= 4,
					FString::Printf(TEXT("%.0f m across, %d x %d points; highest ground %.0f m, %.0f %% of the map above the snow line; %d lakes, %d streams, %d mountain roads (longest %.0f m), %d trees"), ARWTerrain::Half * 2.f, ARWTerrain::N, ARWTerrain::N, Top, 100.f * Snowy / FMath::Max(Samples, 1), Layout.Lakes.Num(), Layout.Streams.Num(), Mountain, Longest, World ? World->Trees.Num() : 0));
				FRWLayout Other = Layout;
				Other.Params.Seed = Layout.Params.Seed + 7;
				const FVector2D Pr(1400.f, 900.f);
				const float Same0 = Layout.Landscape(Pr.X, Pr.Y, false), Same1 = Layout.Landscape(Pr.X, Pr.Y, false), Differs = Other.Landscape(Pr.X, Pr.Y, false);
				Check(TEXT("A seed gives the same map every time, another seed another one"), Same0 == Same1 && FMath::Abs(Same0 - Differs) > 1.f, FString::Printf(TEXT("seed %d: %.2f m twice, seed %d: %.2f m at the same point"), Layout.Params.Seed, Same0, Other.Params.Seed, Differs));
			}
			// a rock the bucket curls round rides in it, and falls out when the bucket is tipped
			{
				CX->Bucket.Load.Clear(); CX->Tool = 0; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				const float KeepB = CX->BoomA, KeepA = CX->ArmA, KeepK = CX->BktA;
				float UpA = CX->BktA, UpZ = -2.f, DnA = CX->BktA, DnZ = 2.f;
				for (float Ang = CX->BktLo + 1.f; Ang < CX->BktHi; Ang += 4.f) { CX->BktA = Ang; CX->SimStep(Dt); const float Z = CX->MouthDir().Z; if (Z > UpZ) { UpZ = Z; UpA = Ang; } if (Z < DnZ) { DnZ = Z; DnA = Ang; } }
				CX->BktA = UpA; CX->SimStep(Dt);
				const FVector Tp = CX->TipWorld();
				ARWProp* Rk = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				Rk->Init(1, T, FVector(Tp.X, Tp.Y, T->HeightAt(Tp.X, Tp.Y)), 0.f);
				Rk->SetRockSize(0.45f);
				// put it where the bucket's floor is, as if the bucket had just scooped it
				const FTransform BT = CX->BucketP->GetComponentTransform();
				const FVector Piv = BT.GetLocation() * CM2M;
				const FVector Cav = (Tp + Piv) * 0.5f - CX->MouthDir() * CX->Bucket.Depth * 0.45f;
				Rk->SetActorLocation((Cav - FVector(0, 0, 0.45f * Rk->RockSize)) * M2CM);
				for (int32 k = 0; k < 3; ++k) CX->SimStep(Dt);
				const bool bIn = CX->InBucket.Get() == Rk;
				// swing the arm up a little: it comes along
				const float Z0 = Rk->PosM().Z;
				for (int32 k = 0; k < 40; ++k) { CX->InA1 = 0.6f; CX->SimStep(Dt); }
				CX->InA1 = 0.f;
				const float Lift = Rk->PosM().Z - Z0;
				// tip it out
				CX->BktA = DnA; CX->SimStep(Dt); CX->SimStep(Dt);
				const bool bOut = !CX->InBucket.IsValid() && !Rk->bCarried;
				for (int32 k = 0; k < 120; ++k) Rk->Tick(Dt);
				Check(TEXT("The bucket scoops up a rock and tips it out"), bIn && Lift > 0.2f && bOut,
					FString::Printf(TEXT("rock of %.0f kg: in the bucket %s, lifted %.2f m with the boom, out when tipped %s"), Rk->MassKg, bIn ? TEXT("yes") : TEXT("no"), Lift, bOut ? TEXT("yes") : TEXT("no")));
				Rk->Destroy();
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
				CX->BoomA = KeepB; CX->ArmA = KeepA; CX->BktA = KeepK; CX->SimStep(Dt);
			}
			// a tree and a rock placed by hand in the level (as in the Unreal Editor): the game takes them over; the tree is
			// pushed over and its trunk scooped up with the bucket, the rock is pushed along and scooped up
			{
				const FVector2D TAt(26.f, -104.f), RAt(31.f, -104.f);
				const float TZ = T->HeightAt(TAt.X, TAt.Y), RZ = T->HeightAt(RAt.X, RAt.Y);
				auto Placed = [&](UStaticMesh* M, const FVector& AtM, const FVector& Scale, const TCHAR* Tag)
				{
					AStaticMeshActor* A = GetWorld()->SpawnActor<AStaticMeshActor>(AtM * M2CM, FRotator::ZeroRotator);
					A->GetStaticMeshComponent()->SetMobility(EComponentMobility::Movable);
					A->GetStaticMeshComponent()->SetStaticMesh(M);
					A->SetActorScale3D(Scale);
					A->Tags.Add(Tag);
					return A;
				};
				// a 9 m tree (a cylinder 1 m tall, centred) and a rock 0.6 m across (a sphere 1 m across, centred)
				AStaticMeshActor* TreeA = Placed(ARWMachine::GCyl, FVector(TAt.X, TAt.Y, TZ + 4.5f), FVector(0.4f, 0.4f, 9.f), TEXT("RWTree"));
				AStaticMeshActor* RockA = Placed(ARWMachine::GSphere, FVector(RAt.X, RAt.Y, RZ + 0.3f), FVector(0.6f), TEXT("RWRock"));
				const int32 Trees0 = World->Trees.Num();
				const int32 Took = World->AdoptPlaced();
				const bool bCopiesHidden = !TreeA->GetStaticMeshComponent()->IsVisible() && !RockA->GetStaticMeshComponent()->IsVisible();
				const bool bTree = World->Trees.Num() == Trees0 + 1 && World->Trees.Last().bAlive;
				ARWProp* Rock = nullptr;
				for (const TWeakObjectPtr<ARWProp>& Wp : ARWProp::All) if (Wp.IsValid() && Wp->Type == 1 && FVector::Dist2D(Wp->PosM(), FVector(RAt.X, RAt.Y, 0.f)) < 0.1f) Rock = Wp.Get();
				const bool bOwnModel = Rock && Rock->Mesh->GetStaticMesh() == ARWMachine::GSphere;
				// a second look takes nothing more
				const int32 Again = World->AdoptPlaced();
				// pushed over by a tool at 1.5 m/s, half a metre up its trunk
				const int32 NProps = ARWProp::All.Num();
				World->HitTrees(FVector(TAt.X - 0.3f, TAt.Y, TZ + 0.5f), 1.f, FVector(1.5f, 0.f, 0.f));
				const bool bFelled = bTree && !World->Trees.Last().bAlive;
				ARWProp* Lg = (bFelled && ARWProp::All.Num() > NProps) ? ARWProp::All.Last().Get() : nullptr;
				float LogH = 0.f;
				if (Lg) { for (int32 k = 0; k < 240; ++k) Lg->Tick(Dt); LogH = Lg->LogLength(); }
				// the rock pushed along at 1 m/s for a second
				float RockMoved = 0.f;
				if (Rock)
				{
					const FVector R0 = Rock->PosM();
					for (int32 k = 0; k < 60; ++k) { World->HitTrees(Rock->PosM() + FVector(-0.5f, 0.f, 0.3f), 0.6f, FVector(1.f, 0.f, 0.f), 0.5f); Rock->Tick(Dt); }
					RockMoved = FVector::Dist2D(Rock->PosM(), R0);
				}
				// scooped: put where the bucket's floor is (as if just scooped), lifted with the boom, tipped out
				CX->Bucket.Load.Clear(); CX->Tool = 0; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				const float KeepB = CX->BoomA, KeepA = CX->ArmA, KeepK = CX->BktA;
				float UpA = CX->BktA, UpZ = -2.f, DnA = CX->BktA, DnZ = 2.f;
				for (float Ang = CX->BktLo + 1.f; Ang < CX->BktHi; Ang += 4.f) { CX->BktA = Ang; CX->SimStep(Dt); const float Z = CX->MouthDir().Z; if (Z > UpZ) { UpZ = Z; UpA = Ang; } if (Z < DnZ) { DnZ = Z; DnA = Ang; } }
				auto Scoop = [&](ARWProp* P, bool bLog, float& Lift) -> bool
				{
					Lift = 0.f;
					if (!P) return false;
					CX->BoomA = KeepB; CX->ArmA = KeepA; CX->BktA = UpA; CX->SimStep(Dt);
					const FVector Tp = CX->TipWorld();
					const FVector Piv = CX->BucketP->GetComponentTransform().GetLocation() * CM2M;
					const FVector Cav = (Tp + Piv) * 0.5f - CX->MouthDir() * CX->Bucket.Depth * 0.45f;
					if (bLog)
					{
						// the trunk across the bucket's mouth, its middle in the bucket
						const FVector Ax(FMath::Cos(FMath::DegreesToRadians(P->FallYaw)), FMath::Sin(FMath::DegreesToRadians(P->FallYaw)), 0.f);
						P->SetActorLocation((Cav - Ax * 0.5f * P->LogLength() - FVector(0, 0, 0.22f)) * M2CM);
					}
					else P->SetActorLocation((Cav - FVector(0, 0, 0.45f * P->RockSize)) * M2CM);
					for (int32 k = 0; k < 3; ++k) CX->SimStep(Dt);
					const bool bIn = CX->InBucket.Get() == P;
					const float Z0 = P->PosM().Z;
					for (int32 k = 0; k < 40; ++k) { CX->InA1 = 0.6f; CX->SimStep(Dt); }
					CX->InA1 = 0.f;
					Lift = P->PosM().Z - Z0;
					CX->BktA = DnA; CX->SimStep(Dt); CX->SimStep(Dt);
					const bool bOut = !CX->InBucket.IsValid() && !P->bCarried;
					for (int32 k = 0; k < 120; ++k) P->Tick(Dt);
					return bIn && Lift > 0.2f && bOut;
				};
				float RockLift = 0.f, LogLift = 0.f;
				const bool bRockScooped = Scoop(Rock, false, RockLift);
				const bool bLogScooped = Scoop(Lg, true, LogLift);
				CX->BoomA = KeepB; CX->ArmA = KeepA; CX->BktA = KeepK; CX->SimStep(Dt);
				Check(TEXT("Trees and rocks placed in the level are pushed over, pushed and scooped"),
					Took == 2 && Again == 0 && bCopiesHidden && bTree && bOwnModel && bFelled && Lg && RockMoved > 0.3f && bRockScooped && bLogScooped,
					FString::Printf(TEXT("taken over %d (again %d), the level's copies hidden %s; tree %s, pushed over %s (trunk %.1f m); rock of %.0f kg with its own model %s: pushed %.2f m, scooped and lifted %.2f m %s; trunk scooped and lifted %.2f m %s"),
						Took, Again, bCopiesHidden ? TEXT("yes") : TEXT("no"), bTree ? TEXT("in the forest") : TEXT("missing"), bFelled ? TEXT("yes") : TEXT("no"), LogH,
						Rock ? Rock->MassKg : 0.f, bOwnModel ? TEXT("yes") : TEXT("no"), RockMoved, RockLift, bRockScooped ? TEXT("yes") : TEXT("no"), LogLift, bLogScooped ? TEXT("yes") : TEXT("no")));
				if (Rock) Rock->Destroy();
				if (Lg) Lg->Destroy();
				TreeA->Destroy(); RockA->Destroy();
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
			}
			// a felled tree falling uphill on a slope rests on the ground along its whole length (nothing of it in the ground), and is
			// cleared away 15 s after it has come down: still there after 14 s, gone after 16 s
			{
				// a slope of 8 degrees or more near the site, and the way up it
				FVector2D At(40.f, -95.f), Up(1.f, 0.f);
				float Steep = 0.f;
				for (float Y = -300.f; Y <= 300.f && Steep < 0.14f; Y += 7.f)
					for (float X = -300.f; X <= 300.f; X += 7.f)
					{
						const FVector Nm = T->NormalAt(X, Y);
						const float Sl = FVector2D(Nm.X, Nm.Y).Size();
						if (Sl > Steep && Sl < 0.45f && T->HeightAt(X, Y) > T->WaterZ + 1.f) { Steep = Sl; At = FVector2D(X, Y); Up = -FVector2D(Nm.X, Nm.Y).GetSafeNormal(); }
						if (Steep >= 0.14f) break;
					}
				const float UpYaw = FMath::RadiansToDegrees(FMath::Atan2(Up.Y, Up.X));
				ARWProp* Lg = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				Lg->Init(0, T, FVector(At.X, At.Y, T->HeightAt(At.X, At.Y)), UpYaw);
				Lg->RemoveAfter = ARWProp::FelledTreeLife; // as HitTrees does
				Lg->FallAngle = 0.f; Lg->SetActorRotation(FRotator(0.f, UpYaw, 0.f));
				int32 Frames = 0;
				for (; Frames < 600 && Lg->FallAngle < 90.f; ++Frames) Lg->Tick(Dt); // it goes over first
				const float FallS = Frames * Dt;
				for (int32 k = 0; k < FMath::RoundToInt(1.f / Dt); ++k) Lg->Tick(Dt);
				// the trunk's underside all along it (the model's own +Z runs along the trunk, its radius from its bounds)
				float Sink = -1e9f;
				{
					const FTransform AX = Lg->GetActorTransform();
					const FBox Lb = Lg->Mesh->GetStaticMesh()->GetBoundingBox().TransformBy(Lg->Mesh->GetRelativeTransform());
					const float Rad = Lb.Max.X * CM2M, Len = (Lb.Max.Z - FMath::Max(Lb.Min.Z, 0.)) * CM2M;
					for (int32 k = 0; k <= 12; ++k)
					{
						const FVector Q = AX.TransformPosition(FVector(0.f, 0.f, FMath::Max(Lb.Min.Z, 0.) + Len * M2CM * k / 12.f)) * CM2M;
						if (T->InBounds(Q.X, Q.Y)) Sink = FMath::Max(Sink, T->HeightAt(Q.X, Q.Y) - (Q.Z - Rad));
					}
				}
				const float Tilt = Lg->LieTilt;
				for (int32 k = 0; k < FMath::RoundToInt(13.f / Dt); ++k) Lg->Tick(Dt);
				const bool bAt14 = IsValid(Lg) && !Lg->IsActorBeingDestroyed();
				for (int32 k = 0; k < FMath::RoundToInt(2.f / Dt) && IsValid(Lg) && !Lg->IsActorBeingDestroyed(); ++k) Lg->Tick(Dt);
				const bool bGone = !IsValid(Lg) || Lg->IsActorBeingDestroyed();
				Check(TEXT("A felled tree lies on the ground, not in it"), Steep > 0.1f && Sink < 0.03f && Tilt > 3.f,
					FString::Printf(TEXT("6 m trunk fallen uphill on a %.0f deg slope: lies tilted %.1f deg, deepest point of its underside %.2f m %s the ground"),
						FMath::RadiansToDegrees(FMath::Asin(FMath::Min(Steep, 1.f))), Tilt, FMath::Abs(Sink), Sink > 0.f ? TEXT("in") : TEXT("over")));
				Check(TEXT("A felled tree is cleared away 15 s after it comes down"), bAt14 && bGone,
					FString::Printf(TEXT("went over in %.1f s; 14 s later still there: %s; 16 s later gone: %s"), FallS, bAt14 ? TEXT("yes") : TEXT("no"), bGone ? TEXT("yes") : TEXT("no")));
				if (!bGone) Lg->Destroy();
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
			}
			// a felled trunk lying on the ground is shoved along by what pushes it, and turns when pushed off its middle
			{
				const FVector2D At(30.f, -95.f);
				ARWProp* Lg = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				Lg->Init(0, T, FVector(At.X, At.Y, T->HeightAt(At.X, At.Y)), 0.f);
				for (int32 k = 0; k < 5; ++k) Lg->Tick(Dt);
				const FVector P0 = Lg->PosM(); const float Y0 = Lg->FallYaw;
				// pushed sideways near its top end at 1.5 m/s for 2 s
				for (int32 k = 0; k < 120; ++k) World->HitTrees(Lg->PosM() + FVector(FMath::Cos(FMath::DegreesToRadians(Lg->FallYaw)), FMath::Sin(FMath::DegreesToRadians(Lg->FallYaw)), 0.f) * 4.5f + FVector(0, -0.6f, 0.4f), 1.f, FVector(0.f, 1.5f, 0.f));
				const float Moved = FVector::Dist2D(Lg->PosM(), P0), Turned = FMath::Abs(FRotator::NormalizeAxis(Lg->FallYaw - Y0));
				Check(TEXT("A felled trunk can be shoved along and turned"), Moved > 0.5f && Turned > 2.f, FString::Printf(TEXT("moved %.2f m, turned %.0f deg"), Moved, Turned));
				Lg->Destroy();
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
			}
			// a blade lifted over a felled trunk passes over it; at the trunk's height it pushes it; a flick sends it sliding
			{
				const FVector2D At(36.f, -100.f);
				ARWProp* Lg = GetWorld()->SpawnActor<ARWProp>(ARWProp::StaticClass(), FTransform::Identity);
				Lg->Init(0, T, FVector(At.X, At.Y, T->HeightAt(At.X, At.Y)), 0.f);
				for (int32 k = 0; k < 5; ++k) Lg->Tick(Dt);
				const FVector Mid = Lg->PosM() + FVector(2.f, 0.f, 0.f); // along the trunk (it lies along +X)
				const float Half = 0.65f; // a blade 1.3 m tall
				const FVector P0 = Lg->PosM();
				// lifted: the blade's lower edge 1.2 m over the trunk
				for (int32 k = 0; k < 60; ++k) World->HitTrees(Mid + FVector(0.f, -0.6f, 1.2f + Half), 1.f, FVector(0.f, 1.f, 0.f), Half);
				for (int32 k = 0; k < 30; ++k) Lg->Tick(Dt);
				const float Over = FVector::Dist2D(Lg->PosM(), P0);
				// lowered: the edge at the ground
				const FVector P1 = Lg->PosM();
				for (int32 k = 0; k < 60; ++k) World->HitTrees(Lg->PosM() + FVector(2.f, -0.6f, Half - 0.2f), 1.f, FVector(0.f, 1.f, 0.f), Half);
				const float Pushed = FVector::Dist2D(Lg->PosM(), P1);
				// a quick flick (2.5 m/s for a tenth of a second), then let go
				const FVector P2 = Lg->PosM();
				for (int32 k = 0; k < 6; ++k) { World->HitTrees(Lg->PosM() + FVector(2.f, -0.6f, 0.2f), 0.8f, FVector(0.f, 2.5f, 0.f), 0.4f); Lg->Tick(Dt); }
				const float During = FVector::Dist2D(Lg->PosM(), P2);
				for (int32 k = 0; k < 120; ++k) Lg->Tick(Dt);
				const float After = FVector::Dist2D(Lg->PosM(), P2) - During;
				const bool bStopped = FVector2D(Lg->VelM.X, Lg->VelM.Y).Size() < 0.01f;
				Check(TEXT("A raised blade passes over a felled trunk, a lowered one pushes it, a flick slides it"), Over < 0.02f && Pushed > 0.5f && After > 0.1f && bStopped,
					FString::Printf(TEXT("blade 1.2 m up: trunk moved %.2f m; blade down: %.2f m; flicked at 2.5 m/s: %.2f m while touched, slid %.2f m more and stopped: %s"), Over, Pushed, During, After, bStopped ? TEXT("yes") : TEXT("no")));
				Lg->Destroy();
				ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); });
			}
			// plants on ground that is dug go with it; those a little way off stay
			if (World->LowPlantCount() > 0)
			{
				int32 Pk = INDEX_NONE, Far = INDEX_NONE;
				for (int32 k = 0; k < World->LowPlantCount() && (Pk == INDEX_NONE || Far == INDEX_NONE); ++k)
				{
					if (World->IsLowPlantGone(k)) continue;
					const FVector2D Lp = World->LowPlantAt(k);
					if (!T->InBounds(Lp.X, Lp.Y) || Lp.Size() > 800.f) continue;
					if (Pk == INDEX_NONE) Pk = k;
					else if (FVector2D::Distance(Lp, World->LowPlantAt(Pk)) > 20.f) Far = k;
				}
				if (Pk != INDEX_NONE)
				{
					const FVector2D Lq = World->LowPlantAt(Pk);
					FPayload Out;
					T->RemoveAt(T->IndexAt(Lq.X, Lq.Y), 0.1f, Out);
					const bool bGone = World->IsLowPlantGone(Pk), bFarStays = Far == INDEX_NONE || !World->IsLowPlantGone(Far);
					Check(TEXT("Dug ground loses its plants, the rest stay"), bGone && bFarStays,
						FString::Printf(TEXT("plant at %.0f, %.0f: gone %s after 0.1 m was dug there; one 20 m away still there: %s; %d of %d low plants gone in all"),
							Lq.X, Lq.Y, bGone ? TEXT("yes") : TEXT("no"), bFarStays ? TEXT("yes") : TEXT("no"), World->LowPlantsGone(), World->LowPlantCount()));
					T->DepositAt(T->IndexAt(Lq.X, Lq.Y), Out.Dominant(), Out.Total(), Out.Moist);
				}
			}
			// a tree goes over as the real model, in the direction it was pushed, and ends up lying down
			{
				int32 TreeI = INDEX_NONE;
				// (a tree standing on its own: the push must reach only that one)
				for (int32 i = 0; i < World->Trees.Num() && TreeI == INDEX_NONE; ++i)
				{
					if (!World->Trees[i].bAlive || World->Trees[i].FabComp < 0) continue;
					bool bAlone = true;
					for (int32 j = 0; j < World->Trees.Num() && bAlone; ++j) if (j != i && World->Trees[j].bAlive && FVector2D::Distance(World->Trees[j].P, World->Trees[i].P) < 4.f) bAlone = false;
					if (bAlone) TreeI = i;
				}
				if (TreeI != INDEX_NONE)
				{
					const FRWTree& Tr0 = World->Trees[TreeI];
					UStaticMesh* TreeMesh = World->FabTreeH[Tr0.FabComp]->GetStaticMesh();
					const int32 PropsBefore = ARWProp::All.Num();
					const int32 Hit = World->HitTrees(FVector(Tr0.P.X, Tr0.P.Y, Tr0.Z + 1.f), 0.5f, FVector(1, 0, 0));
					ARWProp* Fell = ARWProp::All.Num() > PropsBefore ? ARWProp::All.Last().Get() : nullptr;
					const bool bModel = Fell && Fell->Mesh->GetStaticMesh() == TreeMesh;
					float Start = Fell ? Fell->FallAngle : -1.f;
					if (Fell) for (int32 k = 0; k < 400; ++k) Fell->Tick(Dt);
					const float End = Fell ? Fell->FallAngle : -1.f;
					Check(TEXT("Pushing a tree topples the real tree model"), Hit == 1 && !World->Trees[TreeI].bAlive && bModel && Start < 1.f && End >= 89.f,
						FString::Printf(TEXT("%d tree hit, falling model is the tree: %s, angle %.0f -> %.0f deg"), Hit, bModel ? TEXT("yes") : TEXT("no"), Start, End));
					if (Fell) { Fell->Destroy(); ARWProp::All.RemoveAll([](const TWeakObjectPtr<ARWProp>& W) { return !W.IsValid() || W->IsActorBeingDestroyed(); }); }
					World->SetTreeAlive(TreeI, true);
				}
			}
			// quick switching: goes through the player's own machines only, both ways
			{
				TArray<ARWMachine*> Mine;
				for (ARWMachine* M : Machines) if (M && M->CanOperate()) Mine.Add(M);
				bool bOnlyOwn = true, bRound = Mine.Num() >= 2;
				ARWMachine* Cur = Mine.Num() ? Mine[0] : nullptr;
				for (int32 k = 0; k < Mine.Num(); ++k) { Cur = ARWPlayerController::NextOperable(Machines, Cur, 1); bOnlyOwn &= Cur && Cur->CanOperate(); }
				bRound &= Cur == (Mine.Num() ? Mine[0] : nullptr);
				ARWMachine* Back = Mine.Num() ? ARWPlayerController::NextOperable(Machines, Mine[0], -1) : nullptr;
				Check(TEXT("Switching machines goes through your own machines"), bOnlyOwn && bRound && Back == Mine.Last(),
					FString::Printf(TEXT("%d machines of yours out of %d; a full round comes back to the first: %s"), Mine.Num(), Machines.Num(), bRound ? TEXT("yes") : TEXT("no")));
			}
			// the load must read as broken-up soil, not a smooth sheet: rough surface and many loose pieces; sand flows smoother
			auto SoilDetail = [&](ESoil M, float& Rough, int32& Pieces, int32& Verts, float Ang = -70.f)
			{
				CX->Tool = 0; CX->BktA = Ang; CX->InA1 = CX->InA2 = CX->InA3 = CX->InA4 = 0.f;
				CX->SimStep(Dt);
				CX->Bucket.Load.Clear(); CX->Bucket.Load.Add(M, 0.9f * CX->Bucket.Capacity, 0.2f);
				CX->FillKey = -1; CX->VisualTick(Dt);
				Rough = 0.f; Pieces = 0; Verts = 0;
				const FProcMeshSection* Sc = CX->FillMesh && CX->FillMesh->IsVisible() ? CX->FillMesh->GetProcMeshSection(0) : nullptr;
				if (!Sc) return;
				const TArray<FProcMeshVertex>& Vb = Sc->ProcVertexBuffer;
				const int32 Gt = ARWExcavator::FillNT + 1, Gw = ARWExcavator::FillNW + 1;
				int32 Cnt = 0;
				for (int32 w = 1; w < Gw - 1; ++w)
					for (int32 t = 1; t < Gt - 1; ++t)
					{
						const int32 I = w * Gt + t;
						Rough += (Vb[I - 1].Position - 2.0 * Vb[I].Position + Vb[I + 1].Position).Size(); // bend between neighbours, cm
						++Cnt;
					}
				Rough /= FMath::Max(Cnt, 1);
				Verts = Vb.Num();
				Pieces = (Vb.Num() - CX->FillBaseVerts);
			};
			float RoughDry, RoughSand; int32 PiecesDry, PiecesSand, VertsDry, VertsSand;
			SoilDetail(ESoil::DrySoil, RoughDry, PiecesDry, VertsDry);
			SoilDetail(ESoil::Sand, RoughSand, PiecesSand, VertsSand);
			// it is rebuilt as the bucket moves, so it must stay cheap
			float RoughAgain; int32 PiecesAgain, VertsAgain;
			SoilDetail(ESoil::DrySoil, RoughAgain, PiecesAgain, VertsAgain);
			const double RebuildT0 = FPlatformTime::Seconds();
			for (int32 k = 0; k < 10; ++k) { CX->FillKey = -1; CX->UpdateBucketFill(); }
			const double RebuildMs = (FPlatformTime::Seconds() - RebuildT0) * 100.0;
			// tilted while curling, so the soil would stand above the lip: still one rough pile, with no flat face across the mouth
			{
				float WorstRough = 1e9f; int32 Tilted = 0; FString TiltLog;
				for (float Ang = CX->BktLo + 1.f; Ang < CX->BktHi; Ang += 8.f)
				{
					CX->BktA = Ang; CX->SimStep(Dt);
					const float Mz = CX->MouthDir().Z;
					if (Mz < 0.2f || Mz > 0.75f) continue;
					float RoughT; int32 PiecesT, VertsT;
					SoilDetail(ESoil::DrySoil, RoughT, PiecesT, VertsT, Ang);
					WorstRough = FMath::Min(WorstRough, RoughT); ++Tilted;
					TiltLog += FString::Printf(TEXT(" mouth up %.2f: %.2f cm;"), Mz, RoughT);
				}
				Check(TEXT("Tilted bucket soil has no flat slab across the mouth"), Tilted > 0 && WorstRough > 0.3f,
					FString::Printf(TEXT("%d tilted poses, surface bend per step:%s"), Tilted, *TiltLog));
			}
			CX->Bucket.Load.Clear(); CX->VisualTick(Dt);
			Check(TEXT("Bucket soil looks broken up, not a smooth sheet"), RoughDry > 0.5f && PiecesDry > 2000 && VertsDry < 26000 && RoughSand < RoughDry && RebuildMs < 8.0,
				FString::Printf(TEXT("dry soil: surface bends %.2f cm per step, %d points in loose grains and lumps, %d in all; sand bends %.2f cm; rebuild %.1f ms"), RoughDry, PiecesDry, VertsDry, RoughSand, RebuildMs));
		}
	}
	// 19. map editor places and removes objects
	{
		const int32 Obs0 = World->Obstacles.Num(), P0 = FRWEditor::Placed.Num();
		const int32 Idx = FRWEditor::Place(World, TEXT("House"), FVector(-30.f, -150.f, 0.f), 45.f, 1.f, false);
		const bool bPlaced = Idx != INDEX_NONE && FRWEditor::Placed.Num() == P0 + 1 && World->Obstacles.Num() == Obs0 + 1;
		const bool bRemoved = FRWEditor::RemoveNear(World, FVector(-30.f, -150.f, 0.f), 3.f) && FRWEditor::Placed.Num() == P0;
		const int32 G0 = Terrain->Grass[Terrain->IndexAt(-60.f, -140.f)];
		FRWEditor::PaintGrass(World, FVector2D(-60.f, -140.f), 2.f, true, false);
		Check(TEXT("Map editor place / remove / paint"), bPlaced && bRemoved && Terrain->Grass[Terrain->IndexAt(-60.f, -140.f)] > G0,
			FString::Printf(TEXT("%d catalogue objects; house placed=%s removed=%s; grass %d -> %d"), FRWEditor::Catalog.Num(), bPlaced ? TEXT("yes") : TEXT("no"), bRemoved ? TEXT("yes") : TEXT("no"), G0, (int32)Terrain->Grass[Terrain->IndexAt(-60.f, -140.f)]));
	}
	// Physics tests: an excavator's centre of mass, the load on its tracks and tipping - bucket empty, half, full; stick in and
	// stretched out; a load too heavy at full reach; prying upwards with the hydraulics' full force; swung to the side; on a slope
	{
		ARWExcavator* X = nullptr;
		for (ARWMachine* M : Machines) if (ARWExcavator* Ex = Cast<ARWExcavator>(M)) if (Ex->bModelRig && !X) X = Ex;
		if (X)
		{
			const FVector KeepP = X->PosM; const float KeepYaw = X->Yaw, KB = X->BoomA, KA = X->ArmA, KK = X->BktA, KS = X->Swing; const int32 KT = X->Tool; const FPayload KL = X->Bucket.Load;
			X->Tool = 0; X->Bucket.Load.Clear(); X->TestToolForceN = FVector::ZeroVector; X->TipAngle = X->TipRate = 0.f;
			X->bEngineOn = true; X->Rpm = X->MaxRpm;
			const float InB = FMath::Clamp(35.f, X->BoomLo, X->BoomHi), InA = FMath::Clamp(-125.f, X->ArmLo, X->ArmHi);
			const float OutB = FMath::Clamp(12.f, X->BoomLo, X->BoomHi), OutA = X->ArmHi;
			auto Hold = [&](float Bo, float Ar, float Sw, int32 Frames) { for (int32 k = 0; k < Frames; ++k) { X->BoomA = Bo; X->ArmA = Ar; X->BktA = KK; X->Swing = Sw; X->InA1 = X->InA2 = X->InA3 = X->InA4 = 0.f; X->InThrottle = 0.f; if (!X->TestToolForceN.IsNearlyZero()) X->TestToolAt = X->TipWorld(); X->SimStep(Dt); } };
			auto Share = [&](int32 A, int32 B) { const float Tot = X->CornerLoad[0] + X->CornerLoad[1] + X->CornerLoad[2] + X->CornerLoad[3]; return (X->CornerLoad[A] + X->CornerLoad[B]) / FMath::Max(Tot, 1.f); };
			// (a load put in the bucket and measured at once: kept in the bucket, nothing spills first)
			auto WithLoad = [&](float Frac) { X->Bucket.Load.Clear(); if (Frac > 0.f) X->Bucket.Load.Add(ESoil::DrySoil, Frac * X->Bucket.Capacity, 0.2f); X->StabilityStep(Dt); };
			FString Rep; bool bOK = true;
			// 1-3. stick in: empty, half, full; then stretched out full
			Hold(InB, InA, 0.f, 60);
			float MaxTip = X->TipAngle;
			WithLoad(0.f); const float M0 = X->StabilityMargin, F0 = Share(0, 1), C0 = X->ComLocal.X;
			WithLoad(0.5f); const float F1 = Share(0, 1), C1 = X->ComLocal.X;
			WithLoad(1.f); const float F2 = Share(0, 1), C2 = X->ComLocal.X, M2 = X->StabilityMargin;
			X->Bucket.Load.Clear();
			Hold(OutB, OutA, 0.f, 60);
			MaxTip = FMath::Max(MaxTip, X->TipAngle);
			WithLoad(1.f); const float F3 = Share(0, 1), M3 = X->StabilityMargin, Reach = FVector2D::Distance(FVector2D(X->TipWorld()), FVector2D(X->PosM));
			X->Bucket.Load.Clear();
			Rep += FString::Printf(TEXT("%s, %.0f kg: front of the tracks carries %.0f%% empty, %.0f%% half, %.0f%% full (centre of mass %.2f -> %.2f -> %.2f m), %.0f%% full at %.1f m reach; nearest edge %.2f / %.2f / %.2f m inside; tipped %.1f deg | "),
				*X->Model, X->TotalMassKg, F0 * 100.f, F1 * 100.f, F2 * 100.f, C0, C1, C2, F3 * 100.f, Reach, M0, M2, M3, MaxTip);
			if (!(F1 > F0 && F2 > F1 && F3 > F2 && M3 < M2 && M0 > 0.f && MaxTip < 0.01f)) bOK = false;
			// 4. too heavy at full reach: 12 t hanging at the teeth (a test load, not a rated one) tips it over its front edge; let
			// go, it comes back down
			X->TestToolForceN = FVector(0.f, 0.f, -12000.f * GRAV);
			Hold(OutB, OutA, 0.f, 120);
			const float TipHeavy = X->TipAngle, MHeavy = X->StabilityMargin; const FVector2D DirHeavy = X->TipDir;
			X->TestToolForceN = FVector::ZeroVector;
			Hold(OutB, OutA, 0.f, 240);
			const float TipAfter = X->TipAngle;
			Rep += FString::Printf(TEXT("12 t at the teeth: the weight meets the ground %.2f m %s the front edge, tips %.1f deg about the %s edge; let go: %.1f deg | "), FMath::Abs(MHeavy), MHeavy < 0.f ? TEXT("past") : TEXT("inside"), TipHeavy, DirHeavy.X > 0.7f ? TEXT("front") : TEXT("other"), TipAfter);
			// (it goes over until the bucket comes down on the ground, which then holds it - not to the overturning limit)
			if (!(TipHeavy > 1.f && TipHeavy < 29.f && DirHeavy.X > 0.7f && TipAfter < 0.01f)) bOK = false;
			// 5. prying upwards at full reach with the hydraulics' whole force: the front lifts only if that really carries the
			// resultant past the back edge
			// (the ground pushes back only while the teeth are pressed on it: once the front has lifted them off, it stops)
			const float PryZ = X->TipWorld().Z;
			float TipPry = 0.f, MPry = 1e9f; FVector2D DirPry = X->TipDir;
			for (int32 k = 0; k < 120; ++k)
			{
				X->TestToolForceN = X->TipWorld().Z <= PryZ + 0.02f ? FVector(0.f, 0.f, X->Bucket.ForceLimitN) : FVector(0.f, 0.f, 1.f);
				Hold(OutB, OutA, 0.f, 1);
				if (X->TipAngle > TipPry) { TipPry = X->TipAngle; DirPry = X->TipDir; }
				MPry = FMath::Min(MPry, X->StabilityMargin);
			}
			X->TestToolForceN = FVector::ZeroVector;
			Hold(OutB, OutA, 0.f, 240);
			const bool bPryConsistent = (TipPry > 0.5f) ? DirPry.X < -0.7f : true;
			Rep += FString::Printf(TEXT("prying up with %.0f kN at the teeth: margin %.2f m, tipped %.1f deg%s, after %.1f deg | "), X->Bucket.ForceLimitN / 1000.f, MPry, TipPry, TipPry > 0.5f ? (DirPry.X < -0.7f ? TEXT(" about the back edge (front up)") : TEXT(" about another edge")) : TEXT(""), X->TipAngle);
			if (!bPryConsistent || X->TipAngle > 0.01f) bOK = false;
			// 6. swung 90 degrees, full bucket, stretched out: the weight goes to one side
			Hold(OutB, OutA, 90.f, 90);
			WithLoad(1.f);
			const float Left = Share(0, 2), MSide = X->StabilityMargin;
			X->Bucket.Load.Clear();
			Rep += FString::Printf(TEXT("swung 90 deg full: the left track carries %.0f%%, nearest edge %.2f m | "), Left * 100.f, MSide);
			if (FMath::Abs(Left - 0.5f) < 0.1f) bOK = false;
			Hold(InB, InA, 0.f, 90);
			// 7. on a slope, facing up it: the lower (rear) end of the tracks carries more
			{
				FVector2D At(0.f, 0.f), Up(1.f, 0.f); float Steep = 0.f;
				for (float Yy = -300.f; Yy <= 300.f && Steep < 0.14f; Yy += 9.f)
					for (float Xx = -300.f; Xx <= 300.f; Xx += 9.f)
					{
						const FVector Nm = T->NormalAt(Xx, Yy);
						const float Sl = FVector2D(Nm.X, Nm.Y).Size();
						if (Sl > Steep && Sl < 0.3f && T->HeightAt(Xx, Yy) > T->WaterZ + 1.f) { Steep = Sl; At = FVector2D(Xx, Yy); Up = -FVector2D(Nm.X, Nm.Y).GetSafeNormal(); }
						if (Steep >= 0.14f) break;
					}
				X->PosM = FVector(At.X, At.Y, T->HeightAt(At.X, At.Y)); X->Yaw = FMath::RadiansToDegrees(FMath::Atan2(Up.Y, Up.X)); X->Speed = 0.f;
				Hold(InB, InA, 0.f, 90);
				const float Front = Share(0, 1);
				Rep += FString::Printf(TEXT("on a %.0f deg slope facing up: the front carries %.0f%%, nearest edge %.2f m, tipped %.1f deg"), FMath::RadiansToDegrees(FMath::Asin(FMath::Min(Steep, 1.f))), Front * 100.f, X->StabilityMargin, X->TipAngle);
				if (!(Front < F0 && X->TipAngle < 0.01f)) bOK = false;
			}
			X->PosM = KeepP; X->Yaw = KeepYaw; X->BoomA = KB; X->ArmA = KA; X->BktA = KK; X->Swing = KS; X->Tool = KT; X->Bucket.Load = KL;
			X->TipAngle = X->TipRate = 0.f; X->SimStep(Dt);
			Check(TEXT("An excavator's weight, load and tipping follow the forces (physics tests)"), bOK, Rep);
		}
	}
	// vehicle.xml <mass> read into a model excavator's stability: every part given; a part left out (estimated instead, and
	// said so); a total the parts do not add up to (reported); a file with a bad mass (rejected: back to the estimates); no
	// <mass> at all. (The kg below are test inputs only - not any machine's specification.)
	{
		FString RepAll; bool bAllOK = true; int32 NX = 0;
		for (ARWMachine* M : Machines)
		{
			ARWExcavator* X = Cast<ARWExcavator>(M);
			if (!X || !X->bModelRig) continue;
		{
			const TMap<FString, float> Keep = X->XmlMassKg;
			const FString File = FPaths::ProjectSavedDir() / TEXT("RWTestMass.xml");
				FString Rep; bool bOK = true; const bool KeepChecked = X->bVehicleXmlChecked, KeepValid = X->bXmlControlValid;
			auto Run = [&](const TCHAR* Label, const FString& MassXml, bool& bLoadedOut) -> TArray<ARWMachine::FMassPart>
			{
				FFileHelper::SaveStringToFile(FString::Printf(TEXT("<vehicle>%s</vehicle>"), *MassXml), *File);
				FRWVehicleXml Xml;
				bLoadedOut = Xml.Load(File, X);
				TArray<ARWMachine::FMassPart> Parts; X->MassParts(Parts);
				FString S; float Sum = 0.f;
				for (const ARWMachine::FMassPart& P : Parts) { if (P.Name != TEXT("load")) Sum += P.Kg; S += FString::Printf(TEXT(" %s %.0f (%s);"), *P.Name, P.Kg, *P.Source); }
				Rep += FString::Printf(TEXT("%s: file %s, %.0f kg -%s | "), Label, bLoadedOut ? TEXT("bound") : TEXT("rejected"), Sum, *S);
				return Parts;
			};
			auto Find = [](const TArray<ARWMachine::FMassPart>& Ps, const TCHAR* N) -> const ARWMachine::FMassPart* { for (const ARWMachine::FMassPart& P : Ps) if (P.Name == N) return &P; return nullptr; };
			auto Sum = [](const TArray<ARWMachine::FMassPart>& Ps) { float S = 0.f; for (const ARWMachine::FMassPart& P : Ps) if (P.Name != TEXT("load")) S += P.Kg; return S; };
			const FPayload KL = X->Bucket.Load; X->Bucket.Load.Clear();
			bool bL = false;
			// 1. every part and a total that agrees
			{
				const TArray<ARWMachine::FMassPart> Ps = Run(TEXT("all parts"), TEXT("<mass total=\"22000\"><part name=\"boom\" kg=\"1800\"/><part name=\"stick\" kg=\"800\"/><part name=\"bucket\" kg=\"950\"/><part name=\"undercarriage\" kg=\"7000\"/><part name=\"house\" kg=\"11450\"/></mass>"), bL);
				bool bAllXml = Ps.Num() >= 5; for (const ARWMachine::FMassPart& P : Ps) if (P.Source != TEXT("vehicle.xml")) bAllXml = false;
				const ARWMachine::FMassPart* Bo = Find(Ps, TEXT("boom"));
				if (!bL || !bAllXml || !Bo || !FMath::IsNearlyEqual(Bo->Kg, 1800.f) || !FMath::IsNearlyEqual(Sum(Ps), 22000.f, 1.f)) bOK = false;
			}
			// 2. the stick left out: estimated (7.5 / 3.5 / 33 % shares are the game's estimate), said so, and the total kept
			{
				const TArray<ARWMachine::FMassPart> Ps = Run(TEXT("stick missing"), TEXT("<mass total=\"22000\"><part name=\"boom\" kg=\"1800\"/><part name=\"bucket\" kg=\"950\"/><part name=\"undercarriage\" kg=\"7000\"/></mass>"), bL);
				const ARWMachine::FMassPart* St = Find(Ps, TEXT("stick"));
				const ARWMachine::FMassPart* Ho = Find(Ps, TEXT("house"));
				if (!bL || !St || !St->Source.StartsWith(TEXT("estimate")) || !FMath::IsNearlyEqual(St->Kg, 0.035f * 22000.f, 1.f) || !Ho || Ho->Source == TEXT("vehicle.xml") || !FMath::IsNearlyEqual(Sum(Ps), 22000.f, 1.f)) bOK = false;
			}
			// 3. parts that add up to 1500 kg more than the total: kept as given, and the mismatch reported
			{
				const TArray<ARWMachine::FMassPart> Ps = Run(TEXT("total does not match"), TEXT("<mass total=\"22000\"><part name=\"boom\" kg=\"1800\"/><part name=\"stick\" kg=\"800\"/><part name=\"bucket\" kg=\"950\"/><part name=\"undercarriage\" kg=\"7000\"/><part name=\"house\" kg=\"12950\"/></mass>"), bL);
				bool bFlag = false; for (const ARWMachine::FMassPart& P : Ps) if (P.Source.Contains(TEXT("MISMATCH"))) bFlag = true;
				if (!bL || !bFlag || !FMath::IsNearlyEqual(Sum(Ps), 23500.f, 1.f)) bOK = false;
			}
			// 4. a bad mass (negative, not a number): the file is rejected and nothing of it is used - all estimates again
			{
				const TArray<ARWMachine::FMassPart> Ps = Run(TEXT("bad values"), TEXT("<mass total=\"heavy\"><part name=\"boom\" kg=\"-5\"/><part name=\"stick\" kg=\"abc\"/></mass>"), bL);
				bool bNoXml = true; for (const ARWMachine::FMassPart& P : Ps) if (P.Source.StartsWith(TEXT("vehicle.xml"))) bNoXml = false;
				if (bL || !bNoXml || X->XmlMassKg.Num() != 0 || !FMath::IsNearlyEqual(Sum(Ps), X->EmptyMass, 1.f)) bOK = false;
			}
			// 5. no <mass>: the machine's own mass (mod.json / built-in list) and the estimates
			{
				X->XmlMassKg.Reset();
				TArray<ARWMachine::FMassPart> Ps; X->MassParts(Ps);
				bool bNoXml = true; FString S;
				for (const ARWMachine::FMassPart& P : Ps) { if (P.Source.StartsWith(TEXT("vehicle.xml"))) bNoXml = false; S += FString::Printf(TEXT(" %s %.0f (%s);"), *P.Name, P.Kg, *P.Source); }
				Rep += FString::Printf(TEXT("no <mass> (%s): %.0f kg -%s"), *X->ModId, Sum(Ps), *S);
				if (!bNoXml || !FMath::IsNearlyEqual(Sum(Ps), X->EmptyMass, 1.f)) bOK = false;
			}
			// 6. masses only, for a machine whose controls stay its own: the file also has a control section, which is not
			// bound - only <mass> is read
			{
				FFileHelper::SaveStringToFile(TEXT("<vehicle><nativeControls><control function=\"lift\" input=\"axis1\" min=\"-1\" max=\"1\" speed=\"1\"/></nativeControls><mass total=\"21000\"><part name=\"boom\" kg=\"1700\"/></mass></vehicle>"), *File);
				const bool bValidBefore = X->bXmlControlValid;
				const bool bMo = FRWVehicleXml::LoadMassOnly(File, X);
				TArray<ARWMachine::FMassPart> Ps; X->MassParts(Ps);
				const ARWMachine::FMassPart* Bo = Find(Ps, TEXT("boom"));
				const ARWMachine::FMassPart* St = Find(Ps, TEXT("stick"));
				Rep += FString::Printf(TEXT("masses only: %s, %.0f kg, boom %.0f (%s), stick %.0f (%s), XML control %s | "), bMo ? TEXT("bound") : TEXT("rejected"), Sum(Ps),
					Bo ? Bo->Kg : 0.f, Bo ? *Bo->Source : TEXT("-"), St ? St->Kg : 0.f, St ? *St->Source : TEXT("-"), X->bXmlControlValid ? TEXT("on") : TEXT("off"));
				if (!bMo || !Bo || Bo->Source != TEXT("vehicle.xml") || !FMath::IsNearlyEqual(Bo->Kg, 1700.f) || !St || !St->Source.StartsWith(TEXT("estimate"))
					|| !FMath::IsNearlyEqual(Sum(Ps), 21000.f, 1.f) || X->bXmlControlValid != bValidBefore) bOK = false;
				// 7. loaded again from a file without the boom: no boom left over from before
				FFileHelper::SaveStringToFile(TEXT("<vehicle><mass total=\"21000\"><part name=\"stick\" kg=\"900\"/></mass></vehicle>"), *File);
				FRWVehicleXml::LoadMassOnly(File, X);
				const bool bStale = X->XmlMassKg.Contains(TEXT("boom"));
				Rep += FString::Printf(TEXT("loaded again without the boom: boom %s | "), bStale ? TEXT("LEFT OVER") : TEXT("gone (estimated)"));
				if (bStale) bOK = false;
			}
			IFileManager::Get().Delete(*File);
			X->XmlMassKg = Keep; X->Bucket.Load = KL;
			X->bVehicleXmlChecked = KeepChecked; X->bXmlControlValid = KeepValid;
			RepAll += FString::Printf(TEXT("[%s] %s "), *X->Model, *Rep); if (!bOK) bAllOK = false; ++NX;
			}
		}
		Check(TEXT("vehicle.xml <mass> sets a model excavator's masses, with estimates only where it says nothing"), bAllOK && NX >= 1, FString::Printf(TEXT("%d model excavators: %s"), NX, *RepAll));
	}
	// Terrain tests: soil does not stand up in spikes - dumped again and again in one place, graded over with the back of a
	// bucket, pushed by a dozer - with the settling the game itself runs each frame, at 30, 60 and 120 frames a second, and
	// it keeps its volume
	{
		// (each frame: the work, then the settling the game runs; the worst moment over the work is kept - a spike seen while
		// working matters as much as one left at the end)
		FVector2D BoxC(0.f, 0.f); float BoxX = 4.f, BoxY = 4.f, WorstDuring = 0.f;
		auto RunFrames = [&](float FDt, float Secs, TFunctionRef<void(float)> Step)
		{
			const int32 NF = FMath::RoundToInt(Secs / FDt);
			for (int32 k = 0; k < NF; ++k)
			{
				Step(k * FDt); T->RelaxFor(FDt);
				int32 Pk = 0, St = 0; float Wp = 0.f, Ov = 0.f;
				T->SpikeCount(BoxC, BoxX, BoxY, Pk, St, Wp, &Ov);
				WorstDuring = FMath::Max(WorstDuring, Ov);
			}
		};
		FString Rep;
		bool bOK = true;
		// what is left once it has settled: how far the steepest loose point stands over its angle of repose, the volume
		auto After = [&](float& Over, double& Vol) { int32 Pk = 0, St = 0; float Wp = 0.f; T->SpikeCount(BoxC, BoxX, BoxY, Pk, St, Wp, &Over, &Vol); };
		// 1. a bucket emptied 12 times in the same place, 0.1 m3 every half second, then 3 s to settle
		float Rise[3] = {0.f, 0.f, 0.f};
		int32 Fi = 0;
		for (const float Fps : {30.f, 60.f, 120.f})
		{
			const FVector2D At(-120.f + Fi * 14.f, -170.f);
			BoxC = At; BoxX = BoxY = 4.f; WorstDuring = 0.f;
			const float FDt = 1.f / Fps, H0 = T->HeightAt(At.X, At.Y);
			float Ov0; double V0; After(Ov0, V0);
			float Next = 0.f; int32 Dumps = 0;
			RunFrames(FDt, 9.f, [&](float Tm) { if (Dumps < 12 && Tm >= Next) { FPayload P; P.Add(ESoil::DrySoil, 0.1f, 0.25f); T->DepositDisc(At.X, At.Y, 0.55f, P); ++Dumps; Next += 0.5f; } });
			float Ov1; double V1; After(Ov1, V1);
			Rise[Fi] = T->HeightAt(At.X, At.Y) - H0;
			Rep += FString::Printf(TEXT("12 dumps in one place at %.0f fps: heap %.2f m, steepest point over its angle of repose by %.0f cm while dumping, %.0f cm after, %.2f of 1.20 m3 | "), Fps, Rise[Fi], WorstDuring * 100.f, Ov1 * 100.f, V1 - V0);
			if (Ov1 > 0.05f || WorstDuring > 0.15f || FMath::Abs(V1 - V0 - 1.2) > 0.12) bOK = false;
			++Fi;
		}
		const float RiseSpread = FMath::Max3(Rise[0], Rise[1], Rise[2]) - FMath::Min3(Rise[0], Rise[1], Rise[2]);
		Rep += FString::Printf(TEXT("heap height differs by %.0f cm between frame rates | "), RiseSpread * 100.f);
		if (RiseSpread > 0.1f) bOK = false;
		// 2. a heap of 0.8 m3 graded over twice with the back of a bucket, 60 fps
		{
			const FVector2D At(-78.f, -170.f);
			BoxC = At; BoxX = 5.f; BoxY = 3.f;
			const float FDt = 1.f / 60.f;
			float OvA; double V0; After(OvA, V0);
			FPayload P; P.Add(ESoil::DrySoil, 0.8f, 0.25f);
			T->DepositDisc(At.X, At.Y, 1.f, P);
			RunFrames(FDt, 2.f, [](float) {});
			WorstDuring = 0.f;
			const float Zb = 0.5f * (T->HeightAt(At.X - 3.f, At.Y) + T->HeightAt(At.X + 3.f, At.Y)); // the ground beside the heap
			FBucketTool Bk; Bk.Width = 1.2f; Bk.Depth = 0.6f;
			for (int32 Pass = 0; Pass < 2; ++Pass)
				RunFrames(FDt, 9.f, [&](float Tm)
				{
					const float X = At.X + 2.7f - Tm * 0.6f;
					Bk.Grade(T, FVector(X, At.Y, Zb + 0.59f), FVector(X - 1.f, At.Y, Zb + 0.59f), FVector(0.f, 1.f, 0.f), FVector(-0.6f, 0.f, 0.f), FVector(0.f, 0.f, 1.f), FDt);
				});
			RunFrames(FDt, 2.f, [](float) {});
			float Ov1; double V1; After(Ov1, V1);
			// (what the bucket still carries counts with the ground: loose, it is a little more than it was as ground)
			Rep += FString::Printf(TEXT("0.8 m3 heap graded over twice with the back of a bucket: over its angle of repose by %.0f cm while grading, %.0f cm after; volume %.2f m3 + %.2f carried | "), WorstDuring * 100.f, Ov1 * 100.f, V1 - V0, Bk.GradeCarry.Total());
			if (Ov1 > 0.05f || WorstDuring > 0.15f || FMath::Abs(V1 - V0 + Bk.GradeCarry.Total() - 0.8) > 0.12) bOK = false;
		}
		// 3. a dozer pushing with its blade in the ground for 4 s, 60 fps
		if (Dz)
		{
			const float FDt = 1.f / 60.f;
			Dz->bEngineOn = true; Dz->ThrottleDial = 1.f; Dz->Rpm = Dz->MaxRpm;
			const FVector P0 = Dz->PosM;
			// (the box: where it will go in 4 s at its top speed, all round)
			BoxC = FVector2D(P0.X, P0.Y); BoxX = BoxY = 14.f; WorstDuring = 0.f;
			// (where the steepest loose point in the box is, and what it is made of: to see why it stands)
			auto DozerSpikeLog = [&](const TCHAR* When)
			{
				int32 Pk = 0, St = 0, Wi = INDEX_NONE; float Wp = 0.f, Ov = 0.f;
				T->SpikeCount(BoxC, BoxX, BoxY, Pk, St, Wp, &Ov, nullptr, &Wi);
				if (Wi == INDEX_NONE) return;
				const FLayers& Ly = T->Layers[Wi];
				FString Lay; for (int32 k = 0; k < Ly.Count; ++k) Lay += FString::Printf(TEXT(" [%s %.2f m comp %d]"), *SoilName((ESoil)Ly.Mat[k], 0.3f), Ly.T[k], Ly.Comp[k]);
				FString Nb, NbN; const int32 Gx = Wi % ARWTerrain::N, Gy = Wi / ARWTerrain::N;
				for (int32 dy = -1; dy <= 1; ++dy) for (int32 dx = -1; dx <= 1; ++dx)
				{
					const int32 J = T->Idx(Gx + dx, Gy + dy);
					Nb += FString::Printf(TEXT(" %.2f"), T->Height[J] - T->Height[Wi]);
					NbN += FString::Printf(TEXT(" %.2f/%d"), T->Height[J] - T->Natural[J], T->Layers[J].Count);
				}
				const float* Fl = T->DigFloor.Find(Wi);
				RWLog(FString::Printf(TEXT("TESTDBG dozer %s: over by %.2f m at %.1f, %.1f (dozer %.1f, %.1f, yaw %.0f): height %.2f, natural %.2f, dig floor %s; neighbours relative:%s; neighbours above natural / layers:%s; layers:%s; repose %.0f deg"),
					When, Ov, T->PX(Gx), T->PX(Gy), Dz->PosM.X, Dz->PosM.Y, Dz->Yaw, T->Height[Wi], T->Natural[Wi], Fl ? *FString::Printf(TEXT("%.2f"), *Fl) : TEXT("none"), *Nb, *NbN, *Lay, T->SurfaceState(Wi).Repose));
			};
			DozerSpikeLog(TEXT("before the push"));
			RunFrames(FDt, 4.f, [&](float) { Dz->InThrottle = 1.f; Dz->InA1 = 0.f; Dz->BladeH = -0.06f; Dz->SimStep(FDt); });
			Dz->InThrottle = 0.f; Dz->BladeH = 0.6f;
			const float DuringPush = WorstDuring;
			RunFrames(FDt, 2.f, [&](float) { Dz->SimStep(FDt); });
			float Ov1; double V1; After(Ov1, V1);
			DozerSpikeLog(TEXT("after the push"));
			Rep += FString::Printf(TEXT("dozer pushed %.1f m: over its angle of repose by %.0f cm while pushing, %.0f cm after | "), FVector::Dist2D(P0, Dz->PosM), DuringPush * 100.f, Ov1 * 100.f);
			if (Ov1 > 0.05f || DuringPush > 0.15f) bOK = false;
			// the dozer put somewhere (facing a way), settled there, then pushing for Secs with its blade in the ground; the
			// worst while pushing and what is left 2 s after it stopped, in the box round where it went
			float PushCut = 0.f; // (what the last push really cut, m3: a push that cut nothing proves nothing)
			float PushDist = 0.f; bool bPushStuck = false; // (how far it went, and whether it bogged down)
			auto Push = [&](const FVector2D& At, float YawDeg, float Secs, float& During, float& Left)
			{
				Dz->PosM = FVector(At.X, At.Y, T->HeightAt(At.X, At.Y)); Dz->Yaw = YawDeg; Dz->Speed = 0.f; Dz->InThrottle = 0.f; Dz->BladeH = 0.6f;
				for (int32 k = 0; k < 30; ++k) Dz->SimStep(FDt);
				const float Cut0 = Dz->CutTotal;
				const FVector Start0 = Dz->PosM;
				ON_SCOPE_EXIT { PushCut = Dz->CutTotal - Cut0; PushDist = FVector::Dist2D(Start0, Dz->PosM); bPushStuck = Dz->bStuck; };
				BoxC = At; BoxX = BoxY = 14.f; WorstDuring = 0.f;
				RunFrames(FDt, Secs, [&](float) { Dz->InThrottle = 1.f; Dz->InA1 = 0.f; Dz->BladeH = -0.06f; Dz->SimStep(FDt); });
				Dz->InThrottle = 0.f; Dz->BladeH = 0.6f;
				During = WorstDuring;
				RunFrames(FDt, 2.f, [&](float) { Dz->SimStep(FDt); });
				double Vv; After(Left, Vv);
			};
			// pushed over the same strip three times (back to the start, blade down again)
			{
				const FVector2D Start(Dz->PosM.X, Dz->PosM.Y); const float Yw = Dz->Yaw;
				float Worst = 0.f, Left = 0.f;
				float CutAll = 0.f;
				for (int32 Pass = 0; Pass < 3; ++Pass) { float Du, Le; Push(Start, Yw, 3.f, Du, Le); Worst = FMath::Max(Worst, Du); Left = FMath::Max(Left, Le); CutAll += PushCut; }
				Rep += FString::Printf(TEXT("same strip pushed 3 times (%.1f m3 cut): %.0f cm while pushing, %.0f cm after | "), CutAll, Worst * 100.f, Left * 100.f);
				if (Left > 0.05f || Worst > 0.15f || CutAll < 1.f) bOK = false;
			}
			// up and down a natural slope of 8 degrees or more near the site
			{
				FVector2D At(0.f, 0.f), Up(1.f, 0.f); float Steep = 0.f;
				for (float Y = -300.f; Y <= 300.f && Steep < 0.14f; Y += 9.f)
					for (float X = -300.f; X <= 300.f; X += 9.f)
					{
						const FVector Nm = T->NormalAt(X, Y);
						const float Sl = FVector2D(Nm.X, Nm.Y).Size();
						if (Sl > Steep && Sl < 0.3f && T->HeightAt(X, Y) > T->WaterZ + 1.f) { Steep = Sl; At = FVector2D(X, Y); Up = -FVector2D(Nm.X, Nm.Y).GetSafeNormal(); }
						if (Steep >= 0.14f) break;
					}
				const float UpYaw = FMath::RadiansToDegrees(FMath::Atan2(Up.Y, Up.X));
				float DuU, LeU, DuD, LeD;
				Push(At - Up * 6.f, UpYaw, 4.f, DuU, LeU); const float CutU = PushCut;
				Push(At + Up * 6.f, UpYaw + 180.f, 4.f, DuD, LeD); const float CutD = PushCut;
				Rep += FString::Printf(TEXT("on a %.0f deg slope - uphill (%.1f m3 cut): %.0f cm while pushing, %.0f cm after; downhill (%.1f m3 cut): %.0f / %.0f cm | "), FMath::RadiansToDegrees(FMath::Asin(FMath::Min(Steep, 1.f))), CutU, DuU * 100.f, LeU * 100.f, CutD, DuD * 100.f, LeD * 100.f);
				if (FMath::Max(LeU, LeD) > 0.05f || FMath::Max(DuU, DuD) > 0.15f || Steep < 0.1f || FMath::Min(CutU, CutD) < 0.5f) bOK = false;
			}
			// through a 0.4 m layer of each kind of soil (each its own angle of repose: the test measures against that one)
			{
				// each on its own strip of level, untouched natural ground: the same for all four (they stood side by side at
				// y -140 before, and the clay's strip lay over a 0.6 m crest - there the blade, held at a height on the
				// machine, rose off the ground and cut little whatever the soil; dry soil cut as little there, clay on the dry
				// soil's ground cut 7.3 m3). The strip: x -5..13 m (the dozer starts at -3), y -3..3 m.
				auto StripFit = [&](const FVector2D& At, float& MaxDev, float& Slope) -> bool
				{
					double S[3][4] = {}; TArray<FVector> Pt;
					for (float x = -5.f; x <= 13.f + 1e-3f; x += 1.f)
						for (float y = -3.f; y <= 3.f + 1e-3f; y += 1.f)
						{
							if (!T->InBounds(At.X + x, At.Y + y)) return false;
							const int32 i = T->IndexAt(At.X + x, At.Y + y);
							// (nothing built or worked there: no layers, the ground as the map made it, well above the water)
							if (T->Layers[i].Count > 0 || FMath::Abs(T->Height[i] - T->Natural[i]) > 1e-3f || T->Height[i] < T->WaterZ + 1.f) return false;
							Pt.Add(FVector(x, y, T->Height[i]));
						}
					for (const FVector& P : Pt) { const double R[3] = {1.0, P.X, P.Y}; for (int32 a = 0; a < 3; ++a) { for (int32 b = 0; b < 3; ++b) S[a][b] += R[a] * R[b]; S[a][3] += R[a] * P.Z; } }
					for (int32 c = 0; c < 3; ++c) for (int32 r = c + 1; r < 3; ++r) { const double F = S[r][c] / S[c][c]; for (int32 k = c; k < 4; ++k) S[r][k] -= F * S[c][k]; }
					double Z[3]; for (int32 r = 2; r >= 0; --r) { double V = S[r][3]; for (int32 k = r + 1; k < 3; ++k) V -= S[r][k] * Z[k]; Z[r] = V / S[r][r]; }
					MaxDev = 0.f; for (const FVector& P : Pt) MaxDev = FMath::Max(MaxDev, (float)FMath::Abs(P.Z - (Z[0] + Z[1] * P.X + Z[2] * P.Y)));
					Slope = (float)FMath::Sqrt(Z[1] * Z[1] + Z[2] * Z[2]);
					return true;
				};
				TArray<FVector2D> Sites;
				for (float Y = -400.f; Y <= 400.f && Sites.Num() < 4; Y += 12.f)
					for (float X = -400.f; X <= 400.f && Sites.Num() < 4; X += 12.f)
					{
						const FVector2D At(X, Y);
						bool bFree = true; for (const FVector2D& S2 : Sites) if (FVector2D::Distance(S2, At) < 30.f) bFree = false;
						if (FVector2D::Distance(At, FVector2D(P0.X, P0.Y)) < 40.f) bFree = false; // (clear of the pushes above)
						float Dev = 0.f, Sl = 0.f;
						if (bFree && StripFit(At, Dev, Sl) && Dev < 0.03f && Sl < 0.02f) Sites.Add(At);
					}
				Rep += FString::Printf(TEXT("%d level strips found; "), Sites.Num());
				if (Sites.Num() < 4) bOK = false;
				int32 Si = 0;
				for (const ESoil Kind : {ESoil::DrySoil, ESoil::Clay, ESoil::Sand, ESoil::Gravel})
				{
					if (Si >= Sites.Num()) break;
					const FVector2D At = Sites[Si];
					float Dev = 0.f, Sl = 0.f; StripFit(At, Dev, Sl);
					const float Hs = T->HeightAt(At.X - 2.f, At.Y), He = T->HeightAt(At.X + 12.f, At.Y);
					for (float x = -2.f; x <= 12.f; x += ARWTerrain::CS)
						for (float y = -3.f; y <= 3.f; y += ARWTerrain::CS)
							T->DepositAt(T->IndexAt(At.X + x, At.Y + y), Kind, 0.4f * ARWTerrain::CellArea, 0.3f, 0);
					const int32 Ic = T->IndexAt(At.X + 5.f, At.Y);
					const double Vol0 = AreaVolume(T, At.X + 5.f, At.Y, 3.f);
					RunFrames(FDt, 1.f, [](float) {});
					float Du, Le;
					Push(At - FVector2D(3.f, 0.f), 0.f, 4.f, Du, Le);
					// (the blade's edge over the ground where it stopped: how it stood to the soil)
					const FVector Edge = Dz->LocalToWorldM(FVector(Dz->BladeX + 0.12f, 0.f, -0.06f));
					Rep += FString::Printf(TEXT("%s (%.1f m3 cut, %.1f m driven%s): %.0f / %.0f cm [ground at %.0f, %.0f: start %.2f m, end %.2f m, off level at most %.1f cm, slope %.1f %%; layer %s, moisture %.2f, packed %.2f; strip centre volume %.1f m3; edge %.2f m over the ground at the end]; "),
						*SoilName(Kind, 0.3f), PushCut, PushDist, bPushStuck ? TEXT(", stuck") : TEXT(""), Du * 100.f, Le * 100.f,
						At.X, At.Y, Hs, He, Dev * 100.f, Sl * 100.f, *SoilName(T->SurfaceMat(Ic), T->MoistureAt(Ic)), 0.3f, 0.f, Vol0, Edge.Z - T->HeightAt(Edge.X, Edge.Y));
					if (Le > 0.05f || Du > 0.15f || PushCut < 0.5f) bOK = false;
					++Si;
				}
				// and on a crest (the clay's old strip, x -80, y -140: the ground rises 0.6 m and falls again): the blade held
				// at a height on the machine rises off the ground there - it must never cut below its own edge
				{
					const FVector2D At(-80.f, -140.f);
					float Below = 0.f; // (the most the ground under the cutting edge went below the edge - or below itself where the edge rode over it - in one frame)
					for (float x = -2.f; x <= 12.f; x += ARWTerrain::CS)
						for (float y = -3.f; y <= 3.f; y += ARWTerrain::CS)
							T->DepositAt(T->IndexAt(At.X + x, At.Y + y), ESoil::Clay, 0.4f * ARWTerrain::CellArea, 0.3f, 0);
					RunFrames(FDt, 1.f, [](float) {});
					Dz->PosM = FVector(At.X - 3.f, At.Y, T->HeightAt(At.X - 3.f, At.Y)); Dz->Yaw = 0.f; Dz->Speed = 0.f; Dz->InThrottle = 0.f; Dz->BladeH = 0.6f;
					for (int32 k = 0; k < 30; ++k) Dz->SimStep(FDt);
					const float Cut0 = Dz->CutTotal;
					BoxC = At; BoxX = BoxY = 14.f; WorstDuring = 0.f;
					RunFrames(FDt, 4.f, [&](float)
					{
						Dz->InThrottle = 1.f; Dz->InA1 = 0.f; Dz->BladeH = -0.06f;
						TArray<TPair<int32, float>, TInlineAllocator<16>> Under; // (point under the edge, the lower of the edge and the ground there)
						for (float w = -0.45f; w <= 0.45f + 1e-3f; w += 0.15f)
						{
							const FVector E = Dz->LocalToWorldM(FVector(Dz->BladeX + 0.12f, w * Dz->BladeW, Dz->BladeH));
							const int32 i = T->IndexAt(E.X, E.Y);
							Under.Add(TPair<int32, float>(i, FMath::Min(E.Z, T->Height[i])));
						}
						Dz->SimStep(FDt);
						for (const TPair<int32, float>& U : Under) Below = FMath::Max(Below, U.Value - T->Height[U.Key]);
					});
					Dz->InThrottle = 0.f; Dz->BladeH = 0.6f;
					Rep += FString::Printf(TEXT("| on a crest (clay over the ground at -80, -140, %.1f m3 cut): the ground under the blade's edge went at most %.1f cm below the edge"), Dz->CutTotal - Cut0, Below * 100.f);
					if (Below > 0.03f) bOK = false;
				}
			}
		}
		// 4. a fast pour, as a loader or a bucket emptied in one place: 1 m3 of falling lumps in 1 s from 2 m up, 60 fps
		if (Fx)
		{
			const FVector2D At(-50.f, -170.f);
			const float FDt = 1.f / 60.f;
			BoxC = At; BoxX = BoxY = 4.f; WorstDuring = 0.f;
			float Ov0; double V0; After(Ov0, V0);
			RunFrames(FDt, 4.f, [&](float Tm)
			{
				if (Tm < 1.f) { FPayload P; P.Add(ESoil::DrySoil, FDt * 1.f, 0.25f); Fx->SpawnSoil(FVector(At.X, At.Y, T->HeightAt(At.X, At.Y) + 2.f), FVector::ZeroVector, P, 0.15f); }
				Fx->Tick(FDt);
			});
			float Ov1; double V1; After(Ov1, V1);
			Rep += FString::Printf(TEXT("| 1 m3 poured in 1 s: %.0f cm while pouring, %.0f cm after, %.2f of 1.00 m3 on the ground "), WorstDuring * 100.f, Ov1 * 100.f, V1 - V0);
			if (Ov1 > 0.05f || WorstDuring > 0.15f || FMath::Abs(V1 - V0 - 1.0) > 0.1) bOK = false;
		}
		// 5. a grader cutting through a 0.3 m layer of loose soil for 4 s, its windrow off the trailing end
		{
			ARWGrader* Gr = nullptr;
			for (ARWMachine* M : Machines) if (!Gr) Gr = Cast<ARWGrader>(M);
			if (Gr)
			{
				const FVector2D At(-50.f, -140.f);
				const float FDt = 1.f / 60.f;
				for (float x = -2.f; x <= 14.f; x += ARWTerrain::CS)
					for (float y = -4.f; y <= 4.f; y += ARWTerrain::CS)
						T->DepositAt(T->IndexAt(At.X + x, At.Y + y), ESoil::DrySoil, 0.3f * ARWTerrain::CellArea, 0.3f, 0);
				RunFrames(FDt, 1.f, [](float) {});
				const FVector KeepP = Gr->PosM; const float KeepY = Gr->Yaw; const bool KeepOn = Gr->bEngineOn;
				Gr->PosM = FVector(At.X - 3.f, At.Y, T->HeightAt(At.X - 3.f, At.Y)); Gr->Yaw = 0.f; Gr->Speed = 0.f;
				Gr->bEngineOn = true; Gr->Rpm = Gr->MaxRpm; Gr->ThrottleDial = 1.f;
				for (int32 k = 0; k < 30; ++k) { Gr->InThrottle = 0.f; Gr->SimStep(FDt); }
				BoxC = At + FVector2D(5.f, 0.f); BoxX = 12.f; BoxY = 8.f; WorstDuring = 0.f;
				float Moved = 0.f;
				RunFrames(FDt, 4.f, [&](float) { Gr->InThrottle = 0.6f; Gr->InA1 = 0.f; Gr->BladeH = -0.1f; Gr->SimStep(FDt); Moved += Gr->Carried * FDt; });
				Gr->InThrottle = 0.f;
				const float During = WorstDuring;
				RunFrames(FDt, 2.f, [&](float) { Gr->SimStep(FDt); });
				float Ov1; double V1; After(Ov1, V1);
				Rep += FString::Printf(TEXT("| grader through loose soil (%.1f m3 moved to its windrow): %.0f cm while grading, %.0f cm after"), Moved, During * 100.f, Ov1 * 100.f);
				if (Ov1 > 0.05f || During > 0.15f || Moved < 0.3f) bOK = false;
				Gr->PosM = KeepP; Gr->Yaw = KeepY; Gr->bEngineOn = KeepOn; Gr->SimStep(FDt);
			}
			else Rep += TEXT("| (no grader in this game to test)");
		}
		// a save made while soil is still settling (a column just dropped, nothing settled yet), loaded again: the settling
		// goes on after the load - the queue of it is not in the save, and loading used to clear it, leaving the soil
		// standing too steep for good
		{
			const FVector2D At(-40.f, -170.f);
			BoxC = At; BoxX = BoxY = 4.f; WorstDuring = 0.f;
			float OvA; double V0; After(OvA, V0);
			const int32 Ci = T->IndexAt(At.X, At.Y);
			for (int32 dy = -1; dy <= 1; ++dy) for (int32 dx = -1; dx <= 1; ++dx)
				T->DepositAt(Ci + dy * ARWTerrain::N + dx, ESoil::DrySoil, 1.f * ARWTerrain::CellArea, 0.25f, 0);
			float OvSaved; double VSaved; After(OvSaved, VSaved);
			TArray<uint8> Blob; T->SaveTo(Blob);
			const bool bLoaded = T->LoadFrom(Blob);
			float OvLoaded; double VLoaded; After(OvLoaded, VLoaded);
			RunFrames(1.f / 60.f, 3.f, [](float) {});
			float Ov1; double V1; After(Ov1, V1);
			Check(TEXT("Soil still settling when the game is saved settles after loading"), bLoaded && OvSaved > 0.3f && Ov1 < 0.05f && FMath::Abs(V1 - VSaved) < 0.05,
				FString::Printf(TEXT("a 1 m column of loose soil saved over its angle of repose by %.2f m, loaded %s (%.2f m), 3 s later %.2f m; volume %.2f -> %.2f m3"),
					OvSaved, bLoaded ? TEXT("back") : TEXT("FAILED"), OvLoaded, Ov1, VSaved - V0, V1 - V0));
		}
		Check(TEXT("Soil does not stand up in spikes (terrain tests)"), bOK, Rep);
	}
	// Test B: the soil drawn in each model excavator's bucket stays inside its own steel (the model's triangles) - empty,
	// 30 / 60 / 100 / 120 % loaded, held up and while pouring - and an overloaded bucket keeps no more than it can hold
	{
		FString Rep;
		bool bAllIn = true, bCap = true;
		int32 NB = 0, NExit = 0, BadExit = 0, NOld = 0, BadOld = 0;
		for (ARWMachine* M : Machines)
		{
			ARWExcavator* X = Cast<ARWExcavator>(M);
			if (!X || !X->bModelRig || X->BucketSteel.Num() < 3) continue;
			++NB;
			const float KB = X->BoomA, KA = X->ArmA, KK = X->BktA; const int32 KT = X->Tool; const FPayload KL = X->Bucket.Load;
			X->Tool = 0; X->InA1 = X->InA2 = X->InA3 = X->InA4 = 0.f; X->Bucket.Load.Clear();
			X->BoomA = 35.f; // (in the air)
			float UpA = X->BktA, UpZ = -2.f, PourA = X->BktA, PourGap = 9.f;
			for (float Ang = X->BktLo + 1.f; Ang < X->BktHi; Ang += 3.f)
			{
				X->BktA = Ang; X->SimStep(Dt);
				const float Z = X->MouthDir().Z;
				if (Z > UpZ) { UpZ = Z; UpA = Ang; }
				if (FMath::Abs(Z - 0.15f) < PourGap) { PourGap = FMath::Abs(Z - 0.15f); PourA = Ang; } // tipped till the soil starts to go
			}
			FString Line;
			for (int32 Pose = 0; Pose < 2; ++Pose)
				for (const float Frac : {0.f, 0.3f, 0.6f, 1.f, 1.2f})
				{
					X->Bucket.Load.Clear(); X->BktA = Pose == 0 ? UpA : PourA; X->SimStep(Dt);
					X->Bucket.Load.Clear();
					if (Frac > 0.f) X->Bucket.Load.Add(ESoil::DrySoil, Frac * X->Bucket.Capacity, 0.2f);
					X->FillKey = -1; X->UpdateBucketFill();
					int32 Out = 0, Tot = 0; float Wd = 0.f;
					X->SoilOutsideSteel(Out, Tot, Wd);
					const bool bShown = X->FillMesh && X->FillMesh->IsVisible();
					if ((Frac == 0.f && bShown) || (Frac > 0.f && !bShown) || Out > 0) bAllIn = false;
					if (X->FillLevelFrac > 1.001f) bCap = false;
					if (Frac > 0.f) Line += FString::Printf(TEXT(" %s %.0f%%: %d of %d out%s"), Pose ? TEXT("pouring") : TEXT("held up"), Frac * 100.f, Out, Tot, Out ? *FString::Printf(TEXT(" (up to %.0f cm)"), Wd * 100.f) : TEXT(""));
					// where spilt soil starts falling: straight down from there it must not meet the bucket's own steel
					if (Frac == 1.f && X->ToolRoots.Num() && X->ToolRoots[0] && X->BucketP)
					{
						const FTransform BT = X->ToolRoots[0]->GetComponentTransform();
						const FVector DownB = BT.InverseTransformVectorNoScale(FVector(0.f, 0.f, -1.f));
						auto Through = [&](const FVector& Pw) { float Tt; return ARWExcavator::RaySteel(X->BucketSteel, BT.InverseTransformPosition(Pw * M2CM) * CM2M, DownB, 2.f, Tt); };
						for (const float Sd : {-1.f, 0.f, 1.f})
							for (const bool bTeeth : {false, true}) { ++NExit; BadExit += Through(X->SoilExitAt(Sd, bTeeth)) ? 1 : 0; }
						// (and where it used to start: 12 % back from the teeth, 8 cm lower, across 90 % of the width)
						const FVector Tp = X->TipWorld(), Pv = X->BucketP->GetComponentLocation() * CM2M, LatW = BT.TransformVectorNoScale(FVector(0.f, 1.f, 0.f));
						for (const float Sd : {-0.45f, 0.f, 0.45f}) { ++NOld; BadOld += Through(Tp + (Pv - Tp) * 0.12f + LatW * Sd * X->Bucket.Width - FVector(0.f, 0.f, 0.08f)) ? 1 : 0; }
					}
				}
			// loaded to 160 %: what will not stay runs over the lip within 3 s
			X->BktA = UpA; X->Bucket.Load.Clear(); X->Bucket.Load.Add(ESoil::DrySoil, 1.6f * X->Bucket.Capacity, 0.2f);
			for (int32 k = 0; k < 180; ++k) X->SimStep(Dt);
			const float Held = X->Bucket.Load.Total() / FMath::Max(X->Bucket.Capacity, 0.01f);
			if (Held > 1.26f) bCap = false;
			Rep += FString::Printf(TEXT("%s (%.2f m3):%s; loaded to 160%% it keeps %.0f%% | "), *X->Model, X->Bucket.Capacity, *Line, Held * 100.f);
			X->Bucket.Load = KL; X->BoomA = KB; X->ArmA = KA; X->BktA = KK; X->Tool = KT; X->SimStep(Dt); X->FillKey = -1;
		}
		Check(TEXT("Soil drawn in the bucket stays inside its steel (Test B)"), NB > 0 && bAllIn && bCap, Rep);
		Check(TEXT("Spilt soil leaves the bucket outside its steel (Test B)"), NExit > 0 && BadExit == 0,
			FString::Printf(TEXT("%d of %d places where spilt soil starts would fall through the bucket (the old places: %d of %d)"), BadExit, NExit, BadOld, NOld));
	}
	RWTestLog(FString::Printf(TEXT("================ %d passed, %d failed ================"), GPass, GFail));
	if (FParse::Param(FCommandLine::Get(), TEXT("rwtestexit"))) FGenericPlatformMisc::RequestExit(false);
}
