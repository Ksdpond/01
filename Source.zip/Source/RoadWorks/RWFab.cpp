#include "RWFab.h"
#include "RWTypes.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "AssetRegistry/AssetData.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Misc/ConfigCacheIni.h"

TArray<UStaticMesh*> FRWFab::Conifer, FRWFab::Broadleaf, FRWFab::Bush, FRWFab::Grass, FRWFab::Rock, FRWFab::Palm, FRWFab::Banana, FRWFab::Understory, FRWFab::GroundProp;
UMaterialInterface* FRWFab::Water = nullptr;
UMaterialInterface* FRWFab::Lake = nullptr;
bool FRWFab::bScanned = false;

static bool HasAny(const FString& S, std::initializer_list<const TCHAR*> Words)
{
	for (const TCHAR* W : Words) if (S.Contains(W)) return true;
	return false;
}

FString FRWFab::Classify(const FString& AssetName, const FString& PackagePath)
{
	const FString N = AssetName.ToLower(), S = (PackagePath + TEXT("/") + AssetName).ToLower();
	// parts, lower LODs, impostors and dead wood are not whole plants
	if (HasAny(N, {TEXT("branch"), TEXT("leaf"), TEXT("leaves"), TEXT("trunk"), TEXT("stump"), TEXT("bark"), TEXT("root"), TEXT("debris"),
		TEXT("dead"), TEXT("fallen"), TEXT("billboard"), TEXT("impostor"), TEXT("_lod1"), TEXT("_lod2"), TEXT("_lod3"), TEXT("log_"), TEXT("_log"), TEXT("card")}))
		return FString();
	if (HasAny(S, {TEXT("pine"), TEXT("spruce"), TEXT("conifer"), TEXT("larch"), TEXT("cedar"), TEXT("cypress"), TEXT("hemlock"), TEXT("fir_"), TEXT("_fir"), TEXT("/fir")}))
		return TEXT("conifer");
	if (HasAny(S, {TEXT("bush"), TEXT("shrub"), TEXT("hedge"), TEXT("juniper")})) return TEXT("bush");
	if (HasAny(S, {TEXT("tree"), TEXT("oak"), TEXT("birch"), TEXT("maple"), TEXT("beech"), TEXT("aspen"), TEXT("alder"), TEXT("poplar"), TEXT("willow"), TEXT("elm_"), TEXT("chestnut"), TEXT("acacia")}))
		return TEXT("broadleaf");
	if (HasAny(S, {TEXT("grass"), TEXT("fern"), TEXT("weed"), TEXT("clover"), TEXT("meadow"), TEXT("tuft"), TEXT("dandelion"), TEXT("reed")})) return TEXT("grass");
	if (HasAny(S, {TEXT("rock"), TEXT("boulder"), TEXT("stone"), TEXT("cliff")}) && !HasAny(S, {TEXT("wall"), TEXT("brick"), TEXT("tile")})) return TEXT("rock");
	return FString();
}

float FRWFab::HeightScale(const UStaticMesh* M, float TargetM, float* OutBaseZ)
{
	if (OutBaseZ) *OutBaseZ = 0.f;
	if (!M) return 1.f;
	const FBoxSphereBounds B = M->GetBounds();
	// (a mesh built while the world is being made may have no size yet in the editor: leave it at its own scale)
	if (B.ContainsNaN() || B.BoxExtent.Z < 0.5f) return 1.f;
	const float H = FMath::Max(B.BoxExtent.Z * 2.f, 1.f); // cm
	if (OutBaseZ) *OutBaseZ = B.Origin.Z - B.BoxExtent.Z;
	return TargetM * 100.f / H;
}

void FRWFab::Scan()
{
	if (bScanned) return;
	bScanned = true;
	bool bOff = false;
	GConfig->GetBool(TEXT("RoadWorks.Fab"), TEXT("Disable"), bOff, GGameIni);
	if (bOff || FParse::Param(FCommandLine::Get(), TEXT("rwnofab"))) { RWLog(TEXT("Fab assets: switched off")); return; }

	TMap<FString, TArray<FString>> Pick; // category -> object paths
	// 1) assets named in the config win
	for (const TCHAR* Key : {TEXT("Conifer"), TEXT("Broadleaf"), TEXT("Bush"), TEXT("Grass"), TEXT("Rock"), TEXT("Water"), TEXT("Palm"), TEXT("Banana"), TEXT("Understory"), TEXT("GroundProp"), TEXT("Lake")})
	{
		TArray<FString> L;
		GConfig->GetArray(TEXT("RoadWorks.Fab"), Key, L, GGameIni);
		FString One; if (GConfig->GetString(TEXT("RoadWorks.Fab"), Key, One, GGameIni) && !One.IsEmpty()) L.AddUnique(One);
		if (L.Num()) Pick.Add(FString(Key).ToLower(), L);
	}
	// 2) otherwise look through everything outside the game's own folders
	IAssetRegistry* AR = IAssetRegistry::Get();
	if (AR)
	{
		TArray<FAssetData> Assets;
		AR->GetAssetsByPath(FName(TEXT("/Game")), Assets, true);
		static const TCHAR* Own[] = {TEXT("/Game/Materials"), TEXT("/Game/Textures"), TEXT("/Game/dirt_texture_all"), TEXT("/Game/Fonts"), TEXT("/Game/Lang"), TEXT("/Game/Developers"), TEXT("/Game/Collections")};
		Assets.Sort([](const FAssetData& A, const FAssetData& B) { return A.GetObjectPathString() < B.GetObjectPathString(); });
		TMap<FString, TArray<FString>> Found;
		for (const FAssetData& A : Assets)
		{
			const FString Path = A.PackagePath.ToString();
			bool bOwn = false;
			for (const TCHAR* O : Own) if (Path.StartsWith(O)) bOwn = true;
			if (bOwn) continue;
			const FTopLevelAssetPath Cls = A.AssetClassPath;
			const FString Name = A.AssetName.ToString();
			if (Cls == UStaticMesh::StaticClass()->GetClassPathName())
			{
				const FString C = Classify(Name, Path);
				if (!C.IsEmpty()) Found.FindOrAdd(C).Add(A.GetObjectPathString());
			}
			else if (Cls == UMaterial::StaticClass()->GetClassPathName() || Cls == UMaterialInstanceConstant::StaticClass()->GetClassPathName())
			{
				const FString L = (Path + TEXT("/") + Name).ToLower();
				if (HasAny(L, {TEXT("water"), TEXT("river"), TEXT("lake"), TEXT("pond")}) && !HasAny(L, {TEXT("waterfall"), TEXT("wet"), TEXT("puddle"), TEXT("caustic"), TEXT("bottle")}))
					Found.FindOrAdd(TEXT("water")).Add(A.GetObjectPathString());
			}
		}
		for (auto& KV : Found) if (!Pick.Contains(KV.Key)) Pick.Add(KV.Key, KV.Value);
	}
	auto LoadMeshes = [&](const TCHAR* Key, TArray<UStaticMesh*>& Out)
	{
		Out.Reset();
		if (const TArray<FString>* L = Pick.Find(Key))
			for (const FString& P : *L)
			{
				if (UStaticMesh* M = LoadObject<UStaticMesh>(nullptr, *P)) Out.Add(M);
				else RWLog(FString::Printf(TEXT("Fab assets: %s mesh %s could not be loaded"), Key, *P));
			}
	};
	LoadMeshes(TEXT("conifer"), Conifer);
	LoadMeshes(TEXT("broadleaf"), Broadleaf);
	LoadMeshes(TEXT("bush"), Bush);
	LoadMeshes(TEXT("grass"), Grass);
	LoadMeshes(TEXT("rock"), Rock);
	LoadMeshes(TEXT("palm"), Palm);
	LoadMeshes(TEXT("banana"), Banana);
	LoadMeshes(TEXT("understory"), Understory);
	LoadMeshes(TEXT("groundprop"), GroundProp);
	if (const TArray<FString>* L = Pick.Find(TEXT("water")))
		for (const FString& P : *L) if ((Water = LoadObject<UMaterialInterface>(nullptr, *P)) != nullptr) break;
	if (const TArray<FString>* L = Pick.Find(TEXT("lake")))
		for (const FString& P : *L) if ((Lake = LoadObject<UMaterialInterface>(nullptr, *P)) != nullptr) break;
	RWLog(FString::Printf(TEXT("Fab assets: %s"), *Summary()));
}

TArray<FString> FRWFab::PlaceablePaths()
{
	TArray<FString> Out;
	for (const TCHAR* Key : {TEXT("Conifer"), TEXT("Broadleaf"), TEXT("Bush"), TEXT("Rock"), TEXT("Palm"), TEXT("Banana"), TEXT("Understory"), TEXT("GroundProp"), TEXT("Placeable")})
	{
		TArray<FString> L;
		GConfig->GetArray(TEXT("RoadWorks.Fab"), Key, L, GGameIni);
		for (const FString& P : L) Out.AddUnique(P);
	}
	return Out;
}

FString FRWFab::Summary()
{
	auto Names = [](const TArray<UStaticMesh*>& L) { FString S; for (const UStaticMesh* M : L) S += (S.IsEmpty() ? TEXT("") : TEXT(", ")) + M->GetName(); return S.IsEmpty() ? FString(TEXT("-")) : S; };
	return FString::Printf(TEXT("conifer %d, broadleaf %d, bush %d, grass %d, rock %d, palm %d, banana %d, understory %d, ground props %d, water [%s], lake [%s]"),
		Conifer.Num(), Broadleaf.Num(), Bush.Num(), Grass.Num(), Rock.Num(), Palm.Num(), Banana.Num(), Understory.Num(), GroundProp.Num(), Water ? *Water->GetName() : TEXT("-"), Lake ? *Lake->GetName() : TEXT("-"));
}
