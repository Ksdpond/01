// Builds an excavator from a modder's own 3D model (glTF). The model's parts are mapped to the
// game's working joints by name; each part's pivot (object origin in Blender) becomes the hinge.
//   tracks/undercarriage -> machine root     upper body + cab -> slewing house
//   boom -> boom joint     stick -> stick joint     bucket -> bucket joint
//   hydraulic cylinders: barrel and rod are aimed at each other every frame so they extend.
#include "RWMachines.h"
#include "RWMods.h"
#include "RWGltf.h"
#include "RWTerrain.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "RWMeshGen.h"
#include "RWSoilLook.h"

static float NormDeg(float A) { return FRotator::NormalizeAxis(A); }

// The model's parts a rig list names (any case): "name" exactly, "name*" starting so, "*name" ending so, "*name*" containing
// it, and "*" alone: every part no other list has taken (for files exported with all parts side by side, no hierarchy).
static TArray<int32> RWMatchNodes(const FRWGltfModel& M, const FJsonObject& Rig, const TCHAR* Key, TSet<int32>& Assigned)
{
	TArray<int32> Out;
	const TArray<TSharedPtr<FJsonValue>>* A;
	TArray<FString> Pats;
	if (Rig.TryGetArrayField(Key, A)) for (const TSharedPtr<FJsonValue>& V : *A) Pats.Add(V->AsString());
	else { FString S; if (Rig.TryGetStringField(Key, S)) Pats.Add(S); }
	for (const FString& P : Pats)
	{
		const bool bAll = P == TEXT("*");
		const bool bStart = P.StartsWith(TEXT("*")), bEnd = P.EndsWith(TEXT("*")) && P.Len() > 1;
		const FString Core = P.Mid(bStart ? 1 : 0, P.Len() - (bStart ? 1 : 0) - (bEnd ? 1 : 0));
		for (int32 n = 0; n < M.Nodes.Num(); ++n)
		{
			const FString& Nm = M.Nodes[n].Name;
			bool bHit;
			if (bAll) bHit = !Assigned.Contains(n) && M.Nodes[n].Parent < 0;
			else if (bStart && bEnd) bHit = Nm.Contains(Core, ESearchCase::IgnoreCase);
			else if (bStart) bHit = Nm.EndsWith(Core, ESearchCase::IgnoreCase);
			else if (bEnd) bHit = Nm.StartsWith(Core, ESearchCase::IgnoreCase);
			else bHit = Nm.Equals(Core, ESearchCase::IgnoreCase);
			if (bHit) Out.AddUnique(n);
		}
	}
	for (int32 n : Out) Assigned.Add(n);
	return Out;
}

// The lamps the modder placed - lights or "lamp..." empties in the model (the RoadWorks Blender add-on makes them), or a
// "lamps" list in mod.json ({"pos": [x, y, z] and "dir" in the model's own glTF coordinates, "part", "lumens", "cone", "range"})
// - each on the moving part it belongs to. PartFor gives the component for a part name ("" = the usual one) and where that
// component stands in the machine's rest pose (cm). Returns how many were made (none: the machine keeps its own lamps).
static int32 RWModelLamps(ARWMachine* Mc, const FRWGltfModel& M, const FJsonObject& Def, const FTransform& M0, float MYaw, float MScale,
	TFunctionRef<USceneComponent*(const FString&, FTransform&)> PartFor)
{
	TArray<FRWGltfModel::FLampPoint> All = M.LampPoints();
	const TArray<TSharedPtr<FJsonValue>>* LA;
	if (Def.TryGetArrayField(TEXT("lamps"), LA))
		for (const TSharedPtr<FJsonValue>& V : *LA)
		{
			const TSharedPtr<FJsonObject> O = V->AsObject();
			if (!O) continue;
			auto Vec = [&](const TCHAR* K, FVector& Out) -> bool
			{
				const TArray<TSharedPtr<FJsonValue>>* A;
				if (!O->TryGetArrayField(K, A) || A->Num() != 3) return false;
				const FVector G((*A)[0]->AsNumber(), (*A)[1]->AsNumber(), (*A)[2]->AsNumber());
				Out = FRotator(0.f, MYaw, 0.f).RotateVector(FVector(G.X, G.Z, G.Y));
				return true;
			};
			FRWGltfModel::FLampPoint L;
			if (!Vec(TEXT("pos"), L.Pos)) continue;
			L.Pos *= 100.f * MScale;
			if (!Vec(TEXT("dir"), L.Dir)) L.Dir = FVector(1.f, 0.f, -0.15f);
			L.Dir = L.Dir.GetSafeNormal();
			double Num = 0.0;
			if (O->TryGetNumberField(TEXT("lumens"), Num)) L.Lumens = (float)Num;
			if (O->TryGetNumberField(TEXT("cone"), Num)) L.OuterDeg = (float)Num;
			if (O->TryGetNumberField(TEXT("range"), Num)) L.RangeM = (float)Num;
			O->TryGetBoolField(TEXT("work"), L.bWork);
			O->TryGetStringField(TEXT("part"), L.Part);
			All.Add(L);
		}
	int32 Made = 0;
	for (const FRWGltfModel::FLampPoint& L : All)
	{
		FTransform Rest = FTransform::Identity;
		USceneComponent* P = PartFor(L.Part.ToLower(), Rest);
		if (!P) continue;
		const FVector At = L.Pos + M0.GetTranslation();
		const FVector Local = Rest.InverseTransformPosition(At) * CM2M;
		const FVector Dir = Rest.InverseTransformVectorNoScale(L.Dir);
		Mc->AddLampAt(P, Local, Dir.Rotation(), L.Lumens, L.OuterDeg, L.RangeM, L.Color, L.bWork);
		++Made;
	}
	if (Made) RWLog(FString::Printf(TEXT("Model lamps: %d placed by the model or mod.json"), Made));
	return Made;
}

// A simplified copy of a very detailed part (a track pad of 300 000 triangles drawn 80 times): points in cells of CellM metres
// become one, triangles that fall to nothing go. Enough for a part seen moving past at a few metres.
static void RWSimplify(FMeshBuild& B, float CellM)
{
	TMap<FIntVector, int32> CellOf;
	TArray<FVector3f> Sum; TArray<int32> Cnt;
	TArray<int32> Remap; Remap.SetNumUninitialized(B.P.Num());
	for (int32 i = 0; i < B.P.Num(); ++i)
	{
		const FVector3f& P = B.P[i];
		const FIntVector K(FMath::FloorToInt(P.X / CellM), FMath::FloorToInt(P.Y / CellM), FMath::FloorToInt(P.Z / CellM));
		int32* F = CellOf.Find(K);
		int32 Ix;
		if (F) Ix = *F; else { Ix = Sum.Add(FVector3f::ZeroVector); Cnt.Add(0); CellOf.Add(K, Ix); }
		Sum[Ix] += P; ++Cnt[Ix];
		Remap[i] = Ix;
	}
	FMeshBuild O;
	for (int32 i = 0; i < Sum.Num(); ++i) { O.P.Add(Sum[i] / (float)Cnt[i]); O.N.Add(FVector3f::ZeroVector); O.UV.Add(FVector2f(0.f, 0.f)); }
	TSet<FIntVector> Seen;
	for (int32 t = 0; t + 2 < B.T.Num(); t += 3)
	{
		const int32 A = Remap[B.T[t]], Bb = Remap[B.T[t + 1]], C = Remap[B.T[t + 2]];
		if (A == Bb || Bb == C || A == C) continue;
		// (the same triangle twice: once is enough)
		const int32 Lo = FMath::Min3(A, Bb, C), Hi = FMath::Max3(A, Bb, C), Mid = A + Bb + C - Lo - Hi;
		const FIntVector Key(Lo, Mid, Hi);
		if (Seen.Contains(Key)) continue;
		Seen.Add(Key);
		O.T.Add(A); O.T.Add(Bb); O.T.Add(C);
	}
	for (int32 t = 0; t + 2 < O.T.Num(); t += 3)
	{
		const FVector3f Fn = FVector3f::CrossProduct(O.P[O.T[t + 2]] - O.P[O.T[t]], O.P[O.T[t + 1]] - O.P[O.T[t]]);
		O.N[O.T[t]] += Fn; O.N[O.T[t + 1]] += Fn; O.N[O.T[t + 2]] += Fn;
	}
	for (FVector3f& Nn : O.N) Nn = Nn.GetSafeNormal();
	B = MoveTemp(O);
}

// A chain modelled link by link: one link of the bottom run (plate, side links, pin, bolts - all separate pieces in the file)
// becomes the shoe the game moves round the wheels, so that the moving chain is the model's own.
// OriginAboveGround = height of the chain path over the bottom of the plates (m).
static bool RWShoeFromChain(const FRWGltfModel& M, int32 Node, const FTransform& WT, float OriginAboveGround, UStaticMesh*& OutMesh, float& OutPitch)
{
	const int32 Mh = M.Nodes[Node].Mesh;
	if (!M.MeshPoints.IsValidIndex(Mh) || M.MeshPoints[Mh].Num() == 0) return false;
	const TArray<FVector3f>& Pts = M.MeshPoints[Mh];
	const TArray<int32>& Tris = M.MeshTris[Mh];
	const int32 NV = Pts.Num();
	// separate pieces: joined by triangles, or by vertices at the same place
	TArray<int32> Par; Par.SetNumUninitialized(NV);
	for (int32 i = 0; i < NV; ++i) Par[i] = i;
	auto Root = [&Par](int32 a) { while (Par[a] != a) { Par[a] = Par[Par[a]]; a = Par[a]; } return a; };
	TMap<FIntVector, int32> Seen; Seen.Reserve(NV);
	TArray<FVector> World; World.SetNumUninitialized(NV);
	for (int32 i = 0; i < NV; ++i)
	{
		World[i] = WT.TransformPosition(FVector(Pts[i]));
		const FIntVector K(FMath::RoundToInt(Pts[i].X * 100.f), FMath::RoundToInt(Pts[i].Y * 100.f), FMath::RoundToInt(Pts[i].Z * 100.f));
		if (const int32* F = Seen.Find(K)) Par[Root(i)] = Root(*F); else Seen.Add(K, i);
	}
	for (int32 t = 0; t + 2 < Tris.Num(); t += 3) { Par[Root(Tris[t])] = Root(Tris[t + 1]); Par[Root(Tris[t + 2])] = Root(Tris[t + 1]); }
	TMap<int32, FBox> Pieces;
	FBox All(ForceInit);
	for (int32 i = 0; i < NV; ++i) { All += World[i]; Pieces.FindOrAdd(Root(i), FBox(ForceInit)) += World[i]; }
	// the wide plates on the middle of the bottom run give the pitch and the link to copy
	const float MinZ = All.Min.Z, Wide = All.GetSize().Y;
	TArray<float> PlateX;
	for (const TPair<int32, FBox>& E : Pieces)
		if (E.Value.GetCenter().Z < MinZ + 30.f && E.Value.GetSize().Y > Wide * 0.7f) PlateX.Add(E.Value.GetCenter().X);
	if (PlateX.Num() < 4) return false;
	PlateX.Sort();
	TArray<float> Gaps;
	for (int32 i = 1; i < PlateX.Num(); ++i) if (PlateX[i] - PlateX[i - 1] > 6.f) Gaps.Add(PlateX[i] - PlateX[i - 1]);
	if (Gaps.Num() < 3) return false;
	Gaps.Sort();
	const float Pitch = FMath::Clamp(Gaps[Gaps.Num() / 2], 12.f, 35.f);
	const float X0 = PlateX[PlateX.Num() / 2];
	const FVector Origin(X0, All.GetCenter().Y, MinZ + OriginAboveGround * 100.f);
	// that link: everything low enough to belong to the bottom run within one pitch around the plate
	TSet<int32> Keep;
	for (const TPair<int32, FBox>& E : Pieces)
	{
		const FVector C = E.Value.GetCenter();
		if (C.Z < MinZ + 30.f && C.X >= X0 - Pitch * 0.5f && C.X < X0 + Pitch * 0.5f) Keep.Add(E.Key);
	}
	FMeshBuild B;
	TMap<int32, int32> Map;
	for (int32 t = 0; t + 2 < Tris.Num(); t += 3)
	{
		if (!Keep.Contains(Root(Tris[t]))) continue;
		for (int32 k = 0; k < 3; ++k)
		{
			const int32 v = Tris[t + k];
			int32* Fv = Map.Find(v);
			int32 Nv;
			if (Fv) Nv = *Fv;
			else
			{
				Nv = B.P.Num();
				Map.Add(v, Nv);
				B.P.Add(FVector3f((World[v] - Origin) * CM2M));
				B.N.Add(FVector3f::ZeroVector);
				B.UV.Add(FVector2f(0.f, 0.f));
			}
			B.T.Add(Nv);
		}
	}
	for (int32 t = 0; t + 2 < B.T.Num(); t += 3)
	{
		const FVector3f Fn = FVector3f::CrossProduct(B.P[B.T[t + 2]] - B.P[B.T[t]], B.P[B.T[t + 1]] - B.P[B.T[t]]); // Unreal front-face normal
		B.N[B.T[t]] += Fn; B.N[B.T[t + 1]] += Fn; B.N[B.T[t + 2]] += Fn;
	}
	for (FVector3f& N : B.N) N = N.GetSafeNormal();
	OutMesh = FRWMeshGen::Build(FString::Printf(TEXT("chainlink_%08x_%d"), GetTypeHash(M.Path), Node), B);
	OutPitch = Pitch * CM2M;
	RWLog(FString::Printf(TEXT("Model track: link of %s = %d pieces, %d triangles, pitch %.3f m, %d plates in view"), *M.Nodes[Node].Name, Keep.Num(), B.T.Num() / 3, OutPitch, PlateX.Num()));
	return OutMesh != nullptr;
}

bool ARWDozer::BuildFromModel()
{
	const FRWModMachine* MD = PendingMod;
	if (!MD || !MD->Def.IsValid()) return false;
	FString File;
	if (!MD->Def->TryGetStringField(TEXT("model"), File)) return false;
	double MYaw = -90.0, MScale = 1.0;
	MD->Def->TryGetNumberField(TEXT("model_yaw"), MYaw);
	MD->Def->TryGetNumberField(TEXT("model_scale"), MScale);
	TSharedPtr<FRWGltfModel> M = FRWGltfModel::Get(MD->Folder / File, (float)MScale, (float)MYaw);
	if (!M.IsValid()) return false;
	const TSharedPtr<FJsonObject>* MatSection;
	if (MD->Def->TryGetObjectField(TEXT("materials"), MatSection)) M->ApplyMaterialOverrides(**MatSection);
	const TSharedPtr<FJsonObject>* RigObj;
	if (!MD->Def->TryGetObjectField(TEXT("rig"), RigObj)) { RWLog(TEXT("Dozer model: \"rig\" section missing")); return false; }
	const TSharedPtr<FJsonObject> Rig = *RigObj;
	TSet<int32> Assigned;
	XmlGltfNodes.Reset();
	XmlGltfNodePoints.Reset();
	auto Collect = [&](const TCHAR* Key) { return RWMatchNodes(*M, *Rig, Key, Assigned); };
	Collect(TEXT("hide"));
	// Isolate hydraulic meshes BEFORE blade/body grouping so they are not baked into merged meshes.
	const TArray<int32> HydraulicNodes = Collect(TEXT("hydraulic_parts"));
	FString PinName, EdgeName, EyeName, SeatName;
	Rig->TryGetStringField(TEXT("blade_pin"), PinName);
	Rig->TryGetStringField(TEXT("blade"), EdgeName);
	Rig->TryGetStringField(TEXT("eye"), EyeName);
	Rig->TryGetStringField(TEXT("seat"), SeatName);
	const int32 NPin = M->Find(PinName), NEdge = M->Find(EdgeName), NEye = M->Find(EyeName), NSeat = M->Find(SeatName);
	// Keep the blade mesh separate from its lifting frame: two generic XML-driven
	// joints (angle/yaw and pitch) will own it, preventing native lift from
	// overwriting those two rotations. The blade is still counted as assigned so
	// the body group does not merge it into static geometry.
	TArray<int32> BF = Collect(TEXT("blade_frame"));
	if (NPin >= 0 && !Assigned.Contains(NPin)) { BF.Add(NPin); Assigned.Add(NPin); }
	if (NEdge >= 0 && !Assigned.Contains(NEdge)) Assigned.Add(NEdge);
	const TArray<int32> TK = Collect(TEXT("tracks")), TP = Collect(TEXT("track_pads"));
	RWLog(FString::Printf(TEXT("Dozer rig: blade_frame=%d, tracks=%d, track_pads=%d, blade_pin=%s, blade=%s"),
		BF.Num(), TK.Num(), TP.Num(), NPin >= 0 ? TEXT("ok") : TEXT("missing"), NEdge >= 0 ? TEXT("ok") : TEXT("missing")));
	// lamps placed in the model are lights, not parts to draw
	for (const FRWGltfModel::FLampPoint& L : M->LampPoints()) Assigned.Add(L.Node);
	const TArray<int32> BD = Collect(TEXT("body"));
	if (BD.Num() == 0 || BF.Num() == 0 || NPin < 0 || NEdge < 0)
	{
		RWLog(FString::Printf(TEXT("Dozer model: body (%d parts), blade_frame (%d), blade_pin (%s) and blade (%s) are required - see the part names in Saved/Logs"), BD.Num(), BF.Num(), NPin < 0 ? TEXT("not found") : TEXT("ok"), NEdge < 0 ? TEXT("not found") : TEXT("ok")));
		FString Names; for (const FRWGltfNode& Nd : M->Nodes) Names += Nd.Name + TEXT(", ");
		RWLog(TEXT("Dozer model parts: ") + Names.Left(4000));
		return false;
	}
	// stand it on the ground: the bottom of the tracks
	FBox UB(ForceInit);
	for (int32 n : TP.Num() ? TP : TK.Num() ? TK : BD) UB += M->SubtreeBounds(n, Assigned).TransformBy(M->Nodes[n].World);
	const FTransform M0(FVector(0, 0, -UB.Min.Z));
	auto W = [&](int32 n) { return M->Nodes[n].World * M0; };
	// tracks (the model's own frames and chains stay as they are; the game's shoes are not drawn)
	FBox TB(ForceInit);
	for (int32 n : TK) TB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	for (int32 n : TP) TB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	if (!TB.IsValid) TB = UB.ShiftBy(M0.GetTranslation());
	const FVector TS = TB.GetSize() * CM2M;
	const float TWid = FMath::Clamp(TS.Y * 0.25f, 0.4f, 0.8f);
	TArray<USceneComponent*> Before; Root->GetChildrenComponents(false, Before);
	AddTracks(FMath::Max(TS.X, 2.f), FMath::Max(TS.Y - TWid, 1.2f), TWid, FMath::Max(TS.Z, 0.5f), 6);
	TArray<USceneComponent*> After; Root->GetChildrenComponents(false, After);
	for (USceneComponent* C : After) if (!Before.Contains(C)) C->SetVisibility(false, true);
	TrackLength = FMath::Max(TS.X, 2.f);
	Wheelbase = TrackLength;
	// Rotate wheel meshes around their own bounding-box centres instead of baking
	// them into the static undercarriage. Blender Object Names are the rig keys.
	TrackSpinners.Reset();
	int32 WheelCount = 0;
	for (int32 n : TK)
	{
		const FString& Name = M->Nodes[n].Name;
		const bool bWheel = Name.Contains(TEXT("idler"), ESearchCase::IgnoreCase)
			|| Name.Contains(TEXT("roller"), ESearchCase::IgnoreCase)
			|| Name.Contains(TEXT("sprocket"), ESearchCase::IgnoreCase)
			|| Name.Contains(TEXT("final drive"), ESearchCase::IgnoreCase);
		if (!bWheel) { M->Spawn(this, Root, n, M0.Inverse(), Assigned); continue; }
		const FBox WheelBounds = M->SubtreeBounds(n, Assigned).TransformBy(W(n));
		if (!WheelBounds.IsValid) { M->Spawn(this, Root, n, M0.Inverse(), Assigned); continue; }
		const FVector Centre = WheelBounds.GetCenter();
		const float Radius = FMath::Max(0.05f, (float)(WheelBounds.GetSize().Z * 0.5f * CM2M));
		USceneComponent* WheelPivot = Pivot(Root, Centre * CM2M);
		M->Spawn(this, WheelPivot, n, FTransform(Centre) * M0.Inverse(), Assigned);
		TrackSpinners.Add({WheelPivot, Radius, Centre.Y < 0.f, WheelPivot->GetRelativeRotation().Quaternion()});
		++WheelCount;
	}
	RWLog(FString::Printf(TEXT("Dozer model: %d animated idler/roller/sprocket nodes"), WheelCount));
	// the model's own track pads become the moving chain: the pads' places give its path round the wheels, and one pad
	// of the bottom run (simplified, so that some 80 of them stay quick to draw) is the shoe that goes round it
	if (TP.Num() >= 8)
	{
		int32 Sides = 0;
		// the lowest pad of all: it lies on the ground under the bottom run as the modeller placed it (the shoe to copy when
		// the other pads are not where they show in Blender)
		int32 LowestPad = INDEX_NONE;
		for (int32 n : TP) if (M->MeshPoints.IsValidIndex(M->Nodes[n].Mesh) && (LowestPad == INDEX_NONE || W(n).GetLocation().Z < W(LowestPad).GetLocation().Z)) LowestPad = n;
		for (int32 s = 0; s < 2; ++s)
		{
			// a side's pads: the ones on its side of the machine (pads left at the middle of the model belong to neither)
			TArray<int32> Pads;
			for (int32 n : TP) { const float Py = W(n).GetLocation().Y; if (FMath::Abs(Py) > 20.f && (Py < 0.f) == (s == 0)) Pads.Add(n); }
			// are they spread round the track? (pads placed by an Array / Curve modifier or a constraint in Blender come out of
			// the export all at one place: then the pads only give the shoe's shape and count, the wheels give the path)
			TArray<FVector> Spots;
			for (int32 n : Pads) { const FVector P = W(n).GetLocation(); if (!Spots.ContainsByPredicate([&](const FVector& Q) { return FVector::Dist(P, Q) < 5.f; })) Spots.Add(P); }
			TArray<FVector2D> Pts;
			float Y = 0.f, MinZ = 1e9f;
			int32 Np = INDEX_NONE;
			int32 PadCount = Pads.Num();
			bool bFromWheels = false;
			if (Spots.Num() >= 6)
			{
				// When each link has a numeric suffix, order by that suffix, independent of
				// the GLB node table order. This works for every machine using ordered links.
				bool bNumbered = Pads.Num() >= 8;
				for (int32 n : Pads)
				{
					FString Name = M->Nodes[n].Name, Tail;
					if (!Name.Split(TEXT("_"), nullptr, &Tail, ESearchCase::CaseSensitive, ESearchDir::FromEnd) || Tail.IsEmpty() || !Tail.IsNumeric()) { bNumbered = false; break; }
				}
				if (bNumbered)
				{
					Pads.Sort([&](int32 A, int32 B)
					{
						FString SA, SB;
						M->Nodes[A].Name.Split(TEXT("_"), nullptr, &SA, ESearchCase::CaseSensitive, ESearchDir::FromEnd);
						M->Nodes[B].Name.Split(TEXT("_"), nullptr, &SB, ESearchCase::CaseSensitive, ESearchDir::FromEnd);
						return FCString::Atoi(*SA) < FCString::Atoi(*SB);
					});
				}
				for (int32 n : Pads) { const FVector P = W(n).GetLocation() * CM2M; Pts.Add(FVector2D(P.X, P.Z)); Y += P.Y; MinZ = FMath::Min(MinZ, (float)P.Z); }
				Y /= Pads.Num();
				// Use the artist's actual loop only if neighbours, including the closing
				// pair, have similar spacing; otherwise fall back to the existing hull.
				float TotalStep = 0.f, MaxStep = 0.f, MinStep = 1e9f;
				for (int32 i = 0; i < Pts.Num(); ++i)
				{
					const float D = FVector2D::Distance(Pts[i], Pts[(i + 1) % Pts.Num()]);
					TotalStep += D; MaxStep = FMath::Max(MaxStep, D); MinStep = FMath::Min(MinStep, D);
				}
				const float AvgStep = TotalStep / Pts.Num();
				const bool bOrderedLoop = bNumbered && AvgStep > 0.03f && MaxStep < AvgStep * 1.65f && MinStep > AvgStep * 0.45f;
				if (bOrderedLoop)
				{
					SetOrderedTrackPath(s, Pts, Y);
					ModelTrackLinkCount[s] = Pads.Num();
					RWLog(FString::Printf(TEXT("RWTRACK: side=%s ordered GLB loop, links=%d, length=%.3fm, pitch=%.3fm"),
							s == 0 ? TEXT("left") : TEXT("right"), Pads.Num(), TrackPaths[s].Len, AvgStep));
				}
				else
				{
					SetTrackPath(s, Pts, Y);
					RWLog(FString::Printf(TEXT("RWTRACK: side=%s GLB nodes not a numbered/equidistant loop, using hull"), s == 0 ? TEXT("left") : TEXT("right")));
				}
				if (TrackPaths[s].Len < 0.5f)
				{
					RWLog(FString::Printf(TEXT("Dozer model: %s pad path degenerate (%.3f m); switching to wheel geometry"), s == 0 ? TEXT("left") : TEXT("right"), TrackPaths[s].Len));
					Pts.Reset();
				}
				// the pad in the middle of the bottom run
				TArray<TPair<float, int32>> Low;
				for (int32 n : Pads) { const FVector P = W(n).GetLocation() * CM2M; if (P.Z < MinZ + 0.03f) Low.Add({(float)P.X, n}); }
				Low.Sort([](const TPair<float, int32>& A, const TPair<float, int32>& B) { return A.Key < B.Key; });
				Np = Low.Num() ? Low[Low.Num() / 2].Value : Pads[0];
			}
			if (TrackPaths[s].Len < 0.5f && LowestPad != INDEX_NONE)
			{
				// the path round this side's wheels (idler, sprocket, rollers): the belt over them, the pad's middle as far
				// below the wheels' bottom as the placed pad lies
				TArray<const FSpinner*> Side;
				for (const FSpinner& Sp : TrackSpinners) if (Sp.P && Sp.bLeft == (s == 0)) Side.Add(&Sp);
				if (Side.Num() < 2) { RWLog(FString::Printf(TEXT("Dozer model: %s track: insufficient wheel nodes for wheel-based path; retaining procedural fallback"), s == 0 ? TEXT("left") : TEXT("right"))); continue; }
				float Bottom = 1e9f, YSum = 0.f;
				for (const FSpinner* Sp : Side) { const FVector C = Sp->P->GetRelativeLocation() * CM2M; Bottom = FMath::Min(Bottom, (float)C.Z - Sp->Radius); YSum += C.Y; }
				const float PadZ = W(LowestPad).GetLocation().Z * CM2M;
				const float Off = FMath::Clamp(Bottom - PadZ, 0.02f, 0.3f);
				for (const FSpinner* Sp : Side)
				{
					const FVector C = Sp->P->GetRelativeLocation() * CM2M;
					const float R = Sp->Radius + Off;
					for (int32 a = 0; a < 48; ++a) { const float A = a / 48.f * 2.f * PI; Pts.Add(FVector2D(C.X + FMath::Cos(A) * R, C.Z + FMath::Sin(A) * R)); }
				}
				Y = YSum / Side.Num();
				SetTrackPath(s, Pts, Y);
				if (TrackPaths[s].Len < 0.5f) { RWLog(TEXT("Dozer model: wheel-derived track path is degenerate; retaining procedural fallback")); continue; }
				Np = LowestPad;
				bFromWheels = true;
			}
			if (Np == INDEX_NONE) continue;
			const int32 Mh = M->Nodes[Np].Mesh;
			if (!M->MeshPoints.IsValidIndex(Mh) || !M->MeshTris.IsValidIndex(Mh)) continue;
			const FTransform Wn = W(Np);
			const FVector Origin = Wn.GetLocation();
			FMeshBuild Bd;
			for (const FVector3f& P : M->MeshPoints[Mh]) { Bd.P.Add(FVector3f((Wn.TransformPosition(FVector(P)) - Origin) * CM2M)); Bd.N.Add(FVector3f::ZeroVector); Bd.UV.Add(FVector2f(0.f, 0.f)); }
			Bd.T = M->MeshTris[Mh];
			const int32 TrisBefore = Bd.T.Num() / 3;
			RWSimplify(Bd, 0.015f);
			if (UStaticMesh* PadMesh = FRWMeshGen::Build(FString::Printf(TEXT("trackpad_%08x_%d_%d"), GetTypeHash(M->Path), Np, s), Bd))
			{
				TrackShoeMesh[s] = PadMesh;
				if (bFromWheels)
				{
					// one pad per pad length round the path (they overlap a little at the hinges)
					float X0 = 1e9f, X1 = -1e9f;
					for (const FVector3f& P : Bd.P) { X0 = FMath::Min(X0, P.X); X1 = FMath::Max(X1, P.X); }
					TrackShoePitch = FMath::Clamp((X1 - X0) * 0.97f, 0.12f, 0.45f);
					PadCount = TrackPaths[s].Len > 0.f ? FMath::RoundToInt(TrackPaths[s].Len / TrackShoePitch) : 0;
				}
				else if (TrackPaths[s].Len > 0.f) TrackShoePitch = TrackPaths[s].Len / Pads.Num();
				// the pad's own material; a pad with none is dark worn steel (or the mod's "track_pad_color")
				TrackShoeMat = DarkMID;
				if (M->MeshMats.IsValidIndex(Mh) && M->MeshMats[Mh].Num() > 0 && M->MeshMats[Mh][0] && M->MeshMats[Mh][0] != FRWGltfModel::PlainMat) TrackShoeMat = M->MeshMats[Mh][0];
				const TArray<TSharedPtr<FJsonValue>>* PC;
				if (MD->Def->TryGetArrayField(TEXT("track_pad_color"), PC) && PC->Num() >= 3)
				{
					UMaterialInstanceDynamic* Pm = UMaterialInstanceDynamic::Create(GPaint, this);
					Pm->SetVectorParameterValue(TEXT("Color"), FLinearColor((*PC)[0]->AsNumber(), (*PC)[1]->AsNumber(), (*PC)[2]->AsNumber()));
					Pm->SetScalarParameterValue(TEXT("Metallic"), 0.6f);
					Pm->SetScalarParameterValue(TEXT("Roughness"), 0.6f);
					TrackShoeMat = Pm;
				}
				RWLog(FString::Printf(TEXT("Dozer model: %s track %s, %d pads, path %.2f m, pitch %.3f m, pad %d -> %d triangles"), s == 0 ? TEXT("left") : TEXT("right"),
					bFromWheels ? TEXT("round its wheels (the model's pads were not spread round the track - in Blender apply the modifiers / constraints that place them)") : TEXT("from the pads of the model"),
					PadCount, TrackPaths[s].Len, TrackShoePitch, TrisBefore, Bd.T.Num() / 3));
				++Sides;
			}
		}
		if (Sides)
		{
			RWLog(FString::Printf(TEXT("Dozer track: built %d GLB shoe chain(s), mesh left=%s, right=%s"),
				Sides, TrackShoeMesh[0] ? TEXT("GLB") : TEXT("fallback"), TrackShoeMesh[1] ? TEXT("GLB") : TEXT("fallback")));
			BuildTrackShoes(TWid);
			if (ShoesL) ShoesL->SetVisibility(true, true);
			if (ShoesR) ShoesR->SetVisibility(true, true);
		}
	}
	for (int32 n : BD) M->Spawn(this, Body, n, M0.Inverse(), Assigned);
	// the blade: its frame turns about the pins (trunnions); the cutting edge is the lowest front line of the blade
	const FVector Pin = W(NPin).GetLocation();
	const FBox EB = M->SubtreeBounds(NEdge, Assigned).TransformBy(W(NEdge));
	const FVector Edge(EB.Max.X, 0.f, EB.Min.Z);
	CFrameP = Pivot(Body, Pin * CM2M);
	for (int32 n : BF) M->Spawn(this, CFrameP, n, FTransform(Pin) * M0.Inverse(), Assigned);
	// The articulated blade has two independent joints beneath the existing
	// lifting/tilting frame. GLB <reference> markers are optional; without them
	// an approximate rear-centre pivot is used and must be inspected in-game.
	FString AnglePinName, PitchPinName;
	Rig->TryGetStringField(TEXT("blade_angle_pin"), AnglePinName);
	Rig->TryGetStringField(TEXT("blade_pitch_pin"), PitchPinName);
	const int32 NAnglePin = AnglePinName.IsEmpty() ? INDEX_NONE : M->Find(AnglePinName);
	const int32 NPitchPin = PitchPinName.IsEmpty() ? INDEX_NONE : M->Find(PitchPinName);
	const FVector DefaultBladePivot(FMath::Lerp(EB.Min.X, EB.Max.X, 0.2f), EB.GetCenter().Y, EB.GetCenter().Z);
	const FVector AnglePin = NAnglePin >= 0 ? W(NAnglePin).GetLocation() : DefaultBladePivot;
	const FVector PitchPin = NPitchPin >= 0 ? W(NPitchPin).GetLocation() : AnglePin;
	USceneComponent* AnglePivot = Pivot(CFrameP, (AnglePin-Pin)*CM2M);
	USceneComponent* PitchPivot = Pivot(AnglePivot, (PitchPin-AnglePin)*CM2M);
	XmlGltfNodes.Add(TEXT("blade_angle_pivot"), AnglePivot);
	XmlGltfNodes.Add(TEXT("blade_pitch_pivot"), PitchPivot);
	M->Spawn(this, PitchPivot, NEdge, FTransform(PitchPin) * M0.Inverse(), Assigned);
	UE_LOG(LogTemp, Log, TEXT("RWXML: blade joint pivots created angle=%s pitch=%s (reference markers: angle=%s pitch=%s)"),
		*AnglePin.ToString(), *PitchPin.ToString(), NAnglePin >= 0 ? TEXT("GLB") : TEXT("fallback"), NPitchPin >= 0 ? TEXT("GLB") : TEXT("fallback"));
	// Explicit one-node GLB components for generic XML hydraulics. Only meshes named in
	// <modelRig><group name="hydraulic_parts"> are detached from merged body/blade meshes.
	for (int32 n : HydraulicNodes)
	{
		if (!M->Nodes.IsValidIndex(n)) continue;
		const FTransform Rest = W(n);
		USceneComponent* Hinge = Pivot(Body, Rest.GetLocation() * CM2M, Rest.GetRotation().Rotator());
		M->Spawn(this, Hinge, n, Rest * M0.Inverse(), Assigned);
		const FString NodeName = M->Nodes[n].Name;
		XmlGltfNodes.Add(NodeName.ToLower(), Hinge);
		// its vertices in the pivot's own space (the pivot stands where the node does, unscaled), at most ~4000 of them
		TArray<FVector>& NodePts = XmlGltfNodePoints.Add(NodeName.ToLower());
		const int32 Mh = M->Nodes[n].Mesh;
		if (M->MeshPoints.IsValidIndex(Mh))
		{
			const FTransform HingeT(Rest.GetRotation(), Rest.GetLocation());
			const TArray<FVector3f>& Src = M->MeshPoints[Mh];
			const int32 Step = FMath::Max(1, Src.Num() / 4000);
			for (int32 i = 0; i < Src.Num(); i += Step) NodePts.Add(HingeT.InverseTransformPosition(Rest.TransformPosition(FVector(Src[i]))));
		}
		UE_LOG(LogTemp, Log, TEXT("RWXML: GLB hydraulic node registered name=%s (%d points)"), *NodeName, NodePts.Num());
	}

	CFrameL = FMath::Max(FVector2D(Edge.X - Pin.X, Edge.Z - Pin.Z).Size() * CM2M, 0.5f);
	CFrameA0 = FMath::Asin(FMath::Clamp((Edge.Z - Pin.Z) * CM2M / CFrameL, -1.f, 1.f));
	CFramePinZ = Pin.Z * CM2M;
	BladeX = Edge.X * CM2M;
	BladeW = EB.GetSize().Y * CM2M;
	BladeTall = FMath::Clamp((float)EB.GetSize().Z * CM2M, 0.6f, 2.f);
	BladeH = Edge.Z * CM2M;
	BladeP = Pivot(Root, FVector(BladeX, 0, BladeH)); // (where the physics cuts; nothing drawn on it)
	RipperP = Pivot(Root, FVector(-2.15f, 0, 0.5f));
	bHasRipper = false;
	bRipper = false;
	// the operator: the model's own camera point, or the middle of the body high up
	FBox BB(ForceInit);
	for (int32 n : BD) BB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	// (or seated: eyes 0.85 m over the seat and a little ahead of it)
	FVector Eye = NEye >= 0 ? W(NEye).GetLocation() : NSeat >= 0 ? W(NSeat).GetLocation() + FVector(15.f, 0.f, 85.f) : FVector(BB.GetCenter().X - BB.GetExtent().X * 0.4f, 0.f, BB.Max.Z - 60.f);
	{
		const TArray<TSharedPtr<FJsonValue>>* EyeA;
		if (Rig->TryGetArrayField(TEXT("cab_eye"), EyeA) && EyeA->Num() == 3)
		{
			const FVector G((*EyeA)[0]->AsNumber(), (*EyeA)[1]->AsNumber(), (*EyeA)[2]->AsNumber());
			Eye = FRotator(0.f, (float)MYaw, 0.f).RotateVector(FVector(G.X, G.Z, G.Y) * 100.f * MScale) + M0.GetTranslation();
		}
	}
	CabRoot = Pivot(Body, Eye * CM2M);
	CabCam->AttachToComponent(CabRoot, FAttachmentTransformRules::KeepRelativeTransform);
	CabCam->SetRelativeLocation(FVector::ZeroVector);
	SeatPos = Eye * CM2M - FVector(0, 0, 0.6f);
	Radius2D = FMath::Max(BB.GetSize().X, BB.GetSize().Y) * CM2M * 0.6f;
	// lamps: where the model puts them (body, or "blade" for ones on the push frame), otherwise two on the front of the body
	const int32 OwnLamps = RWModelLamps(this, *M, *MD->Def, M0, (float)MYaw, (float)MScale, [&](const FString& Part, FTransform& Rest) -> USceneComponent*
	{
		if (Part == TEXT("blade") || Part == TEXT("blade_frame")) { Rest = FTransform(Pin); return CFrameP; }
		if (Part == TEXT("tracks") || Part == TEXT("undercarriage")) { Rest = FTransform::Identity; return Root; }
		Rest = FTransform::Identity; return Body;
	});
	if (OwnLamps == 0)
	{
		AddLamp(Body, FVector(BB.Max.X - 20.f, -BB.GetExtent().Y * 0.4f, BB.Max.Z - 60.f) * CM2M, FRotator(-12, 0, 0), 10000, false);
		AddLamp(Body, FVector(BB.Max.X - 20.f, BB.GetExtent().Y * 0.4f, BB.Max.Z - 60.f) * CM2M, FRotator(-12, 0, 0), 10000, false);
	}
	RWLog(FString::Printf(TEXT("Dozer model: %s, tracks %.2f x %.2f m, blade %.2f m wide, edge %.2f m ahead, push frame %.2f m"), *File, TS.X, TS.Y, BladeW, BladeX, CFrameL));
	return true;
}

bool ARWExcavator::BuildFromModel()
{
	const FRWModMachine* MD = PendingMod;
	if (!MD || !MD->Def.IsValid()) return false;
	FString File;
	if (!MD->Def->TryGetStringField(TEXT("model"), File)) return false;
	double MYaw = -90.0, MScale = 1.0;
	MD->Def->TryGetNumberField(TEXT("model_yaw"), MYaw);
	MD->Def->TryGetNumberField(TEXT("model_scale"), MScale);
	TSharedPtr<FRWGltfModel> M = FRWGltfModel::Get(MD->Folder / File, (float)MScale, (float)MYaw);
	if (!M.IsValid()) return false;
	const TSharedPtr<FJsonObject>* MatSection;
	if (MD->Def->TryGetObjectField(TEXT("materials"), MatSection)) M->ApplyMaterialOverrides(**MatSection);
	const TSharedPtr<FJsonObject>* RigObj;
	if (!MD->Def->TryGetObjectField(TEXT("rig"), RigObj)) { RWLog(TEXT("Model rig: \"rig\" section missing")); return false; }
	const TSharedPtr<FJsonObject> Rig = *RigObj;

	// --- collect node lists by name ("name*" starts so, "*name*" contains, "*" = all the rest) ---
	TSet<int32> Assigned;
	for (const FRWGltfModel::FLampPoint& L : M->LampPoints()) Assigned.Add(L.Node); // (lamps are lights, not parts)
	auto Collect = [&](const TCHAR* Key) { return RWMatchNodes(*M, *Rig, Key, Assigned); };
	const TArray<int32> UC = Collect(TEXT("undercarriage")), HS = Collect(TEXT("house")), BM = Collect(TEXT("boom")), AR = Collect(TEXT("arm")), BK = Collect(TEXT("bucket"));
	const TArray<int32> DR = Collect(TEXT("door")), CB = Collect(TEXT("cab"));
	const TArray<int32> TK = Collect(TEXT("tracks")), RL = Collect(TEXT("rollers"));
	Collect(TEXT("hide"));
	FString LinkArmName, LinkBktName, LinkRodName;
	{
		const TSharedPtr<FJsonObject>* LK;
		if (Rig->TryGetObjectField(TEXT("bucket_linkage"), LK))
		{
			(*LK)->TryGetStringField(TEXT("link_arm"), LinkArmName);
			(*LK)->TryGetStringField(TEXT("link_bucket"), LinkBktName);
			(*LK)->TryGetStringField(TEXT("cylinder_rod"), LinkRodName);
		}
	}
	const int32 NLinkArm = M->Find(LinkArmName), NLinkBkt = M->Find(LinkBktName), NLinkRod = M->Find(LinkRodName);
	for (int32 n : {NLinkArm, NLinkBkt}) if (n >= 0) Assigned.Add(n);
	struct FCylDef { int32 Barrel = -1, Rod = -1; FString BarrelOn, RodOn; };
	TArray<FCylDef> Cyl;
	const TArray<TSharedPtr<FJsonValue>>* CylA;
	if (MD->Def->TryGetArrayField(TEXT("cylinders"), CylA))
		for (const TSharedPtr<FJsonValue>& V : *CylA)
		{
			const TSharedPtr<FJsonObject> C = V->AsObject();
			FCylDef D;
			D.Barrel = M->Find(C->GetStringField(TEXT("barrel")));
			D.Rod = M->Find(C->GetStringField(TEXT("rod")));
			C->TryGetStringField(TEXT("barrel_on"), D.BarrelOn);
			C->TryGetStringField(TEXT("rod_on"), D.RodOn);
			if (D.Barrel >= 0 && D.Rod >= 0) { Cyl.Add(D); Assigned.Add(D.Barrel); Assigned.Add(D.Rod); }
		}
	if (HS.Num() == 0 || BM.Num() == 0 || AR.Num() == 0 || BK.Num() == 0)
	{
		RWLog(TEXT("Model rig: house, boom, arm and bucket parts are required"));
		return false;
	}
	auto PivotNode = [&](const TCHAR* Key, const TArray<int32>& L)
	{
		const TSharedPtr<FJsonObject>* Pv; FString Nm;
		if (Rig->TryGetObjectField(TEXT("pivots"), Pv) && (*Pv)->TryGetStringField(Key, Nm) && M->Find(Nm) >= 0) return M->Find(Nm);
		return L[0];
	};
	// --- place the model so the tracks stand on the ground ---
	FBox UB(ForceInit);
	for (int32 n : UC.Num() ? UC : HS) UB += M->SubtreeBounds(n, Assigned).TransformBy(M->Nodes[n].World);
	for (int32 n : TK) UB += M->SubtreeBounds(n, Assigned).TransformBy(M->Nodes[n].World); // the chain's grousers touch the ground
	const FTransform M0(FVector(0, 0, -UB.Min.Z)); // model space -> machine root space
	auto W = [&](int32 n) { return M->Nodes[n].World * M0; };
	auto Loc = [&](int32 n) { return W(n).GetLocation(); };

	// --- undercarriage & tracks (physics contact points come from its size) ---
	const FVector USz = UB.GetSize() * CM2M;
	// track chains listed under "tracks" are replaced by the game's moving track shoes, laid on the same path
	FBox TB(ForceInit);
	for (int32 n : TK) TB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	const bool bAnimTracks = TK.Num() > 0 && TB.IsValid;
	const float TLen = bAnimTracks ? TB.GetSize().X * CM2M : FMath::Max(USz.X, 2.f);
	const float TWid = bAnimTracks ? FMath::Clamp(M->SubtreeBounds(TK[0], Assigned).TransformBy(W(TK[0])).GetSize().Y * CM2M, 0.3f, 1.f) : FMath::Clamp(USz.Y * 0.2f, 0.4f, 0.9f);
	const float TGauge = bAnimTracks ? TB.GetSize().Y * CM2M - TWid : FMath::Max(USz.Y - TWid, 1.2f);
	const float THgt = bAnimTracks ? TB.GetSize().Z * CM2M : 0.9f;
	TArray<USceneComponent*> Before; Root->GetChildrenComponents(false, Before);
	AddTracks(FMath::Max(TLen, 2.f), FMath::Max(TGauge, 1.2f), TWid, THgt, 7);
	TArray<USceneComponent*> After; Root->GetChildrenComponents(false, After);
	for (USceneComponent* C : After) if (!Before.Contains(C) && C != ShoesL && C != ShoesR) C->SetVisibility(false, true); // model has its own frames
	if (bAnimTracks)
	{
		TrackRadOverride = THgt * 0.5f - 0.07f;
		TrackShoeZ = TB.Min.Z * CM2M + 0.07f;
		TrackShoeMat = DarkMID;
		for (USceneComponent* Sh : {ShoesL, ShoesR}) if (Sh) Sh->SetVisibility(true, true);
	}
	else { if (ShoesL) ShoesL->SetVisibility(false, true); if (ShoesR) ShoesR->SetVisibility(false, true); }
	TrackLength = FMath::Max(TLen, 2.f);
	Wheelbase = TrackLength;
	Radius2D = FMath::Max(USz.X, USz.Y) * 0.6f;
	// sprockets, idlers and rollers spin on their own centres
	TSet<int32> Spun;
	for (int32 n : RL)
	{
		const FTransform WR = W(n);
		const FBox RB = M->SubtreeBounds(n, Assigned).TransformBy(WR);
		if (!RB.IsValid) continue;
		// pivot axes = machine axes, so the wheel turns about the sideways (Y) axle
		const FVector C = RB.GetCenter();
		USceneComponent* P = Pivot(Root, C * CM2M);
		M->Spawn(this, P, n, FTransform(C) * M0.Inverse(), Assigned);
		TrackSpinners.Add({P, (float)(RB.GetSize().Z * 0.5f * CM2M), C.Y < 0.f, FQuat::Identity});
		Spun.Add(n);
	}
	for (int32 n : UC) if (!Spun.Contains(n) && !TK.Contains(n)) M->Spawn(this, Root, n, M0.Inverse(), Assigned);
	// lay each chain around that side's own sprocket, idler and rollers (like a belt), touching the model's track bottom
	if (bAnimTracks)
	{
		for (int32 s = 0; s < 2; ++s)
		{
			// that side's chain from the model (left = negative Y)
			FBox KB(ForceInit);
			for (int32 n : TK)
			{
				const FBox B = M->SubtreeBounds(n, Assigned).TransformBy(W(n));
				if (B.IsValid && (B.GetCenter().Y < 0.f) == (s == 0)) KB += B;
			}
			TArray<const FSpinner*> Side;
			// (a part holding the rollers of both sides at once stands in the middle and has no say in the chain's shape)
			for (const FSpinner& Sp : TrackSpinners)
				if (Sp.P && Sp.bLeft == (s == 0) && FMath::Abs(Sp.P->GetRelativeLocation().Y * CM2M) > TrackGauge * 0.25f) Side.Add(&Sp);
			TArray<FVector2D> Pts;
			float Y = (s == 0 ? -1.f : 1.f) * TrackGauge * 0.5f;
			const float GroundZ = (KB.IsValid ? KB.Min.Z : TB.Min.Z) * CM2M;
			if (Side.Num() >= 2)
			{
				float Bottom = 1e9f, YSum = 0.f;
				for (const FSpinner* Sp : Side)
				{
					const FVector C = Sp->P->GetRelativeLocation() * CM2M;
					Bottom = FMath::Min(Bottom, C.Z - Sp->Radius); YSum += C.Y;
				}
				// wheel rim to shoe plate centre; the grouser reaches 7 cm below the plate onto the model's track bottom
				const float Off = FMath::Clamp(Bottom - GroundZ - 0.07f, 0.03f, 0.2f);
				for (const FSpinner* Sp : Side)
				{
					const FVector C = Sp->P->GetRelativeLocation() * CM2M;
					const float R = Sp->Radius + Off;
					for (int32 a = 0; a < 48; ++a) { const float A = a / 48.f * 2.f * PI; Pts.Add(FVector2D(C.X + FMath::Cos(A) * R, C.Z + FMath::Sin(A) * R)); }
				}
				Y = YSum / Side.Num();
			}
			else if (KB.IsValid)
			{
				// no wheels listed: wrap the shoes round the model's own track outline (two end wheels)
				const FVector Mn = KB.Min * CM2M, Mx = KB.Max * CM2M;
				const float H = Mx.Z - Mn.Z, R = FMath::Max(H * 0.5f - 0.07f, 0.08f), Zc = Mn.Z + 0.07f + R;
				for (const float X : {Mn.X + 0.07f + R, Mx.X - 0.07f - R})
					for (int32 a = 0; a < 48; ++a) { const float A = a / 48.f * 2.f * PI; Pts.Add(FVector2D(X + FMath::Cos(A) * R, Zc + FMath::Sin(A) * R)); }
			}
			if (KB.IsValid) Y = KB.GetCenter().Y * CM2M; // centre the shoes on the model's chain
			SetTrackPath(s, Pts, Y);
			// the chain's own links, when the mod asks for them
			bool bOwnShoes = false;
			if (MD->Def->TryGetBoolField(TEXT("track_shoes_from_model"), bOwnShoes) && bOwnShoes && Side.Num() >= 2)
			{
				float Bottom = 1e9f;
				for (const FSpinner* Sp : Side) Bottom = FMath::Min(Bottom, (float)(Sp->P->GetRelativeLocation().Z * CM2M) - Sp->Radius);
				const float Off = FMath::Clamp(Bottom - GroundZ - 0.07f, 0.03f, 0.2f);
				for (int32 n : TK)
				{
					const FBox B = M->SubtreeBounds(n, Assigned).TransformBy(W(n));
					if (!B.IsValid || (B.GetCenter().Y < 0.f) != (s == 0)) continue;
					UStaticMesh* ChainLink = nullptr; float LinkPitch = 0.f;
					// the chain path lies Bottom - Off above the ground, so the link is cut out at that height: its plates then stand on the ground
					if (RWShoeFromChain(*M, n, W(n), Bottom - Off - GroundZ, ChainLink, LinkPitch))
					{
						TrackShoeMesh[s] = ChainLink;
						TrackShoePitch = LinkPitch;
						if (M->MeshMats.IsValidIndex(M->Nodes[n].Mesh) && M->MeshMats[M->Nodes[n].Mesh].Num() > 0) TrackShoeMat = M->MeshMats[M->Nodes[n].Mesh][0];
					}
					break;
				}
			}
			else if (MD->Def->TryGetBoolField(TEXT("track_shoes_from_model"), bOwnShoes) && bOwnShoes && TK.Num() >= 16)
			{
				// a chain modelled as separate link parts: one link of the bottom run becomes the moving shoe
				TArray<TPair<float, int32>> Bottom;
				float MinZ = 1e9f;
				for (int32 n : TK) { const FBox B = M->SubtreeBounds(n, Assigned).TransformBy(W(n)); if (B.IsValid && (B.GetCenter().Y < 0.f) == (s == 0)) MinZ = FMath::Min(MinZ, B.Min.Z); }
				for (int32 n : TK)
				{
					const FBox B = M->SubtreeBounds(n, Assigned).TransformBy(W(n));
					if (B.IsValid && (B.GetCenter().Y < 0.f) == (s == 0) && B.GetCenter().Z < MinZ + 15.f && M->MeshPoints.IsValidIndex(M->Nodes[n].Mesh)) Bottom.Add({(float)B.GetCenter().X, n});
				}
				Bottom.Sort([](const TPair<float, int32>& A, const TPair<float, int32>& B) { return A.Key < B.Key; });
				if (Bottom.Num() >= 4)
				{
					TArray<float> Gaps;
					for (int32 i = 1; i < Bottom.Num(); ++i) if (Bottom[i].Key - Bottom[i - 1].Key > 3.f) Gaps.Add(Bottom[i].Key - Bottom[i - 1].Key);
					Gaps.Sort();
					const int32 Nb = Bottom[Bottom.Num() / 2].Value, Mh = M->Nodes[Nb].Mesh;
					const FTransform Wn = W(Nb);
					const FVector Origin(Bottom[Bottom.Num() / 2].Key, KB.GetCenter().Y, MinZ + 7.f);
					FMeshBuild Bd;
					for (const FVector3f& P : M->MeshPoints[Mh]) { Bd.P.Add(FVector3f((Wn.TransformPosition(FVector(P)) - Origin) * CM2M)); Bd.N.Add(FVector3f::ZeroVector); Bd.UV.Add(FVector2f(0.f, 0.f)); }
					Bd.T = M->MeshTris[Mh];
					for (int32 t = 0; t + 2 < Bd.T.Num(); t += 3)
					{
						const FVector3f Fn = FVector3f::CrossProduct(Bd.P[Bd.T[t + 2]] - Bd.P[Bd.T[t]], Bd.P[Bd.T[t + 1]] - Bd.P[Bd.T[t]]);
						Bd.N[Bd.T[t]] += Fn; Bd.N[Bd.T[t + 1]] += Fn; Bd.N[Bd.T[t + 2]] += Fn;
					}
					for (FVector3f& Nn : Bd.N) Nn = Nn.GetSafeNormal();
					if (UStaticMesh* LinkMesh = FRWMeshGen::Build(FString::Printf(TEXT("linkshoe_%08x_%d"), GetTypeHash(M->Path), Nb), Bd))
					{
						TrackShoeMesh[s] = LinkMesh;
						TrackShoePitch = Gaps.Num() ? FMath::Clamp(Gaps[Gaps.Num() / 2], 12.f, 35.f) * CM2M : 0.2f;
						if (M->MeshMats.IsValidIndex(Mh) && M->MeshMats[Mh].Num() > 0) TrackShoeMat = M->MeshMats[Mh][0];
					}
				}
			}
		}
		BuildTrackShoes(TWid);
	}

	// --- slewing house ---
	const int32 HP = PivotNode(TEXT("house"), HS);
	const FVector HL = FVector(0, 0, Loc(HP).Z); // swing axis through the machine centre
	House = Pivot(Body, HL * CM2M);
	const FTransform PHouse(HL);
	for (int32 n : HS) M->Spawn(this, House, n, PHouse * M0.Inverse(), Assigned);
	// cab: camera at the operator's eye, door on its hinge
	FBox CabB(ForceInit);
	for (int32 n : CB.Num() ? CB : HS) CabB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	const FVector CabC = CabB.GetCenter(), CabS = CabB.GetSize();
	CabRoot = Pivot(House, (CabC - HL) * CM2M);
	CabCam->AttachToComponent(CabRoot, FAttachmentTransformRules::KeepRelativeTransform);
	CabCam->SetRelativeLocation(FVector(CabS.X * 0.08f, 0, CabS.Z * (CB.Num() ? 0.15f : 0.35f)));
	SeatPos = (CabC - HL) * CM2M;
	{
		// (a cab that is part of one big body mesh: the mod says where the operator's eyes are, in the model's own coordinates)
		const TArray<TSharedPtr<FJsonValue>>* EyeA;
		if (Rig->TryGetArrayField(TEXT("cab_eye"), EyeA) && EyeA->Num() == 3)
		{
			const FVector G((*EyeA)[0]->AsNumber(), (*EyeA)[1]->AsNumber(), (*EyeA)[2]->AsNumber());
			const FVector Eye = FRotator(0.f, (float)MYaw, 0.f).RotateVector(FVector(G.X, G.Z, G.Y) * 100.f * MScale) + M0.GetTranslation();
			CabRoot->SetRelativeLocation((Eye - HL) * CM2M);
			CabCam->SetRelativeLocation(FVector::ZeroVector);
			SeatPos = (Eye - HL) * CM2M - FVector(0, 0, 0.6f);
		}
	}
	if (DR.Num())
	{
		DoorPivot = Pivot(House, (Loc(DR[0]) - HL) * CM2M);
		const FTransform PDoor(Loc(DR[0]));
		for (int32 n : DR) M->Spawn(this, DoorPivot, n, PDoor * M0.Inverse(), Assigned);
	}

	// --- boom / stick / bucket: pivots at the pins, joint angles from the model's rest pose ---
	const int32 BP = PivotNode(TEXT("boom"), BM), AP = PivotNode(TEXT("arm"), AR), KP = PivotNode(TEXT("bucket"), BK);
	const FVector LB = Loc(BP), LA = Loc(AP), LK = Loc(KP);
	auto Ang = [](const FVector& D) { return FMath::RadiansToDegrees(FMath::Atan2(D.Z, D.X)); };
	auto Len = [](const FVector& D) { return FMath::Sqrt(D.X * D.X + D.Z * D.Z); };
	const float A1 = Ang(LA - LB), A2 = Ang(LK - LA);
	Lb = Len(LA - LB) * CM2M; La = Len(LK - LA) * CM2M;
	FBox KB(ForceInit);
	for (int32 n : BK) KB += M->SubtreeBounds(n, Assigned).TransformBy(W(n));
	FVector Tip = KB.GetCenter(); float Best = -1.f;
	for (int32 c = 0; c < 8; ++c)
	{
		const FVector Corner((c & 1) ? KB.Max.X : KB.Min.X, LK.Y, (c & 4) ? KB.Max.Z : KB.Min.Z);
		const float D = Len(Corner - LK);
		if (D > Best) { Best = D; Tip = Corner; }
	}
	const float A3 = Ang(Tip - LK);
	Lk = FMath::Max(Best * CM2M * 0.98f, 0.5f); // the farthest point of the bucket is the teeth
	{
		// which side of the pin-to-teeth line holds the shell, and how deep it is: models differ (the CX250D's
		// shell lies on the bucket frame's -Z side, the built-in buckets on +Z). Measured from the bucket's bounds.
		const FVector Xd = Tip - LK;
		const float XL = FMath::Max(Len(Xd), 1.f);
		const FVector2D X2(Xd.X / XL, Xd.Z / XL), Z2(-X2.Y, X2.X); // bucket frame X and Z in the (forward, up) plane
		const FVector Cn = KB.GetCenter() - LK;
		BucketSign = (Cn.X * Z2.X + Cn.Z * Z2.Y) >= 0.f ? 1.f : -1.f;
		float Deep = 0.f;
		for (int32 c = 0; c < 4; ++c)
		{
			const FVector Cc = FVector((c & 1) ? KB.Max.X : KB.Min.X, 0, (c & 2) ? KB.Max.Z : KB.Min.Z) - LK;
			Deep = FMath::Max(Deep, (Cc.X * Z2.X + Cc.Z * Z2.Y) * BucketSign);
		}
		Bucket.Depth = FMath::Clamp(Deep * CM2M * 0.95f, 0.2f * Lk, 0.9f * Lk);
		RWLog(FString::Printf(TEXT("Model bucket: teeth %.2f m from the pin, shell on the %s side, %.2f m deep"), Lk, BucketSign > 0 ? TEXT("+Z") : TEXT("-Z"), Bucket.Depth));
	}
	BoomA = NormDeg(A1); ArmA = NormDeg(A2 - A1); BktA = NormDeg(A3 - A2);
	BoomLo = FMath::Min(BoomLo, BoomA - 5.f); BoomHi = FMath::Max(BoomHi, BoomA + 5.f);
	ArmLo = FMath::Min(ArmLo, ArmA - 5.f); ArmHi = FMath::Max(ArmHi, ArmA + 5.f);
	BktLo = FMath::Min(BktLo, BktA - 5.f); BktHi = FMath::Max(BktHi, BktA + 5.f);
	BoomP = Pivot(House, (LB - HL) * CM2M, FRotator(BoomA, 0, 0));
	ArmP = Pivot(BoomP, FVector(Lb, 0, 0), FRotator(ArmA, 0, 0));
	BucketP = Pivot(ArmP, FVector(La, 0, 0), FRotator(BktA, 0, 0));
	for (int32 t = 0; t < 4; ++t) ToolRoots.Add(Pivot(BucketP, FVector::ZeroVector));
	const FTransform PBoom(FRotator(A1, 0, 0), LB), PArm(FRotator(A2, 0, 0), FVector(LA.X, LB.Y, LA.Z)), PBkt(FRotator(A3, 0, 0), FVector(LK.X, LB.Y, LK.Z));
	for (int32 n : BM) M->Spawn(this, BoomP, n, PBoom * M0.Inverse(), Assigned);
	for (int32 n : AR) M->Spawn(this, ArmP, n, PArm * M0.Inverse(), Assigned);
	for (int32 n : BK) M->Spawn(this, ToolRoots[0], n, PBkt * M0.Inverse(), Assigned);
	// lamps: where the model puts them (on the house, the cab, the boom or the arm), otherwise two work lamps on the cab
	{
		const FTransform PCab(CabRoot->GetRelativeLocation() * M2CM + HL);
		const int32 OwnLamps = RWModelLamps(this, *M, *MD->Def, M0, (float)MYaw, (float)MScale, [&](const FString& Part, FTransform& Rest) -> USceneComponent*
		{
			if (Part == TEXT("boom")) { Rest = PBoom; return BoomP; }
			if (Part == TEXT("arm") || Part == TEXT("stick")) { Rest = PArm; return ArmP; }
			if (Part == TEXT("cab")) { Rest = PCab; return CabRoot; }
			if (Part == TEXT("undercarriage") || Part == TEXT("tracks")) { Rest = FTransform::Identity; return Root; }
			Rest = PHouse; return House;
		});
		if (OwnLamps == 0)
		{
			AddLamp(CabRoot, FVector(CabS.X * 0.5f, -CabS.Y * 0.35f, CabS.Z * 0.5f) * CM2M, FRotator(-18, 0, 0), 9000, true);
			AddLamp(CabRoot, FVector(CabS.X * 0.5f, CabS.Y * 0.35f, CabS.Z * 0.5f) * CM2M, FRotator(-18, 0, 0), 9000, true);
		}
	}
	{
		// measure the real shell from the bucket's own vertices (in the bucket frame): for slices from the back
		// plate to the teeth, how far the steel reaches on the shell side. The soil cavity follows this profile.
		const FTransform BucketRest = PBkt * M0.Inverse(); // bucket frame -> model space
		TArray<int32> Stack(BK); TSet<int32> Seen;
		TArray<FVector> Pts;
		TArray<int32> PtTris;
		while (Stack.Num())
		{
			const int32 n = Stack.Pop();
			if (Seen.Contains(n)) continue;
			Seen.Add(n);
			const FRWGltfNode& Nd = M->Nodes[n];
			if (M->MeshPoints.IsValidIndex(Nd.Mesh))
			{
				const int32 PtBase = Pts.Num();
				for (const FVector3f& P : M->MeshPoints[Nd.Mesh]) Pts.Add(BucketRest.InverseTransformPosition(Nd.World.TransformPosition(FVector(P))) * CM2M);
				if (M->MeshTris.IsValidIndex(Nd.Mesh)) for (const int32 I : M->MeshTris[Nd.Mesh]) PtTris.Add(PtBase + I);
			}
			for (int32 c : Nd.Children) if (!Assigned.Contains(c) || BK.Contains(c)) Stack.Add(c);
		}
		BucketProfile.Reset();
		if (Pts.Num() > 50)
		{
			float X0 = 1e9f, X1 = -1e9f, YMin = 1e9f, YMax = -1e9f;
			for (const FVector& P : Pts) { X0 = FMath::Min(X0, P.X); X1 = FMath::Max(X1, P.X); YMin = FMath::Min(YMin, P.Y); YMax = FMath::Max(YMax, P.Y); }
			const int32 NB = 20;
			const float YMid = 0.5f * (YMin + YMax), YHalf = 0.5f * (YMax - YMin), SliceW = FMath::Max(X1 - X0, 0.01f) / NB;
			// cross-sections of the steel's real surface: a flat plate has vertices only at its corners, so the triangles
			// are cut at the middle of each slice (with no triangles, the vertices in the slice are all there is)
			TArray<float> Deep, RimS, Wide; Deep.Init(-1e9f, NB); RimS.Init(1e9f, NB); Wide.Init(0.f, NB);
			auto Sample = [&](int32 b, const FVector& P)
			{
				const float Zs = P.Z * BucketSign, Off = FMath::Abs(P.Y - YMid);
				Deep[b] = FMath::Max(Deep[b], Zs);
				Wide[b] = FMath::Max(Wide[b], Off);
				if (Off > 0.72f * YHalf) RimS[b] = FMath::Min(RimS[b], Zs); // the outer part of the width is the side plates: their open edge is the rim
			};
			if (PtTris.Num() >= 3)
				for (int32 t = 0; t + 2 < PtTris.Num(); t += 3)
				{
					const FVector Tv[3] = {Pts[PtTris[t]], Pts[PtTris[t + 1]], Pts[PtTris[t + 2]]};
					const float XLo = FMath::Min3(Tv[0].X, Tv[1].X, Tv[2].X), XHi = FMath::Max3(Tv[0].X, Tv[1].X, Tv[2].X);
					const int32 B0 = FMath::Max(0, FMath::FloorToInt((XLo - X0) / SliceW - 0.5f)), B1 = FMath::Min(NB - 1, FMath::CeilToInt((XHi - X0) / SliceW - 0.5f));
					for (int32 b = B0; b <= B1; ++b)
					{
						const float Xc = X0 + (b + 0.5f) * SliceW;
						for (int32 e = 0; e < 3; ++e)
						{
							const FVector& A = Tv[e]; const FVector& C = Tv[(e + 1) % 3];
							if ((A.X - Xc) * (C.X - Xc) > 0.f || A.X == C.X) continue;
							Sample(b, FMath::Lerp(A, C, (Xc - A.X) / (C.X - A.X)));
						}
					}
				}
			else
				for (const FVector& P : Pts) Sample(FMath::Clamp(FMath::FloorToInt((P.X - X0) / SliceW), 0, NB - 1), P);
			FString Dbg;
			for (int32 b = 0; b < NB; ++b) Dbg += FString::Printf(TEXT(" [%.2f deep %.2f rim %.2f hw %.2f]"), X0 + (b + 0.5f) * SliceW, Deep[b], RimS[b] > 1e8f ? -9.f : RimS[b], Wide[b]);
			RWLog(FString::Printf(TEXT("Model bucket slices (Lk %.2f, Y %.2f..%.2f, sign %.0f):%s"), Lk, YMin, YMax, BucketSign, *Dbg));
			// only the part of the length that has side plates is a cavity (what sticks out behind them is the mounting ears)
			TArray<float> Rims, Halfs;
			for (int32 b = 0; b < NB; ++b)
				if (Deep[b] > -1e8f && RimS[b] < 1e8f)
				{
					const float Xc = X0 + (b + 0.5f) * SliceW;
					BucketProfile.Add(FVector2D(Xc, Deep[b]));
					// rim level: read it along the middle of the bucket, not at the ears or the teeth
					if (b >= NB * 3 / 20 && b < NB * 15 / 20 && Deep[b] - RimS[b] > 0.1f) Rims.Add(RimS[b]);
					if (b >= NB * 6 / 20 && b < NB * 14 / 20) Halfs.Add(Wide[b]);
				}
			// the soil's level-full plane stands at the lowest point of the rim: no daylight under the load anywhere
			BucketRimZ = 0.02f;
			for (const float R : Rims) BucketRimZ = FMath::Max(BucketRimZ, R);
			if (Halfs.Num() > 0)
			{
				Halfs.Sort();
				const float KbW = FMath::Max(KB.GetSize().Y * CM2M, 0.1f);
				BucketInnerFrac = FMath::Clamp(2.f * (Halfs[Halfs.Num() / 2] - 0.035f) / KbW, 0.7f, 0.97f);
			}
			RWLog(FString::Printf(TEXT("Model bucket shell profile: %d slices from %.2f to %.2f m, deepest %.2f m, rim level %.2f m, soil width %.0f%%"), BucketProfile.Num(), X0, X1, FMath::Max<float>(Deep), BucketRimZ, BucketInnerFrac * 100.f));
			// the steel itself, and the INSIDE of it: the profile above is the outermost steel in each slice (wear strips and
			// ribs under the floor included), so the soil's own limits are read with rays from the open mouth instead -
			// down onto the inside of the floor and out sideways onto the inside of the side plates
			BucketSteel.Reset(); BucketInside.Reset();
			BucketYMid = YMid;
			if (PtTris.Num() >= 3) for (const int32 I : PtTris) BucketSteel.Add(Pts[I]);
			if (BucketSteel.Num() >= 3)
			{
				const FVector Down(0.f, 0.f, BucketSign); // into the shell
				FString Dbg2;
				for (int32 b = 0; b < NB; ++b)
				{
					if (Deep[b] < -1e8f || RimS[b] > 1e8f) continue;
					const float Xc = X0 + (b + 0.5f) * SliceW;
					const float HwOut = Wide[b];
					// the floor: from well out in front of the mouth, straight in; the shallowest of three lines across the
					// width (the middle and towards both plates, where a rounded corner comes up)
					float Floor = 1e9f;
					for (const float Yf : {0.f, -0.6f, 0.6f})
					{
						const FVector O(Xc, YMid + Yf * HwOut, (RimS[b] - 0.6f) * BucketSign);
						float Tt;
						if (ARWExcavator::RaySteel(BucketSteel, O, Down, 3.f, Tt)) Floor = FMath::Min(Floor, RimS[b] - 0.6f + Tt);
					}
					if (Floor > 1e8f || Floor <= RimS[b]) continue; // (no floor under this slice, or the ray met the rim first)
					// the side plates: from the middle out, half way down the cavity and just above the floor
					float Half = 1e9f;
					for (const float Zf : {0.5f, 0.85f})
					{
						const float Zs = FMath::Lerp(RimS[b], Floor, Zf);
						for (const float Sy : {-1.f, 1.f})
						{
							float Tt;
							if (ARWExcavator::RaySteel(BucketSteel, FVector(Xc, YMid, Zs * BucketSign), FVector(0.f, Sy, 0.f), 2.f * HwOut + 0.2f, Tt)) Half = FMath::Min(Half, Tt);
						}
					}
					if (Half > 1e8f) Half = HwOut - 0.035f;
					BucketInside.Add(FVector(Xc, Floor, Half));
					Dbg2 += FString::Printf(TEXT(" [%.2f floor %.2f (outer %.2f) half %.2f (outer %.2f)]"), Xc, Floor, Deep[b], Half, HwOut);
				}
				RWLog(FString::Printf(TEXT("Model bucket inside (rays on %d steel triangles):%s"), BucketSteel.Num() / 3, *Dbg2));
			}
		}
	}
	Bucket.Width = FMath::Clamp(KB.GetSize().Y * CM2M, 0.5f, 2.5f);
	HeapMID = FRWSoilLook::Make(this, ESoil::DrySoil, 0.2f);
	Heap = MeshPart(ToolRoots[0], FRWMeshGen::SoilLump(1), FVector(0.5f * Lk, 0, 0.15f * Lk * BucketSign), FRotator::ZeroRotator, HeapMID, FVector(0.8f * Lk, Bucket.Width * 0.85f, 0.3f * Lk));
	Heap->SetVisibility(false);

	// --- hydraulic cylinders: barrel and rod pivot on their pins and point at each other ---
	struct FPart { USceneComponent* C; FTransform Rest; };
	auto PartOf = [&](const FString& Nm) -> FPart
	{
		const FString L = Nm.ToLower();
		if (L == TEXT("boom")) return {BoomP, PBoom};
		if (L == TEXT("arm") || L == TEXT("stick")) return {ArmP, PArm};
		if (L == TEXT("bucket")) return {ToolRoots[0], PBkt};
		if (L == TEXT("undercarriage")) return {Root, FTransform::Identity};
		return {House, PHouse};
	};
	// bucket linkage (four-bar): positions in the stick's frame (x along the stick, z up), cm
	if (NLinkArm >= 0 && NLinkBkt >= 0)
	{
		const FTransform InvArm = PArm.Inverse();
		auto ToArm = [&](const FVector& RootP) { const FVector L = InvArm.TransformPosition(RootP); return FVector2D(L.X, L.Z); };
		Link.A = ToArm(FVector(LK.X, LB.Y, LK.Z));
		const FVector CRoot = Loc(NLinkArm), DRoot = Loc(NLinkBkt);
		Link.C = ToArm(CRoot); Link.D0 = ToArm(DRoot); Link.Dprev = Link.D0;
		Link.Y = InvArm.TransformPosition(CRoot).Y;
		// the bucket-side pin is the far end of the bucket link from its pivot
		const FBox HB = M->SubtreeBounds(NLinkBkt, Assigned).TransformBy(W(NLinkBkt));
		FVector BRoot = DRoot; float Far = -1.f;
		for (int32 c = 0; c < 8; ++c)
		{
			const FVector Corner((c & 1) ? HB.Max.X : HB.Min.X, DRoot.Y, (c & 4) ? HB.Max.Z : HB.Min.Z);
			const float Dd = FVector2D::Distance(FVector2D(Corner.X, Corner.Z), FVector2D(DRoot.X, DRoot.Z));
			if (Dd > Far) { Far = Dd; BRoot = Corner; }
		}
		// the pin sits a little inside the link's outline
		BRoot = DRoot + (BRoot - DRoot) * 0.85f;
		Link.B0 = ToArm(BRoot);
		Link.L1 = FVector2D::Distance(Link.C, Link.D0);
		Link.L2 = FVector2D::Distance(Link.B0, Link.D0);
		Link.BktRest = BktA;
		Link.ArmLink = Pivot(ArmP, FVector(Link.C.X, Link.Y, Link.C.Y) * CM2M);
		Link.BktLink = Pivot(ArmP, FVector(Link.D0.X, Link.Y, Link.D0.Y) * CM2M);
		M->Spawn(this, Link.ArmLink, NLinkArm, FTransform(FVector(Link.C.X, Link.Y, Link.C.Y)) * PArm * M0.Inverse(), Assigned);
		M->Spawn(this, Link.BktLink, NLinkBkt, FTransform(FVector(Link.D0.X, Link.Y, Link.D0.Y)) * PArm * M0.Inverse(), Assigned);
		Link.bOn = Link.L1 > 5.f && Link.L2 > 5.f;
		RigPivots.Add(Link.ArmLink); RigPivots.Add(Link.BktLink);
	}
	for (const FCylDef& C : Cyl)
	{
		const bool bLinkRod = Link.bOn && C.Rod == NLinkRod;
		const FPart PA = PartOf(C.BarrelOn), PB = bLinkRod ? FPart{ArmP, PArm} : PartOf(C.RodOn);
		const FTransform WB(Loc(C.Barrel)), WR(Loc(C.Rod));
		USceneComponent* BarP = Pivot(PA.C, FVector::ZeroVector);
		USceneComponent* RodP = Pivot(PB.C, FVector::ZeroVector);
		const FTransform RelA = WB * PA.Rest.Inverse(), RelB = WR * PB.Rest.Inverse();
		BarP->SetRelativeTransform(RelA);
		RodP->SetRelativeTransform(RelB);
		M->Spawn(this, BarP, C.Barrel, WB * M0.Inverse(), Assigned);
		M->Spawn(this, RodP, C.Rod, WR * M0.Inverse(), Assigned);
		const FVector Axis = (WR.GetLocation() - WB.GetLocation()).GetSafeNormal();
		Aims.Add({BarP, RodP, RelA, Axis});
		Aims.Add({RodP, BarP, RelB, -Axis});
		if (bLinkRod) Link.RodAim = Aims.Num() - 1; // the rod end rides on the linkage joint
		RigPivots.Add(BarP); RigPivots.Add(RodP);
	}
	// unassigned parts ride on the house so nothing goes missing
	for (int32 n = 0; n < M->Nodes.Num(); ++n)
		if (!Assigned.Contains(n) && M->Nodes[n].Parent < 0 && M->Nodes[n].Mesh >= 0) M->Spawn(this, House, n, PHouse * M0.Inverse(), Assigned);

	bModelRig = true;
	CamDist = FMath::Max(14.f, USz.X * 3.5f);
	LastTip = TipWorld();
	RWLog(FString::Printf(TEXT("Model rig %s: boom %.2f m, stick %.2f m, bucket %.2f m, %d cylinders, rest angles %.0f/%.0f/%.0f"), *File, Lb, La, Lk, Cyl.Num(), BoomA, ArmA, BktA));
	return true;
}

void ARWExcavator::UpdateLinkage()
{
	// Bucket pin B turns with the bucket around A; joint D is where a circle of radius L1 around the
	// stick pin C meets a circle of radius L2 around B (the branch nearest last frame's solution).
	const float dB = FMath::DegreesToRadians(BktA - Link.BktRest);
	const FVector2D R = Link.B0 - Link.A;
	const FVector2D B = Link.A + FVector2D(R.X * FMath::Cos(dB) - R.Y * FMath::Sin(dB), R.X * FMath::Sin(dB) + R.Y * FMath::Cos(dB));
	const FVector2D CB = B - Link.C;
	float Dd = CB.Size();
	if (Dd < 1.f) return;
	Dd = FMath::Clamp(Dd, FMath::Abs(Link.L1 - Link.L2) + 0.1f, Link.L1 + Link.L2 - 0.1f);
	const FVector2D U = CB.GetSafeNormal(), Perp(-U.Y, U.X);
	const float A = (Link.L1 * Link.L1 - Link.L2 * Link.L2 + Dd * Dd) / (2.f * Dd);
	const float H = FMath::Sqrt(FMath::Max(Link.L1 * Link.L1 - A * A, 0.f));
	const FVector2D P0 = Link.C + U * A;
	const FVector2D S1 = P0 + Perp * H, S2 = P0 - Perp * H;
	const FVector2D D = FVector2D::DistSquared(S1, Link.Dprev) <= FVector2D::DistSquared(S2, Link.Dprev) ? S1 : S2;
	Link.Dprev = D;
	auto Ang = [](const FVector2D& V) { return FMath::RadiansToDegrees(FMath::Atan2(V.Y, V.X)); };
	Link.ArmLink->SetRelativeRotation(FRotator(Ang(D - Link.C) - Ang(Link.D0 - Link.C), 0, 0));
	Link.BktLink->SetRelativeLocationAndRotation(FVector(D.X, Link.Y, D.Y), FRotator(Ang(B - D) - Ang(Link.B0 - Link.D0), 0, 0));
	if (Aims.IsValidIndex(Link.RodAim))
	{
		FTransform& Rel = Aims[Link.RodAim].RestRel;
		Rel.SetLocation(FVector(D.X, Rel.GetLocation().Y, D.Y));
	}
}

void ARWExcavator::UpdateAims()
{
	// Each cylinder half keeps its rest orientation relative to the part it is pinned to, then turns so
	// its axis points at the other half's pin: the rod slides in and out of the barrel.
	for (const FAim& A : Aims)
	{
		if (!A.P || !A.Target || !A.P->GetAttachParent()) continue;
		const FTransform Base = A.RestRel * A.P->GetAttachParent()->GetComponentTransform();
		const FVector Cur = Base.GetRotation().RotateVector(A.Axis);
		const FVector To = (A.Target->GetComponentLocation() - Base.GetLocation()).GetSafeNormal();
		if (To.IsNearlyZero()) continue;
		const FQuat Delta = FQuat::FindBetweenNormals(Cur.GetSafeNormal(), To);
		A.P->SetWorldLocationAndRotation(Base.GetLocation(), Delta * Base.GetRotation());
	}
}
