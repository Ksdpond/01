#include "RWMachines.h"
#include "RWSoilMech.h"
#include "RWGame.h"
#include "RWMods.h"
#include "RWTerrain.h"
#include "RWLoc.h"
#include "RWEffects.h"
#include "RWAudio.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Camera/CameraComponent.h"
#include "RWMeshGen.h"
#include "RWSoilLook.h"
#include "ProceduralMeshComponent.h"
#include "DrawDebugHelpers.h"

TArray<TWeakObjectPtr<ARWProp>> ARWProp::All;

// --------------------------------------------------------------------------------------------
// Props
// --------------------------------------------------------------------------------------------
ARWProp::ARWProp()
{
	PrimaryActorTick.bCanEverTick = true;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(RootComponent);
	Mesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

FString ARWProp::Label() const
{
	switch (Type) { case 0: return TR(TEXT("Log")); case 1: return TR(TEXT("Boulder")); case 2: return TR(TEXT("Concrete barrier")); default: return TR(TEXT("Culvert pipe")); }
}

void ARWProp::Init(int32 InType, ARWTerrain* InTerrain, const FVector& P, float YawDeg)
{
	Type = InType; Terrain = InTerrain;
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(ARWMachine::GPaint, this);
	M->SetScalarParameterValue(TEXT("Metallic"), 0.f);
	M->SetScalarParameterValue(TEXT("Roughness"), 0.85f);
	switch (Type)
	{
	case 0:
		Mesh->SetStaticMesh(ARWMachine::GCyl);
		Mesh->SetRelativeScale3D(FVector(0.45f, 0.45f, 6.f));
		Mesh->SetRelativeLocation(FVector(0, 0, 300));
		M->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.07f, 0.045f, 0.025f));
		MassKg = 650; FallAngle = 90.f;
		break;
	case 1:
		Mesh->SetStaticMesh(FRWMeshGen::Rock(1, 7));
		Mesh->SetRelativeScale3D(FVector(1.5f, 1.3f, 1.1f));
		Mesh->SetRelativeLocation(FVector(0, 0, 40));
		M->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.16f, 0.15f, 0.14f));
		MassKg = 2600;
		break;
	case 2:
		Mesh->SetStaticMesh(ARWMachine::GCube);
		Mesh->SetRelativeScale3D(FVector(2.f, 0.6f, 0.8f));
		Mesh->SetRelativeLocation(FVector(0, 0, 40));
		M->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.42f, 0.41f, 0.38f));
		MassKg = 1900;
		break;
	default:
		// black corrugated drain pipe, open at both ends so water can run through it
		Mesh->SetStaticMesh(FRWMeshGen::CorrugatedPipe(PipeLen, PipeDia));
		Mesh->SetRelativeLocation(FVector(-0.5f * PipeLen, 0.f, 0.5f * PipeDia) * M2CM);
		M->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.02f, 0.02f, 0.022f));
		M->SetScalarParameterValue(TEXT("Roughness"), 0.65f);
		MassKg = 350;
		break;
	}
	Mesh->SetMaterial(0, M);
	FallYaw = YawDeg;
	SetActorLocationAndRotation(P * M2CM, FRotator(Type == 0 ? -FallAngle : 0.f, YawDeg, 0));
	All.Add(this);
}

void ARWProp::Tick(float Dt)
{
	Super::Tick(Dt);
	// a felled tree: gone 15 s after it came down (pushed, flicked or in a bucket meanwhile)
	if (RemoveAfter > 0.f && Type == 0 && FallAngle >= 90.f)
	{
		LyingTime += Dt;
		if (LyingTime >= RemoveAfter) { Destroy(); return; }
	}
	if (bCarried) { bWasCarried = true; if (PipeFloorCells.Num()) ClearPipeFloor(); }
	if (bCarried || !Terrain) return;
	Dt = FMath::Min(Dt, 0.05f);
	FVector P = GetActorLocation() * CM2M;
	if (Type == 0 && FallAngle < 90.f)
	{
		// felled tree toppling over its base
		VelM.X += Dt * (20.f + FallAngle * 2.f);
		FallAngle = FMath::Min(90.f, FallAngle + VelM.X * Dt);
		if (FallAngle >= 90.f) VelM = FVector::ZeroVector;
		SetActorRotation(FRotator(-FallAngle, FallYaw, 0));
		return;
	}
	// let go after a push: it slides on, braked by the ground (friction about 0.6 of its weight) - a flicked log goes
	// a little further, a heavy rock hardly at all
	if ((Type == 0 || Type == 1) && PushedFrames > 0) --PushedFrames;
	else if ((Type == 0 || Type == 1) && FVector2D(VelM.X, VelM.Y).SizeSquared() > 1e-4f)
	{
		FVector2D H(VelM.X, VelM.Y);
		const float Sp = H.Size(), NewSp = FMath::Max(0.f, Sp - 0.6f * GRAV * Dt);
		H *= NewSp / Sp;
		VelM.X = H.X; VelM.Y = H.Y;
		const FVector2D To = FVector2D(P.X, P.Y) + H * Dt;
		if (Terrain->InBounds(To.X, To.Y)) { P.X = To.X; P.Y = To.Y; SetActorLocation(P * M2CM); }
		else { VelM.X = VelM.Y = 0.f; }
	}
	float G = Terrain->HeightAt(P.X, P.Y);
	if (Type == 0)
	{
		// a felled tree rests on its bumper along its whole length, tilted with the ground
		float Tilt = 0.f;
		G = LogRestZ(P, Tilt);
		LieTilt = FMath::FInterpTo(LieTilt, Tilt, Dt, 6.f);
		SetActorRotation(FRotator(-FallAngle + LieTilt, FallYaw, 0));
	}
	if (P.Z > G + 0.01f)
	{
		VelM.Z -= GRAV * Dt;
		P.Z = FMath::Max(G, P.Z + VelM.Z * Dt);
		if (P.Z <= G) VelM = FVector::ZeroVector;
		SetActorLocation(P * M2CM);
	}
	else if (P.Z < G - 0.01f && !bLaid) // a laid pipe stays down when soil is put over it
	{
		// (a tree that has just come down settles onto its crown within a fraction of a second)
		P.Z = Type == 0 ? FMath::Max(FMath::FInterpTo(P.Z, G, Dt, 15.f), G - 0.5f) : G;
		SetActorLocation(P * M2CM);
	}
	if (Type == 3 && bWasCarried && P.Z <= G + 0.01f) { bWasCarried = false; LayPipe(); UpdatePipeFloor(); }
}

void ARWProp::SetRockSize(float S)
{
	RockSize = S;
	Mesh->SetRelativeScale3D(FVector(1.5f, 1.3f, 1.1f) * S);
	Mesh->SetRelativeLocation(FVector(0, 0, 40.f * S));
	MassKg = 2600.f * S * S * S;
}

void ARWProp::SetRockModel(UStaticMesh* M, const TArray<UMaterialInterface*>& Mats, const FTransform& WorldX)
{
	if (!M) return;
	Mesh->SetStaticMesh(M);
	Mesh->EmptyOverrideMaterials();
	for (int32 s = 0; s < Mats.Num(); ++s) if (Mats[s]) Mesh->SetMaterial(s, Mats[s]);
	// turned and scaled as in the level, at the height over the ground it was placed at (the prop stands on the ground)
	const FVector At = GetActorLocation();
	const FQuat Q = GetActorQuat().Inverse() * WorldX.GetRotation();
	Mesh->SetRelativeTransform(FTransform(Q, FVector(0.f, 0.f, WorldX.GetLocation().Z - At.Z), WorldX.GetScale3D()));
	Mesh->SetCastShadow(true);
	const FVector S = M->GetBoundingBox().TransformBy(FTransform(WorldX.GetRotation(), FVector::ZeroVector, WorldX.GetScale3D())).GetSize() * CM2M;
	// (the size the pushing and the bucket go by: 1 = 1.5 m across, as the game's own rocks)
	RockSize = FMath::Max((float)FMath::Max(S.X, S.Y) / 1.5f, 0.05f);
	MassKg = FMath::Max((float)(S.X * S.Y * S.Z) * 0.55f * 2650.f, 5.f);
}

float ARWProp::LogLength() const
{
	return FMath::Max(Mesh->Bounds.BoxExtent.GetMax() * 2.f * CM2M, 4.f);
}

float ARWProp::LogRestZ(const FVector& P, float& OutTilt) const
{
	OutTilt = 0.f;
	if (!Terrain) return P.Z;
	// how far the model reaches below the trunk's line when it lies (its own +X points down then): a plain trunk's thickness,
	// or a tree model's crown
	float Down = 0.22f;
	if (const UStaticMesh* M = Mesh->GetStaticMesh())
		Down = FMath::Max((float)M->GetBoundingBox().TransformBy(Mesh->GetRelativeTransform()).Max.X * CM2M, 0.05f);
	const float Len = LogLength();
	const float Guess = FMath::Clamp(0.1f + 0.015f * Len, 0.12f, 0.45f); // a trunk's half thickness for its length
	// a thin model is a trunk all along; a wide one stands on its trunk near the stump and on its crown further up, which
	// gives a little under the tree's weight (branches bend and break)
	const bool bPlain = Down <= Guess * 1.5f;
	const float Trunk = bPlain ? Down : FMath::Min(Down, Guess);
	const float Crown = bPlain ? Down : FMath::Max(Down * 0.6f, Trunk);
	const FVector2D Ax(FMath::Cos(FMath::DegreesToRadians(FallYaw)), FMath::Sin(FMath::DegreesToRadians(FallYaw)));
	const FVector2D Base(P.X, P.Y);
	constexpr int32 N = 9;
	float Need[N], S[N];
	const float G0 = Terrain->HeightAt(P.X, P.Y);
	for (int32 k = 0; k < N; ++k)
	{
		S[k] = Len * k / (N - 1);
		const FVector2D Q = Base + Ax * S[k];
		const float Gk = Terrain->InBounds(Q.X, Q.Y) ? Terrain->HeightAt(Q.X, Q.Y) : G0;
		Need[k] = Gk + FMath::Lerp(Trunk, Crown, FMath::SmoothStep(0.35f, 0.65f, S[k] / Len));
	}
	// laid along the ground from end to end (no steeper than 35 degrees), as high as its highest point of contact needs
	const float MaxTan = FMath::Tan(FMath::DegreesToRadians(35.f));
	const float Tan = FMath::Clamp((Need[N - 1] - Need[0]) / Len, -MaxTan, MaxTan);
	float Z = -1e9f;
	for (int32 k = 0; k < N; ++k) Z = FMath::Max(Z, Need[k] - S[k] * Tan);
	OutTilt = FMath::RadiansToDegrees(FMath::Atan(Tan));
	return Z;
}

void ARWProp::GetLook(FString& OutMesh, FString& OutMats, FTransform& OutRel) const
{
	auto IsAsset = [](const UObject* O) { const FString P = O ? O->GetPathName() : FString(); return (P.StartsWith(TEXT("/Game/")) || P.StartsWith(TEXT("/Engine/"))) && !P.StartsWith(TEXT("/Engine/Transient")); };
	OutMesh.Reset(); OutMats.Reset();
	OutRel = Mesh->GetRelativeTransform();
	UStaticMesh* M = Mesh->GetStaticMesh();
	if (!IsAsset(M)) return; // (a model the game built itself: the prop's own kind makes it again)
	OutMesh = M->GetPathName();
	for (int32 s = 0; s < Mesh->GetNumMaterials(); ++s)
	{
		UMaterialInterface* Mi = Mesh->GetMaterial(s);
		OutMats += (s ? TEXT(";") : TEXT("")) + (IsAsset(Mi) ? Mi->GetPathName() : FString());
	}
}

void ARWProp::SetLook(const FString& InMesh, const FString& InMats, const FTransform& InRel, float InRockSize, float InMass)
{
	if (!InMesh.IsEmpty())
		if (UStaticMesh* M = LoadObject<UStaticMesh>(nullptr, *InMesh))
		{
			Mesh->SetStaticMesh(M);
			Mesh->EmptyOverrideMaterials();
			TArray<FString> Ms; InMats.ParseIntoArray(Ms, TEXT(";"), false);
			for (int32 s = 0; s < Ms.Num(); ++s) if (!Ms[s].IsEmpty()) if (UMaterialInterface* Mi = LoadObject<UMaterialInterface>(nullptr, *Ms[s])) Mesh->SetMaterial(s, Mi);
			Mesh->SetCastShadow(true);
		}
	Mesh->SetRelativeTransform(InRel);
	if (InRockSize > 0.f) RockSize = InRockSize;
	if (InMass > 0.f) MassKg = InMass;
}

bool ARWProp::Push(const FVector& P, float R, const FVector& V, float Dt, float HalfH)
{
	if (bCarried || (Type != 0 && Type != 1) || (Type == 0 && FallAngle < 89.f)) return false;
	const FVector Me = PosM();
	const FVector2D Q(P.X, P.Y), Base(Me.X, Me.Y);
	float Dist, Along = 0.f;
	FVector2D Axis(1.f, 0.f);
	float Len = 0.f;
	if (Type == 0)
	{
		// a fallen trunk: its whole length counts, from the stump end along the way it fell; it lies on the ground about
		// 0.45 m thick, so a tool whose span (P.Z +- HalfH) is above that passes over it instead of dragging it along
		Axis = FVector2D(FMath::Cos(FMath::DegreesToRadians(FallYaw)), FMath::Sin(FMath::DegreesToRadians(FallYaw)));
		Len = FMath::Max(Mesh->Bounds.BoxExtent.GetMax() * 2.f * CM2M, 4.f);
		Along = FMath::Clamp(FVector2D::DotProduct(Q - Base, Axis), 0.f, Len);
		Dist = FVector2D::Distance(Q, Base + Axis * Along);
		const float Thick = 0.25f; // half the trunk's thickness, around its middle (the actor sits there)
		if (Dist > R + Thick || FMath::Abs(P.Z - Me.Z) > HalfH + Thick) return false;
	}
	else
	{
		Dist = FVector2D::Distance(Q, Base);
		if (Dist > R + 0.7f * RockSize || FMath::Abs(P.Z - (Me.Z + 0.4f * RockSize)) > HalfH + 0.55f * RockSize) return false;
	}
	// slides the way it is pushed (the ground holds back a heavy one), and turns when it is pushed off its middle
	const FVector2D V2(V.X, V.Y);
	const float Give = FMath::Clamp(9000.f / FMath::Max(MassKg, 100.f), 0.35f, 1.f);
	FVector NewP = Me + FVector(V2.X, V2.Y, 0.f) * Dt * Give;
	SetActorLocation(NewP * M2CM);
	// what it carries on once let go: a flick of the bucket sends it sliding a little (friction stops it, see Tick)
	VelM.X = V2.X * Give; VelM.Y = V2.Y * Give;
	PushedFrames = 2;
	if (Type == 0 && Len > 0.f)
	{
		const float Lever = (Along - 0.5f * Len) / (0.5f * Len);
		const float Turn = (Axis.X * V2.Y - Axis.Y * V2.X) * Lever * Dt * 25.f;
		FallYaw += FMath::Clamp(Turn, -3.f, 3.f);
		SetActorRotation(FRotator(-FallAngle + LieTilt, FallYaw, 0));
	}
	return true;
}

float ARWProp::PipeCover() const
{
	if (!Terrain || Type != 3) return 0.f;
	FVector A, B;
	PipeEnds(A, B);
	const FVector2D Axis = FVector2D(B - A).GetSafeNormal(), Lat(-Axis.Y, Axis.X);
	const float R = 0.5f * PipeDia, Base = PosM().Z;
	float Thin = 1e9f;
	for (float d = 0.f; d <= PipeLen + 1e-3f; d += ARWTerrain::CS)
	{
		const FVector2D C = FVector2D(A) + Axis * d;
		// over the crown, and either side of it where the pipe's round shoulder is lower
		for (const float s : {0.f, -0.7f * R, 0.7f * R, -R, R})
		{
			const FVector2D Q = C + Lat * s;
			if (!Terrain->InBounds(Q.X, Q.Y)) continue;
			const float Top = Base + R + FMath::Sqrt(FMath::Max(R * R - s * s, 0.f));
			Thin = FMath::Min(Thin, Terrain->HeightAt(Q.X, Q.Y) - Top);
		}
	}
	return Thin;
}

void ARWProp::UpdatePipeFloor()
{
	ClearPipeFloor();
	if (!Terrain || Type != 3 || !bLaid) return;
	FVector A, B;
	PipeEnds(A, B);
	const FVector2D Axis = FVector2D(B - A).GetSafeNormal(), Lat(-Axis.Y, Axis.X);
	const float R = 0.5f * PipeDia, Base = PosM().Z;
	for (float d = 0.f; d <= PipeLen + 1e-3f; d += ARWTerrain::CS * 0.5f)
		for (float s = -R; s <= R + 1e-3f; s += ARWTerrain::CS * 0.5f)
		{
			const FVector2D Q = FVector2D(A) + Axis * d + Lat * s;
			if (!Terrain->InBounds(Q.X, Q.Y)) continue;
			const int32 i = Terrain->IndexAt(Q.X, Q.Y);
			// only the points really under the pipe, measured from where each point is
			const FVector2D Pt(Terrain->PX(i % ARWTerrain::N), Terrain->PX(i / ARWTerrain::N));
			const float Pd = FVector2D::DotProduct(Pt - FVector2D(A), Axis), Ps = FVector2D::DotProduct(Pt - FVector2D(A), Lat);
			if (Pd < 0.f || Pd > PipeLen || FMath::Abs(Ps) > R) continue;
			Terrain->DigFloor.FindOrAdd(i) = Base + R + FMath::Sqrt(FMath::Max(R * R - Ps * Ps, 0.f)) + 0.02f;
			PipeFloorCells.AddUnique(i);
		}
}

void ARWProp::ClearPipeFloor()
{
	if (Terrain) for (const int32 i : PipeFloorCells) Terrain->DigFloor.Remove(i);
	PipeFloorCells.Reset();
}

void ARWProp::Destroyed()
{
	ClearPipeFloor();
	Super::Destroyed();
}

void ARWProp::PipeEnds(FVector& A, FVector& B) const
{
	const FVector P = PosM();
	const float Yr = FMath::DegreesToRadians(FallYaw);
	const FVector D(FMath::Cos(Yr), FMath::Sin(Yr), 0.f);
	A = P - D * 0.5f * PipeLen;
	B = P + D * 0.5f * PipeLen;
}

void ARWProp::LayPipe()
{
	bLaid = true;
	if (!Terrain) return;
	FVector A, B;
	PipeEnds(A, B);
	const FVector2D Axis = FVector2D(B - A).GetSafeNormal();
	ARWProp* Joined = nullptr;
	FVector2D Outward = FVector2D::ZeroVector; FVector JoinAt = FVector::ZeroVector;
	float BestGap = 1.5f;
	for (const TWeakObjectPtr<ARWProp>& W : All)
	{
		ARWProp* Q = W.Get();
		if (!Q || Q == this || Q->Type != 3 || !Q->bLaid || Q->bCarried) continue;
		FVector QA, QB;
		Q->PipeEnds(QA, QB);
		const FVector2D QAxis = FVector2D(QB - QA).GetSafeNormal();
		if (FMath::Abs(FVector2D::DotProduct(Axis, QAxis)) < 0.9f) continue; // more than about 25 degrees off line
		// which end of the other pipe, and is this pipe beyond it (not lying alongside)
		const FVector QEnds[2] = {QA, QB};
		for (int32 e = 0; e < 2; ++e)
		{
			const FVector2D Out2 = e == 0 ? -QAxis : QAxis;
			const float Gap = FMath::Min(FVector2D::Distance(FVector2D(A), FVector2D(QEnds[e])), FVector2D::Distance(FVector2D(B), FVector2D(QEnds[e])));
			const bool bBeyond = FVector2D::DotProduct(FVector2D(PosM()) - FVector2D(QEnds[e]), Out2) > 0.f;
			if (bBeyond && Gap < BestGap) { BestGap = Gap; Joined = Q; Outward = Out2; JoinAt = QEnds[e]; }
		}
	}
	ARWGameMode* GM = ARWGameMode::Get(this);
	if (Joined)
	{
		// line it up with the pipe it joins, end to end
		const FVector2D C = FVector2D(JoinAt) + Outward * 0.5f * PipeLen;
		FallYaw = Joined->FallYaw;
		SetActorLocationAndRotation(FVector(C.X, C.Y, Terrain->HeightAt(C.X, C.Y)) * M2CM, FRotator(0.f, FallYaw, 0.f));
		// the trench floor decides the height: a big step means the ends do not meet, and water cannot pass
		const float Step = FMath::Abs(PosM().Z - JoinAt.Z);
		if (Step > PipeMaxStep)
		{
			if (GM) GM->Message(TRF(TEXT("Pipe laid but not joined: {0} m step from the next pipe - level the trench floor"), RWNum(Step, 2)));
			return;
		}
	}
	if (!GM) return;
	TArray<FPipeRun> Runs;
	PipeRuns(Runs);
	FVector MyA, MyB;
	PipeEnds(MyA, MyB);
	for (const FPipeRun& R : Runs)
	{
		const bool bMine = FVector::DistSquared(R.In, MyA) < 1e-2f || FVector::DistSquared(R.In, MyB) < 1e-2f || FVector::DistSquared(R.Out, MyA) < 1e-2f || FVector::DistSquared(R.Out, MyB) < 1e-2f;
		if (!bMine) continue;
		const float Len = R.Count * PipeLen;
		GM->Message(TRF(TEXT("Pipe laid: {0} pipes joined, {1} m long, falling {2} %"), RWNum((float)R.Count), RWNum(Len), RWNum((R.In.Z - R.Out.Z) / FMath::Max(Len, 0.1f) * 100.f, 1)));
		break;
	}
}

void ARWProp::PipeRuns(TArray<FPipeRun>& Out)
{
	Out.Reset();
	TArray<ARWProp*> Pipes;
	for (const TWeakObjectPtr<ARWProp>& W : All) if (W.IsValid() && W->Type == 3 && W->bLaid && !W->bCarried) Pipes.Add(W.Get());
	const int32 N = Pipes.Num();
	TArray<FVector> Ends; Ends.SetNum(N * 2);
	for (int32 i = 0; i < N; ++i) Pipes[i]->PipeEnds(Ends[i * 2], Ends[i * 2 + 1]);
	// each pipe end joins whichever other pipe's end touches it
	TArray<int32> Link; Link.Init(INDEX_NONE, N * 2);
	for (int32 a = 0; a < N * 2; ++a)
		for (int32 b = a + 1; b < N * 2; ++b)
			if (a / 2 != b / 2 && Link[a] == INDEX_NONE && Link[b] == INDEX_NONE && FVector2D::DistSquared(FVector2D(Ends[a]), FVector2D(Ends[b])) < 0.09f && FMath::Abs(Ends[a].Z - Ends[b].Z) <= PipeMaxStep)
			{ Link[a] = b; Link[b] = a; }
	// walk each run from a free end to the other free end
	TArray<uint8> Seen; Seen.Init(0, N);
	for (int32 e = 0; e < N * 2; ++e)
	{
		if (Link[e] != INDEX_NONE || Seen[e / 2]) continue;
		FPipeRun R; R.In = Ends[e];
		int32 Cur = e;
		for (;;)
		{
			Seen[Cur / 2] = 1; ++R.Count;
			const int32 Far = Cur ^ 1;
			R.Out = Ends[Far];
			if (Link[Far] == INDEX_NONE || Seen[Link[Far] / 2]) break;
			Cur = Link[Far];
		}
		if (R.Out.Z > R.In.Z) Swap(R.In, R.Out);
		Out.Add(R);
	}
}

// --------------------------------------------------------------------------------------------
// Bucket physics
// --------------------------------------------------------------------------------------------
float FBucketTool::Dig(ARWTerrain* T, const FVector& Tip, const FVector& Heel, const FVector& Lat, const FVector& TipVel, const FVector& Mouth, float Power, float Dt)
{
	Resist = 0; CutRate = 0; Penetration = 0; bBlocked = false;
	DigForceN = 0.f; DigHorizN = 0.f; DigVertN = 0.f;
	if (!T || !FMath::IsFinite(Dt) || Dt <= 0.f || !FMath::IsFinite(Width) || Width <= 0.f || !FMath::IsFinite(Capacity) || Capacity <= 0.f) return 0.f;
	(void)Power; // the pump's speed is already in TipVel
	const int32 NL = FMath::Max(2, FMath::CeilToInt(Width / 0.45f));
	const int32 NA = 3;
	const float Free = Capacity * 1.2f - Load.Total();
	const float Spd = TipVel.Size();
	// angle of attack: soil only breaks into the bucket when the mouth moves into the cut;
	// dragging the flat bottom or the back of the bucket ploughs and resists instead
	const float Into = Spd > 0.005f ? FVector::DotProduct(Mouth, TipVel / Spd) : 0.f;
	Attack = FMath::Clamp(Into, 0.f, 1.f);
	const bool bAccept = Free > 0.f && Spd > 0.03f && Into > -0.15f;
	const float AttackEff = FMath::Lerp(0.4f, 1.f, FMath::Sqrt(Attack));
	const float Plough = 1.f + (1.f - Attack) * 0.8f;
	CutTimer = FMath::Max(0.f, CutTimer - Dt);
	// 1) which ground the bucket is in
	struct FTouch { int32 I; float E; FVector P; bool bEdge; };
	TArray<FTouch, TInlineAllocator<32>> Touch;
	TArray<int32, TInlineAllocator<32>> Seen;
	float EdgeSum = 0.f, DeepE = 0.f; int32 EdgeN = 0, EdgeAll = 0, DeepI = INDEX_NONE;
	for (int32 a = 0; a <= NA; ++a)
	{
		const float Tt = a / float(NA);
		for (int32 l = 0; l <= NL; ++l)
		{
			const float S = (l / float(NL) - 0.5f) * Width;
			const FVector P = Tip + (Heel - Tip) * Tt + Lat * S;
			if (a == 0) ++EdgeAll;
			if (!T->InBounds(P.X, P.Y)) continue;
			const int32 i = T->IndexAt(P.X, P.Y);
			if (Seen.Contains(i)) continue;
			Seen.Add(i);
			const float E = T->Height[i] - P.Z;
			if (E <= 0.f) continue;
			Touch.Add({i, E, P, a == 0});
			Penetration = FMath::Max(Penetration, E);
			if (a == 0) { EdgeSum += E; ++EdgeN; }
			if (E > DeepE) { DeepE = E; DeepI = i; }
		}
	}
	if (Touch.Num() == 0 || DeepI == INDEX_NONE) return 0.f;
	// 2) the force of failing that soil: depth and width of the cut, blade angle, and the soil's own strength
	const FVector Blade = (Heel - Tip).GetSafeNormal();
	const FVector Dir = Spd > 0.005f ? TipVel / Spd : -Blade;
	const float Rake = FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(FVector::DotProduct(Blade, -Dir), -1.f, 1.f)));
	const float CutDepthNow = EdgeN > 0 ? EdgeSum / EdgeN : DeepE * 0.5f;
	const float CutWidth = Width * FMath::Clamp(EdgeN / float(FMath::Max(EdgeAll, 1)), 0.2f, 1.f);
	const ESoil DeepMat = T->SurfaceMat(DeepI);
	const FRWSoilStrength Str = FRWSoilMech::Strength(DeepMat, T->MoistureAt(DeepI), T->SurfaceComp(DeepI));
	// a bucket that cannot take more shoves the soil ahead of it, carrying its own load as well
	const float Surcharge = Free > 0.f ? 0.f : Str.Density * GRAV * 0.4f;
	FRWCutForce Cut = FRWSoilMech::CutForce(Str, CutDepthNow, CutWidth, Rake, Spd, Surcharge);
	// the teeth pressing into the ground ahead, and the loaded bucket's soil rubbing on the face it pushes against
	const float ToothN = T->SurfaceState(DeepI).Bearing * 1000.f * 0.02f * Width * FMath::Clamp(CutDepthNow / 0.1f, 0.f, 1.f);
	const float LoadN = Load.MassKg() * GRAV * 0.25f * FMath::Clamp(CutDepthNow / 0.2f, 0.f, 1.f);
	const float Mult = CutEase * Plough;
	DigForceN = (Cut.Total + ToothN + LoadN) * Mult;
	DigHorizN = (Cut.Horizontal + ToothN + LoadN) * Mult;
	DigVertN = Cut.Vertical * Mult;
	// rock the teeth cannot break stops the bucket
	for (const FTouch& Th : Touch)
		if (!SoilProps(T->SurfaceMat(Th.I)).bDiggable) { DigForceN += ForceLimitN * Th.E * 4.f; bBlocked = true; }
	// 3) soil removed = the volume the cutting edge really sweeps through this step, so a deeper or faster pass fills
	//    quicker, and a stalled bucket takes almost nothing. (Curling also sweeps the bucket's body through the cut.)
	//    Soil can only flow into the mouth so fast: a good full-depth pass still takes about 2.5 s to fill the bucket.
	// (as it always was: the hydraulics already slow the bucket down when the cut is too hard for them - an extra cut-off by
	// the digging force on top of that, added on 10 Nov, stopped a deep bucket from ever filling and broke digging)
	const float VolBudget = bAccept ? FMath::Min3(Free, FMath::Max(CutDepthNow, 0.03f) * CutWidth * Spd * Dt * AttackEff, Capacity / 2.5f * Dt * AttackEff) : 0.f;
	float VolUsed = 0;
	float BestCut = 0.f;
	if (VolBudget > 0.f)
	{
		float Avail = 0.f;
		for (const FTouch& Th : Touch) if (SoilProps(T->SurfaceMat(Th.I)).bDiggable) Avail += Th.E * ARWTerrain::CellArea;
		const float Share = Avail > 1e-6f ? FMath::Min(1.f, VolBudget / Avail) : 0.f;
		for (const FTouch& Th : Touch)
		{
			const ESoil M = T->SurfaceMat(Th.I);
			if (!SoilProps(M).bDiggable) continue;
			const float Before = Load.Total();
			T->RemoveAt(Th.I, Th.E * Share, Load);
			const float Got = Load.Total() - Before;
			VolUsed += Got;
			// freshly cut ground is moister (darker) than the sun-dried surface; it dries back over time
			if (Got > 0.f && T->MoistureAt(Th.I) < 0.42f) T->AddMoisture(Th.I, 0.1f);
			if (Got > BestCut)
			{
				BestCut = Got; CutMat = M; CutMoist = T->MoistureAt(Th.I);
				CutDepth = FMath::Max(0.f, T->Natural[Th.I] - Th.P.Z);
				BreakAt = FVector(Th.P.X, Th.P.Y, T->Height[Th.I]);
			}
		}
	}
	CutRate = VolUsed / FMath::Max(Dt, 1e-4f);
	if (BestCut > 0.f) CutTimer = 1.5f;
	Resist = 2.f * ForceFrac();
	return Resist;
}

float FBucketTool::Spill(ARWEffects* Fx, const FVector& At, const FVector& Vel, const FVector& Mouth, float Dt, float HoldLoose, const FVector& Along)
{
	const float Tot = Load.Total();
	if (Tot <= 1e-4f || !Fx) return 0.f;
	float Rate = 0.f;
	const float Sticky = (Load.Vol[(int32)ESoil::Clay] + Load.Vol[(int32)ESoil::Mud]) / Tot;
	const float Stick = Sticky * FMath::Clamp(Load.Moist * 1.5f, 0.f, 1.f);
	// soil only pours out once the lip is out of the cut: while the teeth are in the ground the load is packed against
	// the face (this used to empty an open bucket as fast as it filled while digging)
	if (Penetration < 0.03f)
	{
		if (HoldLoose >= 0.f)
		{
			// flow over the lip: Q = 3.2 W h^1.5, h = the soil standing above what the bucket holds; a tipped bucket empties
			// in about 2 seconds. Sticky clay clings to the steel and leaves later.
			const float Excess = Tot - HoldLoose * (1.f + 0.6f * Stick);
			if (Excess > 0.f)
			{
				const float H = Excess / FMath::Max(Width * 0.8f, 0.2f);
				Rate = FMath::Max(3.2f * Width * FMath::Pow(H, 1.5f), 0.45f * Capacity) * (1.f - 0.5f * Stick);
			}
		}
		else if (Mouth.Z < 0.3f) Rate = (0.3f - Mouth.Z) * 2.4f * Capacity * (1.f - 0.5f * Stick);
	}
	if (Tot > Capacity * 1.25f) Rate += (Tot - Capacity * 1.25f) * 2.f + 0.05f;
	// heaped soil above the rim is shaken off by fast swings and jerky stops (sticky clay holds on better)
	if (Tot > Capacity * 0.85f) Rate += (Tot - Capacity * 0.85f) * FMath::Clamp((Shake - 3.f) / 8.f, 0.f, 1.f) * 1.2f * (1.f - 0.6f * Sticky);
	if (Rate <= 0.f) return 0.f;
	FPayload Out = Load.Take(FMath::Min(Tot, Rate * Dt));
	if (Along.IsNearlyZero()) Fx->SpawnSoil(At, Vel * 0.8f, Out, Width * 0.3f);
	else
	{
		// a curtain along the edge it pours over: three parts, each only a few centimetres round its own place
		FPayload Part = Out; for (float& V : Part.Vol) V /= 3.f;
		for (const float F : {-0.66f, 0.f, 0.66f}) Fx->SpawnSoil(At + Along * F, Vel * 0.8f, Part, 0.04f);
	}
	// and the fine crumbs that make a pour look like a running stream (seen only: the soil itself is in the lumps above)
	Fx->SpawnChunks(At, Vel * 0.8f, Out.Dominant(), Out.Moist, FMath::Clamp(FMath::RoundToInt(Out.Total() / FMath::Max(Dt, 1e-3f) * 7.f), 0, 12), 0.045f);
	return Out.Total() / FMath::Max(Dt, 1e-4f);
}

FVector FBucketTool::LowestOfBack(const FVector& Tip, const FVector& Pivot, const FVector& Mouth) const
{
	FVector C = Tip; float Lowest = 1e9f;
	for (int32 k = 1; k < 24; ++k)
	{
		const float t = k / 24.f;
		const FVector P = Tip + (Pivot - Tip) * t - Mouth * Depth * 0.9f * FMath::Sin(PI * t);
		if (P.Z < Lowest) { Lowest = P.Z; C = P; }
	}
	return C;
}

float FBucketTool::Grade(ARWTerrain* T, const FVector& Tip, const FVector& Pivot, const FVector& Lat, const FVector& TipVel, const FVector& Mouth, float Dt)
{
	// Backside grading: the curved back of the shell is dragged over the ground. High spots under it are
	// shaved off and carried along, low spots behind it are filled from what it carries, and the strip
	// it passes over is pressed smooth. The strip is exactly as wide as this bucket.
	bGrading = false; GradedWidth = 0.f;
	if (!T) return 0.f;
	const FVector2D V2(TipVel.X, TipVel.Y);
	const float Spd = V2.Size();
	if (Spd < 0.05f) return 0.f;
	// lowest line of the back of the shell (rim from lip to pin, bulging away from the mouth)
	FVector C = LowestOfBack(Tip, Pivot, Mouth);
	if (!T->InBounds(C.X, C.Y)) return 0.f;
	const FVector2D Dir = V2 / Spd;
	const FVector2D L2 = FVector2D(Lat.X, Lat.Y).GetSafeNormal();
	const float Hw = Width * 0.5f;
	float Res = 0.f;
	TArray<int32, TInlineAllocator<128>> Seen;
	// The back's working face is a plane through its lowest line, tilted as the bucket is - one flat level for the whole
	// patch cut flat steps into a slope and levelled away any tilt across the bucket: along the bucket (teeth to pin) it
	// follows the bucket's pitch, across it the bucket's own tilt (a machine on a side slope tilts its bucket with it).
	const float LatH = FVector2D(Lat.X, Lat.Y).Size();
	const float CrossTan = LatH > 0.2f ? FMath::Clamp(Lat.Z / LatH, -0.7f, 0.7f) : 0.f;
	FVector2D Ax(Pivot.X - Tip.X, Pivot.Y - Tip.Y);
	const float AxLen = Ax.Size();
	Ax = AxLen > 0.05f ? Ax / AxLen : Dir;
	const float AlongTan = AxLen > 0.05f ? FMath::Clamp((Pivot.Z - Tip.Z) / AxLen, -0.7f, 0.7f) : 0.f;
	// height of the working face over a point U metres along the bucket from the lowest line (1e9: past the patch it bears on)
	const float FaceHalf = 0.25f + ARWTerrain::CS * 0.25f;
	auto BackZ = [&](float U) -> float { return FMath::Abs(U) <= FaceHalf ? C.Z + U * AlongTan : 1e9f; };
	// touching the ground anywhere under the working face (it was the one point under the middle of the lowest line: over a
	// hollow deeper than 3 cm there the whole back did nothing - not even on the bumps it was bearing on beside it - and the
	// hollow was passed over on every pass, a step in the graded strip)
	{
		bool bTouch = false;
		for (float U = -FaceHalf; U <= FaceHalf + 1e-3f && !bTouch; U += ARWTerrain::CS * 0.25f)
			for (float S = -Hw; S <= Hw + 1e-3f && !bTouch; S += ARWTerrain::CS * 0.5f)
			{
				const FVector2D Q = FVector2D(C.X, C.Y) + L2 * S + Ax * U;
				bTouch = T->InBounds(Q.X, Q.Y) && T->HeightAt(Q.X, Q.Y) >= C.Z + U * AlongTan + S * CrossTan - 0.03f;
			}
		if (!bTouch) return 0.f; // not touching the ground
	}
	// the back presses each point once as it passes over it, however many frames that takes: the share of one pressing
	// given in this frame (it pressed once every frame, 0.03 a frame - about 90 pressings in one pass at 60 fps and twice
	// as many at 120 fps: the fill packed down under the face, sank below it, and drew all the soil carried to fill it again)
	const float PressNow = 1.f - FMath::Pow(1.f - 0.03f, FMath::Clamp(Spd * Dt / (2.f * FaceHalf), 0.f, 1.f));
	// grading works the skin of the ground only: it levels to the mean of the strip, however hard the bucket is pressed.
	// Pressing harder than that makes the back bear on the ground (resistance), it does not cut deeper.
	// (measured ahead, on ground it has not worked yet, and carried back along the slope of that ground, so that it also holds on a hillside)
	float MeanNear = 0.f, MeanFar = 0.f; int32 MeanN = 0;
	for (float s = -Hw; s <= Hw + 1e-3f; s += ARWTerrain::CS)
	{
		const FVector2D Q = FVector2D(C.X, C.Y) + L2 * s;
		const FVector2D A = Q + Dir * 0.75f, B = Q + Dir * 1.5f;
		if (T->InBounds(A.X, A.Y) && T->InBounds(B.X, B.Y)) { MeanNear += T->HeightAt(A.X, A.Y); MeanFar += T->HeightAt(B.X, B.Y); ++MeanN; }
	}
	const float StripMean = MeanN ? (MeanNear + FMath::Clamp(MeanNear - MeanFar, -1.f * MeanN, 1.f * MeanN)) / MeanN : C.Z;
	const float SkinFloor = StripMean - 0.05f;
	// (pressed harder than the skin: the whole back bears on the ground there instead of cutting deeper)
	const float Lift = C.Z < SkinFloor ? SkinFloor - C.Z : 0.f;
	Res += Lift * 25.f;
	const FVector2D C2(C.X, C.Y);
	// every ground point under the back's footprint (as wide as the bucket, along it as far as the curve comes near)
	for (float s = -Hw - ARWTerrain::CS * 0.5f; s <= Hw + ARWTerrain::CS * 0.5f + 1e-3f; s += ARWTerrain::CS * 0.5f)
		for (float a = -0.6f; a <= 0.6f + 1e-3f; a += ARWTerrain::CS * 0.5f)
		{
			const FVector2D Q = C2 + L2 * s + Ax * a;
			if (!T->InBounds(Q.X, Q.Y)) continue;
			const int32 i = T->IndexAt(Q.X, Q.Y);
			if (Seen.Contains(i)) continue;
			Seen.Add(i);
			// where the point really is, across and along the bucket
			const FVector2D Pc(T->PX(i % ARWTerrain::N), T->PX(i / ARWTerrain::N));
			const float W = FVector2D::DotProduct(Pc - C2, L2), U = FVector2D::DotProduct(Pc - C2, Ax);
			if (FMath::Abs(W) > Hw + ARWTerrain::CS * 0.5f) continue;
			const float Bz = BackZ(U);
			if (Bz > 1e8f) continue;
			// the back's height over this point; the last 10 cm of the width press less (no step along the strip's edges)
			const float Tgt = Bz + W * CrossTan + Lift;
			const float Wt = 1.f - FMath::SmoothStep(Hw - 0.1f, Hw + ARWTerrain::CS * 0.5f, FMath::Abs(W));
			const float E = T->Height[i] - Tgt;
			const FSoilState St = T->SurfaceState(i);
			if (E > 0.003f)
			{
				if (!SoilProps(T->SurfaceMat(i)).bDiggable) { Res += E * 6.f; continue; }
				const float Got = T->RemoveAt(i, FMath::Min(E * Wt, 0.04f), GradeCarry);
				Res += Got * (1.f + St.Hardness) * 6.f;
			}
			else if (E < -0.003f && GradeCarry.Total() > 1e-4f)
			{
				// a hollow under the working face: filled up to it from what the bucket carries (loose fill bulks, so a
				// little less volume fits)
				const float Need = -E * Wt * ARWTerrain::CellArea * 1.2f;
				const FPayload Fill = GradeCarry.Take(FMath::Min(Need, GradeCarry.Total()));
				T->DepositAt(i, Fill.Dominant(), Fill.Total(), Fill.Moist, 110);
			}
			if (FMath::Abs(T->Height[i] - Tgt) < 0.02f) T->CompactAt(i, PressNow); // pressed by the back of the bucket
			T->ClearGrass(i, 0.1f);
		}
	// what does not fit is pushed ahead as a small windrow in front of the bucket
	const float Cap = 0.12f * Width;
	if (GradeCarry.Total() > Cap)
	{
		const FPayload Ahead = GradeCarry.Take(GradeCarry.Total() - Cap * 0.7f);
		const FVector2D P = FVector2D(C.X, C.Y) + Dir * 0.55f;
		const int32 N = FMath::Max(1, FMath::RoundToInt(Width / ARWTerrain::CS));
		for (int32 k = 0; k < N; ++k)
		{
			FPayload Part = Ahead; for (float& Vv : Part.Vol) Vv /= N;
			const FVector2D Q = P + L2 * ((k + 0.5f) / N - 0.5f) * Width;
			if (T->InBounds(Q.X, Q.Y)) T->DepositPayloadAt(T->IndexAt(Q.X, Q.Y), Part);
		}
	}
	bGrading = true; GradedWidth = Width;
	Res += 0.15f;
	// a steady drag on the arm, however many points it passes in one frame: it does not stall the stroke the way a cut does
	return FMath::Min(Res, 1.2f);
}

float FBucketTool::Sweep(ARWTerrain* T, const FVector& Tip, const FVector& Pivot, const FVector& TipVel, const FVector& Mouth, float Dt)
{
	// The bucket is dragged sideways (house swing) along the ground. Everything above the bucket's lowest
	// line is shaved off across the bucket's length and pushed out in front of its leading side plate.
	bSweeping = false;
	if (!T) return 0.f;
	const FVector2D V2(TipVel.X, TipVel.Y);
	const float Spd = V2.Size();
	if (Spd < 0.1f) return 0.f;
	float Low = Tip.Z;
	for (int32 k = 1; k < 10; ++k)
	{
		const float t = k / 10.f;
		Low = FMath::Min(Low, (Tip + (Pivot - Tip) * t - Mouth * Depth * 0.9f * FMath::Sin(PI * t)).Z);
	}
	const FVector2D TipH(Tip.X, Tip.Y), PivH(Pivot.X, Pivot.Y);
	const FVector2D Dir = V2 / Spd;
	bool bTouch = false;
	for (int32 k = 0; k <= 4 && !bTouch; ++k)
	{
		const FVector2D Q = FMath::Lerp(PivH, TipH, k / 4.f);
		bTouch = T->InBounds(Q.X, Q.Y) && T->HeightAt(Q.X, Q.Y) > Low - 0.02f;
	}
	if (!bTouch) return 0.f;
	FPayload Moved;
	float Res = 0.f;
	TArray<int32, TInlineAllocator<64>> Seen;
	const float Len = FVector2D::Distance(PivH, TipH) + 0.15f;
	const FVector2D Along = (TipH - PivH).GetSafeNormal();
	for (float a = -0.1f; a <= Len; a += ARWTerrain::CS * 0.5f)
		for (float s = -Width * 0.5f; s <= Width * 0.5f + 1e-3f; s += ARWTerrain::CS * 0.5f)
		{
			const FVector2D Q = PivH + Along * a + Dir * s;
			if (!T->InBounds(Q.X, Q.Y)) continue;
			const int32 i = T->IndexAt(Q.X, Q.Y);
			if (Seen.Contains(i)) continue;
			Seen.Add(i);
			const float E = T->Height[i] - Low;
			if (E <= 0.003f) continue;
			if (!SoilProps(T->SurfaceMat(i)).bDiggable) { Res += E * 6.f; continue; }
			const float Got = T->RemoveAt(i, FMath::Min(E, 0.05f), Moved);
			Res += Got * (1.f + T->SurfaceState(i).Hardness) * 5.f;
		}
	const float Vol = Moved.Total();
	if (Vol > 0.f)
	{
		// the shaved soil rolls up in front of the leading side plate as a small windrow
		const int32 N = FMath::Max(2, FMath::RoundToInt(Len / ARWTerrain::CS));
		for (int32 k = 0; k < N; ++k)
		{
			FPayload Part = Moved; for (float& Vv : Part.Vol) Vv /= N;
			const FVector2D Q = PivH + Along * (Len * (k + 0.5f) / N) + Dir * (Width * 0.5f + 0.35f);
			if (T->InBounds(Q.X, Q.Y)) T->DepositPayloadAt(T->IndexAt(Q.X, Q.Y), Part);
		}
		SweptVol += Vol;
	}
	bSweeping = true;
	return Res + 0.1f;
}

static UStaticMeshComponent* Seg(ARWMachine* M, USceneComponent* Parent, const FVector& A, const FVector& B, float W, float H, UMaterialInterface* Mat)
{
	const FVector D = B - A;
	const float L = D.Size();
	const FRotator R = D.Rotation();
	return M->Part(Parent, EShape::Cube, (A + B) * 0.5f, FVector(L, W, H), R, Mat);
}

static void SetHeap(UStaticMeshComponent* Heap, UMaterialInstanceDynamic* MID, const FPayload& P, float Fill, const FVector& Center, const FVector& MaxScale)
{
	if (!Heap) return;
	const bool bVis = Fill > 0.01f;
	Heap->SetVisibility(bVis);
	if (!bVis) return;
	const float F = FMath::Clamp(Fill, 0.f, 1.3f);
	Heap->SetRelativeLocation(Center * M2CM);
	Heap->SetRelativeScale3D(FVector(MaxScale.X * FMath::Sqrt(F), MaxScale.Y * FMath::Sqrt(FMath::Min(F, 1.f)), FMath::Max(MaxScale.Z * F, 0.01f)));
	if (MID)
	{
		const FSoilProps& S = SoilProps(P.Dominant());
		FRWSoilLook::Apply(MID, P.Dominant(), P.Moist); (void)S;
	}
}

static UMaterialInstanceDynamic* HeapMaterial(UObject* Outer)
{
	return FRWSoilLook::Make(Outer, ESoil::DrySoil, 0.2f); // textured loose soil (plain paint if the soil textures are missing)
}

static ARWProp* NearestProp(const FVector& P, float MaxD)
{
	ARWProp* Best = nullptr; float BD = MaxD;
	for (const TWeakObjectPtr<ARWProp>& W : ARWProp::All)
	{
		if (!W.IsValid() || W->bCarried) continue;
		const float D = FVector::Dist(W->PosM(), P);
		if (D < BD) { BD = D; Best = W.Get(); }
	}
	return Best;
}

// --------------------------------------------------------------------------------------------
// Excavator
// --------------------------------------------------------------------------------------------
void ARWExcavator::Build()
{
	S = (Size == 0 ? 0.55f : Size == 2 ? 1.2f : 1.f) * ModScale;
	const float Masses[3] = {5200, 22000, 36000}, Pw[3] = {30, 120, 200}, Fc[3] = {60, 400, 600}, Fr[3] = {5, 18, 28}, Cap[3] = {0.18f, 1.1f, 1.9f};
	EmptyMass = Masses[Size]; PowerKW = Pw[Size]; FuelCap = Fc[Size]; FuelRate = Fr[Size];
	Lb = 5.7f * S; La = 2.9f * S; Lk = 1.45f * S;
	Bucket.Width = (Size == 0 ? 0.6f : Size == 2 ? 1.5f : 1.2f);
	Bucket.Capacity = Cap[Size] * (1.f + 0.2f * UpTool);
	MaxSpeedF = 1.6f; MaxSpeedR = 1.6f; SpringSag = 0.02f; Wheelbase = 4.4f * S; Radius2D = 3.0f * S;
	CamDist = 15.f * S + 4.f;
	if (PendingMod && BuildFromModel()) return; // a mod supplied a real 3D model: rig it instead of the built-in shapes
	AddTracks(4.45f * S, 2.4f * S, 0.6f * S, 0.9f * S, 7);
	Part(Body, EShape::Cube, FVector(0, 0, 0.72f * S), FVector(2.4f * S, 1.1f * S, 0.36f * S), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cylinder, FVector(0, 0, 0.95f * S), FVector(1.6f * S, 1.6f * S, 0.16f * S), FRotator::ZeroRotator, DarkMID);
	House = Pivot(Body, FVector(0, 0, 1.03f * S));
	Part(House, EShape::Cube, FVector(-0.25f * S, 0, 0.13f * S), FVector(3.2f * S, 2.5f * S, 0.26f * S), FRotator::ZeroRotator, PaintMID);
	Part(House, EShape::Cube, FVector(-1.75f * S, 0, 0.62f * S), FVector(0.75f * S, 2.5f * S, 0.95f * S), FRotator::ZeroRotator, PaintMID);
	Part(House, EShape::Cylinder, FVector(-2.05f * S, 0, 0.62f * S), FVector(0.6f * S, 2.5f * S, 0.95f * S), FRotator::ZeroRotator, PaintMID);
	Part(House, EShape::Cube, FVector(-0.75f * S, 0.32f * S, 0.6f * S), FVector(1.5f * S, 1.85f * S, 0.7f * S), FRotator::ZeroRotator, PaintMID);
	HoodPivot = Pivot(House, FVector(-1.5f * S, 0.32f * S, 0.97f * S));
	Part(HoodPivot, EShape::Cube, FVector(0.72f * S, 0, 0.02f * S), FVector(1.45f * S, 1.8f * S, 0.05f * S), FRotator::ZeroRotator, PaintMID);
	Part(House, EShape::Cube, FVector(-0.75f * S, 0.32f * S, 0.55f * S), FVector(1.1f * S, 1.2f * S, 0.55f * S), FRotator::ZeroRotator, SteelMID); // engine block under hood
	Part(House, EShape::Cylinder, FVector(-0.55f * S, 0.95f * S, 1.25f * S), FVector(0.13f * S, 0.13f * S, 0.65f * S), FRotator::ZeroRotator, DarkMID);
	Part(House, EShape::Cube, FVector(-0.5f * S, 1.24f * S, 0.75f * S), FVector(2.2f * S, 0.03f * S, 0.03f * S), FRotator::ZeroRotator, PaintMID);
	Part(House, EShape::Cube, FVector(0.2f * S, 1.0f * S, 0.45f * S), FVector(0.8f * S, 0.5f * S, 0.4f * S), FRotator::ZeroRotator, PaintMID); // tool box / tank
	AddCab(House, FVector(0.62f * S, -0.72f * S, 1.08f * S), FVector(1.55f * S, 0.95f * S, 1.6f * S));
	SeatPos = FVector(0.5f * S, -0.72f * S, 1.3f * S);
	const FVector Foot(0.78f * S, 0.22f * S, 0.55f * S);
	Part(House, EShape::Cube, Foot + FVector(-0.1f, 0, -0.15f) * S, FVector(0.7f * S, 0.75f * S, 0.6f * S), FRotator::ZeroRotator, PaintMID);
	BoomP = Pivot(House, Foot, FRotator(BoomA, 0, 0));
	const FVector K(0.52f * Lb, 0, 0.55f * S);
	{
		// welded box-section boom: deep at the knee, tapering to both pins
		const TArray<FVector2D> BoomPoly = {
			FVector2D(-0.3f * S, -0.22f * S), FVector2D(0.28f * Lb, -0.12f * S), FVector2D(0.52f * Lb, 0.18f * S), FVector2D(0.8f * Lb, -0.1f * S), FVector2D(Lb + 0.12f * S, -0.2f * S),
			FVector2D(Lb + 0.22f * S, 0.0f), FVector2D(Lb + 0.1f * S, 0.22f * S), FVector2D(0.8f * Lb, 0.34f * S), FVector2D(0.55f * Lb, 0.92f * S), FVector2D(0.5f * Lb, 0.95f * S),
			FVector2D(0.28f * Lb, 0.58f * S), FVector2D(-0.1f * S, 0.32f * S), FVector2D(-0.32f * S, 0.12f * S)};
		MeshPart(BoomP, FRWMeshGen::Profile(FString::Printf(TEXT("boom%d"), Size), BoomPoly, 0.56f * S), FVector::ZeroVector, FRotator::ZeroRotator, PaintMID);
		MeshPart(BoomP, FRWMeshGen::RoundCyl(0.5f * S, 0.7f * S), FVector::ZeroVector, FRotator(0, 0, 90), PaintMID);
		MeshPart(BoomP, FRWMeshGen::RoundCyl(0.42f * S, 0.62f * S), FVector(Lb, 0, 0), FRotator(0, 0, 90), PaintMID);
		MeshPart(BoomP, FRWMeshGen::RoundCyl(0.12f * S, 0.8f * S), FVector(Lb, 0, 0), FRotator(0, 0, 90), SteelMID);
		Part(BoomP, EShape::Cube, FVector(0.45f * Lb, 0, -0.2f * S), FVector(0.35f * S, 0.62f * S, 0.25f * S), FRotator(-10, 0, 0), PaintMID); // cylinder bracket
	}
	// hydraulic hoses along the boom
	Seg(this, BoomP, FVector(0.2f * S, 0.2f * S, 0.38f * S), K + FVector(0, 0.2f * S, 0.33f * S), 0.05f * S, 0.05f * S, RubberMID);
	Seg(this, BoomP, K + FVector(0, 0.2f * S, 0.33f * S), FVector(Lb - 0.4f * S, 0.2f * S, 0.25f * S), 0.05f * S, 0.05f * S, RubberMID);
	Seg(this, BoomP, FVector(0.2f * S, -0.2f * S, 0.38f * S), K + FVector(0, -0.2f * S, 0.33f * S), 0.05f * S, 0.05f * S, RubberMID);
	ArmP = Pivot(BoomP, FVector(Lb, 0, 0), FRotator(ArmA, 0, 0));
	{
		const TArray<FVector2D> ArmPoly = {
			FVector2D(-0.78f * S, 0.36f * S), FVector2D(-0.55f * S, 0.58f * S), FVector2D(0.15f * La, 0.36f * S), FVector2D(La + 0.08f * S, 0.14f * S), FVector2D(La + 0.16f * S, 0.0f),
			FVector2D(La + 0.05f * S, -0.14f * S), FVector2D(0.35f * La, -0.3f * S), FVector2D(-0.15f * S, -0.28f * S), FVector2D(-0.7f * S, 0.05f * S)};
		MeshPart(ArmP, FRWMeshGen::Profile(FString::Printf(TEXT("arm%d"), Size), ArmPoly, 0.4f * S), FVector::ZeroVector, FRotator::ZeroRotator, PaintMID);
		MeshPart(ArmP, FRWMeshGen::RoundCyl(0.12f * S, 0.62f * S), FVector(La, 0, 0), FRotator(0, 0, 90), SteelMID);
		Seg(this, ArmP, FVector(La - 0.55f * S, 0, 0.32f * S), FVector(La + 0.05f * S, 0, 0.42f * S), 0.32f * S, 0.12f * S, PaintMID); // bucket link
	}
	Seg(this, ArmP, FVector(0.1f * S, 0.15f * S, 0.25f * S), FVector(La - 0.3f * S, 0.15f * S, 0.22f * S), 0.04f * S, 0.04f * S, RubberMID);
	// flexible hoses across the moving joints: fixed length from the joint's full range, slack loops clear of the steel
	for (int32 s = -1; s <= 1; s += 2)
	{
		const FVector HA = Foot + FVector(-0.45f, s * 0.2f, 0.35f) * S, HB = FVector(0.2f, s * 0.2f, 0.38f) * S;
		AddHose(House, HA, BoomP, HB, 0.016f * S, HoseReach(BoomP, BoomLo, BoomHi, House, HA, BoomP, HB) * 1.04f + 0.05f * S, FVector(-1, 0, 0.6f));
	}
	for (const float Y : {0.2f, 0.08f})
	{
		const FVector HA(Lb - 0.4f * S, Y * S, 0.25f * S), HB(0.1f * S, (Y - 0.05f) * S, 0.25f * S);
		AddHose(BoomP, HA, ArmP, HB, 0.015f * S, HoseReach(ArmP, ArmLo, ArmHi, BoomP, HA, ArmP, HB) * 1.04f + 0.05f * S, FVector(0, 0, 1));
	}
	BucketP = Pivot(ArmP, FVector(La, 0, 0), FRotator(BktA, 0, 0));
	for (int32 t = 0; t < 4; ++t) ToolRoots.Add(Pivot(BucketP, FVector::ZeroVector));
	{
		// bucket attachments with their own dimensions; B cycles through them before the other tools
		const float W0 = Bucket.Width, C0 = Bucket.Capacity, M0 = EmptyMass * 0.04f;
		auto Spec = [&](const TCHAR* SpId, const TCHAR* SpName, const TCHAR* SpType, float Wd, float Cap, float Dp, float Kg, float Hd)
		{
			FBucketSpec B; B.Id = SpId; B.Name = SpName; B.Type = SpType; B.Width = Wd; B.Capacity = Cap; B.Depth = Dp; B.MassKg = Kg; B.Hardness = Hd;
			BucketSpecs.Add(B);
		};
		Spec(TEXT("std"), TEXT("Digging bucket"), TEXT("standard"), W0, C0, 0.46f * Lk, M0, 1.f);
		Spec(TEXT("grading"), TEXT("Wide grading bucket"), TEXT("grading"), W0 * 1.6f, C0 * 1.05f, 0.3f * Lk, M0 * 0.95f, 1.15f);
		Spec(TEXT("trench"), TEXT("Narrow trenching bucket"), TEXT("trenching"), W0 * 0.5f, C0 * 0.5f, 0.5f * Lk, M0 * 0.6f, 0.9f);
		Spec(TEXT("heavy"), TEXT("Heavy-duty rock bucket"), TEXT("heavy"), W0, C0 * 0.95f, 0.46f * Lk, M0 * 1.35f, 0.75f);
		FRWMods::AddBucketAttachments(BucketSpecs, Size); // buckets shipped by mods that fit this size
		BaseEmptyMass = EmptyMass;
		BucketIdx = 0;
		Bucket.Depth = BucketSpecs[0].Depth; Bucket.MassKg = BucketSpecs[0].MassKg;
		BuildBucketMesh();
	}
	{
		USceneComponent* T1 = ToolRoots[1]; // hydraulic breaker
		Part(T1, EShape::Cube, FVector(0.55f * S, 0, 0), FVector(1.1f * S, 0.5f * S, 0.5f * S), FRotator::ZeroRotator, DarkMID);
		Part(T1, EShape::Cylinder, FVector(1.25f * S, 0, 0), FVector(0.14f * S, 0.14f * S, 0.55f * S), FRotator(-90, 0, 0), SteelMID);
		Part(T1, EShape::Cone, FVector(1.55f * S, 0, 0), FVector(0.14f * S, 0.14f * S, 0.12f * S), FRotator(-90, 0, 0), SteelMID);
	}
	{
		USceneComponent* T2 = ToolRoots[2]; // grapple
		Part(T2, EShape::Cube, FVector(0.35f * S, 0, 0), FVector(0.6f * S, 0.5f * S, 0.5f * S), FRotator::ZeroRotator, PaintMID);
		JawL = Pivot(T2, FVector(0.6f * S, 0, 0.15f * S));
		JawR = Pivot(T2, FVector(0.6f * S, 0, -0.15f * S));
		for (int32 k = -1; k <= 1; ++k)
		{
			Seg(this, JawL, FVector(0, k * 0.3f * S, 0), FVector(0.7f * S, k * 0.3f * S, 0.35f * S), 0.08f * S, 0.1f * S, SteelMID);
			Seg(this, JawR, FVector(0, k * 0.3f * S + 0.15f * S, 0), FVector(0.7f * S, k * 0.3f * S + 0.15f * S, -0.35f * S), 0.08f * S, 0.1f * S, SteelMID);
		}
	}
	{
		USceneComponent* T3 = ToolRoots[3]; // auger drill
		Part(T3, EShape::Cube, FVector(0.3f * S, 0, 0), FVector(0.55f * S, 0.45f * S, 0.45f * S), FRotator::ZeroRotator, DarkMID);
		Auger = Pivot(T3, FVector(0.55f * S, 0, 0));
		Part(Auger, EShape::Cylinder, FVector(0.55f * S, 0, 0), FVector(0.1f * S, 0.1f * S, 1.1f * S), FRotator(-90, 0, 0), SteelMID);
		for (int32 k = 0; k < 9; ++k)
		{
			const float A = k * 0.9f;
			Part(Auger, EShape::Cube, FVector(0.1f * S + k * 0.11f * S, FMath::Cos(A) * 0.15f * S, FMath::Sin(A) * 0.15f * S), FVector(0.03f * S, 0.32f * S, 0.05f * S), FRotator(0, 0, FMath::RadiansToDegrees(A)), SteelMID);
		}
	}
	for (int32 t = 0; t < 4; ++t) ToolRoots[t]->SetVisibility(t == Tool, true);
	// hydraulic cylinders
	Cyls.Add(MakeCyl(House, Foot + FVector(0.45f, 0.28f, -0.45f) * S, BoomP, FVector(0.45f * Lb, 0.28f * S, -0.3f * S), 0.11f * S, 1.6f * S));
	Cyls.Add(MakeCyl(House, Foot + FVector(0.45f, -0.28f, -0.45f) * S, BoomP, FVector(0.45f * Lb, -0.28f * S, -0.3f * S), 0.11f * S, 1.6f * S));
	Cyls.Add(MakeCyl(BoomP, K + FVector(0, 0, 0.32f * S), ArmP, FVector(-0.6f * S, 0, 0.3f * S), 0.1f * S, 1.7f * S));
	Cyls.Add(MakeCyl(ArmP, FVector(0.15f * La, 0, 0.3f * S), BucketP, FVector(0.02f * Lk, 0, 0.3f * Lk), 0.085f * S, 1.1f * S));
	AddLamp(BoomP, FVector(0.3f * Lb, -0.32f * S, 0.4f * S), FRotator(-20, 0, 0), 9000, true);
	LastTip = TipWorld();
}

void ARWExcavator::BuildBucketMesh()
{
	// procedural bucket (tool 0) from the current attachment's width and depth: shell on +Z, mouth faces -Z
	if (bModelRig || ToolRoots.Num() == 0) return;
	USceneComponent* T0 = ToolRoots[0];
	TArray<USceneComponent*> Old; T0->GetChildrenComponents(true, Old);
	for (USceneComponent* C : Old) if (C && C != FillMesh) C->DestroyComponent(); // the soil fill mesh survives a bucket change
	HeapClods.Reset(); Heap = nullptr;
	const float W = Bucket.Width, Dp = FMath::Max(Bucket.Depth, 0.15f * Lk);
	MeshPart(T0, FRWMeshGen::BucketShell(Lk, W, Dp, 0.05f * S), FVector::ZeroVector, FRotator::ZeroRotator, PaintMID);
	for (int32 s = -1; s <= 1; s += 2)
		MeshPart(T0, FRWMeshGen::BucketSide(Lk, Dp, 0.05f * S), FVector(0, s * W * 0.5f, 0), FRotator::ZeroRotator, PaintMID);
	Part(T0, EShape::Cube, FVector(Lk, 0, 0), FVector(0.1f * S, W, (BucketSpecs.IsValidIndex(BucketIdx) && BucketSpecs[BucketIdx].Type == TEXT("heavy") ? 0.09f : 0.05f) * S), FRotator::ZeroRotator, SteelMID);
	const bool bGradingEdge = BucketSpecs.IsValidIndex(BucketIdx) && BucketSpecs[BucketIdx].Type == TEXT("grading");
	if (!bGradingEdge) // grading buckets have a straight blade edge, no teeth
	{
		const int32 Teeth = FMath::Clamp(FMath::RoundToInt(W / 0.25f), 2, 7);
		for (int32 k = 0; k < Teeth; ++k)
			Part(T0, EShape::Cube, FVector(Lk + 0.1f * S, (k / float(Teeth - 1) - 0.5f) * W * 0.9f, -0.03f * S), FVector(0.24f * S, 0.08f * S, 0.06f * S), FRotator(-12, 0, 0), SteelMID);
	}
	Part(T0, EShape::Cube, FVector(0.02f * Lk, 0, 0.2f * Lk), FVector(0.25f * S, FMath::Min(0.4f * S, W * 0.8f), 0.35f * S), FRotator::ZeroRotator, PaintMID); // linkage ears
	if (!HeapMID) HeapMID = HeapMaterial(this);
	Heap = MeshPart(T0, FRWMeshGen::SoilLump(1), FVector(0.5f * Lk, 0, 0.15f * Lk), FRotator::ZeroRotator, HeapMID, FVector(0.8f * Lk, W * 0.9f, 0.3f * Lk));
	Heap->SetVisibility(false);
	T0->SetVisibility(Tool == 0, true);
	Heap->SetVisibility(false);
}

void ARWExcavator::ApplyBucket(int32 Idx)
{
	if (!BucketSpecs.IsValidIndex(Idx)) return;
	BucketIdx = Idx;
	const FBucketSpec& B = BucketSpecs[Idx];
	Bucket.Width = B.Width;
	Bucket.Capacity = B.Capacity * (1.f + 0.2f * UpTool);
	Bucket.Depth = B.Depth;
	Bucket.MassKg = B.MassKg;
	Bucket.CutEase = B.Hardness;
	if (BaseEmptyMass > 0.f) EmptyMass = BaseEmptyMass + (B.MassKg - BucketSpecs[0].MassKg);
	BuildBucketMesh();
}

FVector ARWExcavator::TipWorld() const
{
	const float L = Tool == 0 ? Lk : Tool == 1 ? 1.6f * S : Tool == 2 ? 1.2f * S : 1.7f * S;
	return BucketP->GetComponentTransform().TransformPosition(FVector(L, 0, 0) * M2CM) * CM2M;
}

void ARWExcavator::ToolCycle()
{
	if (Slung.IsValid()) { SlingYaw = FMath::Fmod(SlingYaw + 90.f, 360.f); return; } // a slung pipe: B turns it instead
	if (Bucket.Load.Total() > 0.05f) { Warning = TEXT("Empty the bucket before changing attachment"); return; }
	if (bModelRig) { Warning = TEXT("This model only has its bucket"); return; }
	if (Held.IsValid()) { Held->bCarried = false; Held.Reset(); }
	// next bucket attachment first, then breaker / grapple / auger, then back to the first bucket
	if (Tool == 0 && BucketIdx + 1 < BucketSpecs.Num()) { ApplyBucket(BucketIdx + 1); return; }
	Tool = (Tool + 1) % 4;
	if (Tool == 0) ApplyBucket(0);
	bToolActive = false;
	for (int32 t = 0; t < ToolRoots.Num(); ++t) ToolRoots[t]->SetVisibility(t == Tool, true);
	if (Tool == 0 && Heap) Heap->SetVisibility(false);
	Cyls.Last().B = BucketP;
}

void ARWExcavator::WorkToggle()
{
	if (Tool == 0)
	{
		// with the bucket on: sling a pipe under it on a chain, or set it down
		ARWGameMode* GM = ARWGameMode::Get(this);
		if (Slung.IsValid()) SlingRelease();
		else if (SlingGrab()) { if (GM) GM->Message(TEXT("Pipe on the chain: V sets it down, B turns it")); }
		else if (GM) GM->Message(TEXT("No pipe within reach of the bucket"));
		return;
	}
	bToolActive = !bToolActive;
}

bool ARWExcavator::SlingGrab()
{
	const FVector Tip = TipWorld();
	ARWProp* Best = nullptr; float BD = 3.5f;
	for (const TWeakObjectPtr<ARWProp>& W : ARWProp::All)
	{
		if (!W.IsValid() || W->Type != 3 || W->bCarried) continue;
		const float Dd = FVector::Dist(W->PosM() + FVector(0, 0, 0.5f * ARWProp::PipeDia), Tip);
		if (Dd < BD) { BD = Dd; Best = W.Get(); }
	}
	if (!Best) return false;
	Slung = Best;
	Best->bCarried = true;
	Best->bLaid = false; // picked up again: it no longer belongs to a run
	SlingOff = SlingVel = FVector2D::ZeroVector;
	SlingLastTipVel = FVector::ZeroVector;
	// keep the pipe's direction as it was picked up
	SlingYaw = Best->FallYaw - (Yaw + Swing);
	return true;
}

void ARWExcavator::SlingRelease()
{
	if (Slung.IsValid()) { Slung->bCarried = false; Slung->bWasCarried = true; Slung->VelM = FVector::ZeroVector; }
	Slung.Reset();
	if (SlingMesh) SlingMesh->SetVisibility(false);
}

void ARWExcavator::SlingTick(const FVector& Tip, const FVector& TipVel, float Dt)
{
	if (!Slung.IsValid() || Dt <= 0.f) return;
	const float ChainLen = 1.4f;
	// a pendulum under the bucket: moving the bucket sets it swinging, and it settles down
	FVector TipAcc = (TipVel - SlingLastTipVel) / Dt;
	TipAcc.X = FMath::Clamp(TipAcc.X, -12.f, 12.f); TipAcc.Y = FMath::Clamp(TipAcc.Y, -12.f, 12.f);
	SlingLastTipVel = TipVel;
	const FVector2D Acc = -SlingOff * (GRAV / ChainLen) - SlingVel * 0.5f - FVector2D(TipAcc.X, TipAcc.Y);
	SlingVel += Acc * Dt;
	SlingOff += SlingVel * Dt;
	const float Sz = SlingOff.Size();
	if (Sz > 0.8f * ChainLen) { SlingOff *= 0.8f * ChainLen / Sz; SlingVel *= 0.5f; }
	const float Drop = FMath::Sqrt(FMath::Max(ChainLen * ChainLen - SlingOff.SizeSquared(), 0.01f));
	const FVector Top = Tip + FVector(SlingOff.X, SlingOff.Y, -Drop);
	FVector P = Top - FVector(0.f, 0.f, ARWProp::PipeDia);
	const float G = Terrain ? Terrain->HeightAt(P.X, P.Y) : P.Z;
	if (P.Z < G) { P.Z = G; SlingVel *= 0.8f; } // resting on the ground: the chain goes slack
	const float PipeYaw = Yaw + Swing + SlingYaw;
	Slung->FallYaw = PipeYaw;
	Slung->SetActorLocationAndRotation(P * M2CM, FRotator(0.f, PipeYaw, 0.f));
	// the chain
	if (!SlingMesh)
	{
		SlingMesh = NewObject<UStaticMeshComponent>(this);
		SlingMesh->SetStaticMesh(GCyl);
		UMaterialInstanceDynamic* CM = UMaterialInstanceDynamic::Create(GPaint, this);
		CM->SetVectorParameterValue(TEXT("Color"), FLinearColor(0.03f, 0.03f, 0.03f));
		CM->SetScalarParameterValue(TEXT("Roughness"), 0.7f);
		SlingMesh->SetMaterial(0, CM);
		SlingMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		SlingMesh->SetupAttachment(RootComponent);
		SlingMesh->SetCastShadow(true);
		SlingMesh->RegisterComponent();
	}
	const FVector ChainTop = Tip, ChainEnd = P + FVector(0.f, 0.f, ARWProp::PipeDia);
	const FVector Span = ChainTop - ChainEnd;
	SlingMesh->SetVisibility(true);
	SlingMesh->SetWorldTransform(FTransform(FRotationMatrix::MakeFromZ(Span.GetSafeNormal()).Rotator(), (ChainTop + ChainEnd) * 0.5f * M2CM, FVector(0.05f, 0.05f, FMath::Max((float)Span.Size(), 0.05f))));
}

FString ARWExcavator::HelpText() const
{
	return TR(TEXT("W/S tracks  A/D turn  Q/E swing  R/F boom  T/G arm  Y/H bucket dump/curl  V tool on/off, sling a pipe  B change attachment, turn the pipe  I engine  Z/X throttle  C camera  F2/F3 change machine"));
}

FString ARWExcavator::ToolText() const
{
	static const TCHAR* Names[4] = {TEXT("Bucket"), TEXT("Breaker hammer"), TEXT("Grapple"), TEXT("Auger drill")};
	FString Sx = TR(Names[Tool]);
	if (Tool == 0 && BucketSpecs.IsValidIndex(BucketIdx)) Sx = TR(BucketSpecs[BucketIdx].Name) + FString::Printf(TEXT(" %s m"), *RWNum(Bucket.Width, 2));
	if (Tool == 0 && Bucket.bGrading) Sx += TRF(TEXT("  grading {0} m wide"), RWNum(Bucket.GradedWidth, 2));
	if (Tool == 0 && Bucket.bSweeping) Sx += TR(TEXT("  sweeping the ground"));
	if (PropAngle > 1.f) Sx += TRF(TEXT("  raised on the bucket {0} deg"), RWNum(PropAngle));
	if (Tool == 0) Sx += TRF(TEXT("  load {0} / {1} m3 ({2} kg) {3}"), RWNum(Bucket.Load.Total(), 2), RWNum(Bucket.Capacity, 2), RWNum(Bucket.Load.MassKg()), Bucket.Load.Total() > 0.01f ? TR(SoilName(Bucket.Load.Dominant(), Bucket.Load.Moist)) : FString());
	if (Tool == 0 && Bucket.CutTimer > 0.f) Sx += TRF(TEXT("  cutting {0} at {1} m depth"), TR(SoilName(Bucket.CutMat, Bucket.CutMoist)), RWNum(Bucket.CutDepth, 1));
	if (Tool == 0 && Bucket.DigForceN > 1000.f) Sx += TRF(TEXT("  digging force {0} of {1} kN"), RWNum(Bucket.DigForceN / 1000.f), RWNum(Bucket.ForceLimitN / 1000.f));
	if (Tool == 0 && Bucket.Load.Total() > Bucket.Capacity) Sx += TR(TEXT("  (heaped - swing gently)"));
	else Sx += bToolActive ? TR(TEXT("  [ACTIVE]")) : TR(TEXT("  [off]"));
	if (Tool == 2 && Held.IsValid()) Sx += TR(TEXT("  holding")) + TEXT(" ") + Held->Label();
	Sx += TRF(TEXT("  swing {0}  boom {1}  arm {2}  bucket {3}"), RWNum(FMath::Fmod(Swing + 360.f, 360.f)), RWNum(BoomA), RWNum(ArmA), RWNum(BktA));
	return Sx;
}

bool ARWExcavator::GradePoint(FVector& Out) const
{
	Out = TipWorld();
	return true;
}

void ARWExcavator::WorkTick(float Dt)
{
	const float H = HydSpeedScale();
	// the machine's hydraulics push with up to about 70 % of its weight (a 25 t excavator: ~170 kN of digging force);
	// the speed falls off as the soil force nears that, and stalls at it
	Bucket.ForceLimitN = EmptyMass * GRAV * 0.7f;
	// (grading, sweeping and the other tools report a plain resistance, not a soil force)
	const float Sc = Tool == 0 && DbgBranch == 0 ? FRWSoilMech::HydSpeedScale(Bucket.ForceFrac()) : 1.f / (1.f + Bucket.Resist * 1.2f);
	// overload moment: payload at long reach makes the machine light at the rear
	const FVector Tip = TipWorld();
	const float Reach = FVector::Dist2D(Tip, LocalToWorldM(FVector::ZeroVector));
	const float ExtraBucket = BucketSpecs.Num() ? Bucket.MassKg - BucketSpecs[0].MassKg : 0.f; // a heavier attachment tips sooner
	// soil pulling the bucket down (or the bucket prying upwards) counts against the machine's weight too
	const float SlungKg = Slung.IsValid() ? Slung->MassKg : 0.f;
	const float LoadMoment = (PayloadKg() + SlungKg + EmptyMass * 0.04f + ExtraBucket + FMath::Abs(Bucket.DigVertN) / GRAV) * Reach;
	const float Stab = EmptyMass * TrackLength * 0.28f;
	float LiftSc = 1.f;
	if (LoadMoment > Stab) { Warning = TEXT("TIPPING LOAD - reduce reach"); LiftSc = 0.3f; }
	else LiftSc = FMath::Clamp(1.4f - 0.9f * LoadMoment / FMath::Max(Stab, 1.f), 0.3f, 1.f); // a heavier lift is a slower lift
	// a load far out at reach makes the upper structure much harder to start and to stop turning
	const float SwingI0 = EmptyMass * 9.f;
	const float SwingResp = 7.f * SwingI0 / (SwingI0 + (PayloadKg() + Bucket.MassKg) * Reach * Reach);
	auto Joint = [&](float& A, float& V, float Cmd, float MaxS, float Lo, float Hi, float Resp = 7.f)
	{
		V = FMath::FInterpTo(V, Cmd * MaxS * H, Dt, Resp);
		A += V * Dt;
		if (A < Lo) { A = Lo; if (Cmd < 0) HydLoad = 1.2f; V = 0; }
		if (A > Hi) { A = Hi; if (Cmd > 0) HydLoad = 1.2f; V = 0; }
	};
	HydLoad = 0.f;
	Joint(Swing, VSwing, InA4, 40.f, -1e6f, 1e6f, SwingResp);
	// soil resists pushing the boom down into the ground; lifting out is only limited by the load moment
	Joint(BoomA, VBoom, InA1, 22.f * (InA1 > 0 ? LiftSc : Sc), BoomLo, BoomHi);
	Joint(ArmA, VArm, InA2, 28.f * Sc, ArmLo, ArmHi);
	Joint(BktA, VBkt, InA3, 48.f * Sc, BktLo, BktHi);
	House->SetRelativeRotation(FRotator(0, Swing, 0));
	BoomP->SetRelativeRotation(FRotator(BoomA, 0, 0));
	ArmP->SetRelativeRotation(FRotator(ArmA, 0, 0));
	BucketP->SetRelativeRotation(FRotator(BktA, 0, 0));

	const FVector NewTip = TipWorld();
	const FVector Vel = (NewTip - LastTip) / Dt;
	LastTip = NewTip;
	const FVector Lat = House->GetComponentTransform().TransformVectorNoScale(FVector(0, 1, 0));
	const FTransform BT = BucketP->GetComponentTransform();
	const FVector Mouth = BT.TransformVectorNoScale(FVector(0, 0, -BucketSign)); // the opening faces away from the shell
	const FVector PivotW = BT.GetLocation() * CM2M;
	float R = 0.f;
	Synth->Scrape.store(0.f); Synth->Hammer.store(0.f);
	if (Tool == 0)
	{
		const FVector Heel = NewTip + (PivotW - NewTip) * 0.4f;
		// bucket shake (smoothed acceleration) for spilling heaped soil
		const float Acc = FMath::Min((Vel - LastTipVel).Size() / FMath::Max(Dt, 1e-3f), 60.f);
		LastTipVel = Vel;
		Bucket.Shake = FMath::FInterpTo(Bucket.Shake, Acc, Dt, 6.f);
		// moving the back of the bucket first (bucket open, dragged over the ground) grades instead of digging
		const float TipSpd = Vel.Size();
		// and so does the floor of the bucket lying lower than its teeth while it is drawn along, with the opening not driven
		// into the ground: the teeth are not in the cut at all then, nothing can enter the bucket
		const FVector BellyP = Bucket.LowestOfBack(NewTip, PivotW, Mouth);
		const float BellyZ = FMath::Min(BellyP.Z, NewTip.Z);
		// the ground under the back is worked by the back's own movement: the bucket may turn about it while its teeth go elsewhere
		const FVector BellyVel = (BellyP - LastBelly) / Dt;
		LastBelly = BellyP;
		DbgBellyGap = Terrain->InBounds(BellyP.X, BellyP.Y) ? BellyP.Z - Terrain->HeightAt(BellyP.X, BellyP.Y) : 1e3f;
		const float BellyBelowTeeth = NewTip.Z - BellyZ;
		DbgBelly = BellyBelowTeeth;
		const float IntoMouth = TipSpd > 0.05f ? FVector::DotProduct(Mouth, Vel / TipSpd) : 0.f;
		const bool bBackFirst = TipSpd > 0.05f && (IntoMouth < -0.35f || (BellyBelowTeeth > 0.04f && IntoMouth < 0.5f && Terrain->HeightAt(NewTip.X, NewTip.Y) - NewTip.Z < 0.2f));
		// the bucket bears on the ground (pressed down with its bottom/back, or on rock it cannot cut):
		// instead of sinking in, it pushes the machine up about the far edge of its tracks
		const int32 Gi = Terrain->IndexAt(NewTip.X, NewTip.Y);
		const float Pen = Terrain->HeightAt(NewTip.X, NewTip.Y) - NewTip.Z;
		const float IntoN = TipSpd > 0.03f ? FVector::DotProduct(Mouth, Vel / TipSpd) : 0.f;
		const bool bFirm = !SoilProps(Terrain->SurfaceMat(Gi)).bDiggable || Terrain->SurfaceState(Gi).Hardness > 0.6f;
		// starts when the bucket is pushed down into ground it does not cut; while raised the machine rests on it
		// pressing with the back / bottom of the shell = moving against the mouth, not along the teeth
		const FVector ToothDir = (NewTip - PivotW).GetSafeNormal();
		const bool bBackPress = IntoN < -0.2f && (TipSpd < 0.03f || FVector::DotProduct(Vel / TipSpd, ToothDir) < 0.5f);
		const bool bBearing = bPropLift && (PropAngle > 0.05f || (Pen > 0.02f && Vel.Z < -0.02f && (bBackPress || bFirm)));
		// sideways only when the machine really drags it sideways (swinging, or driving with the house turned): a stalled
		// bucket's tip also drifts sideways as the machine rocks on its tracks, and that must not sweep the ground away
		const bool bDrivenSideways = FMath::Abs(VSwing) > 1.f || FMath::Abs(Speed) > 0.1f;
		const bool bSide = !bBearing && !bBackFirst && bDrivenSideways && TipSpd > 0.15f && FMath::Abs(FVector::DotProduct(Vel / TipSpd, Lat)) > 0.75f;
		Bucket.bGrading = false; Bucket.bSweeping = false;
		if (bBearing)
		{
			R = 0.3f; Bucket.CutRate = 0.f; Bucket.Attack = 0.f;
		}
		else if (bBackFirst)
		{
			R = Bucket.Grade(Terrain, NewTip, PivotW, Lat, BellyVel, Mouth, Dt);
			Bucket.CutRate = 0.f; Bucket.Attack = 0.f;
		}
		else if (bSide)
		{
			R = Bucket.Sweep(Terrain, NewTip, PivotW, Vel, Mouth, Dt);
			Bucket.CutRate = 0.f; Bucket.Attack = 0.f;
		}
		else R = Bucket.Dig(Terrain, NewTip, Heel, Lat, Vel, Mouth, H, Dt);
		Bucket.Resist = R;
		DbgBranch = bBearing ? 3 : bBackFirst ? 1 : bSide ? 2 : 0; DbgInto = IntoN; DbgPen = Pen;
		if (DbgBranch != 0) { Bucket.Penetration = FMath::Max(0.f, Pen); Bucket.DigForceN = Bucket.DigHorizN = Bucket.DigVertN = 0.f; } // (Dig sets them itself)
		{
			// lever from the bucket tip to the track edge the machine tips about
			const FVector Cn = LocalToWorldM(FVector::ZeroVector);
			FVector2D U(NewTip.X - Cn.X, NewTip.Y - Cn.Y);
			const float Reach2 = U.Size();
			U = Reach2 > 0.1f ? U / Reach2 : PropDir;
			const FVector2D Fw(FMath::Cos(FMath::DegreesToRadians(Yaw)), FMath::Sin(FMath::DegreesToRadians(Yaw))), Lt(-Fw.Y, Fw.X);
			const float Edge = FMath::Abs(FVector2D::DotProduct(U, Fw)) * TrackLength * 0.5f + FMath::Abs(FVector2D::DotProduct(U, Lt)) * (TrackGauge + TrackWidth) * 0.5f;
			const float Lever = FMath::Max(Reach2 + Edge, 1.f);
			const float MaxProp = 18.f;
			if (bBearing)
			{
				// the machine rests on the bucket: tilt it so the tip stays on the ground surface. Pushing the
				// tip in raises the machine, lifting the boom lets it settle back (gravity-limited) onto its tracks.
				const float Before = PropAngle;
				const float D = FMath::Max(FMath::RadiansToDegrees((Pen - 0.01f) / Lever), -25.f * Dt);
				PropAngle = FMath::Clamp(PropAngle + D, 0.f, MaxProp);
				if (Before < 0.5f) { PropDir = U; PropPivot = Edge; }
				else if (D > 0.f) PropDir = (PropDir + (U - PropDir) * FMath::Min(1.f, Dt * 3.f)).GetSafeNormal();
				if (Before + D > MaxProp && VBoom < 0.f) { BoomA -= VBoom * Dt; VBoom = 0.f; HydLoad = 1.2f; } // fully raised: the boom stalls
			}
		}
		// the cut breaks out of the face: cohesive soil in a few big clods, dry granular soil in many small bits
		ChunkAcc += Bucket.CutRate * Dt;
		if (Fx && ChunkAcc > 0.04f && Bucket.CutRate > 0.f)
		{
			ChunkAcc = 0.f;
			const ESoil M = Bucket.CutMat;
			const bool bCohesive = M == ESoil::Clay || M == ESoil::Laterite || M == ESoil::Compacted || M == ESoil::WetSoil || M == ESoil::Mud || Bucket.CutMoist > 0.5f;
			const bool bRock = M == ESoil::SmallRock || M == ESoil::LargeRock || M == ESoil::Gravel;
			const int32 Count = bCohesive ? 2 : bRock ? 3 : 5;
			const float ChunkSz = bCohesive ? 0.24f : bRock ? 0.16f : 0.09f;
			const FVector Up = (Mouth * 0.5f + FVector(0, 0, 1.f)).GetSafeNormal();
			Fx->SpawnChunks(Bucket.BreakAt + FVector(0, 0, 0.05f), Vel * 0.5f + Up * (bCohesive ? 1.2f : 1.8f), M, Bucket.CutMoist, Count, ChunkSz);
			if (!bCohesive && Bucket.CutMoist < 0.3f) Fx->SpawnDust(Bucket.BreakAt, 0.5f, Up * 0.5f);
		}
		Synth->Scrape.store(FMath::Clamp(Bucket.CutRate * 1.5f + (Bucket.bBlocked ? 0.5f : 0.f), 0.f, 1.f));
		Synth->Rock.store(Bucket.bBlocked ? 0.7f : 0.f);
		const ESoil PourMat = Bucket.Load.Dominant(); const float PourMoist = Bucket.Load.Moist;
		// soil leaves the bucket where it really can: over the lower edge of the opening, or through it when the bucket is
		// tipped over - just outside the steel (started inside the shell, as it was, it fell through the bucket's own floor)
		const FVector Lip = SoilExitAt(0.f);
		const float Sp = Bucket.Spill(Fx, Lip, Vel, Mouth, Dt, BucketHoldLoose(), SoilExitAt(1.f) - Lip);
		// the soil force reacts on the machine: pulling harder than its tracks can grip drags it along the ground
		{
			const float MassKg = Mass();
			const float Grip = Traction * MassKg * GRAV;
			// the tracks feel only what the hydraulics can deliver, not the full strength of the soil
			const float SlipN = FMath::Min(Bucket.DigHorizN, Bucket.ForceLimitN) - Grip;
			DragSpeed = FMath::FInterpTo(DragSpeed, SlipN > 0.f ? FMath::Min(SlipN / FMath::Max(MassKg, 1.f) * 0.25f, 0.4f) : 0.f, Dt, 5.f);
			if (DragSpeed <= 0.002f) DragVel = FVector::ZeroVector;
			if (DragSpeed > 0.002f && TipSpd > 0.01f)
			{
				// pulled along against the bucket's stroke relative to the machine (the tip's own speed already includes this slide)
				const FVector TipRel = Vel - DragVel;
				DragVel = -FVector(TipRel.X, TipRel.Y, 0.f).GetSafeNormal() * DragSpeed;
				PosM += DragVel * Dt;
				Warning = TEXT("TRACKS SLIPPING - cut shallower");
			}
		}
		if (Fx && Sp > 0.02f)
		{
			// pouring stream: tumbling clods of the real material and, if it is dry, a cloud of dust (visual only;
			// the soil volume itself travels in the clods spawned by Spill)
			// a curtain across the whole lip, as thick as the real flow: fine grains and some lumps
			const bool bSticky = PourMat == ESoil::Clay || PourMat == ESoil::Mud || PourMoist > 0.5f;
			PourAcc += Sp * Dt * (bSticky ? 120.f : 340.f);
			const int32 Grains = FMath::Min(FMath::FloorToInt(PourAcc), 14);
			PourAcc = FMath::Min(PourAcc - Grains, 1.f);
			for (int32 g = 0; g < Grains; ++g)
			{
				const FVector GrainAt = SoilExitAt(FMath::FRandRange(-1.f, 1.f)); // (across the inside width only)
				const FVector Fall = Vel * 0.7f + Mouth * FMath::FRandRange(0.1f, 0.7f) + FVector(0, 0, -0.3f);
				const float GrainSz = FMath::FRand() < 0.12f ? FMath::FRandRange(0.12f, 0.2f) : FMath::FRandRange(0.04f, 0.09f);
				Fx->SpawnChunks(GrainAt, Fall, PourMat, PourMoist, 1, bSticky ? GrainSz * 1.5f : GrainSz);
			}
			if (PourMoist < 0.35f && FMath::FRand() < Sp * Dt * 6.f) Fx->SpawnDust(Lip - FVector(0, 0, 0.6f), 0.45f, Vel * 0.3f);
		}
		// fine soil keeps trickling off the teeth and the outside of a loaded bucket for a few seconds after the cut
		// and while it moves (a curtain of grains, as seen from the cab; visual - the real loss is the bits below)
		if (Bucket.CutRate > 0.f) SinceCut = 0.f; else SinceCut += Dt;
		const float FillNow = Bucket.Load.Total() / FMath::Max(Bucket.Capacity, 0.01f);
		if (Fx && FillNow > 0.3f && (SinceCut < 3.5f || TipSpd > 0.4f))
		{
			const float Strength = FMath::Clamp(FillNow, 0.f, 1.2f) * (SinceCut < 3.5f ? 1.f - SinceCut / 4.f : 0.35f);
			TrickleT += Dt * Strength;
			while (TrickleT > 0.018f)
			{
				TrickleT -= 0.018f;
				const FVector P = SoilExitAt(FMath::FRandRange(-1.f, 1.f), true); // off the outside of the teeth
				Fx->SpawnChunks(P, Vel * 0.8f + FVector(0, 0, -0.4f), PourMat, PourMoist, 1, FMath::FRandRange(0.05f, 0.1f));
				if (PourMoist < 0.35f && FMath::FRand() < 0.06f) Fx->SpawnDust(P - FVector(0, 0, 0.4f), 0.3f, Vel * 0.2f);
			}
		}
		else TrickleT = 0.f;
		// a well-filled bucket that is moving loses a few bits over the edge now and then (real soil, it lands
		// on the ground), with a little dust when it is dry
		if (Fx && Bucket.Load.Total() > 0.8f * Bucket.Capacity && TipSpd > 0.5f)
		{
			DebrisT += Dt;
			if (DebrisT > 0.45f)
			{
				DebrisT = 0.f;
				const FPayload Bit = Bucket.Load.Take(FMath::Min(0.004f, Bucket.Load.Total()));
				Fx->SpawnSoil(Lip, Vel * 0.6f, Bit, 0.12f);
				if (Bit.Moist < 0.35f) Fx->SpawnDust(Lip, 0.25f, Vel * 0.2f);
			}
		}
		Synth->Pour.store(FMath::Clamp(Sp, 0.f, 1.f));
		if (Bucket.CutRate > 0.05f) Dirt = FMath::Min(1.f, Dirt + Dt * 0.002f);
	}
	else if (Tool == 1)
	{
		const float G = Terrain->HeightAt(NewTip.X, NewTip.Y);
		const float E = G - NewTip.Z;
		R = FMath::Max(0.f, E) * 10.f;
		if (bToolActive && bEngineOn)
		{
			Synth->Hammer.store(1.f);
			HydLoad = FMath::Max(HydLoad, 0.8f);
			if (E > -0.15f)
			{
				HammerAcc += Dt;
				if (HammerAcc > 0.35f)
				{
					HammerAcc = 0.f;
					const int32 CX = Terrain->ToGrid(NewTip.X), CY = Terrain->ToGrid(NewTip.Y);
					for (int32 dy = -1; dy <= 1; ++dy)
						for (int32 dx = -1; dx <= 1; ++dx)
							if (Terrain->Valid(CX + dx, CY + dy)) Terrain->BreakRock(Terrain->Idx(CX + dx, CY + dy), 0.25f);
					if (Fx) Fx->SpawnDust(NewTip, 0.7f, FVector(0, 0, 0.5f));
				}
			}
		}
	}
	else if (Tool == 2)
	{
		GrappleClose = FMath::FInterpConstantTo(GrappleClose, bToolActive ? 1.f : 0.f, Dt, 1.5f);
		if (bToolActive && !Held.IsValid() && GrappleClose > 0.6f)
		{
			if (ARWProp* P = NearestProp(NewTip, 1.8f * S)) { Held = P; P->bCarried = true; }
		}
		if (!bToolActive && Held.IsValid()) { Held->bCarried = false; Held->VelM = FVector::ZeroVector; Held.Reset(); }
		const float G = Terrain->HeightAt(NewTip.X, NewTip.Y);
		R = FMath::Max(0.f, G - NewTip.Z) * 6.f;
	}
	else
	{
		const float G = Terrain->HeightAt(NewTip.X, NewTip.Y);
		const float E = G - NewTip.Z;
		if (bToolActive && bEngineOn)
		{
			HydLoad = FMath::Max(HydLoad, 0.6f);
			if (Auger) Auger->AddLocalRotation(FRotator(0, 0, 900.f * Dt));
			if (E > 0.f)
			{
				// drilling: remove a 0.6 m column, auger lifts the spoil to a ring around the hole
				FPayload Spoil;
				const int32 CX = Terrain->ToGrid(NewTip.X), CY = Terrain->ToGrid(NewTip.Y);
				for (int32 dy = -1; dy <= 1; ++dy)
					for (int32 dx = -1; dx <= 1; ++dx)
					{
						if (!Terrain->Valid(CX + dx, CY + dy)) continue;
						const int32 i = Terrain->Idx(CX + dx, CY + dy);
						const float Hd = Terrain->SurfaceState(i).Hardness;
						Terrain->RemoveAt(i, FMath::Min(Terrain->Height[i] - NewTip.Z, 0.5f * Dt / (0.2f + Hd)), Spoil);
					}
				if (Spoil.Total() > 0)
				{
					const float A = FMath::FRand() * 2 * PI;
					const float RX = NewTip.X + FMath::Cos(A) * 1.1f, RY = NewTip.Y + FMath::Sin(A) * 1.1f;
					if (Terrain->InBounds(RX, RY)) Terrain->DepositPayloadAt(Terrain->IndexAt(RX, RY), Spoil);
				}
				Synth->Scrape.store(0.6f);
				R = E * 1.5f;
			}
		}
		else R = FMath::Max(0.f, E) * 10.f;
	}
	if (Tool != 0) { Bucket.Resist = R; Bucket.DigForceN = Bucket.DigHorizN = Bucket.DigVertN = 0.f; PropAngle = FMath::Max(0.f, PropAngle - 25.f * Dt); }
	SlingTick(NewTip, Vel, Dt);
	// pushing trees over: with whatever is on the arm, and by driving the tracks into them
	if (TreeHitter)
	{
		// (the push carries the speed: a fallen trunk or a rock is shoved along at it)
		// the bucket only moves what its teeth and shell reach (about its own depth around the teeth)
		if (Vel.Size() > 0.15f) TreeHitter(NewTip, 0.8f * S, FVector(Vel.X, Vel.Y, 0.f), FMath::Clamp(Bucket.Depth * 0.6f, 0.3f, 0.8f));
		if (FMath::Abs(Speed) > 0.1f)
		{
			// the front of the tracks: from the ground up to the top of the chain
			const float Sgn = Speed > 0.f ? 1.f : -1.f;
			TreeHitter(LocalToWorldM(FVector(Sgn * TrackLength * 0.55f, 0.f, 0.5f)), (TrackGauge + TrackWidth) * 0.5f, Fwd2() * Speed, 0.55f);
		}
	}
	if (JawL) JawL->SetRelativeRotation(FRotator(-35.f * GrappleClose, 0, 0));
	if (JawR) JawR->SetRelativeRotation(FRotator(35.f * GrappleClose, 0, 0));
	if (Held.IsValid())
	{
		Held->SetActorLocation((NewTip - FVector(0, 0, 0.3f)) * M2CM);
		Held->SetActorRotation(FRotator(Held->Type == 0 ? -90.f : 0.f, Yaw + Swing + 90.f, 0));
	}
	// rocks: a boulder the bucket curls round (small enough for its width) rides in it until the bucket is tipped
	// trunks: a felled tree the bucket gets under (lying across the bucket's mouth) rides on it the same way, across the bucket
	if (Tool == 0)
	{
		const FVector Cav = (NewTip + PivotW) * 0.5f - Mouth * Bucket.Depth * 0.45f;
		if (!InBucket.IsValid() && Mouth.Z > 0.3f)
		{
			for (const TWeakObjectPtr<ARWProp>& Wp : ARWProp::All)
			{
				ARWProp* Rk = Wp.Get();
				if (!Rk || Rk->bCarried) continue;
				if (Rk->Type == 1)
				{
					if (1.5f * Rk->RockSize > Bucket.Width * 1.15f) continue;
					const FVector Rc = Rk->PosM() + FVector(0, 0, 0.45f * Rk->RockSize);
					if (FVector::Dist(Rc, Cav) < 0.35f * Bucket.Width + 0.4f * Rk->RockSize) { InBucket = Rk; Rk->bCarried = true; break; }
				}
				else if (Rk->Type == 0 && Rk->FallAngle >= 89.f)
				{
					// the nearest point of the trunk (from its stump end along the way it fell, about 0.22 m over the ground)
					const float Len = Rk->LogLength();
					const FVector Ax(FMath::Cos(FMath::DegreesToRadians(Rk->FallYaw)), FMath::Sin(FMath::DegreesToRadians(Rk->FallYaw)), 0.f);
					const FVector Base = Rk->PosM() + FVector(0, 0, 0.22f);
					const FVector Near = Base + Ax * FMath::Clamp((float)FVector::DotProduct(Cav - Base, Ax), 0.f, Len);
					if (FVector::Dist(Near, Cav) < 0.35f * Bucket.Width + 0.3f) { InBucket = Rk; InBucketLen = Len; Rk->bCarried = true; break; }
				}
			}
		}
		if (ARWProp* Rk = InBucket.Get())
		{
			if (Mouth.Z < -0.15f)
			{
				// tipped out: it falls with the bucket's movement
				Rk->bCarried = false;
				Rk->VelM = FVector(0.f, 0.f, FMath::Min(Vel.Z, 0.f));
				Rk->SetActorLocation((Rk->PosM() + Mouth * 0.4f) * M2CM);
				InBucket = nullptr;
			}
			else if (Rk->Type == 0)
			{
				// across the bucket, its middle in the bucket
				Rk->FallYaw = Yaw + Swing + 90.f;
				const FVector Ax(FMath::Cos(FMath::DegreesToRadians(Rk->FallYaw)), FMath::Sin(FMath::DegreesToRadians(Rk->FallYaw)), 0.f);
				Rk->SetActorLocationAndRotation((Cav + Mouth * 0.15f - Ax * 0.5f * InBucketLen - FVector(0, 0, 0.22f)) * M2CM, FRotator(-Rk->FallAngle, Rk->FallYaw, 0.f));
				R += Rk->MassKg / 4000.f * 0.3f; // its weight on the arm
			}
			else
			{
				Rk->SetActorLocation((Cav + Mouth * 0.15f - FVector(0, 0, 0.45f * Rk->RockSize)) * M2CM);
				Rk->SetActorRotation(FRotator(0.f, Yaw + Swing, 0.f));
				R += Rk->MassKg / 4000.f * 0.3f; // its weight on the arm
			}
		}
	}
	else if (ARWProp* Rk = InBucket.Get()) { Rk->bCarried = false; InBucket = nullptr; }
	const float Flow = (FMath::Abs(VSwing) / 40.f + FMath::Abs(VBoom) / 22.f + FMath::Abs(VArm) / 28.f + FMath::Abs(VBkt) / 48.f) * 0.5f;
	HydLoad = FMath::Max(HydLoad, FMath::Clamp(Flow + R * 0.3f, 0.f, 1.3f));
	if (R > 1.6f) HydLoad = FMath::Max(HydLoad, 1.15f); // relief valve when stalled
	WorkKW = PowerKW * 0.8f * FMath::Clamp(Flow * (0.4f + 0.6f * FMath::Clamp(R, 0.f, 1.f)) + (HydLoad > 1.f ? 0.5f : 0.f), 0.f, 1.f);
}

void ARWExcavator::VisualTick(float Dt)
{
	if (Link.bOn) UpdateLinkage();
	if (Aims.Num()) UpdateAims();
	if (Tool == 0 && !bModelRig) SetHeap(Heap, HeapMID, Bucket.Load, Bucket.Load.Total() / FMath::Max(Bucket.Capacity, 0.01f), FVector(0.5f * Lk, 0, 0.14f * Lk), FVector(0.85f * Lk, Bucket.Width * 0.9f, 0.32f * Lk));
	else if (Tool == 0) SetHeap(Heap, HeapMID, Bucket.Load, Bucket.Load.Total() / FMath::Max(Bucket.Capacity, 0.01f), FVector(0.5f * Lk, 0, 0.15f * Lk * BucketSign), FVector(0.8f * Lk, Bucket.Width * 0.85f, 0.3f * Lk));
	// soil shaped by the bucket's cross-section replaces the old stretched lump
	UpdateBucketFill();
	if (FillMesh && FillMesh->IsVisible()) { if (Heap) Heap->SetVisibility(false); } // its clods are placed on the fill surface
	else UpdateHeapClods();
	if (FillMesh)
	{
		// F6 debug: the cavity the soil fills (magenta box) and the soil itself in bright pink
		static UMaterialInstanceDynamic* Pink = nullptr;
		if (!Pink) { Pink = UMaterialInstanceDynamic::Create(GPaint, GetTransientPackage()); Pink->SetVectorParameterValue(TEXT("Color"), FLinearColor(1.f, 0.05f, 0.6f)); Pink->AddToRoot(); }
		FillMesh->SetMaterial(0, bDebugBucket ? (UMaterialInterface*)Pink : (UMaterialInterface*)HeapMID);
		if (bDebugBucket && ToolRoots.Num())
		{
			const FTransform Xf = ToolRoots[0]->GetComponentTransform();
			const float Dp = FMath::Max(Bucket.Depth, 0.15f * Lk);
			DrawDebugBox(GetWorld(), Xf.TransformPosition(FVector(0.5f * Lk, 0.f, 0.5f * Dp * BucketSign) * M2CM), FVector(0.5f * Lk, Bucket.Width * 0.5f, 0.5f * Dp) * M2CM, Xf.GetRotation(), FColor::Magenta, false, -1.f, 0, 1.5f);
			DrawDebugDirectionalArrow(GetWorld(), Xf.TransformPosition(FVector(0.5f * Lk, 0, 0) * M2CM), Xf.TransformPosition(FVector(0.5f * Lk, 0, 0) * M2CM) + MouthDir() * 80.f, 25.f, FColor::Cyan, false, -1.f, 0, 2.f);
		}
	}
	if (CabCam && CabRoot && CabCam->GetAttachParent() != CabRoot) CabCam->AttachToComponent(CabRoot, FAttachmentTransformRules::KeepRelativeTransform);
}

void ARWExcavator::UpdateHeapClods()
{
	// lumps and stones sitting on the heap make the load look broken-up instead of one smooth blob
	if (!Heap) return;
	USceneComponent* Parent = Heap->GetAttachParent();
	if (!Parent) return;
	static const FVector Off[7] = {{0.1f, 0.f, 1.f}, {-0.45f, 0.35f, 0.8f}, {0.4f, -0.4f, 0.8f}, {-0.3f, -0.5f, 0.75f}, {0.5f, 0.45f, 0.7f}, {-0.6f, 0.f, 0.65f}, {0.15f, 0.6f, 0.7f}};
	if (HeapClods.Num() == 0)
	{
		for (int32 k = 0; k < 7; ++k)
		{
			UStaticMeshComponent* C = MeshPart(Parent, FRWMeshGen::Rock(1.f, 40 + k), FVector::ZeroVector, FRotator(k * 37.f, k * 71.f, k * 23.f), HeapMID, FVector(0.2f));
			C->bCastDynamicShadow = false;
			C->SetVisibility(false);
			HeapClods.Add(C);
		}
	}
	const float F = Tool == 0 ? Bucket.Load.Total() / FMath::Max(Bucket.Capacity, 0.01f) : 0.f;
	const ESoil M = Bucket.Load.Dominant();
	const bool bFine = M == ESoil::Sand || M == ESoil::Mud; // flowing soil has a smooth surface
	const int32 Show = (F < 0.25f || bFine) ? 0 : FMath::Clamp(FMath::RoundToInt(F * 6.f), 1, 7);
	const FVector HL = Heap->GetRelativeLocation(), HS = Heap->GetRelativeScale3D() * 100.f; // heap centre & full size (cm)
	const bool bRocky = M == ESoil::SmallRock || M == ESoil::LargeRock || M == ESoil::Gravel;
	for (int32 k = 0; k < HeapClods.Num(); ++k)
	{
		UStaticMeshComponent* C = HeapClods[k];
		const bool bVis = k < Show && Heap->IsVisible();
		C->SetVisibility(bVis);
		if (!bVis) continue;
		const FVector P = HL + FVector(Off[k].X * HS.X * 0.32f, Off[k].Y * HS.Y * 0.32f, Off[k].Z * HS.Z * 0.42f);
		C->SetRelativeLocation(P);
		const float Sz = (bRocky ? 0.16f : 0.2f) * (0.7f + 0.15f * (k % 3)) * FMath::Clamp(FMath::Sqrt(F), 0.6f, 1.15f) * FMath::Max(S, 0.6f);
		C->SetRelativeScale3D(FVector(Sz, Sz * 0.85f, Sz * 0.7f));
	}
}

// ---- bucket soil detail: broken-up soil instead of a smooth skin ----
// Height (m) of round clods pressed together on a plane: the highest dome over (X, Y), with sharp creases between
// neighbours - which is what makes dug soil look dug, where smooth noise only looks like a wavy sheet.
static float RWClods(float X, float Y, float Cell, int32 Seed)
{
	const int32 IX = FMath::FloorToInt(X / Cell), IY = FMath::FloorToInt(Y / Cell);
	float Best = 0.f;
	for (int32 dy = -1; dy <= 1; ++dy)
		for (int32 dx = -1; dx <= 1; ++dx)
		{
			uint32 H = (uint32)((IX + dx) * 73856093) ^ (uint32)((IY + dy) * 19349663) ^ (uint32)(Seed * 83492791);
			H ^= H >> 13; H *= 0x5bd1e995u; H ^= H >> 15;
			const float Cx = (IX + dx + (H & 255) / 255.f) * Cell, Cy = (IY + dy + ((H >> 8) & 255) / 255.f) * Cell;
			const float R = Cell * (0.55f + 0.45f * ((H >> 16) & 255) / 255.f);
			const float D2 = FMath::Square(X - Cx) + FMath::Square(Y - Cy);
			if (D2 < R * R) Best = FMath::Max(Best, R * FMath::Sqrt(1.f - D2 / (R * R)));
		}
	return Best;
}

// a few irregular lump shapes around the origin (radius about 1), drawn side outward
struct FRWGrainShape { TArray<FVector> P, N; TArray<int32> T; };
static const TArray<FRWGrainShape>& RWGrainShapes(bool bLump)
{
	static TArray<FRWGrainShape> Small, Lumps;
	TArray<FRWGrainShape>& Out = bLump ? Lumps : Small;
	if (Out.Num() > 0) return Out;
	FRandomStream Rs(bLump ? 8123 : 2741);
	for (int32 s = 0; s < 8; ++s)
	{
		const float G = 1.618034f;
		TArray<FVector> P = {{-1, G, 0}, {1, G, 0}, {-1, -G, 0}, {1, -G, 0}, {0, -1, G}, {0, 1, G}, {0, -1, -G}, {0, 1, -G}, {G, 0, -1}, {G, 0, 1}, {-G, 0, -1}, {-G, 0, 1}};
		TArray<int32> T = {0,11,5, 0,5,1, 0,1,7, 0,7,10, 0,10,11, 1,5,9, 5,11,4, 11,10,2, 10,7,6, 7,1,8, 3,9,4, 3,4,2, 3,2,6, 3,6,8, 3,8,9, 4,9,5, 2,4,11, 6,2,10, 8,6,7, 9,8,1};
		if (bLump)
		{
			// one subdivision: enough to look like a clod at arm's length
			TMap<uint64, int32> Mid;
			auto Middle = [&](int32 A, int32 B) { const uint64 Key = ((uint64)FMath::Min(A, B) << 32) | (uint32)FMath::Max(A, B); if (const int32* F = Mid.Find(Key)) return *F; const int32 I = P.Add((P[A] + P[B]) * 0.5f); Mid.Add(Key, I); return I; };
			TArray<int32> T2;
			for (int32 k = 0; k + 2 < T.Num(); k += 3)
			{
				const int32 A = T[k], B = T[k + 1], C = T[k + 2], AB = Middle(A, B), BC = Middle(B, C), CA = Middle(C, A);
				T2.Append({A, AB, CA, B, BC, AB, C, CA, BC, AB, BC, CA});
			}
			T = T2;
		}
		FRWGrainShape Sh;
		for (FVector& Q : P) Q = Q.GetSafeNormal() * Rs.FRandRange(bLump ? 0.58f : 0.55f, 1.25f); // knobbly, not round
		Sh.P = P; Sh.T = T; Sh.N.Init(FVector::ZeroVector, P.Num());
		for (int32 k = 0; k + 2 < Sh.T.Num(); k += 3)
		{
			// Unreal draws the side where (C-A) x (B-A) points: wind every face outward
			FVector Fn = FVector::CrossProduct(Sh.P[Sh.T[k + 2]] - Sh.P[Sh.T[k]], Sh.P[Sh.T[k + 1]] - Sh.P[Sh.T[k]]);
			if (FVector::DotProduct(Fn, Sh.P[Sh.T[k]] + Sh.P[Sh.T[k + 1]] + Sh.P[Sh.T[k + 2]]) < 0.f) { Swap(Sh.T[k + 1], Sh.T[k + 2]); Fn = -Fn; }
			Sh.N[Sh.T[k]] += Fn; Sh.N[Sh.T[k + 1]] += Fn; Sh.N[Sh.T[k + 2]] += Fn;
		}
		for (FVector& Nn : Sh.N) Nn = Nn.GetSafeNormal();
		Out.Add(Sh);
	}
	return Out;
}

// fixed places for the loose pieces, so they stay put from one rebuild to the next instead of flickering
struct FRWFillGrain { float Ft, Fw, Size, FlatZ; int32 Shape; bool bLump; FVector2D UvOff; };
static const TArray<FRWFillGrain>& RWFillGrains()
{
	static TArray<FRWFillGrain> G;
	if (G.Num() > 0) return G;
	FRandomStream Rs(55117);
	for (int32 k = 0; k < 420; ++k)
	{
		FRWFillGrain Q;
		Q.bLump = k % 8 == 0;
		Q.Ft = Rs.FRandRange(0.02f, 0.98f); Q.Fw = Rs.FRandRange(0.02f, 0.98f);
		const float Pk = FMath::Square(Rs.FRand()); // many small ones, few big ones
		Q.Size = Q.bLump ? FMath::Lerp(0.03f, 0.062f, Pk) : FMath::Lerp(0.012f, 0.032f, Pk);
		Q.FlatZ = Rs.FRandRange(0.6f, 0.95f);
		Q.Shape = Rs.RandRange(0, 7);
		Q.UvOff = FVector2D(Rs.FRand(), Rs.FRand());
		G.Add(Q);
	}
	return G;
}

// ---- bucket fill: polygons in the bucket's own plane (x towards the lip, z into the shell) ----
static float RWPolyArea(const TArray<FVector2D>& P)
{
	float A = 0.f;
	for (int32 i = 0; i < P.Num(); ++i) { const FVector2D& a = P[i]; const FVector2D& b = P[(i + 1) % P.Num()]; A += a.X * b.Y - b.X * a.Y; }
	return FMath::Abs(A) * 0.5f;
}

static void RWClipBelow(const TArray<FVector2D>& P, const FVector2D& Up, float Level, TArray<FVector2D>& Out)
{
	// keep the part of a convex polygon at or below the level line (Sutherland-Hodgman against one half-plane)
	Out.Reset();
	for (int32 i = 0; i < P.Num(); ++i)
	{
		const FVector2D& A = P[i]; const FVector2D& B = P[(i + 1) % P.Num()];
		const float Da = FVector2D::DotProduct(A, Up) - Level, Db = FVector2D::DotProduct(B, Up) - Level;
		if (Da <= 0.f) Out.Add(A);
		if ((Da < 0.f && Db > 0.f) || (Da > 0.f && Db < 0.f)) Out.Add(A + (B - A) * (Da / (Da - Db)));
	}
}

bool ARWExcavator::AutoDig(float Dt, float TargetFrac, bool bDump, float DumpTo, int32& Phase, float& PhaseT)
{
	InA1 = InA2 = InA3 = InA4 = 0.f;
	PhaseT += Dt;
	const FVector Tip = TipWorld();
	const float Pen = Terrain ? Terrain->HeightAt(Tip.X, Tip.Y) - Tip.Z : 0.f; // > 0: teeth below the surface
	const float Load = Bucket.Load.Total(), Cap = FMath::Max(Bucket.Capacity, 0.01f);
	auto Next = [&](int32 P) { Phase = P; PhaseT = 0.f; };
	switch (Phase)
	{
	case 0:                                                                             // stick out, open the bucket until the teeth point down
	{
		const bool bArmOut = ArmA >= ArmHi - 35.f, bOpen = BktA >= BktHi - 25.f;
		InA2 = bArmOut ? 0.f : 1.f; InA3 = bOpen ? 0.f : 1.f;
		if ((bArmOut && bOpen) || PhaseT > 5.f) Next(1);
		break;
	}
	case 1: InA1 = -1.f; if (Pen > 0.15f || PhaseT > 6.f) Next(2); break;             // lower the teeth into the ground
	case 2:                                                                             // dig: stick in and curl, keep the depth
		// curl only while the opening still faces down / forward (curling past upright turns this bucket over)
		InA2 = ArmA > ArmLo + 15.f ? -1.f : 0.f;
		InA3 = MouthDir().Z < 0.35f ? 0.55f * MouthUpInput() : 0.f;
		{
			const float Lo = TargetFrac > 1.f ? 0.3f : 0.12f, Hi = TargetFrac > 1.f ? 0.7f : 0.45f; // a heaped bucket needs a deeper cut
			InA1 = (Pen > Hi || Bucket.Resist > 1.3f) ? 0.6f : Pen < Lo ? -0.6f : 0.f; // too deep, or the machine labouring: ease up
		}
		if (Load >= TargetFrac * Cap || PhaseT > 10.f || ArmA <= ArmLo + 15.f) Next(3);
		break;
	case 3:                                                                             // turn the opening up (the way that gets there)
		InA3 = MouthUpInput(); InA2 = -0.3f;
		InA1 = Pen > 0.1f ? 1.f : 0.f; // lift while curling, as an operator does: curling alone in a deep cut stalls
		if (MouthDir().Z > 0.6f || PhaseT > 4.f) Next(4);
		break;
	case 4:                                                                             // lift out of the cut, keep the opening up
		InA1 = 1.f; InA3 = MouthDir().Z < 0.6f ? MouthUpInput() : 0.f;
		if (PhaseT > 1.8f) Next(bDump ? 5 : 9);
		break;
	case 5: InA4 = 1.f; if (PhaseT > 1.6f) Next(6); break;                              // swing to the side
	case 6:                                                                             // turn the opening down: dump
	{
		const float Up = MouthUpInput();
		InA3 = Up != 0.f ? -Up : 1.f;
		if (Load <= DumpTo * Cap || PhaseT > 6.f) Next(9);
		break;
	}
	default: return true;
	}
	return Phase >= 9;
}

float ARWExcavator::MouthUpInput() const
{
	// bucket control (+ = open / dump, - = curl) that turns the opening towards the sky from the current pose:
	// world pitch of the bucket th = boom + stick + bucket; opening up-component = -cos(th) (x BucketSign)
	const float Th = FMath::DegreesToRadians(BoomA + ArmA + BktA);
	const float Grad = FMath::Sin(Th) * BucketSign;
	const float In = Grad >= 0.f ? 1.f : -1.f;
	if ((In > 0.f && BktA >= BktHi - 1.f) || (In < 0.f && BktA <= BktLo + 1.f)) return 0.f; // at the joint stop
	return In;
}

FVector ARWExcavator::MouthDir() const
{
	return BucketP ? BucketP->GetComponentTransform().TransformVectorNoScale(FVector(0, 0, -BucketSign)) : FVector::UpVector;
}

void ARWExcavator::MassParts(TArray<FMassPart>& Out) const
{
	if (!BoomP || !ArmP || !BucketP) { Super::MassParts(Out); return; }
	const FString TotalSrc = XmlMassKg.Contains(TEXT("total")) ? TEXT("vehicle.xml") : ModId.IsEmpty() ? TEXT("built-in machine list") : TEXT("mod.json mass_kg");
	const float Total = XmlMassKg.Contains(TEXT("total")) ? XmlMassKg[TEXT("total")] : EmptyMass;
	// a part's mass: from vehicle.xml when it is there, otherwise an ESTIMATE (a share of the machine's mass usual for a
	// crawler excavator - not this machine's specification) or the bucket's own rating
	auto Part = [&](const TCHAR* Name, float Estimate, const FString& EstSrc, const FVector& At)
	{
		FMassPart P; P.Name = Name; P.At = At;
		if (const float* X = XmlMassKg.Find(FString(Name).ToLower())) { P.Kg = *X; P.Source = TEXT("vehicle.xml"); }
		else { P.Kg = Estimate; P.Source = EstSrc; }
		Out.Add(P);
		return P.Kg;
	};
	auto W = [](const USceneComponent* C) { return C->GetComponentLocation() * CM2M; };
	const FVector Tip = TipWorld();
	const FTransform AT = GetActorTransform();
	float Used = 0.f;
	Used += Part(TEXT("boom"), 0.075f * Total, TEXT("estimate: 7.5% of the machine"), (W(BoomP) + W(ArmP)) * 0.5f);
	Used += Part(TEXT("stick"), 0.035f * Total, TEXT("estimate: 3.5% of the machine"), (W(ArmP) + W(BucketP)) * 0.5f);
	Used += Part(TEXT("bucket"), Bucket.MassKg, TEXT("bucket rating"), (W(BucketP) + Tip) * 0.5f);
	Used += Part(TEXT("undercarriage"), 0.33f * Total, TEXT("estimate: 33% of the machine"), AT.TransformPosition(FVector(0.f, 0.f, 0.45f) * M2CM) * CM2M);
	// the house: the rest, its centre of mass behind the swing centre (the counterweight) - turned with the house
	const USceneComponent* Hs = House ? House : BoomP;
	const FVector HouseAt = Hs->GetComponentLocation() * CM2M - Hs->GetForwardVector() * 0.6f * S + FVector(0.f, 0.f, 0.9f * S);
	Used += Part(TEXT("house"), FMath::Max(Total - Used, 0.2f * Total), TEXT("the rest of the machine; centre of mass estimated 0.6 m behind the swing centre"), HouseAt);
	// vehicle.xml's parts and its total disagree (more than rounding): both are kept as given - there is no telling which one
	// is wrong - and the log says so with the stability line
	if (XmlMassKg.Contains(TEXT("total")) && FMath::Abs(Used - Total) > 0.02f * Total)
		Out.Last().Source += FString::Printf(TEXT("; MISMATCH: the parts add up to %.0f kg, vehicle.xml total %.0f kg"), Used, Total);
	if (Bucket.Load.Total() > 0.f) { FMassPart L; L.Name = TEXT("load"); L.Kg = Bucket.Load.MassKg(); L.At = (W(BucketP) + Tip) * 0.5f; L.Source = TEXT("the soil in the bucket"); Out.Add(L); }
}

FVector ARWExcavator::ToolForceN(FVector& AtWorld) const
{
	AtWorld = TipWorld();
	if (Tool != 0 || Bucket.DigForceN <= 0.f || LastTipVel.SizeSquared() < 1e-4f) return FVector::ZeroVector;
	return -LastTipVel.GetSafeNormal() * FMath::Min(Bucket.DigForceN, Bucket.ForceLimitN);
}

bool ARWExcavator::RaySteel(const TArray<FVector>& Tris, const FVector& O, const FVector& D, float MaxT, float& OutT)
{
	// Moller-Trumbore, both faces (the steel is a closed plate: either side counts)
	OutT = MaxT;
	bool bHit = false;
	for (int32 k = 0; k + 2 < Tris.Num(); k += 3)
	{
		const FVector E1 = Tris[k + 1] - Tris[k], E2 = Tris[k + 2] - Tris[k];
		const FVector Pv = FVector::CrossProduct(D, E2);
		const double Det = FVector::DotProduct(E1, Pv);
		if (FMath::Abs(Det) < 1e-12) continue;
		const double Inv = 1.0 / Det;
		const FVector Tv = O - Tris[k];
		const double U = FVector::DotProduct(Tv, Pv) * Inv;
		if (U < 0.0 || U > 1.0) continue;
		const FVector Q = FVector::CrossProduct(Tv, E1);
		const double V = FVector::DotProduct(D, Q) * Inv;
		if (V < 0.0 || U + V > 1.0) continue;
		const double T = FVector::DotProduct(E2, Q) * Inv;
		if (T > 1e-4 && T < OutT) { OutT = (float)T; bHit = true; }
	}
	return bHit;
}

float ARWExcavator::InsideHalfAt(float X, float Def) const
{
	if (BucketInside.Num() == 0) return Def;
	if (X <= BucketInside[0].X) return FMath::Min(Def, (float)BucketInside[0].Z);
	for (int32 i = 1; i < BucketInside.Num(); ++i)
		if (X <= BucketInside[i].X)
		{
			const float F = (X - BucketInside[i - 1].X) / FMath::Max((float)(BucketInside[i].X - BucketInside[i - 1].X), 1e-4f);
			return FMath::Min(Def, FMath::Lerp((float)BucketInside[i - 1].Z, (float)BucketInside[i].Z, F));
		}
	return FMath::Min(Def, (float)BucketInside.Last().Z);
}

FVector2D ARWExcavator::FindSoilExit(const FTransform& BT, bool bAtTeeth) const
{
	TArray<FVector2D> Poly;
	BuildFillPoly(Poly);
	if (Poly.Num() < 3) return FVector2D::ZeroVector;
	// the opening in the bucket's (x, z) plane: from the back edge to the teeth edge; out of it = away from the inside
	const FVector2D Teeth = Poly.Last(), Back = Poly[0], Mid = (Teeth + Back) * 0.5f;
	FVector2D Cen(0.f, 0.f); for (const FVector2D& P : Poly) Cen += P / Poly.Num();
	const FVector2D Out = (Mid - Cen).GetSafeNormal();
	const FVector DownB = BT.InverseTransformVectorNoScale(FVector(0.f, 0.f, -1.f));
	const float Half = 0.5f * Bucket.Width * (bModelRig ? BucketInnerFrac : 0.92f);
	// falling from there (across the width), does the soil miss the bucket? (built-in buckets have no steel to ask)
	auto Clear = [&](const FVector2D& Q)
	{
		if (BucketSteel.Num() < 3) return true;
		float Tt;
		for (const float Sd : {-0.8f, 0.f, 0.8f})
			if (RaySteel(BucketSteel, FVector(Q.X, BucketYMid + Sd * InsideHalfAt(Q.X, Half), Q.Y), DownB, 3.f, Tt)) return false;
		return true;
	};
	TArray<FVector2D, TInlineAllocator<10>> Cands;
	if (bAtTeeth)
		for (const float D : {0.06f, 0.15f, 0.3f}) Cands.Add(Teeth + (Teeth - Cen).GetSafeNormal() * D);
	else
	{
		// facing down: out through the opening; otherwise over the lower edge first, then the other one - just beyond it,
		// or further out where the bucket's own shell bulges out under that edge
		if (BT.TransformVectorNoScale(FVector(Out.X, 0.f, Out.Y)).Z < -0.15f) Cands.Add(Mid + Out * 0.06f);
		const bool bTeethLower = BT.TransformPosition(FVector(Teeth.X, 0.f, Teeth.Y)).Z <= BT.TransformPosition(FVector(Back.X, 0.f, Back.Y)).Z;
		for (const FVector2D& E : {bTeethLower ? Teeth : Back, bTeethLower ? Back : Teeth})
			for (const float D : {0.06f, 0.15f, 0.3f}) Cands.Add(E + (E - Mid).GetSafeNormal() * D + Out * 0.03f);
	}
	for (const FVector2D& Q : Cands) if (Clear(Q)) return Q;
	return Cands[0];
}

FVector ARWExcavator::SoilExitAt(float Side, bool bAtTeeth) const
{
	if (ToolRoots.Num() == 0 || !ToolRoots[0]) return LastTip;
	const FTransform BT = ToolRoots[0]->GetComponentTransform();
	const int32 Slot = bAtTeeth ? 1 : 0;
	// (only the bucket's turn changes where soil can fall clear - "down" in its own frame - so the exit is found again only
	// when it has turned by a degree or more, not every frame the bucket moves)
	if (!bExitKnown[Slot] || BT.GetRotation().AngularDistance(ExitBT[Slot].GetRotation()) > FMath::DegreesToRadians(1.f))
	{
		ExitAt2D[Slot] = FindSoilExit(BT, bAtTeeth);
		ExitBT[Slot] = BT;
		bExitKnown[Slot] = true;
	}
	const FVector2D At = ExitAt2D[Slot];
	const float HalfDef = 0.5f * Bucket.Width * (bModelRig ? BucketInnerFrac : 0.92f);
	const float Half = FMath::Max(InsideHalfAt(At.X, HalfDef) - 0.06f, 0.05f);
	return BT.TransformPosition(FVector(At.X, BucketYMid + FMath::Clamp(Side, -1.f, 1.f) * Half, At.Y) * M2CM) * CM2M;
}

void ARWExcavator::SoilOutsideSteel(int32& Outside, int32& Total, float& Worst) const
{
	Outside = Total = 0; Worst = 0.f;
	if (!FillMesh || !FillMesh->IsVisible() || BucketSteel.Num() < 3) return;
	const FProcMeshSection* Sec = FillMesh->GetProcMeshSection(0);
	if (!Sec) return;
	float SX0 = 1e9f, SX1 = -1e9f, SHalf = 0.f;
	for (const FVector& P : BucketSteel) { SX0 = FMath::Min(SX0, (float)P.X); SX1 = FMath::Max(SX1, (float)P.X); SHalf = FMath::Max(SHalf, (float)FMath::Abs(P.Y - BucketYMid)); }
	const FVector Down(0.f, 0.f, BucketSign);
	for (int32 v = 0; v < Sec->ProcVertexBuffer.Num(); v += 3) // (every third point: enough to find a breach, quick enough for a test)
	{
		const FVector P = Sec->ProcVertexBuffer[v].Position * CM2M;
		++Total;
		float Out = 0.f, Tt;
		// past the teeth or behind the back
		if (P.X < SX0 - 0.01f) Out = FMath::Max(Out, (float)(SX0 - P.X));
		if (P.X > SX1 + 0.01f) Out = FMath::Max(Out, (float)(P.X - SX1));
		// under the floor: nothing of the bucket further into the shell, and steel back towards the mouth
		if (!RaySteel(BucketSteel, P, Down, 3.f, Tt) && RaySteel(BucketSteel, P, -Down, 3.f, Tt)) Out = FMath::Max(Out, Tt);
		// beyond a side plate: no steel further out, steel back towards the middle (a heap above the plates' edge has steel
		// on neither side, and only has to stay within the bucket's width)
		const float Sy = P.Y >= BucketYMid ? 1.f : -1.f;
		if (!RaySteel(BucketSteel, P, FVector(0.f, Sy, 0.f), 2.f, Tt))
		{
			if (RaySteel(BucketSteel, P, FVector(0.f, -Sy, 0.f), 2.f, Tt)) Out = FMath::Max(Out, Tt);
			else if (FMath::Abs(P.Y - BucketYMid) > SHalf + 0.01f) Out = FMath::Max(Out, (float)(FMath::Abs(P.Y - BucketYMid) - SHalf));
		}
		if (Out > 0.01f) { ++Outside; Worst = FMath::Max(Worst, Out); }
	}
}

void ARWExcavator::BuildFillPoly(TArray<FVector2D>& Poly) const
{
	// interior cross-section: the same arc as the bucket shell (inset by the plate thickness), closed by the mouth
	const float L = Lk, D = FMath::Max(Bucket.Depth, 0.15f * Lk) * 0.94f;
	Poly.Reset();
	// the inside of the floor measured with rays (BucketInside) when there is one: the outermost steel less a fixed 5 cm
	// plate went below the real floor where wear strips or ribs run under it
	TArray<FVector2D> InnerProf;
	for (const FVector& B : BucketInside) InnerProf.Add(FVector2D(B.X, B.Y));
	const TArray<FVector2D>& Prof = InnerProf.Num() >= 4 ? InnerProf : BucketProfile;
	if (Prof.Num() >= 4)
	{
		// a model bucket: follow its real shell (measured from its vertices), inset by the plate thickness, closed by
		// the mouth from the teeth back to the back plate - the soil can then never reach outside the steel
		const float Plate = InnerProf.Num() >= 4 ? 0.01f : 0.05f, Rim = BucketRimZ;
		const FVector2D& First = Prof[0]; const FVector2D& LastP = Prof.Last();
		// the cavity is what lies between the shell and the rim level: find where the inset shell comes up to that level
		int32 I0 = -1, I1 = -1;
		for (int32 i = 0; i < Prof.Num(); ++i) if (Prof[i].Y - Plate > Rim + 0.01f) { if (I0 < 0) I0 = i; I1 = i; }
		if (I0 < 0) { I0 = 0; I1 = Prof.Num() - 1; }
		auto CrossX = [&](int32 Out, int32 In)
		{
			const FVector2D& A = Prof[Out]; const FVector2D& B = Prof[In];
			const float Da = A.Y - Plate - Rim, Db = B.Y - Plate - Rim;
			return FMath::Lerp(A.X, B.X, FMath::Clamp(Da / FMath::Min(Da - Db, -1e-3f), 0.f, 1.f));
		};
		const float XRear = I0 > 0 ? CrossX(I0 - 1, I0) : First.X + Plate, XLip = I1 + 1 < Prof.Num() ? CrossX(I1 + 1, I1) : LastP.X - Plate;
		Poly.Add(FVector2D(XRear, Rim * BucketSign));
		for (int32 i = I0; i <= I1; ++i)
		{
			const float X = FMath::Clamp(Prof[i].X, XRear, XLip);
			Poly.Add(FVector2D(X, FMath::Max(Prof[i].Y - Plate, Rim + 0.01f) * BucketSign));
		}
		Poly.Add(FVector2D(XLip, Rim * BucketSign));
	}
	else
		for (int32 i = 0; i <= 16; ++i)
		{
			const float T = FMath::DegreesToRadians(FMath::Lerp(168.f, 4.f, i / 16.f));
			Poly.Add(FVector2D(0.5f * L + 0.47f * L * FMath::Cos(T), (0.06f * D + 0.9f * D * FMath::Sin(T)) * BucketSign)); // shell side of this bucket
		}
}

float ARWExcavator::BucketHoldLoose() const
{
	if (ToolRoots.Num() == 0 || !ToolRoots[0]) return Bucket.Capacity * 1.25f;
	const FVector Ug = ToolRoots[0]->GetComponentTransform().InverseTransformVectorNoScale(FVector::UpVector);
	FVector2D Up(Ug.X, Ug.Z);
	if (Up.IsNearlyZero()) return Bucket.Capacity * 1.25f;
	Up.Normalize();
	TArray<FVector2D> Poly, Cut;
	BuildFillPoly(Poly);
	const float Afull = RWPolyArea(Poly);
	if (Afull < 1e-4f) return Bucket.Capacity * 1.25f;
	// soil runs out over the teeth edge of the mouth, so the level can rise no higher than that edge. With the rear edge
	// lower instead, the load rests against the back of the bucket and only leaves once the mouth has really tipped over.
	const float TeethH = FVector2D::DotProduct(Poly.Last(), Up), RearH = FVector2D::DotProduct(Poly[0], Up);
	if (RearH < TeethH)
	{
		const float MouthUp = FVector2D::DotProduct(Up, FVector2D(0.f, -BucketSign));
		return Bucket.Capacity * 1.25f * FMath::Clamp(MouthUp / 0.3f, 0.f, 1.f);
	}
	const float LipLevel = TeethH;
	RWClipBelow(Poly, Up, LipLevel, Cut);
	const float AHold = RWPolyArea(Cut);
	// on top of that, a pile at the soil's angle of repose rising from the lip
	float Chord = 0.f;
	{
		const FVector2D Along(-Up.Y, Up.X);
		float Lo = 1e9f, Hi = -1e9f;
		for (const FVector2D& P : Cut)
			if (FMath::Abs(FVector2D::DotProduct(P, Up) - LipLevel) < 2e-3f) { const float Sd = FVector2D::DotProduct(P, Along); Lo = FMath::Min(Lo, Sd); Hi = FMath::Max(Hi, Sd); }
		if (Hi > Lo) Chord = Hi - Lo;
	}
	const FSoilProps& Sp = SoilProps(Bucket.Load.Dominant());
	// freshly dug soil still holds together, so in the bucket it stands well steeper than a loose heap's angle of repose
	const float Rep = FMath::DegreesToRadians(FMath::Min(FMath::Lerp((float)Sp.Repose, (float)Sp.WetRepose, FMath::Clamp(Bucket.Load.Moist, 0.f, 1.f)) + 25.f, 70.f));
	const float APile = 0.25f * Chord * Chord * FMath::Tan(Rep); // a ridge: half the chord to its crown
	const float Struck = Bucket.Capacity / 1.2f; // the rating says how much the shape holds, whatever its modelled size
	const float ByShape = FMath::Min(Struck * (AHold + APile) / Afull, Bucket.Capacity * 1.25f);
	// a dug load is packed in: it keeps its place until the mouth has tipped well over, and only then goes by the shape
	const float MouthUpNow = FVector2D::DotProduct(Up, FVector2D(0.f, -BucketSign));
	return FMath::Lerp(ByShape, Bucket.Capacity * 1.25f, FMath::SmoothStep(0.15f, 0.5f, MouthUpNow));
}

void ARWExcavator::UpdateBucketFill()
{
	if (ToolRoots.Num() == 0) return;
	USceneComponent* T0 = ToolRoots[0];
	const float Load = Bucket.Load.Total();
	if (!IsValid(FillMesh))
	{
		FillMesh = NewObject<UProceduralMeshComponent>(this);
		FillMesh->SetupAttachment(T0);
		FillMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		FillMesh->SetCastShadow(true);
		FillMesh->RegisterComponent();
	}
	if (Tool != 0 || Load < 0.01f * Bucket.Capacity) { if (FillMesh->IsVisible()) FillMesh->SetVisibility(false); FillKey = -1; FillLevelFrac = 0.f; return; }
	// which way is "up" (against gravity) in the bucket's frame
	const FVector Ug = T0->GetComponentTransform().InverseTransformVectorNoScale(FVector::UpVector);
	FVector2D Up(Ug.X, Ug.Z);
	if (Up.IsNearlyZero()) Up = FVector2D(0, 1);
	Up.Normalize();
	const int32 Key = FMath::RoundToInt(Load / Bucket.Capacity * 200.f) * 1000 + FMath::RoundToInt(FMath::RadiansToDegrees(FMath::Atan2(Up.Y, Up.X)) * 0.5f) + 500;
	if (Key == FillKey && FillMesh->IsVisible()) return; // nothing changed enough to rebuild
	// while the bucket moves the key changes almost every frame: at most 15 rebuilds a second (FillKey -1 forces one)
	const double FillNow = FPlatformTime::Seconds();
	if (FillKey != -1 && FillMesh->IsVisible() && FillNow - FillBuiltAt < 1.0 / 15.0) return;
	FillBuiltAt = FillNow;
	FillKey = Key;
	const float D = FMath::Max(Bucket.Depth, 0.15f * Lk) * 0.94f;
	TArray<FVector2D> Poly;
	BuildFillPoly(Poly);
	// a bucket's rated (heaped) capacity is about 1.2 x the volume inside the shell (struck capacity)
	const float Struck = Bucket.Capacity / 1.2f;
	const float Fin = FMath::Min(Load / FMath::Max(Struck, 1e-3f), 1.f);
	FillLevelFrac = Fin;
	float Lo = 1e9f, Hi = -1e9f;
	for (const FVector2D& P : Poly) { const float H = FVector2D::DotProduct(P, Up); Lo = FMath::Min(Lo, H); Hi = FMath::Max(Hi, H); }
	const float Afull = RWPolyArea(Poly);
	TArray<FVector2D> Cut;
	FVector2D SA = Poly[0], SB = Poly.Last(); // full: the surface spans the mouth from the back edge to the lip
	// scooped soil does not lie flat: part of it heaps up into a rounded mound in the middle (less for sand / mud)
	const ESoil HeapMat = Bucket.Load.Dominant();
	const float DomeShare = (HeapMat == ESoil::Sand || HeapMat == ESoil::Mud) ? 0.12f : 0.28f;
	const float LevelFrac = Fin * (1.f - DomeShare);
	{
		// find the level whose cross-section below it holds exactly this much soil
		float A = Lo, B = Hi;
		for (int32 it = 0; it < 22; ++it) { const float M = (A + B) * 0.5f; RWClipBelow(Poly, Up, M, Cut); (RWPolyArea(Cut) < LevelFrac * Afull ? A : B) = M; }
		const float Level = (A + B) * 0.5f;
		RWClipBelow(Poly, Up, Level, Cut);
		const FVector2D Along(-Up.Y, Up.X);
		bool bAny = false;
		for (const FVector2D& P : Cut)
			if (FMath::Abs(FVector2D::DotProduct(P, Up) - Level) < 2e-3f)
			{
				if (!bAny) { SA = SB = P; bAny = true; }
				if (FVector2D::DotProduct(P, Along) < FVector2D::DotProduct(SA, Along)) SA = P;
				if (FVector2D::DotProduct(P, Along) > FVector2D::DotProduct(SB, Along)) SB = P;
			}
		if (!bAny) { FillMesh->SetVisibility(false); return; }
	}
	// overloaded: the extra soil heaps up over the mouth (the spill code sheds what will not stay on)
	const float W = Bucket.Width * (bModelRig ? BucketInnerFrac : 0.92f);
	// the inside half width where a point lies along the bucket: the side plates as measured there (a bucket narrows at its
	// back and at rounded corners - one width for the whole length let the soil through the plates there)
	auto HalfAt = [&](float X) { return FMath::Max(InsideHalfAt(X, 0.5f * W) - (BucketInside.Num() ? 0.01f : 0.f), 0.05f); };
	auto P3w = [&](const FVector2D& Q, float Side) { return FVector(Q.X, BucketYMid + Side * HalfAt(Q.X), Q.Y) * M2CM; }; // Side -1..1
	const float Excess = FMath::Max(0.f, Load - Struck) / FMath::Max(W, 0.1f); // m2 of cross-section above the rim
	// keep the soil inside the steel: a surface point may only leave the cavity through the open mouth, and only
	// when the mouth faces up enough to hold a heap (otherwise the mound / lumps would poke through the plates)
	const FVector2D MouthOut(0.f, -BucketSign); // the opening, in the bucket's (x, z) plane
	const FVector2D CA = Poly.Last(), CB = Poly[0]; // mouth chord: lip -> back edge
	FVector2D Cen(0.f, 0.f); for (const FVector2D& P : Poly) Cen += P / Poly.Num();
	auto Side = [](const FVector2D& A, const FVector2D& B, const FVector2D& P) { return (B.X - A.X) * (P.Y - A.Y) - (B.Y - A.Y) * (P.X - A.X); };
	const float PolyS = Side(Poly[0], Poly[1], Cen) >= 0.f ? 1.f : -1.f;
	// tilted so the level would stand above the lip: soil has no flat face across the opening, it slumps down to the lip.
	// The surface then runs from the shell straight down to the lip, as one rough sloping pile.
	float SlumpArea = 0.f;
	bool bSlumped = false;
	if (FVector2D::DotProduct(Up, MouthOut) > 0.f) // only with the mouth facing up: facing down the soil simply falls out
	{
		const float ChordLen = FMath::Max(FVector2D::Distance(CA, CB), 0.01f);
		for (int32 i = 0; i < Cut.Num(); ++i)
		{
			const FVector2D A = Cut[i], B = Cut[(i + 1) % Cut.Num()];
			if (FMath::Abs(Side(CA, CB, A)) / ChordLen > 0.01f || FMath::Abs(Side(CA, CB, B)) / ChordLen > 0.01f || FVector2D::Distance(A, B) < 0.02f) continue;
			const bool bAHigh = FVector2D::DotProduct(A, Up) > FVector2D::DotProduct(B, Up);
			const FVector2D Top = bAHigh ? A : B, Low = bAHigh ? B : A;
			FVector2D& MouthEnd = FVector2D::DistSquared(SA, Top) < FVector2D::DistSquared(SB, Top) ? SA : SB;
			const FVector2D Other = &MouthEnd == &SA ? SB : SA;
			// a small load in the corner of the shell would slope too steeply: it keeps its level surface
			const FVector2D AlongLevel(-Up.Y, Up.X);
			const float Drop = FVector2D::DotProduct(Top - Low, Up), Run = FMath::Abs(FVector2D::DotProduct(Low - Other, AlongLevel));
			if (Run > 0.01f && Drop / Run <= 1.73f)
			{
				SlumpArea = 0.5f * FMath::Abs((Top.X - Other.X) * (Low.Y - Other.Y) - (Top.Y - Other.Y) * (Low.X - Other.X)); // what slumped off the face goes on the pile
				MouthEnd = Low;
				bSlumped = true;
			}
			break;
		}
	}
	const float Chord = FVector2D::Distance(SA, SB);
	// mound cross-section = the domed share of the soil + anything above level-full; a parabola along the surface
	// times a sine across the width holds (4 / 3pi) x peak x chord, so the peak follows from the volume
	const float MoundArea = Fin * DomeShare * Afull + Excess + SlumpArea;
	// (a heap of dug soil stands at about 1 : 1 over the mouth: no higher than a third of the mouth's length or about half
	// its width - a taller mound stood far out of the bucket, more than real soil holds there)
	const float Peak = FMath::Min(MoundArea / (0.4244f * FMath::Max(Chord, 0.05f)), FMath::Min(Chord * 0.33f, W * 0.55f));
	const bool bHeapOK = bSlumped || FVector2D::DotProduct(Up, MouthOut) > 0.35f;
	// the surface rises away from the soil under it (straight up when the surface is level)
	FVector2D Rise = (SB - SA).GetSafeNormal();
	Rise = FVector2D(-Rise.Y, Rise.X);
	if (FVector2D::DotProduct(Rise, Up) < 0.f) Rise = -Rise;
	// a point on the surface line (Ft 0..1 from SA to SB) and the way out of the soil there
	auto SurfAt = [&](float Ft, FVector2D& OutRise) -> FVector2D
	{
		OutRise = Rise;
		return FMath::Lerp(SA, SB, Ft);
	};
	// point in polygon (works for a real, not quite convex shell profile too)
	auto Inside = [&](const FVector2D& P)
	{
		bool bIn = false;
		for (int32 i = 0, j = Poly.Num() - 1; i < Poly.Num(); j = i++)
		{
			const FVector2D& A = Poly[i]; const FVector2D& B = Poly[j];
			if ((A.Y > P.Y) != (B.Y > P.Y) && P.X < (B.X - A.X) * (P.Y - A.Y) / (B.Y - A.Y) + A.X) bIn = !bIn;
		}
		return bIn;
	};
	(void)PolyS;
	const float CenSide = Side(CA, CB, Cen);
	// out through the opening, and not past the teeth or the back plate
	const float MouthXLo = FMath::Min(CA.X, CB.X), MouthXHi = FMath::Max(CA.X, CB.X);
	auto BeyondMouth = [&](const FVector2D& P) { return Side(CA, CB, P) * CenSide < 0.f && P.X > MouthXLo && P.X < MouthXHi; };
	auto ClampUp = [&](const FVector2D& B, const FVector2D& Dir, float Hh) -> float
	{
		if (Hh <= 0.f) return Inside(B + Dir * Hh) ? Hh : 0.f; // a dip must not go through the floor of the bucket: the steel would show
		const float Step = FMath::Max(Hh / 10.f, 0.006f);
		for (float T = Step; T <= Hh + 1e-4f; T += Step)
		{
			const FVector2D P = B + Dir * T;
			if (!Inside(P) && !(bHeapOK && BeyondMouth(P))) return FMath::Max(0.f, T - Step);
		}
		return Hh;
	};
	// how this soil breaks up: sand and mud flow, clay comes out in big lumps, gravel and rock as separate stones
	float Rough = 1.f, GrainK = 1.f, GrainSz = 1.f, LumpK = 1.f;
	if (HeapMat == ESoil::Sand) { Rough = 0.3f; GrainK = 0.6f; GrainSz = 0.5f; LumpK = 0.f; }
	else if (HeapMat == ESoil::Mud) { Rough = 0.5f; GrainK = 0.15f; LumpK = 0.5f; }
	else if (HeapMat == ESoil::Clay) { Rough = 1.15f; LumpK = 1.4f; }
	else if (HeapMat == ESoil::Gravel || HeapMat == ESoil::SmallRock || HeapMat == ESoil::LargeRock) { Rough = 0.9f; GrainSz = 1.4f; LumpK = 1.2f; }
	const float Rs = FMath::Clamp(Lk / 1.45f, 0.6f, 1.4f); // detail follows the size of the bucket
	const float FullArea = FMath::Max(Bucket.Width * Lk, 0.1f);
	// height of the soil surface over the level it would have as a liquid: a rough heap of clods pressed together, not a
	// smooth dome. It settles to nothing right at the steel, where the mesh must meet the shell.
	auto SurfaceH = [&](float Ft, float Fw) -> float
	{
		const float EdgeF = FMath::Sin(PI * Ft) * FMath::Sin(PI * Fw);
		const float EdgeS = FMath::Sqrt(FMath::Max(EdgeF, 0.f));
		const float Xm = Ft * Chord, Ym = (Fw - 0.5f) * W;
		// no clean dome: a pile with slumps and shoulders
		const float Mound = Peak * (1.f - FMath::Square(2.f * Ft - 1.f)) * FMath::Sin(PI * Fw) * (1.f + 0.3f * RWNoise2(Ft * 2.6f, Fw * 2.4f, 53) + 0.14f * RWNoise2(Ft * 6.f, Fw * 5.5f, 57));
		const float Swell = (0.6f * RWNoise2(Xm * 2.6f / Rs, Ym * 2.6f / Rs, 31) + 0.45f * RWNoise2(Xm * 6.f / Rs, Ym * 6.f / Rs, 37)) * 0.085f * Rs;
		// lumps of three sizes pressed into each other, with creases between them, are the surface itself
		const float Clods = 0.5f * RWClods(Xm, Ym, 0.21f * Rs, 41) + 0.85f * RWClods(Xm, Ym, 0.095f * Rs, 43) + 0.7f * RWClods(Xm, Ym, 0.045f * Rs, 45)
			+ 0.008f * Rs * RWNoise2(Xm * 34.f, Ym * 34.f, 47) - 0.11f * Rs;
		// machine leaning sideways (slope, propped on the bucket): keep the surface level across the width too
		const float Lean = FMath::Clamp(-Ug.Y * Ym / FMath::Max(FVector2D(Ug.X, Ug.Z).Size(), 0.3f), -0.25f * D, 0.25f * D);
		return Mound + (Swell * (0.4f + 0.6f * Rough) + Clods * Rough) * EdgeS + 0.01f * Lk * EdgeF + Lean;
	};
	// soil surface: a fine grid across the bucket, so the clods show in its outline and shading
	const int32 NT = FillNT, NW = FillNW;
	TArray<FVector> V; TArray<int32> Tri; TArray<FVector2D> UV;
	V.Reserve(19000); UV.Reserve(19000); Tri.Reserve(60000);
	auto P3 = [&](const FVector2D& Q, float Y) { return FVector(Q.X, Y, Q.Y) * M2CM; };
	for (int32 w = 0; w <= NW; ++w)
		for (int32 t = 0; t <= NT; ++t)
		{
			const float Ft = t / float(NT), Fw = w / float(NW);
			FVector2D Out2;
			const FVector2D Base = SurfAt(Ft, Out2);
			V.Add(P3w(Base + Out2 * ClampUp(Base, Out2, SurfaceH(Ft, Fw)), 2.f * Fw - 1.f));
			UV.Add(FVector2D(Ft * Chord, Fw * W) * 1.6f);
		}
	auto GridIx = [&](int32 t, int32 w) { return w * (NT + 1) + t; };
	for (int32 w = 0; w < NW; ++w)
		for (int32 t = 0; t < NT; ++t) { const int32 a = GridIx(t, w), b = GridIx(t + 1, w), c = GridIx(t, w + 1), d = GridIx(t + 1, w + 1); Tri.Append({a, c, b, b, c, d}); }
	if (Peak > 0.01f)
	{
		// heaped: close the mound's ends down to the rim at the side plates
		for (int32 s = 0; s < 2; ++s)
		{
			const int32 w = s == 0 ? 0 : NW;
			const float PlateSide = 2.f * w / float(NW) - 1.f;
			const int32 Base = V.Num();
			for (int32 t = 0; t <= NT; ++t) { FVector2D Unused2; V.Add(P3w(SurfAt(t / float(NT), Unused2), PlateSide)); UV.Add(FVector2D(t / float(NT) * Chord, 0.f) * 1.6f); }
			for (int32 t = 0; t < NT; ++t) { const int32 a = GridIx(t, w), b = GridIx(t + 1, w), c = Base + t, d = Base + t + 1; Tri.Append({a, b, c, b, d, c}); Tri.Append({a, c, b, b, c, d}); }
		}
	}
	// Unreal draws the side of a triangle where (C-A) x (B-A) points (the same rule the terrain uses); the old code
	// used (B-A) x (C-A), so the soil surface faced into the bucket and was culled - invisible from above
	TArray<FVector> N; N.Init(FVector::ZeroVector, V.Num());
	for (int32 k = 0; k + 2 < Tri.Num(); k += 3)
	{
		const FVector Fn = FVector::CrossProduct(V[Tri[k + 2]] - V[Tri[k]], V[Tri[k + 1]] - V[Tri[k]]);
		N[Tri[k]] += Fn; N[Tri[k + 1]] += Fn; N[Tri[k + 2]] += Fn;
	}
	for (FVector& Nn : N) Nn = Nn.GetSafeNormal();
	if (FVector::DotProduct(N[GridIx(NT / 2, NW / 2)], FVector(Rise.X, 0.f, Rise.Y)) < 0.f)
	{
		// make the drawn side face out of the bucket (towards the sky)
		for (int32 k = 0; k + 2 < Tri.Num(); k += 3) Swap(Tri[k + 1], Tri[k + 2]);
		for (FVector& Nn : N) Nn = -Nn;
	}
	// the body of the load: everything under that surface down to the steel, closed all round, so the load is solid and
	// fills the bucket - seen from below or through a gap in the plates there is soil, not a sheet with air under it
	{
		TArray<FVector2D> BodyPoly;
		RWClipBelow(Poly, Rise, FVector2D::DotProduct(SA, Rise), BodyPoly);
		if (BodyPoly.Num() >= 3)
		{
			FVector2D BodyC(0.f, 0.f);
			for (const FVector2D& P : BodyPoly) BodyC += P / BodyPoly.Num();
			auto AddFace = [&](const FVector& A, const FVector& B, const FVector& C, const FVector& Nn)
			{
				const int32 I = V.Num();
				for (const FVector& Q : {A, B, C})
				{
					V.Add(Q); N.Add(Nn);
					UV.Add(FMath::Abs(Nn.Y) > 0.5f ? FVector2D(Q.X, Q.Z) * CM2M * 1.6f : FVector2D(Q.X + Q.Z, Q.Y) * CM2M * 1.6f);
				}
				// Unreal's front face: (C-A) x (B-A) along the outward normal
				if (FVector::DotProduct(FVector::CrossProduct(C - A, B - A), Nn) >= 0.f) Tri.Append({I, I + 1, I + 2});
				else Tri.Append({I, I + 2, I + 1});
			};
			const float TopLevel = FVector2D::DotProduct(SA, Rise);
			for (int32 i = 0; i < BodyPoly.Num(); ++i)
			{
				const FVector2D& A = BodyPoly[i]; const FVector2D& B = BodyPoly[(i + 1) % BodyPoly.Num()];
				if (FVector2D::DistSquared(A, B) < 1e-6f) continue;
				// the two ends, against the side plates (as far out as the plates are at each point)
				AddFace(P3w(BodyC, -1.f), P3w(A, -1.f), P3w(B, -1.f), FVector(0, -1, 0));
				AddFace(P3w(BodyC, 1.f), P3w(A, 1.f), P3w(B, 1.f), FVector(0, 1, 0));
				// the run along the shell (the top edge is the surface grid)
				if (FMath::Abs(FVector2D::DotProduct(A, Rise) - TopLevel) < 2e-3f && FMath::Abs(FVector2D::DotProduct(B, Rise) - TopLevel) < 2e-3f) continue;
				FVector2D Out(-(B - A).Y, (B - A).X);
				Out.Normalize();
				if (FVector2D::DotProduct(Out, (A + B) * 0.5f - BodyC) < 0.f) Out = -Out;
				const FVector Nn(Out.X, 0.f, Out.Y);
				AddFace(P3w(A, -1.f), P3w(B, -1.f), P3w(B, 1.f), Nn);
				AddFace(P3w(A, -1.f), P3w(B, 1.f), P3w(A, 1.f), Nn);
			}
		}
	}
	FillBaseVerts = V.Num();
	// the loose pieces: hundreds of grains and clods lying on the soil, half sunk in it. They are what makes this read
	// as a load of dirt rather than a textured skin. Each stays inside the steel (or above the open mouth).
	if (GrainK > 0.f || LumpK > 0.f)
	{
		const TArray<FRWFillGrain>& Grains = RWFillGrains();
		const TArray<FRWGrainShape>& ShS = RWGrainShapes(false);
		const TArray<FRWGrainShape>& ShL = RWGrainShapes(true);
		const float AreaK = FMath::Clamp(Chord * W / FullArea, 0.08f, 1.f);
		const FVector2D Along(-Rise.Y, Rise.X);
		const int32 Budget = FMath::RoundToInt(Grains.Num() * AreaK);
		for (int32 k = 0; k < Budget; ++k)
		{
			const FRWFillGrain& G = Grains[k];
			// thin out per soil type with a fixed choice per piece, so the set does not change as the load changes
			const float Pick = FMath::Frac(k * 0.61803f);
			if (Pick >= (G.bLump ? LumpK : GrainK)) continue;
			const float R = G.Size * Rs * (G.bLump ? 1.f : GrainSz);
			FVector2D Out2;
			const FVector2D Base = SurfAt(G.Ft, Out2);
			// sunk well into the surface, so they read as part of the soil rather than beads lying on it
			const FVector2D C2 = Base + Out2 * (ClampUp(Base, Out2, SurfaceH(G.Ft, G.Fw)) - (G.bLump ? 0.5f : 0.2f) * R);
			// across: within the side plates as they are at this point along the bucket
			const float HalfHere = HalfAt(C2.X);
			const float Yw = BucketYMid + (2.f * G.Fw - 1.f) * HalfHere;
			if (FMath::Abs(Yw - BucketYMid) + R > HalfHere) continue;
			bool bOK = true;
			for (const FVector2D& Dq : {Out2, -Out2, Along, -Along}) { const FVector2D Pq = C2 + Dq * R * 1.2f; if (!Inside(Pq) && !(bHeapOK && BeyondMouth(Pq))) { bOK = false; break; } }
			if (!bOK) continue;
			const FRWGrainShape& Sh = (G.bLump ? ShL : ShS)[G.Shape];
			const FVector C3 = P3(C2, Yw);
			const int32 B0 = V.Num();
			const FVector Sc(R * M2CM, R * M2CM * 0.9f, R * M2CM * G.FlatZ);
			for (int32 q = 0; q < Sh.P.Num(); ++q)
			{
				V.Add(C3 + Sh.P[q] * Sc);
				N.Add((Sh.N[q] / FVector(1.f, 0.9f, G.FlatZ)).GetSafeNormal());
				UV.Add(G.UvOff + FVector2D(Sh.P[q].X, Sh.P[q].Y) * R * 1.6f);
			}
			for (const int32 I : Sh.T) Tri.Add(B0 + I);
		}
	}
	TArray<FProcMeshTangent> Tan; Tan.Init(FProcMeshTangent(FVector(1, 0, 0), false), V.Num());
	FillMesh->CreateMeshSection_LinearColor(0, V, Tri, N, UV, TArray<FLinearColor>(), Tan, false);
	// loose clods lying on the soil surface (not for sand / mud, which flow smooth)
	if (HeapClods.Num() == 0) UpdateHeapClods(); // creates them
	const ESoil Dom = Bucket.Load.Dominant();
	const bool bClods = Dom != ESoil::Sand && Dom != ESoil::Mud && Load > 0.15f * Bucket.Capacity;
	for (int32 k = 0; k < HeapClods.Num(); ++k)
	{
		UStaticMeshComponent* C = HeapClods[k];
		if (!C) continue;
		C->SetVisibility(bClods);
		if (!bClods) continue;
		// scattered over the middle of the heap, not in a neat row
		const int32 Tt = FMath::RoundToInt(NT * (0.2f + 0.6f * FMath::Frac(k * 0.61803f + 0.13f))), Ww = FMath::RoundToInt(NW * (0.2f + 0.6f * FMath::Frac(k * 0.75488f + 0.41f)));
		C->SetRelativeLocation(V[GridIx(Tt, Ww)]);
		const float Sz = (0.09f + 0.035f * (k % 3)) * FMath::Clamp(Lk / 1.45f, 0.6f, 1.4f);
		C->SetRelativeScale3D(FVector(Sz, Sz * 0.85f, Sz * 0.6f));
	}
	FillMesh->SetMaterial(0, HeapMID);
	FillMesh->SetVisibility(true);
}

void ARWExcavator::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << Swing << BoomA << ArmA << BktA << Tool;
	for (int32 m = 0; m < SOIL_COUNT; ++m) Ar << Bucket.Load.Vol[m];
	Ar << Bucket.Load.Moist;
}

// --------------------------------------------------------------------------------------------
// Dump truck
// --------------------------------------------------------------------------------------------
void ARWDumpTruck::Build()
{
	const bool bBig = Size >= 1;
	EmptyMass = bBig ? 14500 : 11000; PowerKW = bBig ? 330 : 280; FuelCap = 350; FuelRate = 30;
	Capacity = (bBig ? 16.f : 10.f) * (1.f + 0.15f * UpTool);
	BedLen = bBig ? 5.6f : 4.6f; BedW = 2.3f; BedH = bBig ? 1.15f : 1.0f;
	Ratios = {6.5f, 7.0f, 5.0f, 3.6f, 2.6f, 1.9f, 1.4f, 1.0f, 0.8f}; NumGears = 8; FinalDrive = 4.3f;
	SpringSag = 0.07f; BrakeDecel = 6.5f; MaxSteer = 36.f; CgHeight = 1.4f;
	const float R = 0.53f, W = 0.32f;
	if (bBig)
	{
		AddWheel(FVector2D(3.6f, -1.0f), R, W, true, false, true); AddWheel(FVector2D(3.6f, 1.0f), R, W, true, false, true);
		AddWheel(FVector2D(2.2f, -1.0f), R, W, true, false, true); AddWheel(FVector2D(2.2f, 1.0f), R, W, true, false, true);
		AddWheel(FVector2D(-1.3f, -0.9f), R, W, false, true, true, true); AddWheel(FVector2D(-1.3f, 0.9f), R, W, false, true, true, true);
		AddWheel(FVector2D(-2.7f, -0.9f), R, W, false, true, true, true); AddWheel(FVector2D(-2.7f, 0.9f), R, W, false, true, true, true);
		Wheelbase = 5.2f;
	}
	else
	{
		AddWheel(FVector2D(2.9f, -1.0f), R, W, true, false, true); AddWheel(FVector2D(2.9f, 1.0f), R, W, true, false, true);
		AddWheel(FVector2D(-1.0f, -0.9f), R, W, false, true, true, true); AddWheel(FVector2D(-1.0f, 0.9f), R, W, false, true, true, true);
		AddWheel(FVector2D(-2.35f, -0.9f), R, W, false, true, true, true); AddWheel(FVector2D(-2.35f, 0.9f), R, W, false, true, true, true);
		Wheelbase = 4.6f;
	}
	const float FrontX = bBig ? 4.3f : 3.6f;
	Radius2D = 3.6f;
	CamDist = 16.f;
	// chassis
	for (int32 s = -1; s <= 1; s += 2) Part(Body, EShape::Cube, FVector(0.2f, s * 0.45f, 0.95f), FVector(FrontX * 2.f, 0.16f, 0.3f), FRotator::ZeroRotator, DarkMID);
	Part(Body, EShape::Cube, FVector(FrontX + 0.15f, 0, 0.75f), FVector(0.25f, 2.4f, 0.35f), FRotator::ZeroRotator, DarkMID); // bumper
	// cab-over cab
	Part(Body, EShape::Cube, FVector(FrontX - 0.85f, 0, 1.35f), FVector(1.7f, 2.45f, 0.8f), FRotator::ZeroRotator, PaintMID);
	AddCab(Body, FVector(FrontX - 0.85f, 0, 2.5f), FVector(1.65f, 2.4f, 1.45f));
	Part(Body, EShape::Cube, FVector(FrontX + 0.01f, 0, 1.3f), FVector(0.05f, 1.6f, 0.55f), FRotator::ZeroRotator, DarkMID); // grille
	HoodPivot = Pivot(Body, FVector(FrontX + 0.03f, 0, 1.6f));
	Part(HoodPivot, EShape::Cube, FVector(0.0f, 0, -0.25f), FVector(0.04f, 1.7f, 0.5f), FRotator::ZeroRotator, PaintMID);
	AddLamp(Body, FVector(FrontX + 0.05f, -0.95f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	AddLamp(Body, FVector(FrontX + 0.05f, 0.95f, 1.0f), FRotator(-3, 0, 0), 12000, false);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Part(Body, EShape::Cylinder, FVector(0.6f, s * 1.0f, 0.9f), FVector(0.6f, 0.6f, 1.2f), FRotator(90, 0, 0), SteelMID); // fuel / air tanks
		Part(Body, EShape::Cube, FVector(-1.7f, s * 1.15f, 1.15f), FVector(2.1f, 0.5f, 0.05f), FRotator::ZeroRotator, DarkMID);   // mudguards
	}
	Part(Body, EShape::Cylinder, FVector(FrontX - 1.85f, 1.05f, 2.4f), FVector(0.14f, 0.14f, 1.6f), FRotator::ZeroRotator, ChromeMID); // exhaust
	// tipper body
	BedPivotL = FVector(-(bBig ? 3.5f : 3.0f), 0, 1.3f);
	BedP = Pivot(Body, BedPivotL);
	Part(BedP, EShape::Cube, FVector(BedLen * 0.5f, 0, 0.05f), FVector(BedLen, BedW, 0.1f), FRotator::ZeroRotator, PaintMID);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Part(BedP, EShape::Cube, FVector(BedLen * 0.5f, s * BedW * 0.5f, BedH * 0.5f), FVector(BedLen, 0.08f, BedH), FRotator::ZeroRotator, PaintMID);
		for (int32 k = 0; k < 5; ++k) Part(BedP, EShape::Cube, FVector(0.3f + k * (BedLen - 0.6f) / 4.f, s * (BedW * 0.5f + 0.05f), BedH * 0.5f), FVector(0.08f, 0.08f, BedH), FRotator::ZeroRotator, PaintMID);
		Part(BedP, EShape::Cube, FVector(BedLen * 0.5f, s * (BedW * 0.5f + 0.05f), BedH), FVector(BedLen, 0.12f, 0.1f), FRotator::ZeroRotator, PaintMID);
	}
	Part(BedP, EShape::Cube, FVector(BedLen - 0.05f, 0, BedH * 0.65f), FVector(0.1f, BedW, BedH * 1.3f), FRotator::ZeroRotator, PaintMID);
	Part(BedP, EShape::Cube, FVector(BedLen + 0.35f, 0, BedH * 1.28f), FVector(0.8f, BedW, 0.06f), FRotator::ZeroRotator, PaintMID); // cab guard
	for (int32 k = 0; k < 4; ++k) Part(BedP, EShape::Cube, FVector(0.5f + k * (BedLen - 1.f) / 3.f, 0, -0.1f), FVector(0.12f, BedW, 0.15f), FRotator::ZeroRotator, DarkMID);
	GateP = Pivot(BedP, FVector(-0.02f, 0, BedH));
	Part(GateP, EShape::Cube, FVector(0, 0, -BedH * 0.5f), FVector(0.08f, BedW, BedH), FRotator::ZeroRotator, PaintMID);
	HeapMID = HeapMaterial(this);
	Heap = Part(BedP, EShape::Cube, FVector(BedLen * 0.5f, 0, 0.2f), FVector(BedLen * 0.96f, BedW * 0.94f, 0.1f), FRotator::ZeroRotator, HeapMID, true);
	HeapTop = MeshPart(BedP, FRWMeshGen::SoilLump(2), FVector(BedLen * 0.5f, 0, 0.5f), FRotator::ZeroRotator, HeapMID, FVector(BedLen * 0.9f, BedW * 0.9f, 0.3f));
	Heap->SetVisibility(false); HeapTop->SetVisibility(false);
	Cyls.Add(MakeCyl(Body, BedPivotL + FVector(BedLen * 0.78f, 0, -0.35f), BedP, FVector(BedLen * 0.8f, 0, -0.08f), 0.12f, 0.9f));
	SeatPos = FVector(FrontX - 0.85f, -0.5f, 2.6f);
	if (CabCam) CabCam->SetRelativeLocation(FVector(-0.1f, -0.5f, 0.25f) * M2CM);
}

FString ARWDumpTruck::HelpText() const
{
	return TR(TEXT("W accelerate  S brake/reverse  A/D steer  Space brake  R/F raise/lower body  I engine  L lights  O door  C camera  Enter exit"));
}

FString ARWDumpTruck::ToolText() const
{
	return TRF(TEXT("Body {0} deg   load {1} / {2} m3  ({3} t {4})   gear {5}"), RWNum(BedAngle), RWNum(Load.Total(), 1), RWNum(Capacity), RWNum(Load.MassKg() / 1000.f, 1),
		Load.Total() > 0.05f ? TR(SoilName(Load.Dominant(), Load.Moist)) : TR(TEXT("empty")), Gear < 0 ? FString(TEXT("R")) : Gear == 0 ? FString(TEXT("N")) : FString::FromInt(Gear));
}

bool ARWDumpTruck::TryReceive(const FVector& P, ESoil M, float Vol, float Moist)
{
	if (!BedP) return false;
	const FVector L = BedP->GetComponentTransform().InverseTransformPosition(P * M2CM) * CM2M;
	if (L.X < 0.05f || L.X > BedLen - 0.05f || FMath::Abs(L.Y) > BedW * 0.5f || L.Z < -0.3f || L.Z > BedH + 1.8f) return false;
	if (Load.Total() > Capacity * 1.25f) return false;
	Load.Add(M, Vol, Moist);
	return true;
}

void ARWDumpTruck::WorkTick(float Dt)
{
	const float Rate = bEngineOn ? 9.f : (InA1 < 0 ? 5.f : 0.f);
	BedVel = InA1 * Rate;
	BedAngle = FMath::Clamp(BedAngle + BedVel * Dt, 0.f, 52.f);
	HydLoad = FMath::Abs(BedVel) > 0.1f ? 0.6f + 0.4f * FMath::Clamp(Load.MassKg() / 15000.f, 0.f, 1.f) : 0.f;
	Synth->Pour.store(0.f);
	const float Tot = Load.Total();
	if (BedAngle > 16.f && Tot > 0.001f)
	{
		const float Sticky = (Load.Vol[(int32)ESoil::Clay] + Load.Vol[(int32)ESoil::Mud]) / Tot;
		const float Flow = (BedAngle - 16.f) / 36.f * 3.2f * (1.f - 0.5f * Sticky) + (BedAngle > 45.f ? 0.5f : 0.f);
		FPayload Out = Load.Take(FMath::Min(Tot, Flow * Dt));
		const FVector At = BedP->GetComponentTransform().TransformPosition(FVector(-0.3f, 0, 0.3f) * M2CM) * CM2M;
		if (Fx) Fx->SpawnSoil(At, -Fwd2() * 1.2f + Fwd2() * Speed, Out, 0.8f);
		Delivered += Out.Total();
		Synth->Pour.store(FMath::Clamp(Flow * 0.5f, 0.f, 1.f));
	}
	// heaped loads spill on rough ground
	if (Tot > Capacity * 0.9f && (FMath::Abs(BodyVz) > 0.3f || FMath::Abs(PitchRate) > 8.f) && FMath::Abs(Speed) > 1.f)
	{
		FPayload Out = Load.Take((Tot - Capacity * 0.85f) * 0.6f * Dt + 0.01f);
		const float Side = FMath::FRand() > 0.5f ? 1.f : -1.f;
		const FVector At = BedP->GetComponentTransform().TransformPosition(FVector(BedLen * FMath::FRand(), Side * BedW * 0.55f, BedH + 0.2f) * M2CM) * CM2M;
		if (Fx) Fx->SpawnSoil(At, Fwd2() * Speed, Out, 0.2f);
		Spilled += Out.Total();
	}
	if (BedAngle > 3.f && FMath::Abs(Speed) > 4.f) Warning = TEXT("Lower the tipper body before driving!");
}

void ARWDumpTruck::VisualTick(float Dt)
{
	BedP->SetRelativeRotation(FRotator(BedAngle, 0, 0));
	if (GateP) GateP->SetRelativeRotation(FRotator(FMath::Clamp((BedAngle - 12.f) * 1.4f, 0.f, 45.f), 0, 0));
	const float V = Load.Total();
	const float Hh = V / (BedLen * BedW * 0.95f);
	const bool bVis = V > 0.02f;
	Heap->SetVisibility(bVis); HeapTop->SetVisibility(bVis && Hh > BedH * 0.6f);
	if (bVis)
	{
		const float Hb = FMath::Min(Hh, BedH * 0.85f);
		Heap->SetRelativeLocation(FVector(BedLen * 0.5f, 0, 0.1f + Hb * 0.5f) * M2CM);
		Heap->SetRelativeScale3D(FVector(BedLen * 0.96f, BedW * 0.94f, FMath::Max(Hb, 0.01f)));
		const float Extra = FMath::Max(0.f, Hh - BedH * 0.6f) * 2.2f;
		HeapTop->SetRelativeLocation(FVector(BedLen * 0.5f, 0, 0.1f + Hb) * M2CM);
		HeapTop->SetRelativeScale3D(FVector(BedLen * 0.92f, BedW * 0.9f, FMath::Max(Extra, 0.01f)));
		const FSoilProps& S = SoilProps(Load.Dominant());
		FRWSoilLook::Apply(HeapMID, Load.Dominant(), Load.Moist); (void)S;
	}
}

void ARWDumpTruck::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << BedAngle;
	for (int32 m = 0; m < SOIL_COUNT; ++m) Ar << Load.Vol[m];
	Ar << Load.Moist;
}

// --------------------------------------------------------------------------------------------
// Bulldozer
// --------------------------------------------------------------------------------------------
void ARWDozer::Build()
{
	EmptyMass = 20000; PowerKW = 150; FuelCap = 400; FuelRate = 24;
	MaxSpeedF = 3.2f; MaxSpeedR = 4.0f; SpringSag = 0.02f; Wheelbase = 3.3f; Radius2D = 2.9f; CamDist = 14.f;
	if (PendingMod && BuildFromModel()) return; // a mod supplied a real 3D model
	AddTracks(3.3f, 2.0f, 0.56f, 0.95f, 6);
	Part(Body, EShape::Cube, FVector(0.55f, 0, 1.5f), FVector(2.5f, 1.3f, 1.1f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(1.82f, 0, 1.45f), FVector(0.06f, 1.2f, 0.9f), FRotator::ZeroRotator, DarkMID);
	for (int32 k = 0; k < 6; ++k) Part(Body, EShape::Cube, FVector(1.86f, 0, 1.1f + k * 0.14f), FVector(0.04f, 1.15f, 0.04f), FRotator::ZeroRotator, PaintMID);
	HoodPivot = Pivot(Body, FVector(-0.7f, 0, 2.06f));
	Part(HoodPivot, EShape::Cube, FVector(1.25f, 0, 0), FVector(2.5f, 1.32f, 0.05f), FRotator::ZeroRotator, PaintMID);
	for (int32 s = -1; s <= 1; s += 2) Part(Body, EShape::Cube, FVector(-0.1f, s * 1.0f, 1.0f), FVector(3.3f, 0.66f, 0.06f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cube, FVector(-0.4f, 0, 1.1f), FVector(3.0f, 1.3f, 0.3f), FRotator::ZeroRotator, DarkMID);
	AddCab(Body, FVector(-0.95f, 0, 2.3f), FVector(1.4f, 1.5f, 1.5f), true);
	Part(Body, EShape::Cube, FVector(-1.85f, 0, 1.35f), FVector(0.5f, 1.6f, 0.75f), FRotator::ZeroRotator, PaintMID);
	Part(Body, EShape::Cylinder, FVector(0.9f, 0.4f, 2.4f), FVector(0.14f, 0.14f, 0.8f), FRotator::ZeroRotator, DarkMID);
	AddLamp(Body, FVector(1.6f, -0.5f, 2.08f), FRotator(-12, 0, 0), 10000, false);
	AddLamp(Body, FVector(1.6f, 0.5f, 2.08f), FRotator(-12, 0, 0), 10000, false);
	BladeP = Pivot(Root, FVector(BladeX, 0, BladeH));
	MeshPart(BladeP, FRWMeshGen::Moldboard(BladeW, 1.3f, 0.32f, 0.07f), FVector(0.12f, 0, 0), FRotator::ZeroRotator, PaintMID);
	Part(BladeP, EShape::Cube, FVector(0.1f, 0, 0.03f), FVector(0.14f, BladeW + 0.04f, 0.07f), FRotator::ZeroRotator, SteelMID);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Part(BladeP, EShape::Cube, FVector(0.05f, s * BladeW * 0.5f, 0.6f), FVector(0.5f, 0.06f, 1.2f), FRotator::ZeroRotator, PaintMID);
		Part(BladeP, EShape::Cube, FVector(-0.25f, s * 0.9f, 0.55f), FVector(0.3f, 0.12f, 0.9f), FRotator::ZeroRotator, DarkMID);
		Cyls.Add(MakeCyl(Root, FVector(-0.5f, s * 1.05f, 0.45f), BladeP, FVector(-0.3f, s * 1.05f, 0.3f), 0.13f, 3.0f));
		Cyls.Add(MakeCyl(Body, FVector(1.55f, s * 0.6f, 1.95f), BladeP, FVector(-0.2f, s * 0.6f, 0.95f), 0.09f, 1.0f));
	}
	RipperP = Pivot(Root, FVector(-2.15f, 0, 0.5f));
	Part(RipperP, EShape::Cube, FVector(0, 0, 0.35f), FVector(0.25f, 1.6f, 0.2f), FRotator::ZeroRotator, DarkMID);
	for (int32 k = -1; k <= 1; ++k) Part(RipperP, EShape::Cube, FVector(-0.05f, k * 0.6f, -0.15f), FVector(0.12f, 0.08f, 1.0f), FRotator(15, 0, 0), SteelMID);
	SeatPos = FVector(-0.9f, 0, 2.5f);
}

FString ARWDozer::HelpText() const
{
	return TR(TEXT("W/S travel  A/D steer  R/F blade up/down  T/G blade tilt  B ripper up/down  I engine  Z/X throttle  C camera  Enter exit"));
}

FString ARWDozer::ToolText() const
{
	return TRF(TEXT("Blade {0} m  tilt {1} deg   pile ahead {2} m3   ripper {3}   push {4} kN"), RWNum(BladeH, 2), RWNum(BladeTilt), RWNum(PileVol, 1), bRipper ? TR(TEXT("DOWN")) : TR(TEXT("up")), RWNum(DrawbarLoad / 1000.f));
}

bool ARWDozer::GradePoint(FVector& Out) const
{
	Out = LocalToWorldM(FVector(BladeX + 0.1f, 0, BladeH));
	return true;
}

void ARWDozer::WorkTick(float Dt)
{
	const float H = HydSpeedScale();
	// In XML mode, an unbound or invalid channel does not silently fall back
	// to the hardcoded legacy input. XML config owns the rates and limits.
	const float LiftInput = (!bXmlControlRequested || (bXmlControlValid && bRWXmlLiftBound)) ? InA1 : 0.f;
	const float TiltInput = (!bXmlControlRequested || (bXmlControlValid && bRWXmlTiltBound)) ? InA2 : 0.f;
	BladeVel = FMath::FInterpTo(BladeVel, LiftInput * RWBladeLiftSpeed * H, Dt, 8.f);
	BladeH = FMath::Clamp(BladeH + BladeVel * Dt, RWBladeLiftMin, RWBladeLiftMax);
	BladeTilt = FMath::Clamp(BladeTilt + TiltInput * RWBladeTiltSpeed * H * Dt, RWBladeTiltMin, RWBladeTiltMax);
	HydLoad = FMath::Abs(BladeVel) / FMath::Max(0.01f, RWBladeLiftSpeed) * 0.7f;
	const float TanT = FMath::Tan(FMath::DegreesToRadians(BladeTilt));
	const FVector F = Fwd2();
	FPayload Cut;
	float CutVol = 0.f, Pile = 0.f, Hard = 0.f;
	bool bBlocked = false;
	const int32 NW = FMath::CeilToInt(BladeW / 0.25f);
	TArray<int32, TInlineAllocator<64>> Seen;
	const float MaxDepth = 0.02f + FMath::Max(Speed, 0.f) * Dt * 1.2f;
	float EdgeDepthSum = 0.f, EdgeDeep = 0.f; int32 EdgeCells = 0, EdgeI = INDEX_NONE;
	for (int32 w = 0; w <= NW; ++w)
	{
		const float Y = (w / float(NW) - 0.5f) * BladeW;
		const FVector Edge = LocalToWorldM(FVector(BladeX + 0.12f, Y, BladeH + Y * TanT));
		for (int32 d = 0; d < 9; ++d)
		{
			const FVector P = Edge + F * (d * 0.25f);
			if (!Terrain->InBounds(P.X, P.Y)) continue;
			const int32 i = Terrain->IndexAt(P.X, P.Y);
			if (Seen.Contains(i)) continue;
			Seen.Add(i);
			const float E = Terrain->Height[i] - Edge.Z;
			if (E <= 0.f) continue;
			Pile += E * ARWTerrain::CellArea;
			if (d == 0) { EdgeDepthSum += E; ++EdgeCells; if (E > EdgeDeep) { EdgeDeep = E; EdgeI = i; } }
			if (d <= 2)
			{
				const FSoilState St = Terrain->SurfaceState(i);
				const float Dh = FMath::Min(E, MaxDepth / (0.4f + St.Hardness));
				const float Before = Cut.Total();
				const float Got = Terrain->RemoveAt(i, Dh, Cut);
				CutVol += Cut.Total() - Before;
				Hard += St.Hardness * Got;
				if (Got < Dh * 0.5f) bBlocked = true;
			}
		}
	}
	// material rolls ahead of the blade: deposit across a band in front
	if (Cut.Total() > 0.f)
	{
		const int32 NB = FMath::CeilToInt(BladeW * 0.9f / 0.5f);
		const float Share = 1.f / ((NB + 1) * 2);
		for (int32 w = 0; w <= NB; ++w)
			for (int32 d = 0; d < 2; ++d)
			{
				const float Y = (w / float(NB) - 0.5f) * BladeW * 0.9f;
				const FVector P = LocalToWorldM(FVector(BladeX + 0.95f + d * 0.45f, Y, 0));
				if (!Terrain->InBounds(P.X, P.Y)) continue;
				FPayload Part1 = Cut;
				for (float& V : Part1.Vol) V *= Share;
				Terrain->DepositPayloadAt(Terrain->IndexAt(P.X, P.Y), Part1);
			}
		// and the pile settles at once to its angle of repose in front of the blade, spilling round its ends - put down in
		// two rows a frame and left for the slow settling queue, it stood up in a ridge metres steeper than soil can.
		// The blade is a wall: nothing flows back through it.
		const FTransform MT = GetActorTransform();
		const FVector PileC = LocalToWorldM(FVector(BladeX + 1.2f, 0.f, 0.f));
		Terrain->SettleAround(PileC.X, PileC.Y, BladeW * 0.5f + 1.5f, 4, [&](int32 j)
		{
			const FVector Lp = MT.InverseTransformPosition(FVector(Terrain->PX(j % ARWTerrain::N), Terrain->PX(j / ARWTerrain::N), Terrain->Height[j]) * M2CM) * CM2M;
			return Lp.X < BladeX + 0.15f && FMath::Abs(Lp.Y) < BladeW * 0.5f + 0.1f;
		});
	}
	CutTotal += CutVol;
	PileVol = Pile;
	// the blade cuts at about 55 degrees: same soil-wedge force as a bucket, plus the weight of the pile it pushes
	float BladeCutN = 0.f;
	if (EdgeCells > 0 && EdgeI != INDEX_NONE && FMath::Abs(Speed) > 0.02f)
	{
		const FRWSoilStrength Str = FRWSoilMech::Strength(Terrain->SurfaceMat(EdgeI), Terrain->MoistureAt(EdgeI), Terrain->SurfaceComp(EdgeI));
		BladeCutN = FRWSoilMech::CutForce(Str, EdgeDepthSum / EdgeCells, BladeW * FMath::Clamp(EdgeCells / float(NW + 1), 0.1f, 1.f), 55.f, FMath::Abs(Speed)).Horizontal;
	}
	(void)Hard;
	DrawbarLoad = FMath::Min(Pile * 1700.f * GRAV * 0.55f + BladeCutN + (bBlocked ? 80000.f : 0.f), 320000.f);
	Synth->Scrape.store(FMath::Clamp(CutVol / Dt * 0.8f + (bBlocked ? 0.4f : 0.f), 0.f, 1.f));
	Synth->Rock.store(bBlocked ? 0.6f : 0.f);
	// the blade pushes what stands in front of its face, from the cutting edge to its top: raised over a trunk it leaves
	// the trunk where it lies (it used to reach 2.5 m above the edge, so a felled tree kept coming along)
	if (TreeHitter && FMath::Abs(Speed) > 0.3f) TreeHitter(LocalToWorldM(FVector(BladeX + 0.3f, 0, BladeH + 0.5f * BladeTall)), BladeW * 0.55f, F * Speed, 0.5f * BladeTall);
	// ripper
	RipperH = FMath::FInterpConstantTo(RipperH, bRipper ? -0.55f : 0.4f, Dt, 0.4f * FMath::Max(H, 0.1f));
	if (RipperH < -0.25f && FMath::Abs(Speed) > 0.05f)
	{
		for (int32 k = -1; k <= 1; ++k)
		{
			const FVector P = LocalToWorldM(FVector(-2.2f, k * 0.6f, 0));
			if (!Terrain->InBounds(P.X, P.Y)) continue;
			const int32 i = Terrain->IndexAt(P.X, P.Y);
			Terrain->BreakRock(i, 0.4f);
			Terrain->BaseComp[i] = FMath::Min<uint8>(Terrain->BaseComp[i], 90);
			FLayers& L = Terrain->Layers[i];
			if (L.Count > 0) L.Comp[L.Count - 1] = FMath::Min<uint8>(L.Comp[L.Count - 1], 80);
			Terrain->ClearGrass(i, 1.f);
		}
		DrawbarLoad += 45000.f;
		Synth->Rock.store(0.4f);
	}
}

void ARWDozer::VisualTick(float Dt)
{
	BladeP->SetRelativeLocation(FVector(BladeX, 0, BladeH) * M2CM);
	BladeP->SetRelativeRotation(FRotator(0, 0, BladeTilt));
	if (CFrameP)
	{
		// the push frame swings about its pins until the cutting edge is at the blade height
		const float S = FMath::Clamp((BladeH - CFramePinZ) / CFrameL, -0.95f, 0.95f);
		CFrameP->SetRelativeRotation(FRotator(FMath::RadiansToDegrees(FMath::Asin(S) - CFrameA0), 0.f, BladeTilt));
		return;
	}
	RipperP->SetRelativeLocation(FVector(-2.15f, 0, 0.5f + RipperH) * M2CM);
}

void ARWDozer::SerializeState(FArchive& Ar)
{
	Super::SerializeState(Ar);
	Ar << BladeH << BladeTilt << bRipper;
}
