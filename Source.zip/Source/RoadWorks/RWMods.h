// Mod support: every folder in Mods/ with a mod.json can add machines (based on a built-in machine
// type, with its own name, stats, paint, size and extra parts / custom meshes from a mod .pak) and
// translations. See Mods/README_MODDING.md.
#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class ARWMachine;
class ARWGameMode;

struct FRWModMachine
{
	FString ModName, Id, Base, Name, NameTh, Folder;
	int32 Size = 1;
	TSharedPtr<FJsonObject> Def;
};

struct FRWModInfo
{
	FString Name, Author, Version, Folder, Error;
	FString Id, WorkshopId, SdkVersion; // for the future mod SDK / Steam Workshop
	int32 Machines = 0, Props = 0, Replacements = 0;
	bool bEnabled = true;
};

struct FRWModProp
{
	FString ModName;
	TSharedPtr<FJsonObject> Def;
	FString Folder;
};

class ROADWORKS_API FRWMods
{
public:
	static TArray<FRWModInfo> Mods;
	static TArray<FRWModMachine> Machines;
	static TArray<FString> SearchDirs();
	static void LoadAll();
	static UClass* BaseClass(const FString& Base);
	// before Build(): geometry scale; after Build(): stats, paint, extra parts
	static void PreBuild(ARWMachine* M, const FRWModMachine& D);
	static void PostBuild(ARWMachine* M, const FRWModMachine& D);
	static void SpawnAll(ARWGameMode* GM);

	// world assets: props/buildings placed by mods and replacements for built-in environment models
	static TArray<FRWModProp> Props;
	static TMap<FString, FString> Replacements; // key ("tree_conifer", "rock", "house", "terrain_material"...) -> asset path
	static class UStaticMesh* ReplacementMesh(const FString& Key);
	static class UMaterialInterface* ReplacementMaterial(const FString& Key);
	static void SpawnProps(class ARWWorld* World);

	// attachments shipped by mods: "attachments": [{ "kind": "excavator_bucket", ... }]
	static TArray<TSharedPtr<FJsonObject>> Attachments;
	static void AddBucketAttachments(TArray<struct FBucketSpec>& Out, int32 MachineSize);
	static struct FBucketSpec BucketFromJson(const TSharedPtr<FJsonObject>& O, const struct FBucketSpec& Def);

	// enable / disable (applied on next start)
	static void SetEnabled(int32 Index, bool bOn);
	static TArray<FString> DisabledList();
};
