using UnrealBuildTool;

public class RoadWorksEditorTarget : TargetRules
{
	public RoadWorksEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.Latest;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("RoadWorks");
	}
}
