using UnrealBuildTool;

public class RoadWorksTarget : TargetRules
{
	public RoadWorksTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.Latest;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("RoadWorks");
	}
}
